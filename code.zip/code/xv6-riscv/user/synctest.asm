
user/_synctest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <counter_worker>:
char counter_stacks[NTHREADS][PGSIZE] __attribute__((aligned(PGSIZE)));
char pc_stacks[2][PGSIZE] __attribute__((aligned(PGSIZE)));

void
counter_worker(void *arg)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	e04a                	sd	s2,0(sp)
   a:	1000                	addi	s0,sp,32
   c:	64e1                	lui	s1,0x18
   e:	6a048493          	addi	s1,s1,1696 # 186a0 <base+0xf6a0>
  int i;
  (void)arg;

  for(i = 0; i < ITERATIONS; i++){
    sem_wait(SEM_COUNTER);
    counter++;
  12:	00002917          	auipc	s2,0x2
  16:	ffe90913          	addi	s2,s2,-2 # 2010 <counter>
    sem_wait(SEM_COUNTER);
  1a:	4501                	li	a0,0
  1c:	6fa000ef          	jal	716 <sem_wait>
    counter++;
  20:	00092783          	lw	a5,0(s2)
  24:	2785                	addiw	a5,a5,1
  26:	00f92023          	sw	a5,0(s2)
    sem_signal(SEM_COUNTER);
  2a:	4501                	li	a0,0
  2c:	6f2000ef          	jal	71e <sem_signal>
  for(i = 0; i < ITERATIONS; i++){
  30:	34fd                	addiw	s1,s1,-1
  32:	f4e5                	bnez	s1,1a <counter_worker+0x1a>
  }

  exit(0);
  34:	4501                	li	a0,0
  36:	620000ef          	jal	656 <exit>

000000000000003a <producer>:
}

void
producer(void *arg)
{
  3a:	715d                	addi	sp,sp,-80
  3c:	e486                	sd	ra,72(sp)
  3e:	e0a2                	sd	s0,64(sp)
  40:	fc26                	sd	s1,56(sp)
  42:	f84a                	sd	s2,48(sp)
  44:	f44e                	sd	s3,40(sp)
  46:	f052                	sd	s4,32(sp)
  48:	ec56                	sd	s5,24(sp)
  4a:	e85a                	sd	s6,16(sp)
  4c:	e45e                	sd	s7,8(sp)
  4e:	e062                	sd	s8,0(sp)
  50:	0880                	addi	s0,sp,80
  int i;
  (void)arg;

  for(i = 1; i <= ITEMS; i++){
  52:	4485                	li	s1,1
    sem_wait(SEM_EMPTY);
  54:	8c26                	mv	s8,s1
    sem_wait(SEM_MUTEX);
  56:	4a0d                	li	s4,3

    buffer[in] = i;
  58:	00002997          	auipc	s3,0x2
  5c:	fb498993          	addi	s3,s3,-76 # 200c <in>
  60:	00003b97          	auipc	s7,0x3
  64:	fa0b8b93          	addi	s7,s7,-96 # 3000 <buffer>
    in = (in + 1) % BUFSIZE;
  68:	66666ab7          	lui	s5,0x66666
  6c:	667a8a93          	addi	s5,s5,1639 # 66666667 <base+0x6665d667>
    produced++;
  70:	00002917          	auipc	s2,0x2
  74:	f9490913          	addi	s2,s2,-108 # 2004 <produced>
    printf("Produced: %d\n", i);
  78:	00001b17          	auipc	s6,0x1
  7c:	c18b0b13          	addi	s6,s6,-1000 # c90 <malloc+0xfc>
    sem_wait(SEM_EMPTY);
  80:	8562                	mv	a0,s8
  82:	694000ef          	jal	716 <sem_wait>
    sem_wait(SEM_MUTEX);
  86:	8552                	mv	a0,s4
  88:	68e000ef          	jal	716 <sem_wait>
    buffer[in] = i;
  8c:	0009a783          	lw	a5,0(s3)
  90:	00279713          	slli	a4,a5,0x2
  94:	975e                	add	a4,a4,s7
  96:	c304                	sw	s1,0(a4)
    in = (in + 1) % BUFSIZE;
  98:	2785                	addiw	a5,a5,1
  9a:	03578733          	mul	a4,a5,s5
  9e:	9705                	srai	a4,a4,0x21
  a0:	41f7d69b          	sraiw	a3,a5,0x1f
  a4:	9f15                	subw	a4,a4,a3
  a6:	0027169b          	slliw	a3,a4,0x2
  aa:	9f35                	addw	a4,a4,a3
  ac:	9f99                	subw	a5,a5,a4
  ae:	00f9a023          	sw	a5,0(s3)
    produced++;
  b2:	00092783          	lw	a5,0(s2)
  b6:	2785                	addiw	a5,a5,1
  b8:	00f92023          	sw	a5,0(s2)
    printf("Produced: %d\n", i);
  bc:	85a6                	mv	a1,s1
  be:	855a                	mv	a0,s6
  c0:	21d000ef          	jal	adc <printf>

    sem_signal(SEM_MUTEX);
  c4:	8552                	mv	a0,s4
  c6:	658000ef          	jal	71e <sem_signal>
    sem_signal(SEM_FULL);
  ca:	4509                	li	a0,2
  cc:	652000ef          	jal	71e <sem_signal>
  for(i = 1; i <= ITEMS; i++){
  d0:	2485                	addiw	s1,s1,1
  d2:	47ad                	li	a5,11
  d4:	faf496e3          	bne	s1,a5,80 <producer+0x46>
  }

  exit(0);
  d8:	4501                	li	a0,0
  da:	57c000ef          	jal	656 <exit>

00000000000000de <consumer>:
}

void
consumer(void *arg)
{
  de:	715d                	addi	sp,sp,-80
  e0:	e486                	sd	ra,72(sp)
  e2:	e0a2                	sd	s0,64(sp)
  e4:	fc26                	sd	s1,56(sp)
  e6:	f84a                	sd	s2,48(sp)
  e8:	f44e                	sd	s3,40(sp)
  ea:	f052                	sd	s4,32(sp)
  ec:	ec56                	sd	s5,24(sp)
  ee:	e85a                	sd	s6,16(sp)
  f0:	e45e                	sd	s7,8(sp)
  f2:	e062                	sd	s8,0(sp)
  f4:	0880                	addi	s0,sp,80
  f6:	44a9                	li	s1,10
  int item;
  (void)arg;

  for(int i = 0; i < ITEMS; i++){
    sem_wait(SEM_FULL);
  f8:	4c09                	li	s8,2
    sem_wait(SEM_MUTEX);
  fa:	4a0d                	li	s4,3

    item = buffer[out];
  fc:	00002997          	auipc	s3,0x2
 100:	f0c98993          	addi	s3,s3,-244 # 2008 <out>
 104:	00003b97          	auipc	s7,0x3
 108:	efcb8b93          	addi	s7,s7,-260 # 3000 <buffer>
    out = (out + 1) % BUFSIZE;
 10c:	66666ab7          	lui	s5,0x66666
 110:	667a8a93          	addi	s5,s5,1639 # 66666667 <base+0x6665d667>
    consumed++;
 114:	00002917          	auipc	s2,0x2
 118:	eec90913          	addi	s2,s2,-276 # 2000 <consumed>
    printf("Consumed: %d\n", item);
 11c:	00001b17          	auipc	s6,0x1
 120:	b84b0b13          	addi	s6,s6,-1148 # ca0 <malloc+0x10c>
    sem_wait(SEM_FULL);
 124:	8562                	mv	a0,s8
 126:	5f0000ef          	jal	716 <sem_wait>
    sem_wait(SEM_MUTEX);
 12a:	8552                	mv	a0,s4
 12c:	5ea000ef          	jal	716 <sem_wait>
    item = buffer[out];
 130:	0009a783          	lw	a5,0(s3)
 134:	00279693          	slli	a3,a5,0x2
 138:	96de                	add	a3,a3,s7
    out = (out + 1) % BUFSIZE;
 13a:	2785                	addiw	a5,a5,1
 13c:	03578733          	mul	a4,a5,s5
 140:	9705                	srai	a4,a4,0x21
 142:	41f7d61b          	sraiw	a2,a5,0x1f
 146:	9f11                	subw	a4,a4,a2
 148:	0027161b          	slliw	a2,a4,0x2
 14c:	9f31                	addw	a4,a4,a2
 14e:	9f99                	subw	a5,a5,a4
 150:	00f9a023          	sw	a5,0(s3)
    consumed++;
 154:	00092783          	lw	a5,0(s2)
 158:	2785                	addiw	a5,a5,1
 15a:	00f92023          	sw	a5,0(s2)
    printf("Consumed: %d\n", item);
 15e:	428c                	lw	a1,0(a3)
 160:	855a                	mv	a0,s6
 162:	17b000ef          	jal	adc <printf>

    sem_signal(SEM_MUTEX);
 166:	8552                	mv	a0,s4
 168:	5b6000ef          	jal	71e <sem_signal>
    sem_signal(SEM_EMPTY);
 16c:	4505                	li	a0,1
 16e:	5b0000ef          	jal	71e <sem_signal>
  for(int i = 0; i < ITEMS; i++){
 172:	34fd                	addiw	s1,s1,-1
 174:	f8c5                	bnez	s1,124 <consumer+0x46>
  }

  exit(0);
 176:	4501                	li	a0,0
 178:	4de000ef          	jal	656 <exit>

000000000000017c <main>:
}

int
main(void)
{
 17c:	7179                	addi	sp,sp,-48
 17e:	f406                	sd	ra,40(sp)
 180:	f022                	sd	s0,32(sp)
 182:	ec26                	sd	s1,24(sp)
 184:	e84a                	sd	s2,16(sp)
 186:	e44e                	sd	s3,8(sp)
 188:	e052                	sd	s4,0(sp)
 18a:	1800                	addi	s0,sp,48
  int i;
  int failed = 0;

  printf("\n=== Synchronized Counter Test ===\n");
 18c:	00001517          	auipc	a0,0x1
 190:	b2450513          	addi	a0,a0,-1244 # cb0 <malloc+0x11c>
 194:	149000ef          	jal	adc <printf>

  counter = 0;
 198:	00002797          	auipc	a5,0x2
 19c:	e607ac23          	sw	zero,-392(a5) # 2010 <counter>
  if(sem_init(SEM_COUNTER, 1) < 0){
 1a0:	4585                	li	a1,1
 1a2:	4501                	li	a0,0
 1a4:	56a000ef          	jal	70e <sem_init>
 1a8:	00006497          	auipc	s1,0x6
 1ac:	e5848493          	addi	s1,s1,-424 # 6000 <counter_stacks>
 1b0:	00009a17          	auipc	s4,0x9
 1b4:	e50a0a13          	addi	s4,s4,-432 # 9000 <base>
    printf("FAIL: counter semaphore initialization\n");
    exit(1);
  }

  for(i = 0; i < NTHREADS; i++){
    if(clone(counter_worker, 0, counter_stacks[i]) < 0){
 1b8:	00000917          	auipc	s2,0x0
 1bc:	e4890913          	addi	s2,s2,-440 # 0 <counter_worker>
  for(i = 0; i < NTHREADS; i++){
 1c0:	6985                	lui	s3,0x1
  if(sem_init(SEM_COUNTER, 1) < 0){
 1c2:	0a054b63          	bltz	a0,278 <main+0xfc>
    if(clone(counter_worker, 0, counter_stacks[i]) < 0){
 1c6:	8626                	mv	a2,s1
 1c8:	4581                	li	a1,0
 1ca:	854a                	mv	a0,s2
 1cc:	532000ef          	jal	6fe <clone>
 1d0:	0a054d63          	bltz	a0,28a <main+0x10e>
  for(i = 0; i < NTHREADS; i++){
 1d4:	94ce                	add	s1,s1,s3
 1d6:	ff4498e3          	bne	s1,s4,1c6 <main+0x4a>
 1da:	448d                	li	s1,3
  int failed = 0;
 1dc:	4901                	li	s2,0
       exit(1);
     }
  }

  for(i = 0; i < NTHREADS; i++){
    if(join() < 0){
 1de:	528000ef          	jal	706 <join>
 1e2:	0a054d63          	bltz	a0,29c <main+0x120>
  for(i = 0; i < NTHREADS; i++){
 1e6:	34fd                	addiw	s1,s1,-1
 1e8:	f8fd                	bnez	s1,1de <main+0x62>
      failed = 1;
    }
    
  }

  printf("Final counter: %d (expected 300000)\n", counter);
 1ea:	00002497          	auipc	s1,0x2
 1ee:	e2648493          	addi	s1,s1,-474 # 2010 <counter>
 1f2:	408c                	lw	a1,0(s1)
 1f4:	00001517          	auipc	a0,0x1
 1f8:	b4c50513          	addi	a0,a0,-1204 # d40 <malloc+0x1ac>
 1fc:	0e1000ef          	jal	adc <printf>

  if(counter != 300000)
 200:	4098                	lw	a4,0(s1)
 202:	2701                	sext.w	a4,a4
 204:	000497b7          	lui	a5,0x49
 208:	3e078793          	addi	a5,a5,992 # 493e0 <base+0x403e0>
 20c:	00f71463          	bne	a4,a5,214 <main+0x98>
    failed = 1;

  if(!failed)
 210:	08090e63          	beqz	s2,2ac <main+0x130>
    printf("Counter test: PASS\n");
  else
    printf("Counter test: FAIL\n");
 214:	00001517          	auipc	a0,0x1
 218:	b6c50513          	addi	a0,a0,-1172 # d80 <malloc+0x1ec>
 21c:	0c1000ef          	jal	adc <printf>
 220:	4905                	li	s2,1

  printf("\n=== Producer-Consumer Test ===\n");
 222:	00001517          	auipc	a0,0x1
 226:	b7650513          	addi	a0,a0,-1162 # d98 <malloc+0x204>
 22a:	0b3000ef          	jal	adc <printf>

  in = 0;
 22e:	00002797          	auipc	a5,0x2
 232:	dc07af23          	sw	zero,-546(a5) # 200c <in>
  out = 0;
 236:	00002797          	auipc	a5,0x2
 23a:	dc07a923          	sw	zero,-558(a5) # 2008 <out>
  produced = 0;
 23e:	00002797          	auipc	a5,0x2
 242:	dc07a323          	sw	zero,-570(a5) # 2004 <produced>
  consumed = 0;
 246:	00002797          	auipc	a5,0x2
 24a:	da07ad23          	sw	zero,-582(a5) # 2000 <consumed>

  if(sem_init(SEM_EMPTY, BUFSIZE) < 0 ||
 24e:	4595                	li	a1,5
 250:	4505                	li	a0,1
 252:	4bc000ef          	jal	70e <sem_init>
 256:	00054863          	bltz	a0,266 <main+0xea>
     sem_init(SEM_FULL, 0) < 0 ||
 25a:	4581                	li	a1,0
 25c:	4509                	li	a0,2
 25e:	4b0000ef          	jal	70e <sem_init>
  if(sem_init(SEM_EMPTY, BUFSIZE) < 0 ||
 262:	04055c63          	bgez	a0,2ba <main+0x13e>
     sem_init(SEM_MUTEX, 1) < 0){
    printf("FAIL: producer-consumer semaphore initialization\n");
 266:	00001517          	auipc	a0,0x1
 26a:	b5a50513          	addi	a0,a0,-1190 # dc0 <malloc+0x22c>
 26e:	06f000ef          	jal	adc <printf>
    exit(1);
 272:	4505                	li	a0,1
 274:	3e2000ef          	jal	656 <exit>
    printf("FAIL: counter semaphore initialization\n");
 278:	00001517          	auipc	a0,0x1
 27c:	a6050513          	addi	a0,a0,-1440 # cd8 <malloc+0x144>
 280:	05d000ef          	jal	adc <printf>
    exit(1);
 284:	4505                	li	a0,1
 286:	3d0000ef          	jal	656 <exit>
       printf("FAIL: clone counter thread\n");
 28a:	00001517          	auipc	a0,0x1
 28e:	a7650513          	addi	a0,a0,-1418 # d00 <malloc+0x16c>
 292:	04b000ef          	jal	adc <printf>
       exit(1);
 296:	4505                	li	a0,1
 298:	3be000ef          	jal	656 <exit>
      printf("FAIL: join counter thread\n");
 29c:	00001517          	auipc	a0,0x1
 2a0:	a8450513          	addi	a0,a0,-1404 # d20 <malloc+0x18c>
 2a4:	039000ef          	jal	adc <printf>
      failed = 1;
 2a8:	4905                	li	s2,1
 2aa:	bf35                	j	1e6 <main+0x6a>
    printf("Counter test: PASS\n");
 2ac:	00001517          	auipc	a0,0x1
 2b0:	abc50513          	addi	a0,a0,-1348 # d68 <malloc+0x1d4>
 2b4:	029000ef          	jal	adc <printf>
 2b8:	b7ad                	j	222 <main+0xa6>
     sem_init(SEM_MUTEX, 1) < 0){
 2ba:	4585                	li	a1,1
 2bc:	450d                	li	a0,3
 2be:	450000ef          	jal	70e <sem_init>
     sem_init(SEM_FULL, 0) < 0 ||
 2c2:	fa0542e3          	bltz	a0,266 <main+0xea>
  }

  if(clone(producer, 0, pc_stacks[0]) < 0){
 2c6:	00004617          	auipc	a2,0x4
 2ca:	d3a60613          	addi	a2,a2,-710 # 4000 <pc_stacks>
 2ce:	4581                	li	a1,0
 2d0:	00000517          	auipc	a0,0x0
 2d4:	d6a50513          	addi	a0,a0,-662 # 3a <producer>
 2d8:	426000ef          	jal	6fe <clone>
 2dc:	08054763          	bltz	a0,36a <main+0x1ee>
    printf("FAIL: clone producer\n");
    exit(1);
  }
  if(clone(consumer, 0, pc_stacks[1]) < 0){
 2e0:	00005617          	auipc	a2,0x5
 2e4:	d2060613          	addi	a2,a2,-736 # 5000 <pc_stacks+0x1000>
 2e8:	4581                	li	a1,0
 2ea:	00000517          	auipc	a0,0x0
 2ee:	df450513          	addi	a0,a0,-524 # de <consumer>
 2f2:	40c000ef          	jal	6fe <clone>
 2f6:	08054363          	bltz	a0,37c <main+0x200>
   printf("FAIL: clone consumer\n");
   exit(1);
  }

  if(join() < 0 || join() < 0){
 2fa:	40c000ef          	jal	706 <join>
 2fe:	00054663          	bltz	a0,30a <main+0x18e>
 302:	404000ef          	jal	706 <join>
 306:	00055963          	bgez	a0,318 <main+0x19c>
    printf("FAIL: join producer-consumer threads\n");
 30a:	00001517          	auipc	a0,0x1
 30e:	b1e50513          	addi	a0,a0,-1250 # e28 <malloc+0x294>
 312:	7ca000ef          	jal	adc <printf>
    failed = 1;
 316:	4905                	li	s2,1
  }

  

  printf("Produced total: %d\n", produced);
 318:	00002497          	auipc	s1,0x2
 31c:	cec48493          	addi	s1,s1,-788 # 2004 <produced>
 320:	408c                	lw	a1,0(s1)
 322:	00001517          	auipc	a0,0x1
 326:	b2e50513          	addi	a0,a0,-1234 # e50 <malloc+0x2bc>
 32a:	7b2000ef          	jal	adc <printf>
  printf("Consumed total: %d\n", consumed);
 32e:	00002597          	auipc	a1,0x2
 332:	cd25a583          	lw	a1,-814(a1) # 2000 <consumed>
 336:	00001517          	auipc	a0,0x1
 33a:	b3250513          	addi	a0,a0,-1230 # e68 <malloc+0x2d4>
 33e:	79e000ef          	jal	adc <printf>

  if(produced != ITEMS || consumed != ITEMS)
 342:	4098                	lw	a4,0(s1)
 344:	47a9                	li	a5,10
 346:	00f71863          	bne	a4,a5,356 <main+0x1da>
 34a:	00002717          	auipc	a4,0x2
 34e:	cb672703          	lw	a4,-842(a4) # 2000 <consumed>
 352:	02f70e63          	beq	a4,a5,38e <main+0x212>
    failed = 1;

  if(!failed)
    printf("Producer-Consumer test: PASS\n");
  else
    printf("Q2 synchronization test: FAIL\n");
 356:	00001517          	auipc	a0,0x1
 35a:	b4a50513          	addi	a0,a0,-1206 # ea0 <malloc+0x30c>
 35e:	77e000ef          	jal	adc <printf>
 362:	4905                	li	s2,1

  exit(failed);
 364:	854a                	mv	a0,s2
 366:	2f0000ef          	jal	656 <exit>
    printf("FAIL: clone producer\n");
 36a:	00001517          	auipc	a0,0x1
 36e:	a8e50513          	addi	a0,a0,-1394 # df8 <malloc+0x264>
 372:	76a000ef          	jal	adc <printf>
    exit(1);
 376:	4505                	li	a0,1
 378:	2de000ef          	jal	656 <exit>
   printf("FAIL: clone consumer\n");
 37c:	00001517          	auipc	a0,0x1
 380:	a9450513          	addi	a0,a0,-1388 # e10 <malloc+0x27c>
 384:	758000ef          	jal	adc <printf>
   exit(1);
 388:	4505                	li	a0,1
 38a:	2cc000ef          	jal	656 <exit>
  if(!failed)
 38e:	fc0914e3          	bnez	s2,356 <main+0x1da>
    printf("Producer-Consumer test: PASS\n");
 392:	00001517          	auipc	a0,0x1
 396:	aee50513          	addi	a0,a0,-1298 # e80 <malloc+0x2ec>
 39a:	742000ef          	jal	adc <printf>
 39e:	b7d9                	j	364 <main+0x1e8>

00000000000003a0 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 3a0:	1141                	addi	sp,sp,-16
 3a2:	e406                	sd	ra,8(sp)
 3a4:	e022                	sd	s0,0(sp)
 3a6:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 3a8:	dd5ff0ef          	jal	17c <main>
  exit(r);
 3ac:	2aa000ef          	jal	656 <exit>

00000000000003b0 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
 3b0:	1141                	addi	sp,sp,-16
 3b2:	e406                	sd	ra,8(sp)
 3b4:	e022                	sd	s0,0(sp)
 3b6:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 3b8:	87aa                	mv	a5,a0
 3ba:	0585                	addi	a1,a1,1
 3bc:	0785                	addi	a5,a5,1
 3be:	fff5c703          	lbu	a4,-1(a1)
 3c2:	fee78fa3          	sb	a4,-1(a5)
 3c6:	fb75                	bnez	a4,3ba <strcpy+0xa>
    ;
  return os;
}
 3c8:	60a2                	ld	ra,8(sp)
 3ca:	6402                	ld	s0,0(sp)
 3cc:	0141                	addi	sp,sp,16
 3ce:	8082                	ret

00000000000003d0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 3d0:	1141                	addi	sp,sp,-16
 3d2:	e406                	sd	ra,8(sp)
 3d4:	e022                	sd	s0,0(sp)
 3d6:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 3d8:	00054783          	lbu	a5,0(a0)
 3dc:	cb91                	beqz	a5,3f0 <strcmp+0x20>
 3de:	0005c703          	lbu	a4,0(a1)
 3e2:	00f71763          	bne	a4,a5,3f0 <strcmp+0x20>
    p++, q++;
 3e6:	0505                	addi	a0,a0,1
 3e8:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 3ea:	00054783          	lbu	a5,0(a0)
 3ee:	fbe5                	bnez	a5,3de <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 3f0:	0005c503          	lbu	a0,0(a1)
}
 3f4:	40a7853b          	subw	a0,a5,a0
 3f8:	60a2                	ld	ra,8(sp)
 3fa:	6402                	ld	s0,0(sp)
 3fc:	0141                	addi	sp,sp,16
 3fe:	8082                	ret

0000000000000400 <strlen>:

uint
strlen(const char *s)
{
 400:	1141                	addi	sp,sp,-16
 402:	e406                	sd	ra,8(sp)
 404:	e022                	sd	s0,0(sp)
 406:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 408:	00054783          	lbu	a5,0(a0)
 40c:	cf91                	beqz	a5,428 <strlen+0x28>
 40e:	00150793          	addi	a5,a0,1
 412:	86be                	mv	a3,a5
 414:	0785                	addi	a5,a5,1
 416:	fff7c703          	lbu	a4,-1(a5)
 41a:	ff65                	bnez	a4,412 <strlen+0x12>
 41c:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 420:	60a2                	ld	ra,8(sp)
 422:	6402                	ld	s0,0(sp)
 424:	0141                	addi	sp,sp,16
 426:	8082                	ret
  for (n = 0; s[n]; n++)
 428:	4501                	li	a0,0
 42a:	bfdd                	j	420 <strlen+0x20>

000000000000042c <memset>:

void *
memset(void *dst, int c, uint n)
{
 42c:	1141                	addi	sp,sp,-16
 42e:	e406                	sd	ra,8(sp)
 430:	e022                	sd	s0,0(sp)
 432:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 434:	ca19                	beqz	a2,44a <memset+0x1e>
 436:	87aa                	mv	a5,a0
 438:	1602                	slli	a2,a2,0x20
 43a:	9201                	srli	a2,a2,0x20
 43c:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 440:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 444:	0785                	addi	a5,a5,1
 446:	fee79de3          	bne	a5,a4,440 <memset+0x14>
  }
  return dst;
}
 44a:	60a2                	ld	ra,8(sp)
 44c:	6402                	ld	s0,0(sp)
 44e:	0141                	addi	sp,sp,16
 450:	8082                	ret

0000000000000452 <strchr>:

char *
strchr(const char *s, char c)
{
 452:	1141                	addi	sp,sp,-16
 454:	e406                	sd	ra,8(sp)
 456:	e022                	sd	s0,0(sp)
 458:	0800                	addi	s0,sp,16
  for (; *s; s++)
 45a:	00054783          	lbu	a5,0(a0)
 45e:	cf81                	beqz	a5,476 <strchr+0x24>
    if (*s == c)
 460:	00f58763          	beq	a1,a5,46e <strchr+0x1c>
  for (; *s; s++)
 464:	0505                	addi	a0,a0,1
 466:	00054783          	lbu	a5,0(a0)
 46a:	fbfd                	bnez	a5,460 <strchr+0xe>
      return (char *)s;
  return 0;
 46c:	4501                	li	a0,0
}
 46e:	60a2                	ld	ra,8(sp)
 470:	6402                	ld	s0,0(sp)
 472:	0141                	addi	sp,sp,16
 474:	8082                	ret
  return 0;
 476:	4501                	li	a0,0
 478:	bfdd                	j	46e <strchr+0x1c>

000000000000047a <gets>:

char *
gets(char *buf, int max)
{
 47a:	711d                	addi	sp,sp,-96
 47c:	ec86                	sd	ra,88(sp)
 47e:	e8a2                	sd	s0,80(sp)
 480:	e4a6                	sd	s1,72(sp)
 482:	e0ca                	sd	s2,64(sp)
 484:	fc4e                	sd	s3,56(sp)
 486:	f852                	sd	s4,48(sp)
 488:	f456                	sd	s5,40(sp)
 48a:	f05a                	sd	s6,32(sp)
 48c:	ec5e                	sd	s7,24(sp)
 48e:	e862                	sd	s8,16(sp)
 490:	1080                	addi	s0,sp,96
 492:	8baa                	mv	s7,a0
 494:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 496:	892a                	mv	s2,a0
 498:	4481                	li	s1,0
    cc = read(0, &c, 1);
 49a:	faf40b13          	addi	s6,s0,-81
 49e:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
 4a0:	8c26                	mv	s8,s1
 4a2:	0014899b          	addiw	s3,s1,1
 4a6:	84ce                	mv	s1,s3
 4a8:	0349d463          	bge	s3,s4,4d0 <gets+0x56>
    cc = read(0, &c, 1);
 4ac:	8656                	mv	a2,s5
 4ae:	85da                	mv	a1,s6
 4b0:	4501                	li	a0,0
 4b2:	1bc000ef          	jal	66e <read>
    if (cc < 1)
 4b6:	00a05d63          	blez	a0,4d0 <gets+0x56>
      break;
    buf[i++] = c;
 4ba:	faf44783          	lbu	a5,-81(s0)
 4be:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 4c2:	0905                	addi	s2,s2,1
 4c4:	ff678713          	addi	a4,a5,-10
 4c8:	c319                	beqz	a4,4ce <gets+0x54>
 4ca:	17cd                	addi	a5,a5,-13
 4cc:	fbf1                	bnez	a5,4a0 <gets+0x26>
    buf[i++] = c;
 4ce:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 4d0:	9c5e                	add	s8,s8,s7
 4d2:	000c0023          	sb	zero,0(s8)
  return buf;
}
 4d6:	855e                	mv	a0,s7
 4d8:	60e6                	ld	ra,88(sp)
 4da:	6446                	ld	s0,80(sp)
 4dc:	64a6                	ld	s1,72(sp)
 4de:	6906                	ld	s2,64(sp)
 4e0:	79e2                	ld	s3,56(sp)
 4e2:	7a42                	ld	s4,48(sp)
 4e4:	7aa2                	ld	s5,40(sp)
 4e6:	7b02                	ld	s6,32(sp)
 4e8:	6be2                	ld	s7,24(sp)
 4ea:	6c42                	ld	s8,16(sp)
 4ec:	6125                	addi	sp,sp,96
 4ee:	8082                	ret

00000000000004f0 <stat>:

int
stat(const char *n, struct stat *st)
{
 4f0:	1101                	addi	sp,sp,-32
 4f2:	ec06                	sd	ra,24(sp)
 4f4:	e822                	sd	s0,16(sp)
 4f6:	e04a                	sd	s2,0(sp)
 4f8:	1000                	addi	s0,sp,32
 4fa:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 4fc:	4581                	li	a1,0
 4fe:	198000ef          	jal	696 <open>
  if (fd < 0)
 502:	02054263          	bltz	a0,526 <stat+0x36>
 506:	e426                	sd	s1,8(sp)
 508:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 50a:	85ca                	mv	a1,s2
 50c:	1a2000ef          	jal	6ae <fstat>
 510:	892a                	mv	s2,a0
  close(fd);
 512:	8526                	mv	a0,s1
 514:	16a000ef          	jal	67e <close>
  return r;
 518:	64a2                	ld	s1,8(sp)
}
 51a:	854a                	mv	a0,s2
 51c:	60e2                	ld	ra,24(sp)
 51e:	6442                	ld	s0,16(sp)
 520:	6902                	ld	s2,0(sp)
 522:	6105                	addi	sp,sp,32
 524:	8082                	ret
    return -1;
 526:	57fd                	li	a5,-1
 528:	893e                	mv	s2,a5
 52a:	bfc5                	j	51a <stat+0x2a>

000000000000052c <atoi>:

int
atoi(const char *s)
{
 52c:	1141                	addi	sp,sp,-16
 52e:	e406                	sd	ra,8(sp)
 530:	e022                	sd	s0,0(sp)
 532:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 534:	00054683          	lbu	a3,0(a0)
 538:	fd06879b          	addiw	a5,a3,-48
 53c:	0ff7f793          	zext.b	a5,a5
 540:	4625                	li	a2,9
 542:	02f66963          	bltu	a2,a5,574 <atoi+0x48>
 546:	872a                	mv	a4,a0
  n = 0;
 548:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 54a:	0705                	addi	a4,a4,1
 54c:	0025179b          	slliw	a5,a0,0x2
 550:	9fa9                	addw	a5,a5,a0
 552:	0017979b          	slliw	a5,a5,0x1
 556:	9fb5                	addw	a5,a5,a3
 558:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 55c:	00074683          	lbu	a3,0(a4)
 560:	fd06879b          	addiw	a5,a3,-48
 564:	0ff7f793          	zext.b	a5,a5
 568:	fef671e3          	bgeu	a2,a5,54a <atoi+0x1e>
  return n;
}
 56c:	60a2                	ld	ra,8(sp)
 56e:	6402                	ld	s0,0(sp)
 570:	0141                	addi	sp,sp,16
 572:	8082                	ret
  n = 0;
 574:	4501                	li	a0,0
 576:	bfdd                	j	56c <atoi+0x40>

0000000000000578 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 578:	1141                	addi	sp,sp,-16
 57a:	e406                	sd	ra,8(sp)
 57c:	e022                	sd	s0,0(sp)
 57e:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 580:	02b57563          	bgeu	a0,a1,5aa <memmove+0x32>
    while (n-- > 0)
 584:	00c05f63          	blez	a2,5a2 <memmove+0x2a>
 588:	1602                	slli	a2,a2,0x20
 58a:	9201                	srli	a2,a2,0x20
 58c:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 590:	872a                	mv	a4,a0
      *dst++ = *src++;
 592:	0585                	addi	a1,a1,1
 594:	0705                	addi	a4,a4,1
 596:	fff5c683          	lbu	a3,-1(a1)
 59a:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 59e:	fee79ae3          	bne	a5,a4,592 <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 5a2:	60a2                	ld	ra,8(sp)
 5a4:	6402                	ld	s0,0(sp)
 5a6:	0141                	addi	sp,sp,16
 5a8:	8082                	ret
    while (n-- > 0)
 5aa:	fec05ce3          	blez	a2,5a2 <memmove+0x2a>
    dst += n;
 5ae:	00c50733          	add	a4,a0,a2
    src += n;
 5b2:	95b2                	add	a1,a1,a2
 5b4:	fff6079b          	addiw	a5,a2,-1
 5b8:	1782                	slli	a5,a5,0x20
 5ba:	9381                	srli	a5,a5,0x20
 5bc:	fff7c793          	not	a5,a5
 5c0:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 5c2:	15fd                	addi	a1,a1,-1
 5c4:	177d                	addi	a4,a4,-1
 5c6:	0005c683          	lbu	a3,0(a1)
 5ca:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 5ce:	fef71ae3          	bne	a4,a5,5c2 <memmove+0x4a>
 5d2:	bfc1                	j	5a2 <memmove+0x2a>

00000000000005d4 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 5d4:	1141                	addi	sp,sp,-16
 5d6:	e406                	sd	ra,8(sp)
 5d8:	e022                	sd	s0,0(sp)
 5da:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 5dc:	c61d                	beqz	a2,60a <memcmp+0x36>
 5de:	1602                	slli	a2,a2,0x20
 5e0:	9201                	srli	a2,a2,0x20
 5e2:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 5e6:	00054783          	lbu	a5,0(a0)
 5ea:	0005c703          	lbu	a4,0(a1)
 5ee:	00e79863          	bne	a5,a4,5fe <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 5f2:	0505                	addi	a0,a0,1
    p2++;
 5f4:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 5f6:	fed518e3          	bne	a0,a3,5e6 <memcmp+0x12>
  }
  return 0;
 5fa:	4501                	li	a0,0
 5fc:	a019                	j	602 <memcmp+0x2e>
      return *p1 - *p2;
 5fe:	40e7853b          	subw	a0,a5,a4
}
 602:	60a2                	ld	ra,8(sp)
 604:	6402                	ld	s0,0(sp)
 606:	0141                	addi	sp,sp,16
 608:	8082                	ret
  return 0;
 60a:	4501                	li	a0,0
 60c:	bfdd                	j	602 <memcmp+0x2e>

000000000000060e <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 60e:	1141                	addi	sp,sp,-16
 610:	e406                	sd	ra,8(sp)
 612:	e022                	sd	s0,0(sp)
 614:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 616:	f63ff0ef          	jal	578 <memmove>
}
 61a:	60a2                	ld	ra,8(sp)
 61c:	6402                	ld	s0,0(sp)
 61e:	0141                	addi	sp,sp,16
 620:	8082                	ret

0000000000000622 <sbrk>:

char *
sbrk(int n)
{
 622:	1141                	addi	sp,sp,-16
 624:	e406                	sd	ra,8(sp)
 626:	e022                	sd	s0,0(sp)
 628:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 62a:	4585                	li	a1,1
 62c:	0b2000ef          	jal	6de <sys_sbrk>
}
 630:	60a2                	ld	ra,8(sp)
 632:	6402                	ld	s0,0(sp)
 634:	0141                	addi	sp,sp,16
 636:	8082                	ret

0000000000000638 <sbrklazy>:

char *
sbrklazy(int n)
{
 638:	1141                	addi	sp,sp,-16
 63a:	e406                	sd	ra,8(sp)
 63c:	e022                	sd	s0,0(sp)
 63e:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 640:	4589                	li	a1,2
 642:	09c000ef          	jal	6de <sys_sbrk>
}
 646:	60a2                	ld	ra,8(sp)
 648:	6402                	ld	s0,0(sp)
 64a:	0141                	addi	sp,sp,16
 64c:	8082                	ret

000000000000064e <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 64e:	4885                	li	a7,1
 ecall
 650:	00000073          	ecall
 ret
 654:	8082                	ret

0000000000000656 <exit>:
.global exit
exit:
 li a7, SYS_exit
 656:	4889                	li	a7,2
 ecall
 658:	00000073          	ecall
 ret
 65c:	8082                	ret

000000000000065e <wait>:
.global wait
wait:
 li a7, SYS_wait
 65e:	488d                	li	a7,3
 ecall
 660:	00000073          	ecall
 ret
 664:	8082                	ret

0000000000000666 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 666:	4891                	li	a7,4
 ecall
 668:	00000073          	ecall
 ret
 66c:	8082                	ret

000000000000066e <read>:
.global read
read:
 li a7, SYS_read
 66e:	4895                	li	a7,5
 ecall
 670:	00000073          	ecall
 ret
 674:	8082                	ret

0000000000000676 <write>:
.global write
write:
 li a7, SYS_write
 676:	48c1                	li	a7,16
 ecall
 678:	00000073          	ecall
 ret
 67c:	8082                	ret

000000000000067e <close>:
.global close
close:
 li a7, SYS_close
 67e:	48d5                	li	a7,21
 ecall
 680:	00000073          	ecall
 ret
 684:	8082                	ret

0000000000000686 <kill>:
.global kill
kill:
 li a7, SYS_kill
 686:	4899                	li	a7,6
 ecall
 688:	00000073          	ecall
 ret
 68c:	8082                	ret

000000000000068e <exec>:
.global exec
exec:
 li a7, SYS_exec
 68e:	489d                	li	a7,7
 ecall
 690:	00000073          	ecall
 ret
 694:	8082                	ret

0000000000000696 <open>:
.global open
open:
 li a7, SYS_open
 696:	48bd                	li	a7,15
 ecall
 698:	00000073          	ecall
 ret
 69c:	8082                	ret

000000000000069e <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 69e:	48c5                	li	a7,17
 ecall
 6a0:	00000073          	ecall
 ret
 6a4:	8082                	ret

00000000000006a6 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 6a6:	48c9                	li	a7,18
 ecall
 6a8:	00000073          	ecall
 ret
 6ac:	8082                	ret

00000000000006ae <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 6ae:	48a1                	li	a7,8
 ecall
 6b0:	00000073          	ecall
 ret
 6b4:	8082                	ret

00000000000006b6 <link>:
.global link
link:
 li a7, SYS_link
 6b6:	48cd                	li	a7,19
 ecall
 6b8:	00000073          	ecall
 ret
 6bc:	8082                	ret

00000000000006be <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 6be:	48d1                	li	a7,20
 ecall
 6c0:	00000073          	ecall
 ret
 6c4:	8082                	ret

00000000000006c6 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 6c6:	48a5                	li	a7,9
 ecall
 6c8:	00000073          	ecall
 ret
 6cc:	8082                	ret

00000000000006ce <dup>:
.global dup
dup:
 li a7, SYS_dup
 6ce:	48a9                	li	a7,10
 ecall
 6d0:	00000073          	ecall
 ret
 6d4:	8082                	ret

00000000000006d6 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 6d6:	48ad                	li	a7,11
 ecall
 6d8:	00000073          	ecall
 ret
 6dc:	8082                	ret

00000000000006de <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 6de:	48b1                	li	a7,12
 ecall
 6e0:	00000073          	ecall
 ret
 6e4:	8082                	ret

00000000000006e6 <pause>:
.global pause
pause:
 li a7, SYS_pause
 6e6:	48b5                	li	a7,13
 ecall
 6e8:	00000073          	ecall
 ret
 6ec:	8082                	ret

00000000000006ee <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 6ee:	48b9                	li	a7,14
 ecall
 6f0:	00000073          	ecall
 ret
 6f4:	8082                	ret

00000000000006f6 <sync>:
.global sync
sync:
 li a7, SYS_sync
 6f6:	48d9                	li	a7,22
 ecall
 6f8:	00000073          	ecall
 ret
 6fc:	8082                	ret

00000000000006fe <clone>:
.global clone
clone:
 li a7, SYS_clone
 6fe:	48dd                	li	a7,23
 ecall
 700:	00000073          	ecall
 ret
 704:	8082                	ret

0000000000000706 <join>:
.global join
join:
 li a7, SYS_join
 706:	48e1                	li	a7,24
 ecall
 708:	00000073          	ecall
 ret
 70c:	8082                	ret

000000000000070e <sem_init>:
.global sem_init
sem_init:
 li a7, SYS_sem_init
 70e:	48e5                	li	a7,25
 ecall
 710:	00000073          	ecall
 ret
 714:	8082                	ret

0000000000000716 <sem_wait>:
.global sem_wait
sem_wait:
 li a7, SYS_sem_wait
 716:	48e9                	li	a7,26
 ecall
 718:	00000073          	ecall
 ret
 71c:	8082                	ret

000000000000071e <sem_signal>:
.global sem_signal
sem_signal:
 li a7, SYS_sem_signal
 71e:	48ed                	li	a7,27
 ecall
 720:	00000073          	ecall
 ret
 724:	8082                	ret

0000000000000726 <set_priority>:
.global set_priority
set_priority:
 li a7, SYS_set_priority
 726:	48f1                	li	a7,28
 ecall
 728:	00000073          	ecall
 ret
 72c:	8082                	ret

000000000000072e <get_priority>:
.global get_priority
get_priority:
 li a7, SYS_get_priority
 72e:	48f5                	li	a7,29
 ecall
 730:	00000073          	ecall
 ret
 734:	8082                	ret

0000000000000736 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 736:	1101                	addi	sp,sp,-32
 738:	ec06                	sd	ra,24(sp)
 73a:	e822                	sd	s0,16(sp)
 73c:	1000                	addi	s0,sp,32
 73e:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 742:	4605                	li	a2,1
 744:	fef40593          	addi	a1,s0,-17
 748:	f2fff0ef          	jal	676 <write>
}
 74c:	60e2                	ld	ra,24(sp)
 74e:	6442                	ld	s0,16(sp)
 750:	6105                	addi	sp,sp,32
 752:	8082                	ret

0000000000000754 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 754:	715d                	addi	sp,sp,-80
 756:	e486                	sd	ra,72(sp)
 758:	e0a2                	sd	s0,64(sp)
 75a:	f84a                	sd	s2,48(sp)
 75c:	f44e                	sd	s3,40(sp)
 75e:	0880                	addi	s0,sp,80
 760:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 762:	c6d1                	beqz	a3,7ee <printint+0x9a>
 764:	0805d563          	bgez	a1,7ee <printint+0x9a>
    neg = 1;
    x = -xx;
 768:	40b005b3          	neg	a1,a1
    neg = 1;
 76c:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 76e:	fb840993          	addi	s3,s0,-72
  neg = 0;
 772:	86ce                	mv	a3,s3
  i = 0;
 774:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
 776:	00000817          	auipc	a6,0x0
 77a:	75280813          	addi	a6,a6,1874 # ec8 <digits>
 77e:	88ba                	mv	a7,a4
 780:	0017051b          	addiw	a0,a4,1
 784:	872a                	mv	a4,a0
 786:	02c5f7b3          	remu	a5,a1,a2
 78a:	97c2                	add	a5,a5,a6
 78c:	0007c783          	lbu	a5,0(a5)
 790:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
 794:	87ae                	mv	a5,a1
 796:	02c5d5b3          	divu	a1,a1,a2
 79a:	0685                	addi	a3,a3,1
 79c:	fec7f1e3          	bgeu	a5,a2,77e <printint+0x2a>
  if (neg)
 7a0:	00030c63          	beqz	t1,7b8 <printint+0x64>
    buf[i++] = '-';
 7a4:	fd050793          	addi	a5,a0,-48
 7a8:	00878533          	add	a0,a5,s0
 7ac:	02d00793          	li	a5,45
 7b0:	fef50423          	sb	a5,-24(a0)
 7b4:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
 7b8:	02e05563          	blez	a4,7e2 <printint+0x8e>
 7bc:	fc26                	sd	s1,56(sp)
 7be:	377d                	addiw	a4,a4,-1
 7c0:	00e984b3          	add	s1,s3,a4
 7c4:	19fd                	addi	s3,s3,-1 # fff <digits+0x137>
 7c6:	99ba                	add	s3,s3,a4
 7c8:	1702                	slli	a4,a4,0x20
 7ca:	9301                	srli	a4,a4,0x20
 7cc:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 7d0:	0004c583          	lbu	a1,0(s1)
 7d4:	854a                	mv	a0,s2
 7d6:	f61ff0ef          	jal	736 <putc>
  while (--i >= 0)
 7da:	14fd                	addi	s1,s1,-1
 7dc:	ff349ae3          	bne	s1,s3,7d0 <printint+0x7c>
 7e0:	74e2                	ld	s1,56(sp)
}
 7e2:	60a6                	ld	ra,72(sp)
 7e4:	6406                	ld	s0,64(sp)
 7e6:	7942                	ld	s2,48(sp)
 7e8:	79a2                	ld	s3,40(sp)
 7ea:	6161                	addi	sp,sp,80
 7ec:	8082                	ret
  neg = 0;
 7ee:	4301                	li	t1,0
 7f0:	bfbd                	j	76e <printint+0x1a>

00000000000007f2 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 7f2:	711d                	addi	sp,sp,-96
 7f4:	ec86                	sd	ra,88(sp)
 7f6:	e8a2                	sd	s0,80(sp)
 7f8:	e4a6                	sd	s1,72(sp)
 7fa:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 7fc:	0005c483          	lbu	s1,0(a1)
 800:	22048363          	beqz	s1,a26 <vprintf+0x234>
 804:	e0ca                	sd	s2,64(sp)
 806:	fc4e                	sd	s3,56(sp)
 808:	f852                	sd	s4,48(sp)
 80a:	f456                	sd	s5,40(sp)
 80c:	f05a                	sd	s6,32(sp)
 80e:	ec5e                	sd	s7,24(sp)
 810:	e862                	sd	s8,16(sp)
 812:	8b2a                	mv	s6,a0
 814:	8a2e                	mv	s4,a1
 816:	8bb2                	mv	s7,a2
  state = 0;
 818:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 81a:	4901                	li	s2,0
 81c:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 81e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 822:	06400c13          	li	s8,100
 826:	a00d                	j	848 <vprintf+0x56>
        putc(fd, c0);
 828:	85a6                	mv	a1,s1
 82a:	855a                	mv	a0,s6
 82c:	f0bff0ef          	jal	736 <putc>
 830:	a019                	j	836 <vprintf+0x44>
    } else if (state == '%') {
 832:	03598363          	beq	s3,s5,858 <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
 836:	0019079b          	addiw	a5,s2,1
 83a:	893e                	mv	s2,a5
 83c:	873e                	mv	a4,a5
 83e:	97d2                	add	a5,a5,s4
 840:	0007c483          	lbu	s1,0(a5)
 844:	1c048a63          	beqz	s1,a18 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 848:	0004879b          	sext.w	a5,s1
    if (state == 0) {
 84c:	fe0993e3          	bnez	s3,832 <vprintf+0x40>
      if (c0 == '%') {
 850:	fd579ce3          	bne	a5,s5,828 <vprintf+0x36>
        state = '%';
 854:	89be                	mv	s3,a5
 856:	b7c5                	j	836 <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
 858:	00ea06b3          	add	a3,s4,a4
 85c:	0016c603          	lbu	a2,1(a3)
      if (c1)
 860:	1c060863          	beqz	a2,a30 <vprintf+0x23e>
      if (c0 == 'd') {
 864:	03878763          	beq	a5,s8,892 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 868:	f9478693          	addi	a3,a5,-108
 86c:	0016b693          	seqz	a3,a3
 870:	f9c60593          	addi	a1,a2,-100
 874:	e99d                	bnez	a1,8aa <vprintf+0xb8>
 876:	ca95                	beqz	a3,8aa <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 878:	008b8493          	addi	s1,s7,8
 87c:	4685                	li	a3,1
 87e:	4629                	li	a2,10
 880:	000bb583          	ld	a1,0(s7)
 884:	855a                	mv	a0,s6
 886:	ecfff0ef          	jal	754 <printint>
        i += 1;
 88a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 88c:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 88e:	4981                	li	s3,0
 890:	b75d                	j	836 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 892:	008b8493          	addi	s1,s7,8
 896:	4685                	li	a3,1
 898:	4629                	li	a2,10
 89a:	000ba583          	lw	a1,0(s7)
 89e:	855a                	mv	a0,s6
 8a0:	eb5ff0ef          	jal	754 <printint>
 8a4:	8ba6                	mv	s7,s1
      state = 0;
 8a6:	4981                	li	s3,0
 8a8:	b779                	j	836 <vprintf+0x44>
        c2 = fmt[i + 2] & 0xff;
 8aa:	9752                	add	a4,a4,s4
 8ac:	00274583          	lbu	a1,2(a4)
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 8b0:	f9460713          	addi	a4,a2,-108
 8b4:	00173713          	seqz	a4,a4
 8b8:	8f75                	and	a4,a4,a3
 8ba:	f9c58513          	addi	a0,a1,-100
 8be:	18051363          	bnez	a0,a44 <vprintf+0x252>
 8c2:	18070163          	beqz	a4,a44 <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 8c6:	008b8493          	addi	s1,s7,8
 8ca:	4685                	li	a3,1
 8cc:	4629                	li	a2,10
 8ce:	000bb583          	ld	a1,0(s7)
 8d2:	855a                	mv	a0,s6
 8d4:	e81ff0ef          	jal	754 <printint>
        i += 2;
 8d8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 8da:	8ba6                	mv	s7,s1
      state = 0;
 8dc:	4981                	li	s3,0
        i += 2;
 8de:	bfa1                	j	836 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 8e0:	008b8493          	addi	s1,s7,8
 8e4:	4681                	li	a3,0
 8e6:	4629                	li	a2,10
 8e8:	000be583          	lwu	a1,0(s7)
 8ec:	855a                	mv	a0,s6
 8ee:	e67ff0ef          	jal	754 <printint>
 8f2:	8ba6                	mv	s7,s1
      state = 0;
 8f4:	4981                	li	s3,0
 8f6:	b781                	j	836 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 8f8:	008b8493          	addi	s1,s7,8
 8fc:	4681                	li	a3,0
 8fe:	4629                	li	a2,10
 900:	000bb583          	ld	a1,0(s7)
 904:	855a                	mv	a0,s6
 906:	e4fff0ef          	jal	754 <printint>
        i += 1;
 90a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 90c:	8ba6                	mv	s7,s1
      state = 0;
 90e:	4981                	li	s3,0
 910:	b71d                	j	836 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 912:	008b8493          	addi	s1,s7,8
 916:	4681                	li	a3,0
 918:	4629                	li	a2,10
 91a:	000bb583          	ld	a1,0(s7)
 91e:	855a                	mv	a0,s6
 920:	e35ff0ef          	jal	754 <printint>
        i += 2;
 924:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 926:	8ba6                	mv	s7,s1
      state = 0;
 928:	4981                	li	s3,0
        i += 2;
 92a:	b731                	j	836 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 92c:	008b8493          	addi	s1,s7,8
 930:	4681                	li	a3,0
 932:	4641                	li	a2,16
 934:	000be583          	lwu	a1,0(s7)
 938:	855a                	mv	a0,s6
 93a:	e1bff0ef          	jal	754 <printint>
 93e:	8ba6                	mv	s7,s1
      state = 0;
 940:	4981                	li	s3,0
 942:	bdd5                	j	836 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 944:	008b8493          	addi	s1,s7,8
 948:	4681                	li	a3,0
 94a:	4641                	li	a2,16
 94c:	000bb583          	ld	a1,0(s7)
 950:	855a                	mv	a0,s6
 952:	e03ff0ef          	jal	754 <printint>
        i += 1;
 956:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 958:	8ba6                	mv	s7,s1
      state = 0;
 95a:	4981                	li	s3,0
 95c:	bde9                	j	836 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 95e:	008b8493          	addi	s1,s7,8
 962:	4681                	li	a3,0
 964:	4641                	li	a2,16
 966:	000bb583          	ld	a1,0(s7)
 96a:	855a                	mv	a0,s6
 96c:	de9ff0ef          	jal	754 <printint>
        i += 2;
 970:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 972:	8ba6                	mv	s7,s1
      state = 0;
 974:	4981                	li	s3,0
        i += 2;
 976:	b5c1                	j	836 <vprintf+0x44>
 978:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 97a:	008b8793          	addi	a5,s7,8
 97e:	8cbe                	mv	s9,a5
 980:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 984:	03000593          	li	a1,48
 988:	855a                	mv	a0,s6
 98a:	dadff0ef          	jal	736 <putc>
  putc(fd, 'x');
 98e:	07800593          	li	a1,120
 992:	855a                	mv	a0,s6
 994:	da3ff0ef          	jal	736 <putc>
 998:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 99a:	00000b97          	auipc	s7,0x0
 99e:	52eb8b93          	addi	s7,s7,1326 # ec8 <digits>
 9a2:	03c9d793          	srli	a5,s3,0x3c
 9a6:	97de                	add	a5,a5,s7
 9a8:	0007c583          	lbu	a1,0(a5)
 9ac:	855a                	mv	a0,s6
 9ae:	d89ff0ef          	jal	736 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 9b2:	0992                	slli	s3,s3,0x4
 9b4:	34fd                	addiw	s1,s1,-1
 9b6:	f4f5                	bnez	s1,9a2 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 9b8:	8be6                	mv	s7,s9
      state = 0;
 9ba:	4981                	li	s3,0
 9bc:	6ca2                	ld	s9,8(sp)
 9be:	bda5                	j	836 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 9c0:	008b8493          	addi	s1,s7,8
 9c4:	000bc583          	lbu	a1,0(s7)
 9c8:	855a                	mv	a0,s6
 9ca:	d6dff0ef          	jal	736 <putc>
 9ce:	8ba6                	mv	s7,s1
      state = 0;
 9d0:	4981                	li	s3,0
 9d2:	b595                	j	836 <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 9d4:	008b8993          	addi	s3,s7,8
 9d8:	000bb483          	ld	s1,0(s7)
 9dc:	cc91                	beqz	s1,9f8 <vprintf+0x206>
        for (; *s; s++)
 9de:	0004c583          	lbu	a1,0(s1)
 9e2:	c985                	beqz	a1,a12 <vprintf+0x220>
          putc(fd, *s);
 9e4:	855a                	mv	a0,s6
 9e6:	d51ff0ef          	jal	736 <putc>
        for (; *s; s++)
 9ea:	0485                	addi	s1,s1,1
 9ec:	0004c583          	lbu	a1,0(s1)
 9f0:	f9f5                	bnez	a1,9e4 <vprintf+0x1f2>
        if ((s = va_arg(ap, char *)) == 0)
 9f2:	8bce                	mv	s7,s3
      state = 0;
 9f4:	4981                	li	s3,0
 9f6:	b581                	j	836 <vprintf+0x44>
          s = "(null)";
 9f8:	00000497          	auipc	s1,0x0
 9fc:	4c848493          	addi	s1,s1,1224 # ec0 <malloc+0x32c>
        for (; *s; s++)
 a00:	02800593          	li	a1,40
 a04:	b7c5                	j	9e4 <vprintf+0x1f2>
        putc(fd, '%');
 a06:	85be                	mv	a1,a5
 a08:	855a                	mv	a0,s6
 a0a:	d2dff0ef          	jal	736 <putc>
      state = 0;
 a0e:	4981                	li	s3,0
 a10:	b51d                	j	836 <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 a12:	8bce                	mv	s7,s3
      state = 0;
 a14:	4981                	li	s3,0
 a16:	b505                	j	836 <vprintf+0x44>
 a18:	6906                	ld	s2,64(sp)
 a1a:	79e2                	ld	s3,56(sp)
 a1c:	7a42                	ld	s4,48(sp)
 a1e:	7aa2                	ld	s5,40(sp)
 a20:	7b02                	ld	s6,32(sp)
 a22:	6be2                	ld	s7,24(sp)
 a24:	6c42                	ld	s8,16(sp)
    }
  }
}
 a26:	60e6                	ld	ra,88(sp)
 a28:	6446                	ld	s0,80(sp)
 a2a:	64a6                	ld	s1,72(sp)
 a2c:	6125                	addi	sp,sp,96
 a2e:	8082                	ret
      if (c0 == 'd') {
 a30:	06400713          	li	a4,100
 a34:	e4e78fe3          	beq	a5,a4,892 <vprintf+0xa0>
      } else if (c0 == 'l' && c1 == 'd') {
 a38:	f9478693          	addi	a3,a5,-108
 a3c:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 a40:	85b2                	mv	a1,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 a42:	4701                	li	a4,0
      } else if (c0 == 'u') {
 a44:	07500513          	li	a0,117
 a48:	e8a78ce3          	beq	a5,a0,8e0 <vprintf+0xee>
      } else if (c0 == 'l' && c1 == 'u') {
 a4c:	f8b60513          	addi	a0,a2,-117
 a50:	e119                	bnez	a0,a56 <vprintf+0x264>
 a52:	ea0693e3          	bnez	a3,8f8 <vprintf+0x106>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 a56:	f8b58513          	addi	a0,a1,-117
 a5a:	e119                	bnez	a0,a60 <vprintf+0x26e>
 a5c:	ea071be3          	bnez	a4,912 <vprintf+0x120>
      } else if (c0 == 'x') {
 a60:	07800513          	li	a0,120
 a64:	eca784e3          	beq	a5,a0,92c <vprintf+0x13a>
      } else if (c0 == 'l' && c1 == 'x') {
 a68:	f8860613          	addi	a2,a2,-120
 a6c:	e219                	bnez	a2,a72 <vprintf+0x280>
 a6e:	ec069be3          	bnez	a3,944 <vprintf+0x152>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 a72:	f8858593          	addi	a1,a1,-120
 a76:	e199                	bnez	a1,a7c <vprintf+0x28a>
 a78:	ee0713e3          	bnez	a4,95e <vprintf+0x16c>
      } else if (c0 == 'p') {
 a7c:	07000713          	li	a4,112
 a80:	eee78ce3          	beq	a5,a4,978 <vprintf+0x186>
      } else if (c0 == 'c') {
 a84:	06300713          	li	a4,99
 a88:	f2e78ce3          	beq	a5,a4,9c0 <vprintf+0x1ce>
      } else if (c0 == 's') {
 a8c:	07300713          	li	a4,115
 a90:	f4e782e3          	beq	a5,a4,9d4 <vprintf+0x1e2>
      } else if (c0 == '%') {
 a94:	02500713          	li	a4,37
 a98:	f6e787e3          	beq	a5,a4,a06 <vprintf+0x214>
        putc(fd, '%');
 a9c:	02500593          	li	a1,37
 aa0:	855a                	mv	a0,s6
 aa2:	c95ff0ef          	jal	736 <putc>
        putc(fd, c0);
 aa6:	85a6                	mv	a1,s1
 aa8:	855a                	mv	a0,s6
 aaa:	c8dff0ef          	jal	736 <putc>
      state = 0;
 aae:	4981                	li	s3,0
 ab0:	b359                	j	836 <vprintf+0x44>

0000000000000ab2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 ab2:	715d                	addi	sp,sp,-80
 ab4:	ec06                	sd	ra,24(sp)
 ab6:	e822                	sd	s0,16(sp)
 ab8:	1000                	addi	s0,sp,32
 aba:	e010                	sd	a2,0(s0)
 abc:	e414                	sd	a3,8(s0)
 abe:	e818                	sd	a4,16(s0)
 ac0:	ec1c                	sd	a5,24(s0)
 ac2:	03043023          	sd	a6,32(s0)
 ac6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 aca:	8622                	mv	a2,s0
 acc:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 ad0:	d23ff0ef          	jal	7f2 <vprintf>
}
 ad4:	60e2                	ld	ra,24(sp)
 ad6:	6442                	ld	s0,16(sp)
 ad8:	6161                	addi	sp,sp,80
 ada:	8082                	ret

0000000000000adc <printf>:

void
printf(const char *fmt, ...)
{
 adc:	711d                	addi	sp,sp,-96
 ade:	ec06                	sd	ra,24(sp)
 ae0:	e822                	sd	s0,16(sp)
 ae2:	1000                	addi	s0,sp,32
 ae4:	e40c                	sd	a1,8(s0)
 ae6:	e810                	sd	a2,16(s0)
 ae8:	ec14                	sd	a3,24(s0)
 aea:	f018                	sd	a4,32(s0)
 aec:	f41c                	sd	a5,40(s0)
 aee:	03043823          	sd	a6,48(s0)
 af2:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 af6:	00840613          	addi	a2,s0,8
 afa:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 afe:	85aa                	mv	a1,a0
 b00:	4505                	li	a0,1
 b02:	cf1ff0ef          	jal	7f2 <vprintf>
}
 b06:	60e2                	ld	ra,24(sp)
 b08:	6442                	ld	s0,16(sp)
 b0a:	6125                	addi	sp,sp,96
 b0c:	8082                	ret

0000000000000b0e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 b0e:	1141                	addi	sp,sp,-16
 b10:	e406                	sd	ra,8(sp)
 b12:	e022                	sd	s0,0(sp)
 b14:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 b16:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b1a:	00001797          	auipc	a5,0x1
 b1e:	4fe7b783          	ld	a5,1278(a5) # 2018 <freep>
 b22:	a039                	j	b30 <free+0x22>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b24:	6398                	ld	a4,0(a5)
 b26:	00e7e463          	bltu	a5,a4,b2e <free+0x20>
 b2a:	00e6ea63          	bltu	a3,a4,b3e <free+0x30>
{
 b2e:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 b30:	fed7fae3          	bgeu	a5,a3,b24 <free+0x16>
 b34:	6398                	ld	a4,0(a5)
 b36:	00e6e463          	bltu	a3,a4,b3e <free+0x30>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 b3a:	fee7eae3          	bltu	a5,a4,b2e <free+0x20>
      break;
  if (bp + bp->s.size == p->s.ptr) {
 b3e:	ff852583          	lw	a1,-8(a0)
 b42:	6390                	ld	a2,0(a5)
 b44:	02059813          	slli	a6,a1,0x20
 b48:	01c85713          	srli	a4,a6,0x1c
 b4c:	9736                	add	a4,a4,a3
 b4e:	02e60563          	beq	a2,a4,b78 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 b52:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
 b56:	4790                	lw	a2,8(a5)
 b58:	02061593          	slli	a1,a2,0x20
 b5c:	01c5d713          	srli	a4,a1,0x1c
 b60:	973e                	add	a4,a4,a5
 b62:	02e68263          	beq	a3,a4,b86 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 b66:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 b68:	00001717          	auipc	a4,0x1
 b6c:	4af73823          	sd	a5,1200(a4) # 2018 <freep>
}
 b70:	60a2                	ld	ra,8(sp)
 b72:	6402                	ld	s0,0(sp)
 b74:	0141                	addi	sp,sp,16
 b76:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 b78:	4618                	lw	a4,8(a2)
 b7a:	9f2d                	addw	a4,a4,a1
 b7c:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 b80:	6398                	ld	a4,0(a5)
 b82:	6310                	ld	a2,0(a4)
 b84:	b7f9                	j	b52 <free+0x44>
    p->s.size += bp->s.size;
 b86:	ff852703          	lw	a4,-8(a0)
 b8a:	9f31                	addw	a4,a4,a2
 b8c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 b8e:	ff053683          	ld	a3,-16(a0)
 b92:	bfd1                	j	b66 <free+0x58>

0000000000000b94 <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 b94:	7139                	addi	sp,sp,-64
 b96:	fc06                	sd	ra,56(sp)
 b98:	f822                	sd	s0,48(sp)
 b9a:	f04a                	sd	s2,32(sp)
 b9c:	ec4e                	sd	s3,24(sp)
 b9e:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 ba0:	02051993          	slli	s3,a0,0x20
 ba4:	0209d993          	srli	s3,s3,0x20
 ba8:	09bd                	addi	s3,s3,15
 baa:	0049d993          	srli	s3,s3,0x4
 bae:	2985                	addiw	s3,s3,1
 bb0:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
 bb2:	00001517          	auipc	a0,0x1
 bb6:	46653503          	ld	a0,1126(a0) # 2018 <freep>
 bba:	c905                	beqz	a0,bea <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 bbc:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 bbe:	4798                	lw	a4,8(a5)
 bc0:	09377663          	bgeu	a4,s3,c4c <malloc+0xb8>
 bc4:	f426                	sd	s1,40(sp)
 bc6:	e852                	sd	s4,16(sp)
 bc8:	e456                	sd	s5,8(sp)
 bca:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 bcc:	8a4e                	mv	s4,s3
 bce:	6705                	lui	a4,0x1
 bd0:	00e9f363          	bgeu	s3,a4,bd6 <malloc+0x42>
 bd4:	6a05                	lui	s4,0x1
 bd6:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 bda:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 bde:	00001497          	auipc	s1,0x1
 be2:	43a48493          	addi	s1,s1,1082 # 2018 <freep>
  if (p == SBRK_ERROR)
 be6:	5afd                	li	s5,-1
 be8:	a83d                	j	c26 <malloc+0x92>
 bea:	f426                	sd	s1,40(sp)
 bec:	e852                	sd	s4,16(sp)
 bee:	e456                	sd	s5,8(sp)
 bf0:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 bf2:	00008797          	auipc	a5,0x8
 bf6:	40e78793          	addi	a5,a5,1038 # 9000 <base>
 bfa:	00001717          	auipc	a4,0x1
 bfe:	40f73f23          	sd	a5,1054(a4) # 2018 <freep>
 c02:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 c04:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 c08:	b7d1                	j	bcc <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 c0a:	6398                	ld	a4,0(a5)
 c0c:	e118                	sd	a4,0(a0)
 c0e:	a899                	j	c64 <malloc+0xd0>
  hp->s.size = nu;
 c10:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 c14:	0541                	addi	a0,a0,16
 c16:	ef9ff0ef          	jal	b0e <free>
  return freep;
 c1a:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
 c1c:	c125                	beqz	a0,c7c <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 c1e:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 c20:	4798                	lw	a4,8(a5)
 c22:	03277163          	bgeu	a4,s2,c44 <malloc+0xb0>
    if (p == freep)
 c26:	6098                	ld	a4,0(s1)
 c28:	853e                	mv	a0,a5
 c2a:	fef71ae3          	bne	a4,a5,c1e <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 c2e:	8552                	mv	a0,s4
 c30:	9f3ff0ef          	jal	622 <sbrk>
  if (p == SBRK_ERROR)
 c34:	fd551ee3          	bne	a0,s5,c10 <malloc+0x7c>
        return 0;
 c38:	4501                	li	a0,0
 c3a:	74a2                	ld	s1,40(sp)
 c3c:	6a42                	ld	s4,16(sp)
 c3e:	6aa2                	ld	s5,8(sp)
 c40:	6b02                	ld	s6,0(sp)
 c42:	a03d                	j	c70 <malloc+0xdc>
 c44:	74a2                	ld	s1,40(sp)
 c46:	6a42                	ld	s4,16(sp)
 c48:	6aa2                	ld	s5,8(sp)
 c4a:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 c4c:	fae90fe3          	beq	s2,a4,c0a <malloc+0x76>
        p->s.size -= nunits;
 c50:	4137073b          	subw	a4,a4,s3
 c54:	c798                	sw	a4,8(a5)
        p += p->s.size;
 c56:	02071693          	slli	a3,a4,0x20
 c5a:	01c6d713          	srli	a4,a3,0x1c
 c5e:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 c60:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 c64:	00001717          	auipc	a4,0x1
 c68:	3aa73a23          	sd	a0,948(a4) # 2018 <freep>
      return (void *)(p + 1);
 c6c:	01078513          	addi	a0,a5,16
  }
}
 c70:	70e2                	ld	ra,56(sp)
 c72:	7442                	ld	s0,48(sp)
 c74:	7902                	ld	s2,32(sp)
 c76:	69e2                	ld	s3,24(sp)
 c78:	6121                	addi	sp,sp,64
 c7a:	8082                	ret
 c7c:	74a2                	ld	s1,40(sp)
 c7e:	6a42                	ld	s4,16(sp)
 c80:	6aa2                	ld	s5,8(sp)
 c82:	6b02                	ld	s6,0(sp)
 c84:	b7f5                	j	c70 <malloc+0xdc>
