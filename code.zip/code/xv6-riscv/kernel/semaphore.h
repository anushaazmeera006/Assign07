#ifndef SEMAPHORE_H
#define SEMAPHORE_H

#include "spinlock.h"

#define NSEM 10

// Q2: one kernel-resident counting semaphore.
struct semaphore {
  int value;
  int initialized;
  struct spinlock lk;
};

void seminit(void);
int ksem_init(int sem_id, int value);
int ksem_wait(int sem_id);
int ksem_signal(int sem_id);

#endif

