#include "types.h"
#include "riscv.h"
#include "spinlock.h"
#include "param.h"
#include "proc.h"
#include "defs.h"
#include "semaphore.h"

static struct semaphore semaphores[NSEM];
static struct spinlock semtable_lock;

// Return the fixed-array entry for sem_id, or zero for an invalid ID.
static struct semaphore *
get_semaphore(int sem_id)
{
  if (sem_id < 0 || sem_id >= NSEM)
    return 0;
  return &semaphores[sem_id];
}

// Q2: initialize the fixed kernel semaphore table during xv6 boot.
void
seminit(void)
{
  int i;

  initlock(&semtable_lock, "semtable");
  for (i = 0; i < NSEM; i++) {
    semaphores[i].value = 0;
    semaphores[i].initialized = 0;
    initlock(&semaphores[i].lk, "semaphore");
  }
}

// Q2: initialize a counting semaphore with a non-negative permit count.
int
ksem_init(int sem_id, int value)
{
  struct semaphore *sem = get_semaphore(sem_id);

  if (sem == 0 || value < 0)
    return -1;

  acquire(&semtable_lock);
  acquire(&sem->lk);
  sem->value = value;
  sem->initialized = 1;
  release(&sem->lk);
  release(&semtable_lock);

  return 0;
}

// Q2: consume one permit. Sleep while no permit is available.
int
ksem_wait(int sem_id)
{
  struct semaphore *sem = get_semaphore(sem_id);

  if (sem == 0)
    return -1;

  acquire(&semtable_lock);
  acquire(&sem->lk);
  if (!sem->initialized) {
    release(&sem->lk);
    release(&semtable_lock);
    return -1;
  }
  release(&semtable_lock);

  while (sem->value == 0) {
    // Register the sleep channel before releasing the semaphore lock so a
    // signal cannot be lost between the value check and sleep().
    sleep_prepare(sem);
    release(&sem->lk);
    sleep();
    acquire(&sem->lk);
  }

  sem->value--;
  release(&sem->lk);
  return 0;
}

// Q2: return one permit and wake processes waiting for this semaphore.
int
ksem_signal(int sem_id)
{
  struct semaphore *sem = get_semaphore(sem_id);

  if (sem == 0)
    return -1;

  acquire(&semtable_lock);
  acquire(&sem->lk);
  if (!sem->initialized) {
    release(&sem->lk);
    release(&semtable_lock);
    return -1;
  }

  sem->value++;
  release(&sem->lk);
  release(&semtable_lock);

  wakeup(sem);
  return 0;
}
