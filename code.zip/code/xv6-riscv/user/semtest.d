user/semtest.o: user/semtest.c kernel/types.h kernel/stat.h user/user.h
