
user/_deadlock:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <print_vector>:

int need[N][M];
int finish[N];

void print_vector(char *name, int v[M])
{
       0:	7179                	addi	sp,sp,-48
       2:	f406                	sd	ra,40(sp)
       4:	f022                	sd	s0,32(sp)
       6:	ec26                	sd	s1,24(sp)
       8:	e84a                	sd	s2,16(sp)
       a:	e44e                	sd	s3,8(sp)
       c:	1800                	addi	s0,sp,48
       e:	892e                	mv	s2,a1
  int j;
  printf("%s: ", name);
      10:	85aa                	mv	a1,a0
      12:	00001517          	auipc	a0,0x1
      16:	0fe50513          	addi	a0,a0,254 # 1110 <malloc+0xf6>
      1a:	749000ef          	jal	f62 <printf>
  for(j = 0; j < M; j++)
      1e:	84ca                	mv	s1,s2
      20:	0931                	addi	s2,s2,12
    printf("%d ", v[j]);
      22:	00001997          	auipc	s3,0x1
      26:	0fe98993          	addi	s3,s3,254 # 1120 <malloc+0x106>
      2a:	408c                	lw	a1,0(s1)
      2c:	854e                	mv	a0,s3
      2e:	735000ef          	jal	f62 <printf>
  for(j = 0; j < M; j++)
      32:	0491                	addi	s1,s1,4
      34:	ff249be3          	bne	s1,s2,2a <print_vector+0x2a>
  printf("\n");
      38:	00001517          	auipc	a0,0x1
      3c:	0f050513          	addi	a0,a0,240 # 1128 <malloc+0x10e>
      40:	723000ef          	jal	f62 <printf>
}
      44:	70a2                	ld	ra,40(sp)
      46:	7402                	ld	s0,32(sp)
      48:	64e2                	ld	s1,24(sp)
      4a:	6942                	ld	s2,16(sp)
      4c:	69a2                	ld	s3,8(sp)
      4e:	6145                	addi	sp,sp,48
      50:	8082                	ret

0000000000000052 <calculate_need>:

void calculate_need(void)
{
      52:	1141                	addi	sp,sp,-16
      54:	e406                	sd	ra,8(sp)
      56:	e022                	sd	s0,0(sp)
      58:	0800                	addi	s0,sp,16
  int i, j;
  for(i = 0; i < N; i++)
      5a:	00002797          	auipc	a5,0x2
      5e:	fa678793          	addi	a5,a5,-90 # 2000 <maximum>
      62:	00002697          	auipc	a3,0x2
      66:	fde68693          	addi	a3,a3,-34 # 2040 <allocation>
      6a:	00002717          	auipc	a4,0x2
      6e:	03670713          	addi	a4,a4,54 # 20a0 <need>
      72:	00002517          	auipc	a0,0x2
      76:	fca50513          	addi	a0,a0,-54 # 203c <maximum+0x3c>
    for(j = 0; j < M; j++)
      need[i][j] = maximum[i][j] - allocation[i][j];
      7a:	4390                	lw	a2,0(a5)
      7c:	428c                	lw	a1,0(a3)
      7e:	9e0d                	subw	a2,a2,a1
      80:	c310                	sw	a2,0(a4)
      82:	43d0                	lw	a2,4(a5)
      84:	42cc                	lw	a1,4(a3)
      86:	9e0d                	subw	a2,a2,a1
      88:	c350                	sw	a2,4(a4)
      8a:	4790                	lw	a2,8(a5)
      8c:	468c                	lw	a1,8(a3)
      8e:	9e0d                	subw	a2,a2,a1
      90:	c710                	sw	a2,8(a4)
  for(i = 0; i < N; i++)
      92:	07b1                	addi	a5,a5,12
      94:	06b1                	addi	a3,a3,12
      96:	0731                	addi	a4,a4,12
      98:	fea791e3          	bne	a5,a0,7a <calculate_need+0x28>
}
      9c:	60a2                	ld	ra,8(sp)
      9e:	6402                	ld	s0,0(sp)
      a0:	0141                	addi	sp,sp,16
      a2:	8082                	ret

00000000000000a4 <less_equal>:

int less_equal(int a[M], int b[M])
{
      a4:	1141                	addi	sp,sp,-16
      a6:	e406                	sd	ra,8(sp)
      a8:	e022                	sd	s0,0(sp)
      aa:	0800                	addi	s0,sp,16
      ac:	4781                	li	a5,0
  int j;
  for(j = 0; j < M; j++)
      ae:	4631                	li	a2,12
    if(a[j] > b[j])
      b0:	00f506b3          	add	a3,a0,a5
      b4:	00f58733          	add	a4,a1,a5
      b8:	4294                	lw	a3,0(a3)
      ba:	4318                	lw	a4,0(a4)
      bc:	00d74a63          	blt	a4,a3,d0 <less_equal+0x2c>
  for(j = 0; j < M; j++)
      c0:	0791                	addi	a5,a5,4
      c2:	fec797e3          	bne	a5,a2,b0 <less_equal+0xc>
      return 0;
  return 1;
      c6:	4505                	li	a0,1
}
      c8:	60a2                	ld	ra,8(sp)
      ca:	6402                	ld	s0,0(sp)
      cc:	0141                	addi	sp,sp,16
      ce:	8082                	ret
      return 0;
      d0:	4501                	li	a0,0
      d2:	bfdd                	j	c8 <less_equal+0x24>

00000000000000d4 <print_matrices>:

void print_matrices(void)
{
      d4:	7139                	addi	sp,sp,-64
      d6:	fc06                	sd	ra,56(sp)
      d8:	f822                	sd	s0,48(sp)
      da:	f426                	sd	s1,40(sp)
      dc:	f04a                	sd	s2,32(sp)
      de:	ec4e                	sd	s3,24(sp)
      e0:	e852                	sd	s4,16(sp)
      e2:	e456                	sd	s5,8(sp)
      e4:	0080                	addi	s0,sp,64
  int i;
  printf("Process  Allocation    Need\n");
      e6:	00001517          	auipc	a0,0x1
      ea:	04a50513          	addi	a0,a0,74 # 1130 <malloc+0x116>
      ee:	675000ef          	jal	f62 <printf>
  for(i = 0; i < N; i++)
      f2:	00002917          	auipc	s2,0x2
      f6:	f4e90913          	addi	s2,s2,-178 # 2040 <allocation>
      fa:	00002497          	auipc	s1,0x2
      fe:	fa648493          	addi	s1,s1,-90 # 20a0 <need>
     102:	4981                	li	s3,0
    printf("P%d       %d %d %d       %d %d %d\n",
     104:	00001a97          	auipc	s5,0x1
     108:	04ca8a93          	addi	s5,s5,76 # 1150 <malloc+0x136>
  for(i = 0; i < N; i++)
     10c:	4a15                	li	s4,5
    printf("P%d       %d %d %d       %d %d %d\n",
     10e:	0084a883          	lw	a7,8(s1)
     112:	0044a803          	lw	a6,4(s1)
     116:	409c                	lw	a5,0(s1)
     118:	00892703          	lw	a4,8(s2)
     11c:	00492683          	lw	a3,4(s2)
     120:	00092603          	lw	a2,0(s2)
     124:	85ce                	mv	a1,s3
     126:	8556                	mv	a0,s5
     128:	63b000ef          	jal	f62 <printf>
  for(i = 0; i < N; i++)
     12c:	2985                	addiw	s3,s3,1
     12e:	0931                	addi	s2,s2,12
     130:	04b1                	addi	s1,s1,12
     132:	fd499ee3          	bne	s3,s4,10e <print_matrices+0x3a>
           i,
           allocation[i][0], allocation[i][1], allocation[i][2],
           need[i][0], need[i][1], need[i][2]);
  print_vector("Available", available);
     136:	00002597          	auipc	a1,0x2
     13a:	f4a58593          	addi	a1,a1,-182 # 2080 <available>
     13e:	00001517          	auipc	a0,0x1
     142:	03a50513          	addi	a0,a0,58 # 1178 <malloc+0x15e>
     146:	ebbff0ef          	jal	0 <print_vector>
}
     14a:	70e2                	ld	ra,56(sp)
     14c:	7442                	ld	s0,48(sp)
     14e:	74a2                	ld	s1,40(sp)
     150:	7902                	ld	s2,32(sp)
     152:	69e2                	ld	s3,24(sp)
     154:	6a42                	ld	s4,16(sp)
     156:	6aa2                	ld	s5,8(sp)
     158:	6121                	addi	sp,sp,64
     15a:	8082                	ret

000000000000015c <safe_state>:

int safe_state(void)
{
     15c:	7135                	addi	sp,sp,-160
     15e:	ed06                	sd	ra,152(sp)
     160:	e922                	sd	s0,144(sp)
     162:	e526                	sd	s1,136(sp)
     164:	e14a                	sd	s2,128(sp)
     166:	fcce                	sd	s3,120(sp)
     168:	f8d2                	sd	s4,112(sp)
     16a:	f4d6                	sd	s5,104(sp)
     16c:	f0da                	sd	s6,96(sp)
     16e:	ecde                	sd	s7,88(sp)
     170:	e8e2                	sd	s8,80(sp)
     172:	e4e6                	sd	s9,72(sp)
     174:	e0ea                	sd	s10,64(sp)
     176:	fc6e                	sd	s11,56(sp)
     178:	1100                	addi	s0,sp,160
  int work[M];
  int done[N];
  int i, j, found, count = 0;

  for(j = 0; j < M; j++)
    work[j] = available[j];
     17a:	00002797          	auipc	a5,0x2
     17e:	e8678793          	addi	a5,a5,-378 # 2000 <maximum>
     182:	0807a703          	lw	a4,128(a5)
     186:	f8e42023          	sw	a4,-128(s0)
     18a:	0847a703          	lw	a4,132(a5)
     18e:	f8e42223          	sw	a4,-124(s0)
     192:	0887a783          	lw	a5,136(a5)
     196:	f8f42423          	sw	a5,-120(s0)
  for(i = 0; i < N; i++)
    done[i] = 0;
     19a:	f6042423          	sw	zero,-152(s0)
     19e:	f6042623          	sw	zero,-148(s0)
     1a2:	f6042823          	sw	zero,-144(s0)
     1a6:	f6042a23          	sw	zero,-140(s0)
     1aa:	f6042c23          	sw	zero,-136(s0)
  int i, j, found, count = 0;
     1ae:	4c01                	li	s8,0

  while(count < N) {
    found = 0;
    for(i = 0; i < N; i++) {
      if(!done[i] && less_equal(need[i], work)) {
     1b0:	f8040b93          	addi	s7,s0,-128
    for(i = 0; i < N; i++) {
     1b4:	4a95                	li	s5,5
        for(j = 0; j < M; j++)
          work[j] += allocation[i][j];
        done[i] = 1;
     1b6:	4c85                	li	s9,1
        count++;
        found = 1;
        printf("P%d can finish; Work = %d %d %d\n",
     1b8:	00001d97          	auipc	s11,0x1
     1bc:	fd0d8d93          	addi	s11,s11,-48 # 1188 <malloc+0x16e>
  while(count < N) {
     1c0:	4d11                	li	s10,4
     1c2:	a08d                	j	224 <safe_state+0xc8>
          work[j] += allocation[i][j];
     1c4:	000a2783          	lw	a5,0(s4)
     1c8:	f8042603          	lw	a2,-128(s0)
     1cc:	9e3d                	addw	a2,a2,a5
     1ce:	f8c42023          	sw	a2,-128(s0)
     1d2:	f8442783          	lw	a5,-124(s0)
     1d6:	004a2683          	lw	a3,4(s4)
     1da:	9ebd                	addw	a3,a3,a5
     1dc:	f8d42223          	sw	a3,-124(s0)
     1e0:	f8842783          	lw	a5,-120(s0)
     1e4:	008a2703          	lw	a4,8(s4)
     1e8:	9f3d                	addw	a4,a4,a5
     1ea:	f8e42423          	sw	a4,-120(s0)
        done[i] = 1;
     1ee:	01992023          	sw	s9,0(s2)
        count++;
     1f2:	2c05                	addiw	s8,s8,1
        printf("P%d can finish; Work = %d %d %d\n",
     1f4:	85a6                	mv	a1,s1
     1f6:	856e                	mv	a0,s11
     1f8:	56b000ef          	jal	f62 <printf>
        found = 1;
     1fc:	8b66                	mv	s6,s9
    for(i = 0; i < N; i++) {
     1fe:	2485                	addiw	s1,s1,1
     200:	0911                	addi	s2,s2,4
     202:	09b1                	addi	s3,s3,12
     204:	0a31                	addi	s4,s4,12
     206:	01548b63          	beq	s1,s5,21c <safe_state+0xc0>
      if(!done[i] && less_equal(need[i], work)) {
     20a:	00092783          	lw	a5,0(s2)
     20e:	fbe5                	bnez	a5,1fe <safe_state+0xa2>
     210:	85de                	mv	a1,s7
     212:	854e                	mv	a0,s3
     214:	e91ff0ef          	jal	a4 <less_equal>
     218:	d17d                	beqz	a0,1fe <safe_state+0xa2>
     21a:	b76d                	j	1c4 <safe_state+0x68>
               i, work[0], work[1], work[2]);
      }
    }
    if(!found)
     21c:	020b0163          	beqz	s6,23e <safe_state+0xe2>
  while(count < N) {
     220:	018d4f63          	blt	s10,s8,23e <safe_state+0xe2>
    for(i = 0; i < N; i++) {
     224:	f6840913          	addi	s2,s0,-152
     228:	00002997          	auipc	s3,0x2
     22c:	e7898993          	addi	s3,s3,-392 # 20a0 <need>
     230:	00002a17          	auipc	s4,0x2
     234:	e10a0a13          	addi	s4,s4,-496 # 2040 <allocation>
    found = 0;
     238:	4b01                	li	s6,0
    for(i = 0; i < N; i++) {
     23a:	4481                	li	s1,0
     23c:	b7f9                	j	20a <safe_state+0xae>
      break;
  }

  if(count == N) {
     23e:	4795                	li	a5,5
     240:	02fc0863          	beq	s8,a5,270 <safe_state+0x114>
    printf("SAFE state. Safe sequence exists.\n");
    return 1;
  }

  printf("UNSAFE state. No safe sequence found.\n");
     244:	00001517          	auipc	a0,0x1
     248:	f9450513          	addi	a0,a0,-108 # 11d8 <malloc+0x1be>
     24c:	517000ef          	jal	f62 <printf>
  return 0;
     250:	4501                	li	a0,0
}
     252:	60ea                	ld	ra,152(sp)
     254:	644a                	ld	s0,144(sp)
     256:	64aa                	ld	s1,136(sp)
     258:	690a                	ld	s2,128(sp)
     25a:	79e6                	ld	s3,120(sp)
     25c:	7a46                	ld	s4,112(sp)
     25e:	7aa6                	ld	s5,104(sp)
     260:	7b06                	ld	s6,96(sp)
     262:	6be6                	ld	s7,88(sp)
     264:	6c46                	ld	s8,80(sp)
     266:	6ca6                	ld	s9,72(sp)
     268:	6d06                	ld	s10,64(sp)
     26a:	7de2                	ld	s11,56(sp)
     26c:	610d                	addi	sp,sp,160
     26e:	8082                	ret
    printf("SAFE state. Safe sequence exists.\n");
     270:	00001517          	auipc	a0,0x1
     274:	f4050513          	addi	a0,a0,-192 # 11b0 <malloc+0x196>
     278:	4eb000ef          	jal	f62 <printf>
    return 1;
     27c:	4505                	li	a0,1
     27e:	bfd1                	j	252 <safe_state+0xf6>

0000000000000280 <detect_deadlock>:

int detect_deadlock(int alloc[N][M],
                    int request[N][M],
                    int avail[M])
{
     280:	7171                	addi	sp,sp,-176
     282:	f506                	sd	ra,168(sp)
     284:	f122                	sd	s0,160(sp)
     286:	ed26                	sd	s1,152(sp)
     288:	e94a                	sd	s2,144(sp)
     28a:	e54e                	sd	s3,136(sp)
     28c:	e152                	sd	s4,128(sp)
     28e:	fcd6                	sd	s5,120(sp)
     290:	f8da                	sd	s6,112(sp)
     292:	f4de                	sd	s7,104(sp)
     294:	f0e2                	sd	s8,96(sp)
     296:	ece6                	sd	s9,88(sp)
     298:	e8ea                	sd	s10,80(sp)
     29a:	e4ee                	sd	s11,72(sp)
     29c:	1900                	addi	s0,sp,176
     29e:	f4a43c23          	sd	a0,-168(s0)
     2a2:	f4b43823          	sd	a1,-176(s0)
  int work[M];
  int done[N];
  int i, j, found, deadlocked = 0;

  for(j = 0; j < M; j++)
    work[j] = avail[j];
     2a6:	421c                	lw	a5,0(a2)
     2a8:	f8f42023          	sw	a5,-128(s0)
     2ac:	425c                	lw	a5,4(a2)
     2ae:	f8f42223          	sw	a5,-124(s0)
     2b2:	461c                	lw	a5,8(a2)
     2b4:	f8f42423          	sw	a5,-120(s0)
  for(j = 0; j < M; j++)
     2b8:	f6840c13          	addi	s8,s0,-152
     2bc:	87aa                	mv	a5,a0
     2be:	03c50813          	addi	a6,a0,60
    work[j] = avail[j];
     2c2:	8762                	mv	a4,s8

  for(i = 0; i < N; i++) {
    done[i] = 1;
     2c4:	4505                	li	a0,1
     2c6:	a029                	j	2d0 <detect_deadlock+0x50>
  for(i = 0; i < N; i++) {
     2c8:	0711                	addi	a4,a4,4
     2ca:	07b1                	addi	a5,a5,12
     2cc:	03078263          	beq	a5,a6,2f0 <detect_deadlock+0x70>
    done[i] = 1;
     2d0:	85ba                	mv	a1,a4
     2d2:	c308                	sw	a0,0(a4)
    for(j = 0; j < M; j++)
      if(alloc[i][j] != 0)
     2d4:	86be                	mv	a3,a5
     2d6:	4390                	lw	a2,0(a5)
     2d8:	c219                	beqz	a2,2de <detect_deadlock+0x5e>
        done[i] = 0;
     2da:	00072023          	sw	zero,0(a4)
      if(alloc[i][j] != 0)
     2de:	42d0                	lw	a2,4(a3)
     2e0:	c219                	beqz	a2,2e6 <detect_deadlock+0x66>
        done[i] = 0;
     2e2:	0005a023          	sw	zero,0(a1)
      if(alloc[i][j] != 0)
     2e6:	4694                	lw	a3,8(a3)
     2e8:	d2e5                	beqz	a3,2c8 <detect_deadlock+0x48>
        done[i] = 0;
     2ea:	0005a023          	sw	zero,0(a1)
     2ee:	bfe9                	j	2c8 <detect_deadlock+0x48>
  }

  while(1) {
    found = 0;
    for(i = 0; i < N; i++) {
      if(!done[i] && less_equal(request[i], work)) {
     2f0:	f8040c93          	addi	s9,s0,-128
    for(i = 0; i < N; i++) {
     2f4:	4b15                	li	s6,5
     2f6:	f8c40d13          	addi	s10,s0,-116
        for(j = 0; j < M; j++)
          work[j] += alloc[i][j];
        done[i] = 1;
     2fa:	4d85                	li	s11,1
     2fc:	a0b9                	j	34a <detect_deadlock+0xca>
    for(i = 0; i < N; i++) {
     2fe:	2905                	addiw	s2,s2,1
     300:	0491                	addi	s1,s1,4
     302:	09b1                	addi	s3,s3,12
     304:	0a31                	addi	s4,s4,12
     306:	05690063          	beq	s2,s6,346 <detect_deadlock+0xc6>
      if(!done[i] && less_equal(request[i], work)) {
     30a:	8aa6                	mv	s5,s1
     30c:	409c                	lw	a5,0(s1)
     30e:	fbe5                	bnez	a5,2fe <detect_deadlock+0x7e>
     310:	85e6                	mv	a1,s9
     312:	854e                	mv	a0,s3
     314:	d91ff0ef          	jal	a4 <less_equal>
     318:	d17d                	beqz	a0,2fe <detect_deadlock+0x7e>
     31a:	f8040793          	addi	a5,s0,-128
     31e:	86d2                	mv	a3,s4
          work[j] += alloc[i][j];
     320:	4390                	lw	a2,0(a5)
     322:	4298                	lw	a4,0(a3)
     324:	9f31                	addw	a4,a4,a2
     326:	c398                	sw	a4,0(a5)
        for(j = 0; j < M; j++)
     328:	0791                	addi	a5,a5,4
     32a:	0691                	addi	a3,a3,4
     32c:	fefd1ae3          	bne	s10,a5,320 <detect_deadlock+0xa0>
        done[i] = 1;
     330:	01baa023          	sw	s11,0(s5)
        found = 1;
        printf("Detection: P%d can finish\n", i);
     334:	85ca                	mv	a1,s2
     336:	00001517          	auipc	a0,0x1
     33a:	eca50513          	addi	a0,a0,-310 # 1200 <malloc+0x1e6>
     33e:	425000ef          	jal	f62 <printf>
        found = 1;
     342:	8bee                	mv	s7,s11
     344:	bf6d                	j	2fe <detect_deadlock+0x7e>
      }
    }
    if(!found)
     346:	000b8a63          	beqz	s7,35a <detect_deadlock+0xda>
    for(i = 0; i < N; i++) {
     34a:	f5043983          	ld	s3,-176(s0)
    work[j] = avail[j];
     34e:	f5843a03          	ld	s4,-168(s0)
     352:	84e2                	mv	s1,s8
    found = 0;
     354:	4b81                	li	s7,0
    for(i = 0; i < N; i++) {
     356:	4901                	li	s2,0
     358:	bf4d                	j	30a <detect_deadlock+0x8a>
      break;
  }

  printf("Processes still unfinished: ");
     35a:	00001517          	auipc	a0,0x1
     35e:	ec650513          	addi	a0,a0,-314 # 1220 <malloc+0x206>
     362:	401000ef          	jal	f62 <printf>
  int i, j, found, deadlocked = 0;
     366:	895e                	mv	s2,s7
  for(i = 0; i < N; i++) {
    if(!done[i]) {
      printf("P%d ", i);
     368:	00001a17          	auipc	s4,0x1
     36c:	ed8a0a13          	addi	s4,s4,-296 # 1240 <malloc+0x226>
      deadlocked = 1;
     370:	4985                	li	s3,1
  for(i = 0; i < N; i++) {
     372:	4495                	li	s1,5
     374:	a029                	j	37e <detect_deadlock+0xfe>
     376:	2b85                	addiw	s7,s7,1
     378:	0c11                	addi	s8,s8,4
     37a:	009b8b63          	beq	s7,s1,390 <detect_deadlock+0x110>
    if(!done[i]) {
     37e:	000c2783          	lw	a5,0(s8)
     382:	fbf5                	bnez	a5,376 <detect_deadlock+0xf6>
      printf("P%d ", i);
     384:	85de                	mv	a1,s7
     386:	8552                	mv	a0,s4
     388:	3db000ef          	jal	f62 <printf>
      deadlocked = 1;
     38c:	894e                	mv	s2,s3
     38e:	b7e5                	j	376 <detect_deadlock+0xf6>
    }
  }
  printf("\n");
     390:	00001517          	auipc	a0,0x1
     394:	d9850513          	addi	a0,a0,-616 # 1128 <malloc+0x10e>
     398:	3cb000ef          	jal	f62 <printf>

  if(deadlocked)
     39c:	02090863          	beqz	s2,3cc <detect_deadlock+0x14c>
    printf("DEADLOCK detected.\n");
     3a0:	00001517          	auipc	a0,0x1
     3a4:	ea850513          	addi	a0,a0,-344 # 1248 <malloc+0x22e>
     3a8:	3bb000ef          	jal	f62 <printf>
  else
    printf("No deadlock detected.\n");

  return deadlocked;
}
     3ac:	854a                	mv	a0,s2
     3ae:	70aa                	ld	ra,168(sp)
     3b0:	740a                	ld	s0,160(sp)
     3b2:	64ea                	ld	s1,152(sp)
     3b4:	694a                	ld	s2,144(sp)
     3b6:	69aa                	ld	s3,136(sp)
     3b8:	6a0a                	ld	s4,128(sp)
     3ba:	7ae6                	ld	s5,120(sp)
     3bc:	7b46                	ld	s6,112(sp)
     3be:	7ba6                	ld	s7,104(sp)
     3c0:	7c06                	ld	s8,96(sp)
     3c2:	6ce6                	ld	s9,88(sp)
     3c4:	6d46                	ld	s10,80(sp)
     3c6:	6da6                	ld	s11,72(sp)
     3c8:	614d                	addi	sp,sp,176
     3ca:	8082                	ret
    printf("No deadlock detected.\n");
     3cc:	00001517          	auipc	a0,0x1
     3d0:	e9450513          	addi	a0,a0,-364 # 1260 <malloc+0x246>
     3d4:	38f000ef          	jal	f62 <printf>
     3d8:	bfd1                	j	3ac <detect_deadlock+0x12c>

00000000000003da <unsafe_request_test>:
void unsafe_request_test(void)
{
     3da:	7155                	addi	sp,sp,-208
     3dc:	e586                	sd	ra,200(sp)
     3de:	e1a2                	sd	s0,192(sp)
     3e0:	0980                	addi	s0,sp,208
  int alloc[3][3] = {
     3e2:	00001797          	auipc	a5,0x1
     3e6:	0f678793          	addi	a5,a5,246 # 14d8 <malloc+0x4be>
     3ea:	6390                	ld	a2,0(a5)
     3ec:	6794                	ld	a3,8(a5)
     3ee:	6b98                	ld	a4,16(a5)
     3f0:	fcc43423          	sd	a2,-56(s0)
     3f4:	fcd43823          	sd	a3,-48(s0)
     3f8:	fce43c23          	sd	a4,-40(s0)
     3fc:	6f98                	ld	a4,24(a5)
     3fe:	fee43023          	sd	a4,-32(s0)
     402:	5398                	lw	a4,32(a5)
     404:	fee42423          	sw	a4,-24(s0)
    {1, 0, 0},
    {0, 1, 0},
    {0, 0, 1}
  };
  int max[3][3] = {
     408:	7790                	ld	a2,40(a5)
     40a:	7b94                	ld	a3,48(a5)
     40c:	7f98                	ld	a4,56(a5)
     40e:	fac43023          	sd	a2,-96(s0)
     412:	fad43423          	sd	a3,-88(s0)
     416:	fae43823          	sd	a4,-80(s0)
     41a:	63b8                	ld	a4,64(a5)
     41c:	fae43c23          	sd	a4,-72(s0)
     420:	47bc                	lw	a5,72(a5)
     422:	fcf42023          	sw	a5,-64(s0)
    {2, 1, 0},
    {0, 2, 1},
    {1, 0, 2}
  };
  int avail[3] = {0, 0, 0};
     426:	f8042823          	sw	zero,-112(s0)
     42a:	f8042a23          	sw	zero,-108(s0)
     42e:	f8042c23          	sw	zero,-104(s0)
  int req[3] = {1, 0, 0};
     432:	4785                	li	a5,1
     434:	f8f42023          	sw	a5,-128(s0)
     438:	f8042223          	sw	zero,-124(s0)
     43c:	f8042423          	sw	zero,-120(s0)
  int need3[3][3];
  int work[3], finish[3] = {0, 0, 0};
     440:	f2042c23          	sw	zero,-200(s0)
     444:	f2042e23          	sw	zero,-196(s0)
     448:	f4042023          	sw	zero,-192(s0)
  int i, j, found, count = 0;

  printf("Testing request by P0: 1 0 0\n");
     44c:	00001517          	auipc	a0,0x1
     450:	e2c50513          	addi	a0,a0,-468 # 1278 <malloc+0x25e>
     454:	30f000ef          	jal	f62 <printf>

  for(i = 0; i < 3; i++) {
     458:	f9040793          	addi	a5,s0,-112
     45c:	f4840813          	addi	a6,s0,-184
     460:	fa040613          	addi	a2,s0,-96
     464:	fc840313          	addi	t1,s0,-56
     468:	f5840e13          	addi	t3,s0,-168
     46c:	f9c40893          	addi	a7,s0,-100
  printf("Testing request by P0: 1 0 0\n");
     470:	86f2                	mv	a3,t3
     472:	871a                	mv	a4,t1
     474:	85be                	mv	a1,a5
    work[i] = avail[i];
     476:	4188                	lw	a0,0(a1)
     478:	00a82023          	sw	a0,0(a6)
    for(j = 0; j < 3; j++)
      need3[i][j] = max[i][j] - alloc[i][j];
     47c:	4208                	lw	a0,0(a2)
     47e:	00072e83          	lw	t4,0(a4)
     482:	41d5053b          	subw	a0,a0,t4
     486:	c288                	sw	a0,0(a3)
     488:	4248                	lw	a0,4(a2)
     48a:	00472e83          	lw	t4,4(a4)
     48e:	41d5053b          	subw	a0,a0,t4
     492:	c2c8                	sw	a0,4(a3)
     494:	4608                	lw	a0,8(a2)
     496:	00872e83          	lw	t4,8(a4)
     49a:	41d5053b          	subw	a0,a0,t4
     49e:	c688                	sw	a0,8(a3)
  for(i = 0; i < 3; i++) {
     4a0:	0591                	addi	a1,a1,4
     4a2:	0811                	addi	a6,a6,4
     4a4:	0631                	addi	a2,a2,12
     4a6:	0731                	addi	a4,a4,12
     4a8:	06b1                	addi	a3,a3,12
     4aa:	fd1596e3          	bne	a1,a7,476 <unsafe_request_test+0x9c>
     4ae:	f8040513          	addi	a0,s0,-128
     4b2:	86f2                	mv	a3,t3
     4b4:	871a                	mv	a4,t1
  }

  for(j = 0; j < 3; j++) {
    avail[j] -= req[j];
     4b6:	410c                	lw	a1,0(a0)
     4b8:	4390                	lw	a2,0(a5)
     4ba:	9e0d                	subw	a2,a2,a1
     4bc:	c390                	sw	a2,0(a5)
    alloc[0][j] += req[j];
     4be:	4310                	lw	a2,0(a4)
     4c0:	9e2d                	addw	a2,a2,a1
     4c2:	c310                	sw	a2,0(a4)
    need3[0][j] -= req[j];
     4c4:	4290                	lw	a2,0(a3)
     4c6:	9e0d                	subw	a2,a2,a1
     4c8:	c290                	sw	a2,0(a3)
  for(j = 0; j < 3; j++) {
     4ca:	0791                	addi	a5,a5,4
     4cc:	0511                	addi	a0,a0,4
     4ce:	0711                	addi	a4,a4,4
     4d0:	0691                	addi	a3,a3,4
     4d2:	ff1792e3          	bne	a5,a7,4b6 <unsafe_request_test+0xdc>
  }

  for(j = 0; j < 3; j++)
    work[j] = avail[j];
     4d6:	f9042803          	lw	a6,-112(s0)
     4da:	f9442783          	lw	a5,-108(s0)
     4de:	f4f42623          	sw	a5,-180(s0)
     4e2:	f9842783          	lw	a5,-104(s0)
     4e6:	f4f42823          	sw	a5,-176(s0)
  int i, j, found, count = 0;
     4ea:	4f01                	li	t5,0
     4ec:	f4440593          	addi	a1,s0,-188
     4f0:	a889                	j	542 <unsafe_request_test+0x168>

  while(1) {
    found = 0;
    for(i = 0; i < 3; i++) {
     4f2:	0791                	addi	a5,a5,4
     4f4:	0731                	addi	a4,a4,12
     4f6:	06b1                	addi	a3,a3,12
     4f8:	04b78463          	beq	a5,a1,540 <unsafe_request_test+0x166>
      if(!finish[i] &&
     4fc:	4390                	lw	a2,0(a5)
     4fe:	fa75                	bnez	a2,4f2 <unsafe_request_test+0x118>
     500:	4310                	lw	a2,0(a4)
     502:	fec848e3          	blt	a6,a2,4f2 <unsafe_request_test+0x118>
         need3[i][0] <= work[0] &&
         need3[i][1] <= work[1] &&
     506:	f4c42603          	lw	a2,-180(s0)
         need3[i][0] <= work[0] &&
     50a:	00472883          	lw	a7,4(a4)
     50e:	ff1642e3          	blt	a2,a7,4f2 <unsafe_request_test+0x118>
         need3[i][2] <= work[2]) {
     512:	f5042883          	lw	a7,-176(s0)
         need3[i][1] <= work[1] &&
     516:	00872e83          	lw	t4,8(a4)
     51a:	fdd8cce3          	blt	a7,t4,4f2 <unsafe_request_test+0x118>
        for(j = 0; j < 3; j++)
          work[j] += alloc[i][j];
     51e:	4288                	lw	a0,0(a3)
     520:	0105083b          	addw	a6,a0,a6
     524:	42c8                	lw	a0,4(a3)
     526:	9e29                	addw	a2,a2,a0
     528:	f4c42623          	sw	a2,-180(s0)
     52c:	4690                	lw	a2,8(a3)
     52e:	0116063b          	addw	a2,a2,a7
     532:	f4c42823          	sw	a2,-176(s0)
        finish[i] = 1;
     536:	4605                	li	a2,1
     538:	c390                	sw	a2,0(a5)
        count++;
     53a:	2f05                	addiw	t5,t5,1
        found = 1;
     53c:	8532                	mv	a0,a2
     53e:	bf55                	j	4f2 <unsafe_request_test+0x118>
      }
    }
    if(!found)
     540:	c519                	beqz	a0,54e <unsafe_request_test+0x174>
    for(i = 0; i < 3; i++) {
     542:	f3840793          	addi	a5,s0,-200
  int i, j, found, count = 0;
     546:	869a                	mv	a3,t1
     548:	8772                	mv	a4,t3
    found = 0;
     54a:	4501                	li	a0,0
     54c:	bf45                	j	4fc <unsafe_request_test+0x122>
      break;
  }

  if(count == 3)
     54e:	478d                	li	a5,3
     550:	00ff0c63          	beq	t5,a5,568 <unsafe_request_test+0x18e>
    printf("Request keeps state SAFE.\n");
  else
    printf("Request makes state UNSAFE; deny request.\n");
     554:	00001517          	auipc	a0,0x1
     558:	d6450513          	addi	a0,a0,-668 # 12b8 <malloc+0x29e>
     55c:	207000ef          	jal	f62 <printf>
}
     560:	60ae                	ld	ra,200(sp)
     562:	640e                	ld	s0,192(sp)
     564:	6169                	addi	sp,sp,208
     566:	8082                	ret
    printf("Request keeps state SAFE.\n");
     568:	00001517          	auipc	a0,0x1
     56c:	d3050513          	addi	a0,a0,-720 # 1298 <malloc+0x27e>
     570:	1f3000ef          	jal	f62 <printf>
     574:	b7f5                	j	560 <unsafe_request_test+0x186>

0000000000000576 <pipe_deadlock_demo>:


void pipe_deadlock_demo(void)
{
     576:	7139                	addi	sp,sp,-64
     578:	fc06                	sd	ra,56(sp)
     57a:	f822                	sd	s0,48(sp)
     57c:	0080                	addi	s0,sp,64
  int p1[2], p2[2];
  int pidA, pidB;
  char c = 'X';
     57e:	05800793          	li	a5,88
     582:	fcf407a3          	sb	a5,-49(s0)

  printf("\n=== Actual Process Deadlock Demo ===\n");
     586:	00001517          	auipc	a0,0x1
     58a:	d6250513          	addi	a0,a0,-670 # 12e8 <malloc+0x2ce>
     58e:	1d5000ef          	jal	f62 <printf>

  if(pipe(p1) < 0 || pipe(p2) < 0) {
     592:	fd840513          	addi	a0,s0,-40
     596:	556000ef          	jal	aec <pipe>
     59a:	0a054963          	bltz	a0,64c <pipe_deadlock_demo+0xd6>
     59e:	fd040513          	addi	a0,s0,-48
     5a2:	54a000ef          	jal	aec <pipe>
     5a6:	0a054363          	bltz	a0,64c <pipe_deadlock_demo+0xd6>
     5aa:	f426                	sd	s1,40(sp)
    printf("Pipe creation failed\n");
    return;
  }

  pidA = fork();
     5ac:	528000ef          	jal	ad4 <fork>
     5b0:	84aa                	mv	s1,a0
  if(pidA < 0) {
     5b2:	0a054763          	bltz	a0,660 <pipe_deadlock_demo+0xea>
     5b6:	f04a                	sd	s2,32(sp)
    close(p1[0]); close(p1[1]);
    close(p2[0]); close(p2[1]);
    return;
  }

  if(pidA == 0) {
     5b8:	0c050c63          	beqz	a0,690 <pipe_deadlock_demo+0x11a>
    close(p2[0]);
    close(p1[1]);
    exit(0);
  }

  pidB = fork();
     5bc:	518000ef          	jal	ad4 <fork>
     5c0:	892a                	mv	s2,a0
  if(pidB < 0) {
     5c2:	10054763          	bltz	a0,6d0 <pipe_deadlock_demo+0x15a>
    close(p2[0]); close(p2[1]);
    wait(0);
    return;
  }

  if(pidB == 0) {
     5c6:	14050463          	beqz	a0,70e <pipe_deadlock_demo+0x198>
    close(p1[0]);
    close(p2[1]);
    exit(0);
  }

  close(p1[0]);
     5ca:	fd842503          	lw	a0,-40(s0)
     5ce:	536000ef          	jal	b04 <close>
  close(p1[1]);
     5d2:	fdc42503          	lw	a0,-36(s0)
     5d6:	52e000ef          	jal	b04 <close>
  close(p2[0]);
     5da:	fd042503          	lw	a0,-48(s0)
     5de:	526000ef          	jal	b04 <close>
  close(p2[1]);
     5e2:	fd442503          	lw	a0,-44(s0)
     5e6:	51e000ef          	jal	b04 <close>

  for(volatile int i = 0; i < 10000000; i++)
     5ea:	fc042423          	sw	zero,-56(s0)
     5ee:	fc842703          	lw	a4,-56(s0)
     5f2:	2701                	sext.w	a4,a4
     5f4:	009897b7          	lui	a5,0x989
     5f8:	67f78793          	addi	a5,a5,1663 # 98967f <base+0x987587>
     5fc:	00e7cd63          	blt	a5,a4,616 <pipe_deadlock_demo+0xa0>
     600:	873e                	mv	a4,a5
     602:	fc842783          	lw	a5,-56(s0)
     606:	2785                	addiw	a5,a5,1
     608:	fcf42423          	sw	a5,-56(s0)
     60c:	fc842783          	lw	a5,-56(s0)
     610:	2781                	sext.w	a5,a5
     612:	fef758e3          	bge	a4,a5,602 <pipe_deadlock_demo+0x8c>
  ;
  printf("Parent: circular wait detected; stopping children\n");
     616:	00001517          	auipc	a0,0x1
     61a:	d8250513          	addi	a0,a0,-638 # 1398 <malloc+0x37e>
     61e:	145000ef          	jal	f62 <printf>

  kill(pidA);
     622:	8526                	mv	a0,s1
     624:	4e8000ef          	jal	b0c <kill>
  kill(pidB);
     628:	854a                	mv	a0,s2
     62a:	4e2000ef          	jal	b0c <kill>
  wait(0);
     62e:	4501                	li	a0,0
     630:	4b4000ef          	jal	ae4 <wait>
  wait(0);
     634:	4501                	li	a0,0
     636:	4ae000ef          	jal	ae4 <wait>

  printf("Actual-process deadlock demo completed.\n");
     63a:	00001517          	auipc	a0,0x1
     63e:	d9650513          	addi	a0,a0,-618 # 13d0 <malloc+0x3b6>
     642:	121000ef          	jal	f62 <printf>
     646:	74a2                	ld	s1,40(sp)
     648:	7902                	ld	s2,32(sp)
     64a:	a039                	j	658 <pipe_deadlock_demo+0xe2>
    printf("Pipe creation failed\n");
     64c:	00001517          	auipc	a0,0x1
     650:	cc450513          	addi	a0,a0,-828 # 1310 <malloc+0x2f6>
     654:	10f000ef          	jal	f62 <printf>
}
     658:	70e2                	ld	ra,56(sp)
     65a:	7442                	ld	s0,48(sp)
     65c:	6121                	addi	sp,sp,64
     65e:	8082                	ret
    printf("Fork A failed\n");
     660:	00001517          	auipc	a0,0x1
     664:	cc850513          	addi	a0,a0,-824 # 1328 <malloc+0x30e>
     668:	0fb000ef          	jal	f62 <printf>
    close(p1[0]); close(p1[1]);
     66c:	fd842503          	lw	a0,-40(s0)
     670:	494000ef          	jal	b04 <close>
     674:	fdc42503          	lw	a0,-36(s0)
     678:	48c000ef          	jal	b04 <close>
    close(p2[0]); close(p2[1]);
     67c:	fd042503          	lw	a0,-48(s0)
     680:	484000ef          	jal	b04 <close>
     684:	fd442503          	lw	a0,-44(s0)
     688:	47c000ef          	jal	b04 <close>
    return;
     68c:	74a2                	ld	s1,40(sp)
     68e:	b7e9                	j	658 <pipe_deadlock_demo+0xe2>
    close(p1[0]);
     690:	fd842503          	lw	a0,-40(s0)
     694:	470000ef          	jal	b04 <close>
    close(p2[1]);
     698:	fd442503          	lw	a0,-44(s0)
     69c:	468000ef          	jal	b04 <close>
    printf("Child A: waiting to read from Pipe2\n");
     6a0:	00001517          	auipc	a0,0x1
     6a4:	c9850513          	addi	a0,a0,-872 # 1338 <malloc+0x31e>
     6a8:	0bb000ef          	jal	f62 <printf>
    read(p2[0], &c, 1);
     6ac:	4605                	li	a2,1
     6ae:	fcf40593          	addi	a1,s0,-49
     6b2:	fd042503          	lw	a0,-48(s0)
     6b6:	43e000ef          	jal	af4 <read>
    close(p2[0]);
     6ba:	fd042503          	lw	a0,-48(s0)
     6be:	446000ef          	jal	b04 <close>
    close(p1[1]);
     6c2:	fdc42503          	lw	a0,-36(s0)
     6c6:	43e000ef          	jal	b04 <close>
    exit(0);
     6ca:	4501                	li	a0,0
     6cc:	410000ef          	jal	adc <exit>
    printf("Fork B failed\n");
     6d0:	00001517          	auipc	a0,0x1
     6d4:	c9050513          	addi	a0,a0,-880 # 1360 <malloc+0x346>
     6d8:	08b000ef          	jal	f62 <printf>
    kill(pidA);
     6dc:	8526                	mv	a0,s1
     6de:	42e000ef          	jal	b0c <kill>
    close(p1[0]); close(p1[1]);
     6e2:	fd842503          	lw	a0,-40(s0)
     6e6:	41e000ef          	jal	b04 <close>
     6ea:	fdc42503          	lw	a0,-36(s0)
     6ee:	416000ef          	jal	b04 <close>
    close(p2[0]); close(p2[1]);
     6f2:	fd042503          	lw	a0,-48(s0)
     6f6:	40e000ef          	jal	b04 <close>
     6fa:	fd442503          	lw	a0,-44(s0)
     6fe:	406000ef          	jal	b04 <close>
    wait(0);
     702:	4501                	li	a0,0
     704:	3e0000ef          	jal	ae4 <wait>
    return;
     708:	74a2                	ld	s1,40(sp)
     70a:	7902                	ld	s2,32(sp)
     70c:	b7b1                	j	658 <pipe_deadlock_demo+0xe2>
    close(p1[1]);
     70e:	fdc42503          	lw	a0,-36(s0)
     712:	3f2000ef          	jal	b04 <close>
    close(p2[0]);
     716:	fd042503          	lw	a0,-48(s0)
     71a:	3ea000ef          	jal	b04 <close>
    printf("Child B: waiting to read from Pipe1\n");
     71e:	00001517          	auipc	a0,0x1
     722:	c5250513          	addi	a0,a0,-942 # 1370 <malloc+0x356>
     726:	03d000ef          	jal	f62 <printf>
    read(p1[0], &c, 1);
     72a:	4605                	li	a2,1
     72c:	fcf40593          	addi	a1,s0,-49
     730:	fd842503          	lw	a0,-40(s0)
     734:	3c0000ef          	jal	af4 <read>
    close(p1[0]);
     738:	fd842503          	lw	a0,-40(s0)
     73c:	3c8000ef          	jal	b04 <close>
    close(p2[1]);
     740:	fd442503          	lw	a0,-44(s0)
     744:	3c0000ef          	jal	b04 <close>
    exit(0);
     748:	4501                	li	a0,0
     74a:	392000ef          	jal	adc <exit>

000000000000074e <main>:

int main(void)
{
     74e:	7135                	addi	sp,sp,-160
     750:	ed06                	sd	ra,152(sp)
     752:	e922                	sd	s0,144(sp)
     754:	1100                	addi	s0,sp,160
  
  int deadlock_request[N][M] = {
     756:	00001797          	auipc	a5,0x1
     75a:	d8278793          	addi	a5,a5,-638 # 14d8 <malloc+0x4be>
     75e:	0507b883          	ld	a7,80(a5)
     762:	0587b803          	ld	a6,88(a5)
     766:	73a8                	ld	a0,96(a5)
     768:	77ac                	ld	a1,104(a5)
     76a:	7bb0                	ld	a2,112(a5)
     76c:	7fb4                	ld	a3,120(a5)
     76e:	fb143823          	sd	a7,-80(s0)
     772:	fb043c23          	sd	a6,-72(s0)
     776:	fca43023          	sd	a0,-64(s0)
     77a:	fcb43423          	sd	a1,-56(s0)
     77e:	fcc43823          	sd	a2,-48(s0)
     782:	fcd43c23          	sd	a3,-40(s0)
     786:	63d8                	ld	a4,128(a5)
     788:	fee43023          	sd	a4,-32(s0)
     78c:	0887a783          	lw	a5,136(a5)
     790:	fef42423          	sw	a5,-24(s0)
    {0, 1, 0},
    {0, 0, 1},
    {0, 0, 0},
    {0, 0, 0}
  };
  int deadlock_alloc[N][M] = {
     794:	f7143823          	sd	a7,-144(s0)
     798:	f7043c23          	sd	a6,-136(s0)
     79c:	f8a43023          	sd	a0,-128(s0)
     7a0:	f8b43423          	sd	a1,-120(s0)
     7a4:	f8c43823          	sd	a2,-112(s0)
     7a8:	f8d43c23          	sd	a3,-104(s0)
     7ac:	fae43023          	sd	a4,-96(s0)
     7b0:	faf42423          	sw	a5,-88(s0)
    {0, 1, 0},
    {0, 0, 1},
    {0, 0, 0},
    {0, 0, 0}
  };
  int deadlock_avail[M] = {0, 0, 0};
     7b4:	f6042023          	sw	zero,-160(s0)
     7b8:	f6042223          	sw	zero,-156(s0)
     7bc:	f6042423          	sw	zero,-152(s0)

  printf("\n=== Q3: Deadlock Detection and Avoidance ===\n");
     7c0:	00001517          	auipc	a0,0x1
     7c4:	c4050513          	addi	a0,a0,-960 # 1400 <malloc+0x3e6>
     7c8:	79a000ef          	jal	f62 <printf>

  calculate_need();
     7cc:	887ff0ef          	jal	52 <calculate_need>
  print_matrices();
     7d0:	905ff0ef          	jal	d4 <print_matrices>

  printf("\n=== Test 1: Banker's Safe-State Test ===\n");
     7d4:	00001517          	auipc	a0,0x1
     7d8:	c5c50513          	addi	a0,a0,-932 # 1430 <malloc+0x416>
     7dc:	786000ef          	jal	f62 <printf>
  safe_state();
     7e0:	97dff0ef          	jal	15c <safe_state>

  printf("\n=== Test 2: Deadlock Detection ===\n");
     7e4:	00001517          	auipc	a0,0x1
     7e8:	c7c50513          	addi	a0,a0,-900 # 1460 <malloc+0x446>
     7ec:	776000ef          	jal	f62 <printf>
  detect_deadlock(deadlock_alloc, deadlock_request, deadlock_avail);
     7f0:	f6040613          	addi	a2,s0,-160
     7f4:	fb040593          	addi	a1,s0,-80
     7f8:	f7040513          	addi	a0,s0,-144
     7fc:	a85ff0ef          	jal	280 <detect_deadlock>

  printf("\n=== Test 3: Unsafe Request ===\n");
     800:	00001517          	auipc	a0,0x1
     804:	c8850513          	addi	a0,a0,-888 # 1488 <malloc+0x46e>
     808:	75a000ef          	jal	f62 <printf>
  unsafe_request_test();
     80c:	bcfff0ef          	jal	3da <unsafe_request_test>
  pipe_deadlock_demo();
     810:	d67ff0ef          	jal	576 <pipe_deadlock_demo>
  printf("\nQ3 matrix tests completed.\n");
     814:	00001517          	auipc	a0,0x1
     818:	c9c50513          	addi	a0,a0,-868 # 14b0 <malloc+0x496>
     81c:	746000ef          	jal	f62 <printf>
  exit(0);
     820:	4501                	li	a0,0
     822:	2ba000ef          	jal	adc <exit>

0000000000000826 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
     826:	1141                	addi	sp,sp,-16
     828:	e406                	sd	ra,8(sp)
     82a:	e022                	sd	s0,0(sp)
     82c:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
     82e:	f21ff0ef          	jal	74e <main>
  exit(r);
     832:	2aa000ef          	jal	adc <exit>

0000000000000836 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
     836:	1141                	addi	sp,sp,-16
     838:	e406                	sd	ra,8(sp)
     83a:	e022                	sd	s0,0(sp)
     83c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
     83e:	87aa                	mv	a5,a0
     840:	0585                	addi	a1,a1,1
     842:	0785                	addi	a5,a5,1
     844:	fff5c703          	lbu	a4,-1(a1)
     848:	fee78fa3          	sb	a4,-1(a5)
     84c:	fb75                	bnez	a4,840 <strcpy+0xa>
    ;
  return os;
}
     84e:	60a2                	ld	ra,8(sp)
     850:	6402                	ld	s0,0(sp)
     852:	0141                	addi	sp,sp,16
     854:	8082                	ret

0000000000000856 <strcmp>:

int
strcmp(const char *p, const char *q)
{
     856:	1141                	addi	sp,sp,-16
     858:	e406                	sd	ra,8(sp)
     85a:	e022                	sd	s0,0(sp)
     85c:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
     85e:	00054783          	lbu	a5,0(a0)
     862:	cb91                	beqz	a5,876 <strcmp+0x20>
     864:	0005c703          	lbu	a4,0(a1)
     868:	00f71763          	bne	a4,a5,876 <strcmp+0x20>
    p++, q++;
     86c:	0505                	addi	a0,a0,1
     86e:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
     870:	00054783          	lbu	a5,0(a0)
     874:	fbe5                	bnez	a5,864 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
     876:	0005c503          	lbu	a0,0(a1)
}
     87a:	40a7853b          	subw	a0,a5,a0
     87e:	60a2                	ld	ra,8(sp)
     880:	6402                	ld	s0,0(sp)
     882:	0141                	addi	sp,sp,16
     884:	8082                	ret

0000000000000886 <strlen>:

uint
strlen(const char *s)
{
     886:	1141                	addi	sp,sp,-16
     888:	e406                	sd	ra,8(sp)
     88a:	e022                	sd	s0,0(sp)
     88c:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
     88e:	00054783          	lbu	a5,0(a0)
     892:	cf91                	beqz	a5,8ae <strlen+0x28>
     894:	00150793          	addi	a5,a0,1
     898:	86be                	mv	a3,a5
     89a:	0785                	addi	a5,a5,1
     89c:	fff7c703          	lbu	a4,-1(a5)
     8a0:	ff65                	bnez	a4,898 <strlen+0x12>
     8a2:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
     8a6:	60a2                	ld	ra,8(sp)
     8a8:	6402                	ld	s0,0(sp)
     8aa:	0141                	addi	sp,sp,16
     8ac:	8082                	ret
  for (n = 0; s[n]; n++)
     8ae:	4501                	li	a0,0
     8b0:	bfdd                	j	8a6 <strlen+0x20>

00000000000008b2 <memset>:

void *
memset(void *dst, int c, uint n)
{
     8b2:	1141                	addi	sp,sp,-16
     8b4:	e406                	sd	ra,8(sp)
     8b6:	e022                	sd	s0,0(sp)
     8b8:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
     8ba:	ca19                	beqz	a2,8d0 <memset+0x1e>
     8bc:	87aa                	mv	a5,a0
     8be:	1602                	slli	a2,a2,0x20
     8c0:	9201                	srli	a2,a2,0x20
     8c2:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
     8c6:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
     8ca:	0785                	addi	a5,a5,1
     8cc:	fee79de3          	bne	a5,a4,8c6 <memset+0x14>
  }
  return dst;
}
     8d0:	60a2                	ld	ra,8(sp)
     8d2:	6402                	ld	s0,0(sp)
     8d4:	0141                	addi	sp,sp,16
     8d6:	8082                	ret

00000000000008d8 <strchr>:

char *
strchr(const char *s, char c)
{
     8d8:	1141                	addi	sp,sp,-16
     8da:	e406                	sd	ra,8(sp)
     8dc:	e022                	sd	s0,0(sp)
     8de:	0800                	addi	s0,sp,16
  for (; *s; s++)
     8e0:	00054783          	lbu	a5,0(a0)
     8e4:	cf81                	beqz	a5,8fc <strchr+0x24>
    if (*s == c)
     8e6:	00f58763          	beq	a1,a5,8f4 <strchr+0x1c>
  for (; *s; s++)
     8ea:	0505                	addi	a0,a0,1
     8ec:	00054783          	lbu	a5,0(a0)
     8f0:	fbfd                	bnez	a5,8e6 <strchr+0xe>
      return (char *)s;
  return 0;
     8f2:	4501                	li	a0,0
}
     8f4:	60a2                	ld	ra,8(sp)
     8f6:	6402                	ld	s0,0(sp)
     8f8:	0141                	addi	sp,sp,16
     8fa:	8082                	ret
  return 0;
     8fc:	4501                	li	a0,0
     8fe:	bfdd                	j	8f4 <strchr+0x1c>

0000000000000900 <gets>:

char *
gets(char *buf, int max)
{
     900:	711d                	addi	sp,sp,-96
     902:	ec86                	sd	ra,88(sp)
     904:	e8a2                	sd	s0,80(sp)
     906:	e4a6                	sd	s1,72(sp)
     908:	e0ca                	sd	s2,64(sp)
     90a:	fc4e                	sd	s3,56(sp)
     90c:	f852                	sd	s4,48(sp)
     90e:	f456                	sd	s5,40(sp)
     910:	f05a                	sd	s6,32(sp)
     912:	ec5e                	sd	s7,24(sp)
     914:	e862                	sd	s8,16(sp)
     916:	1080                	addi	s0,sp,96
     918:	8baa                	mv	s7,a0
     91a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
     91c:	892a                	mv	s2,a0
     91e:	4481                	li	s1,0
    cc = read(0, &c, 1);
     920:	faf40b13          	addi	s6,s0,-81
     924:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
     926:	8c26                	mv	s8,s1
     928:	0014899b          	addiw	s3,s1,1
     92c:	84ce                	mv	s1,s3
     92e:	0349d463          	bge	s3,s4,956 <gets+0x56>
    cc = read(0, &c, 1);
     932:	8656                	mv	a2,s5
     934:	85da                	mv	a1,s6
     936:	4501                	li	a0,0
     938:	1bc000ef          	jal	af4 <read>
    if (cc < 1)
     93c:	00a05d63          	blez	a0,956 <gets+0x56>
      break;
    buf[i++] = c;
     940:	faf44783          	lbu	a5,-81(s0)
     944:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
     948:	0905                	addi	s2,s2,1
     94a:	ff678713          	addi	a4,a5,-10
     94e:	c319                	beqz	a4,954 <gets+0x54>
     950:	17cd                	addi	a5,a5,-13
     952:	fbf1                	bnez	a5,926 <gets+0x26>
    buf[i++] = c;
     954:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
     956:	9c5e                	add	s8,s8,s7
     958:	000c0023          	sb	zero,0(s8)
  return buf;
}
     95c:	855e                	mv	a0,s7
     95e:	60e6                	ld	ra,88(sp)
     960:	6446                	ld	s0,80(sp)
     962:	64a6                	ld	s1,72(sp)
     964:	6906                	ld	s2,64(sp)
     966:	79e2                	ld	s3,56(sp)
     968:	7a42                	ld	s4,48(sp)
     96a:	7aa2                	ld	s5,40(sp)
     96c:	7b02                	ld	s6,32(sp)
     96e:	6be2                	ld	s7,24(sp)
     970:	6c42                	ld	s8,16(sp)
     972:	6125                	addi	sp,sp,96
     974:	8082                	ret

0000000000000976 <stat>:

int
stat(const char *n, struct stat *st)
{
     976:	1101                	addi	sp,sp,-32
     978:	ec06                	sd	ra,24(sp)
     97a:	e822                	sd	s0,16(sp)
     97c:	e04a                	sd	s2,0(sp)
     97e:	1000                	addi	s0,sp,32
     980:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     982:	4581                	li	a1,0
     984:	198000ef          	jal	b1c <open>
  if (fd < 0)
     988:	02054263          	bltz	a0,9ac <stat+0x36>
     98c:	e426                	sd	s1,8(sp)
     98e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
     990:	85ca                	mv	a1,s2
     992:	1a2000ef          	jal	b34 <fstat>
     996:	892a                	mv	s2,a0
  close(fd);
     998:	8526                	mv	a0,s1
     99a:	16a000ef          	jal	b04 <close>
  return r;
     99e:	64a2                	ld	s1,8(sp)
}
     9a0:	854a                	mv	a0,s2
     9a2:	60e2                	ld	ra,24(sp)
     9a4:	6442                	ld	s0,16(sp)
     9a6:	6902                	ld	s2,0(sp)
     9a8:	6105                	addi	sp,sp,32
     9aa:	8082                	ret
    return -1;
     9ac:	57fd                	li	a5,-1
     9ae:	893e                	mv	s2,a5
     9b0:	bfc5                	j	9a0 <stat+0x2a>

00000000000009b2 <atoi>:

int
atoi(const char *s)
{
     9b2:	1141                	addi	sp,sp,-16
     9b4:	e406                	sd	ra,8(sp)
     9b6:	e022                	sd	s0,0(sp)
     9b8:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
     9ba:	00054683          	lbu	a3,0(a0)
     9be:	fd06879b          	addiw	a5,a3,-48
     9c2:	0ff7f793          	zext.b	a5,a5
     9c6:	4625                	li	a2,9
     9c8:	02f66963          	bltu	a2,a5,9fa <atoi+0x48>
     9cc:	872a                	mv	a4,a0
  n = 0;
     9ce:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
     9d0:	0705                	addi	a4,a4,1
     9d2:	0025179b          	slliw	a5,a0,0x2
     9d6:	9fa9                	addw	a5,a5,a0
     9d8:	0017979b          	slliw	a5,a5,0x1
     9dc:	9fb5                	addw	a5,a5,a3
     9de:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
     9e2:	00074683          	lbu	a3,0(a4)
     9e6:	fd06879b          	addiw	a5,a3,-48
     9ea:	0ff7f793          	zext.b	a5,a5
     9ee:	fef671e3          	bgeu	a2,a5,9d0 <atoi+0x1e>
  return n;
}
     9f2:	60a2                	ld	ra,8(sp)
     9f4:	6402                	ld	s0,0(sp)
     9f6:	0141                	addi	sp,sp,16
     9f8:	8082                	ret
  n = 0;
     9fa:	4501                	li	a0,0
     9fc:	bfdd                	j	9f2 <atoi+0x40>

00000000000009fe <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
     9fe:	1141                	addi	sp,sp,-16
     a00:	e406                	sd	ra,8(sp)
     a02:	e022                	sd	s0,0(sp)
     a04:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     a06:	02b57563          	bgeu	a0,a1,a30 <memmove+0x32>
    while (n-- > 0)
     a0a:	00c05f63          	blez	a2,a28 <memmove+0x2a>
     a0e:	1602                	slli	a2,a2,0x20
     a10:	9201                	srli	a2,a2,0x20
     a12:	00c507b3          	add	a5,a0,a2
  dst = vdst;
     a16:	872a                	mv	a4,a0
      *dst++ = *src++;
     a18:	0585                	addi	a1,a1,1
     a1a:	0705                	addi	a4,a4,1
     a1c:	fff5c683          	lbu	a3,-1(a1)
     a20:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
     a24:	fee79ae3          	bne	a5,a4,a18 <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
     a28:	60a2                	ld	ra,8(sp)
     a2a:	6402                	ld	s0,0(sp)
     a2c:	0141                	addi	sp,sp,16
     a2e:	8082                	ret
    while (n-- > 0)
     a30:	fec05ce3          	blez	a2,a28 <memmove+0x2a>
    dst += n;
     a34:	00c50733          	add	a4,a0,a2
    src += n;
     a38:	95b2                	add	a1,a1,a2
     a3a:	fff6079b          	addiw	a5,a2,-1
     a3e:	1782                	slli	a5,a5,0x20
     a40:	9381                	srli	a5,a5,0x20
     a42:	fff7c793          	not	a5,a5
     a46:	97ba                	add	a5,a5,a4
      *--dst = *--src;
     a48:	15fd                	addi	a1,a1,-1
     a4a:	177d                	addi	a4,a4,-1
     a4c:	0005c683          	lbu	a3,0(a1)
     a50:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
     a54:	fef71ae3          	bne	a4,a5,a48 <memmove+0x4a>
     a58:	bfc1                	j	a28 <memmove+0x2a>

0000000000000a5a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
     a5a:	1141                	addi	sp,sp,-16
     a5c:	e406                	sd	ra,8(sp)
     a5e:	e022                	sd	s0,0(sp)
     a60:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     a62:	c61d                	beqz	a2,a90 <memcmp+0x36>
     a64:	1602                	slli	a2,a2,0x20
     a66:	9201                	srli	a2,a2,0x20
     a68:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
     a6c:	00054783          	lbu	a5,0(a0)
     a70:	0005c703          	lbu	a4,0(a1)
     a74:	00e79863          	bne	a5,a4,a84 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
     a78:	0505                	addi	a0,a0,1
    p2++;
     a7a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
     a7c:	fed518e3          	bne	a0,a3,a6c <memcmp+0x12>
  }
  return 0;
     a80:	4501                	li	a0,0
     a82:	a019                	j	a88 <memcmp+0x2e>
      return *p1 - *p2;
     a84:	40e7853b          	subw	a0,a5,a4
}
     a88:	60a2                	ld	ra,8(sp)
     a8a:	6402                	ld	s0,0(sp)
     a8c:	0141                	addi	sp,sp,16
     a8e:	8082                	ret
  return 0;
     a90:	4501                	li	a0,0
     a92:	bfdd                	j	a88 <memcmp+0x2e>

0000000000000a94 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
     a94:	1141                	addi	sp,sp,-16
     a96:	e406                	sd	ra,8(sp)
     a98:	e022                	sd	s0,0(sp)
     a9a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
     a9c:	f63ff0ef          	jal	9fe <memmove>
}
     aa0:	60a2                	ld	ra,8(sp)
     aa2:	6402                	ld	s0,0(sp)
     aa4:	0141                	addi	sp,sp,16
     aa6:	8082                	ret

0000000000000aa8 <sbrk>:

char *
sbrk(int n)
{
     aa8:	1141                	addi	sp,sp,-16
     aaa:	e406                	sd	ra,8(sp)
     aac:	e022                	sd	s0,0(sp)
     aae:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
     ab0:	4585                	li	a1,1
     ab2:	0b2000ef          	jal	b64 <sys_sbrk>
}
     ab6:	60a2                	ld	ra,8(sp)
     ab8:	6402                	ld	s0,0(sp)
     aba:	0141                	addi	sp,sp,16
     abc:	8082                	ret

0000000000000abe <sbrklazy>:

char *
sbrklazy(int n)
{
     abe:	1141                	addi	sp,sp,-16
     ac0:	e406                	sd	ra,8(sp)
     ac2:	e022                	sd	s0,0(sp)
     ac4:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
     ac6:	4589                	li	a1,2
     ac8:	09c000ef          	jal	b64 <sys_sbrk>
}
     acc:	60a2                	ld	ra,8(sp)
     ace:	6402                	ld	s0,0(sp)
     ad0:	0141                	addi	sp,sp,16
     ad2:	8082                	ret

0000000000000ad4 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
     ad4:	4885                	li	a7,1
 ecall
     ad6:	00000073          	ecall
 ret
     ada:	8082                	ret

0000000000000adc <exit>:
.global exit
exit:
 li a7, SYS_exit
     adc:	4889                	li	a7,2
 ecall
     ade:	00000073          	ecall
 ret
     ae2:	8082                	ret

0000000000000ae4 <wait>:
.global wait
wait:
 li a7, SYS_wait
     ae4:	488d                	li	a7,3
 ecall
     ae6:	00000073          	ecall
 ret
     aea:	8082                	ret

0000000000000aec <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
     aec:	4891                	li	a7,4
 ecall
     aee:	00000073          	ecall
 ret
     af2:	8082                	ret

0000000000000af4 <read>:
.global read
read:
 li a7, SYS_read
     af4:	4895                	li	a7,5
 ecall
     af6:	00000073          	ecall
 ret
     afa:	8082                	ret

0000000000000afc <write>:
.global write
write:
 li a7, SYS_write
     afc:	48c1                	li	a7,16
 ecall
     afe:	00000073          	ecall
 ret
     b02:	8082                	ret

0000000000000b04 <close>:
.global close
close:
 li a7, SYS_close
     b04:	48d5                	li	a7,21
 ecall
     b06:	00000073          	ecall
 ret
     b0a:	8082                	ret

0000000000000b0c <kill>:
.global kill
kill:
 li a7, SYS_kill
     b0c:	4899                	li	a7,6
 ecall
     b0e:	00000073          	ecall
 ret
     b12:	8082                	ret

0000000000000b14 <exec>:
.global exec
exec:
 li a7, SYS_exec
     b14:	489d                	li	a7,7
 ecall
     b16:	00000073          	ecall
 ret
     b1a:	8082                	ret

0000000000000b1c <open>:
.global open
open:
 li a7, SYS_open
     b1c:	48bd                	li	a7,15
 ecall
     b1e:	00000073          	ecall
 ret
     b22:	8082                	ret

0000000000000b24 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
     b24:	48c5                	li	a7,17
 ecall
     b26:	00000073          	ecall
 ret
     b2a:	8082                	ret

0000000000000b2c <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
     b2c:	48c9                	li	a7,18
 ecall
     b2e:	00000073          	ecall
 ret
     b32:	8082                	ret

0000000000000b34 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
     b34:	48a1                	li	a7,8
 ecall
     b36:	00000073          	ecall
 ret
     b3a:	8082                	ret

0000000000000b3c <link>:
.global link
link:
 li a7, SYS_link
     b3c:	48cd                	li	a7,19
 ecall
     b3e:	00000073          	ecall
 ret
     b42:	8082                	ret

0000000000000b44 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
     b44:	48d1                	li	a7,20
 ecall
     b46:	00000073          	ecall
 ret
     b4a:	8082                	ret

0000000000000b4c <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
     b4c:	48a5                	li	a7,9
 ecall
     b4e:	00000073          	ecall
 ret
     b52:	8082                	ret

0000000000000b54 <dup>:
.global dup
dup:
 li a7, SYS_dup
     b54:	48a9                	li	a7,10
 ecall
     b56:	00000073          	ecall
 ret
     b5a:	8082                	ret

0000000000000b5c <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
     b5c:	48ad                	li	a7,11
 ecall
     b5e:	00000073          	ecall
 ret
     b62:	8082                	ret

0000000000000b64 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
     b64:	48b1                	li	a7,12
 ecall
     b66:	00000073          	ecall
 ret
     b6a:	8082                	ret

0000000000000b6c <pause>:
.global pause
pause:
 li a7, SYS_pause
     b6c:	48b5                	li	a7,13
 ecall
     b6e:	00000073          	ecall
 ret
     b72:	8082                	ret

0000000000000b74 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
     b74:	48b9                	li	a7,14
 ecall
     b76:	00000073          	ecall
 ret
     b7a:	8082                	ret

0000000000000b7c <sync>:
.global sync
sync:
 li a7, SYS_sync
     b7c:	48d9                	li	a7,22
 ecall
     b7e:	00000073          	ecall
 ret
     b82:	8082                	ret

0000000000000b84 <clone>:
.global clone
clone:
 li a7, SYS_clone
     b84:	48dd                	li	a7,23
 ecall
     b86:	00000073          	ecall
 ret
     b8a:	8082                	ret

0000000000000b8c <join>:
.global join
join:
 li a7, SYS_join
     b8c:	48e1                	li	a7,24
 ecall
     b8e:	00000073          	ecall
 ret
     b92:	8082                	ret

0000000000000b94 <sem_init>:
.global sem_init
sem_init:
 li a7, SYS_sem_init
     b94:	48e5                	li	a7,25
 ecall
     b96:	00000073          	ecall
 ret
     b9a:	8082                	ret

0000000000000b9c <sem_wait>:
.global sem_wait
sem_wait:
 li a7, SYS_sem_wait
     b9c:	48e9                	li	a7,26
 ecall
     b9e:	00000073          	ecall
 ret
     ba2:	8082                	ret

0000000000000ba4 <sem_signal>:
.global sem_signal
sem_signal:
 li a7, SYS_sem_signal
     ba4:	48ed                	li	a7,27
 ecall
     ba6:	00000073          	ecall
 ret
     baa:	8082                	ret

0000000000000bac <set_priority>:
.global set_priority
set_priority:
 li a7, SYS_set_priority
     bac:	48f1                	li	a7,28
 ecall
     bae:	00000073          	ecall
 ret
     bb2:	8082                	ret

0000000000000bb4 <get_priority>:
.global get_priority
get_priority:
 li a7, SYS_get_priority
     bb4:	48f5                	li	a7,29
 ecall
     bb6:	00000073          	ecall
 ret
     bba:	8082                	ret

0000000000000bbc <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
     bbc:	1101                	addi	sp,sp,-32
     bbe:	ec06                	sd	ra,24(sp)
     bc0:	e822                	sd	s0,16(sp)
     bc2:	1000                	addi	s0,sp,32
     bc4:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
     bc8:	4605                	li	a2,1
     bca:	fef40593          	addi	a1,s0,-17
     bce:	f2fff0ef          	jal	afc <write>
}
     bd2:	60e2                	ld	ra,24(sp)
     bd4:	6442                	ld	s0,16(sp)
     bd6:	6105                	addi	sp,sp,32
     bd8:	8082                	ret

0000000000000bda <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
     bda:	715d                	addi	sp,sp,-80
     bdc:	e486                	sd	ra,72(sp)
     bde:	e0a2                	sd	s0,64(sp)
     be0:	f84a                	sd	s2,48(sp)
     be2:	f44e                	sd	s3,40(sp)
     be4:	0880                	addi	s0,sp,80
     be6:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
     be8:	c6d1                	beqz	a3,c74 <printint+0x9a>
     bea:	0805d563          	bgez	a1,c74 <printint+0x9a>
    neg = 1;
    x = -xx;
     bee:	40b005b3          	neg	a1,a1
    neg = 1;
     bf2:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
     bf4:	fb840993          	addi	s3,s0,-72
  neg = 0;
     bf8:	86ce                	mv	a3,s3
  i = 0;
     bfa:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
     bfc:	00001817          	auipc	a6,0x1
     c00:	96c80813          	addi	a6,a6,-1684 # 1568 <digits>
     c04:	88ba                	mv	a7,a4
     c06:	0017051b          	addiw	a0,a4,1
     c0a:	872a                	mv	a4,a0
     c0c:	02c5f7b3          	remu	a5,a1,a2
     c10:	97c2                	add	a5,a5,a6
     c12:	0007c783          	lbu	a5,0(a5)
     c16:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
     c1a:	87ae                	mv	a5,a1
     c1c:	02c5d5b3          	divu	a1,a1,a2
     c20:	0685                	addi	a3,a3,1
     c22:	fec7f1e3          	bgeu	a5,a2,c04 <printint+0x2a>
  if (neg)
     c26:	00030c63          	beqz	t1,c3e <printint+0x64>
    buf[i++] = '-';
     c2a:	fd050793          	addi	a5,a0,-48
     c2e:	00878533          	add	a0,a5,s0
     c32:	02d00793          	li	a5,45
     c36:	fef50423          	sb	a5,-24(a0)
     c3a:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
     c3e:	02e05563          	blez	a4,c68 <printint+0x8e>
     c42:	fc26                	sd	s1,56(sp)
     c44:	377d                	addiw	a4,a4,-1
     c46:	00e984b3          	add	s1,s3,a4
     c4a:	19fd                	addi	s3,s3,-1
     c4c:	99ba                	add	s3,s3,a4
     c4e:	1702                	slli	a4,a4,0x20
     c50:	9301                	srli	a4,a4,0x20
     c52:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
     c56:	0004c583          	lbu	a1,0(s1)
     c5a:	854a                	mv	a0,s2
     c5c:	f61ff0ef          	jal	bbc <putc>
  while (--i >= 0)
     c60:	14fd                	addi	s1,s1,-1
     c62:	ff349ae3          	bne	s1,s3,c56 <printint+0x7c>
     c66:	74e2                	ld	s1,56(sp)
}
     c68:	60a6                	ld	ra,72(sp)
     c6a:	6406                	ld	s0,64(sp)
     c6c:	7942                	ld	s2,48(sp)
     c6e:	79a2                	ld	s3,40(sp)
     c70:	6161                	addi	sp,sp,80
     c72:	8082                	ret
  neg = 0;
     c74:	4301                	li	t1,0
     c76:	bfbd                	j	bf4 <printint+0x1a>

0000000000000c78 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
     c78:	711d                	addi	sp,sp,-96
     c7a:	ec86                	sd	ra,88(sp)
     c7c:	e8a2                	sd	s0,80(sp)
     c7e:	e4a6                	sd	s1,72(sp)
     c80:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
     c82:	0005c483          	lbu	s1,0(a1)
     c86:	22048363          	beqz	s1,eac <vprintf+0x234>
     c8a:	e0ca                	sd	s2,64(sp)
     c8c:	fc4e                	sd	s3,56(sp)
     c8e:	f852                	sd	s4,48(sp)
     c90:	f456                	sd	s5,40(sp)
     c92:	f05a                	sd	s6,32(sp)
     c94:	ec5e                	sd	s7,24(sp)
     c96:	e862                	sd	s8,16(sp)
     c98:	8b2a                	mv	s6,a0
     c9a:	8a2e                	mv	s4,a1
     c9c:	8bb2                	mv	s7,a2
  state = 0;
     c9e:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
     ca0:	4901                	li	s2,0
     ca2:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
     ca4:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
     ca8:	06400c13          	li	s8,100
     cac:	a00d                	j	cce <vprintf+0x56>
        putc(fd, c0);
     cae:	85a6                	mv	a1,s1
     cb0:	855a                	mv	a0,s6
     cb2:	f0bff0ef          	jal	bbc <putc>
     cb6:	a019                	j	cbc <vprintf+0x44>
    } else if (state == '%') {
     cb8:	03598363          	beq	s3,s5,cde <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
     cbc:	0019079b          	addiw	a5,s2,1
     cc0:	893e                	mv	s2,a5
     cc2:	873e                	mv	a4,a5
     cc4:	97d2                	add	a5,a5,s4
     cc6:	0007c483          	lbu	s1,0(a5)
     cca:	1c048a63          	beqz	s1,e9e <vprintf+0x226>
    c0 = fmt[i] & 0xff;
     cce:	0004879b          	sext.w	a5,s1
    if (state == 0) {
     cd2:	fe0993e3          	bnez	s3,cb8 <vprintf+0x40>
      if (c0 == '%') {
     cd6:	fd579ce3          	bne	a5,s5,cae <vprintf+0x36>
        state = '%';
     cda:	89be                	mv	s3,a5
     cdc:	b7c5                	j	cbc <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
     cde:	00ea06b3          	add	a3,s4,a4
     ce2:	0016c603          	lbu	a2,1(a3)
      if (c1)
     ce6:	1c060863          	beqz	a2,eb6 <vprintf+0x23e>
      if (c0 == 'd') {
     cea:	03878763          	beq	a5,s8,d18 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
     cee:	f9478693          	addi	a3,a5,-108
     cf2:	0016b693          	seqz	a3,a3
     cf6:	f9c60593          	addi	a1,a2,-100
     cfa:	e99d                	bnez	a1,d30 <vprintf+0xb8>
     cfc:	ca95                	beqz	a3,d30 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
     cfe:	008b8493          	addi	s1,s7,8
     d02:	4685                	li	a3,1
     d04:	4629                	li	a2,10
     d06:	000bb583          	ld	a1,0(s7)
     d0a:	855a                	mv	a0,s6
     d0c:	ecfff0ef          	jal	bda <printint>
        i += 1;
     d10:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
     d12:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
     d14:	4981                	li	s3,0
     d16:	b75d                	j	cbc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
     d18:	008b8493          	addi	s1,s7,8
     d1c:	4685                	li	a3,1
     d1e:	4629                	li	a2,10
     d20:	000ba583          	lw	a1,0(s7)
     d24:	855a                	mv	a0,s6
     d26:	eb5ff0ef          	jal	bda <printint>
     d2a:	8ba6                	mv	s7,s1
      state = 0;
     d2c:	4981                	li	s3,0
     d2e:	b779                	j	cbc <vprintf+0x44>
        c2 = fmt[i + 2] & 0xff;
     d30:	9752                	add	a4,a4,s4
     d32:	00274583          	lbu	a1,2(a4)
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
     d36:	f9460713          	addi	a4,a2,-108
     d3a:	00173713          	seqz	a4,a4
     d3e:	8f75                	and	a4,a4,a3
     d40:	f9c58513          	addi	a0,a1,-100
     d44:	18051363          	bnez	a0,eca <vprintf+0x252>
     d48:	18070163          	beqz	a4,eca <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
     d4c:	008b8493          	addi	s1,s7,8
     d50:	4685                	li	a3,1
     d52:	4629                	li	a2,10
     d54:	000bb583          	ld	a1,0(s7)
     d58:	855a                	mv	a0,s6
     d5a:	e81ff0ef          	jal	bda <printint>
        i += 2;
     d5e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
     d60:	8ba6                	mv	s7,s1
      state = 0;
     d62:	4981                	li	s3,0
        i += 2;
     d64:	bfa1                	j	cbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
     d66:	008b8493          	addi	s1,s7,8
     d6a:	4681                	li	a3,0
     d6c:	4629                	li	a2,10
     d6e:	000be583          	lwu	a1,0(s7)
     d72:	855a                	mv	a0,s6
     d74:	e67ff0ef          	jal	bda <printint>
     d78:	8ba6                	mv	s7,s1
      state = 0;
     d7a:	4981                	li	s3,0
     d7c:	b781                	j	cbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     d7e:	008b8493          	addi	s1,s7,8
     d82:	4681                	li	a3,0
     d84:	4629                	li	a2,10
     d86:	000bb583          	ld	a1,0(s7)
     d8a:	855a                	mv	a0,s6
     d8c:	e4fff0ef          	jal	bda <printint>
        i += 1;
     d90:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
     d92:	8ba6                	mv	s7,s1
      state = 0;
     d94:	4981                	li	s3,0
     d96:	b71d                	j	cbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     d98:	008b8493          	addi	s1,s7,8
     d9c:	4681                	li	a3,0
     d9e:	4629                	li	a2,10
     da0:	000bb583          	ld	a1,0(s7)
     da4:	855a                	mv	a0,s6
     da6:	e35ff0ef          	jal	bda <printint>
        i += 2;
     daa:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
     dac:	8ba6                	mv	s7,s1
      state = 0;
     dae:	4981                	li	s3,0
        i += 2;
     db0:	b731                	j	cbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
     db2:	008b8493          	addi	s1,s7,8
     db6:	4681                	li	a3,0
     db8:	4641                	li	a2,16
     dba:	000be583          	lwu	a1,0(s7)
     dbe:	855a                	mv	a0,s6
     dc0:	e1bff0ef          	jal	bda <printint>
     dc4:	8ba6                	mv	s7,s1
      state = 0;
     dc6:	4981                	li	s3,0
     dc8:	bdd5                	j	cbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     dca:	008b8493          	addi	s1,s7,8
     dce:	4681                	li	a3,0
     dd0:	4641                	li	a2,16
     dd2:	000bb583          	ld	a1,0(s7)
     dd6:	855a                	mv	a0,s6
     dd8:	e03ff0ef          	jal	bda <printint>
        i += 1;
     ddc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
     dde:	8ba6                	mv	s7,s1
      state = 0;
     de0:	4981                	li	s3,0
     de2:	bde9                	j	cbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     de4:	008b8493          	addi	s1,s7,8
     de8:	4681                	li	a3,0
     dea:	4641                	li	a2,16
     dec:	000bb583          	ld	a1,0(s7)
     df0:	855a                	mv	a0,s6
     df2:	de9ff0ef          	jal	bda <printint>
        i += 2;
     df6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
     df8:	8ba6                	mv	s7,s1
      state = 0;
     dfa:	4981                	li	s3,0
        i += 2;
     dfc:	b5c1                	j	cbc <vprintf+0x44>
     dfe:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
     e00:	008b8793          	addi	a5,s7,8
     e04:	8cbe                	mv	s9,a5
     e06:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
     e0a:	03000593          	li	a1,48
     e0e:	855a                	mv	a0,s6
     e10:	dadff0ef          	jal	bbc <putc>
  putc(fd, 'x');
     e14:	07800593          	li	a1,120
     e18:	855a                	mv	a0,s6
     e1a:	da3ff0ef          	jal	bbc <putc>
     e1e:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     e20:	00000b97          	auipc	s7,0x0
     e24:	748b8b93          	addi	s7,s7,1864 # 1568 <digits>
     e28:	03c9d793          	srli	a5,s3,0x3c
     e2c:	97de                	add	a5,a5,s7
     e2e:	0007c583          	lbu	a1,0(a5)
     e32:	855a                	mv	a0,s6
     e34:	d89ff0ef          	jal	bbc <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     e38:	0992                	slli	s3,s3,0x4
     e3a:	34fd                	addiw	s1,s1,-1
     e3c:	f4f5                	bnez	s1,e28 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
     e3e:	8be6                	mv	s7,s9
      state = 0;
     e40:	4981                	li	s3,0
     e42:	6ca2                	ld	s9,8(sp)
     e44:	bda5                	j	cbc <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
     e46:	008b8493          	addi	s1,s7,8
     e4a:	000bc583          	lbu	a1,0(s7)
     e4e:	855a                	mv	a0,s6
     e50:	d6dff0ef          	jal	bbc <putc>
     e54:	8ba6                	mv	s7,s1
      state = 0;
     e56:	4981                	li	s3,0
     e58:	b595                	j	cbc <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
     e5a:	008b8993          	addi	s3,s7,8
     e5e:	000bb483          	ld	s1,0(s7)
     e62:	cc91                	beqz	s1,e7e <vprintf+0x206>
        for (; *s; s++)
     e64:	0004c583          	lbu	a1,0(s1)
     e68:	c985                	beqz	a1,e98 <vprintf+0x220>
          putc(fd, *s);
     e6a:	855a                	mv	a0,s6
     e6c:	d51ff0ef          	jal	bbc <putc>
        for (; *s; s++)
     e70:	0485                	addi	s1,s1,1
     e72:	0004c583          	lbu	a1,0(s1)
     e76:	f9f5                	bnez	a1,e6a <vprintf+0x1f2>
        if ((s = va_arg(ap, char *)) == 0)
     e78:	8bce                	mv	s7,s3
      state = 0;
     e7a:	4981                	li	s3,0
     e7c:	b581                	j	cbc <vprintf+0x44>
          s = "(null)";
     e7e:	00000497          	auipc	s1,0x0
     e82:	65248493          	addi	s1,s1,1618 # 14d0 <malloc+0x4b6>
        for (; *s; s++)
     e86:	02800593          	li	a1,40
     e8a:	b7c5                	j	e6a <vprintf+0x1f2>
        putc(fd, '%');
     e8c:	85be                	mv	a1,a5
     e8e:	855a                	mv	a0,s6
     e90:	d2dff0ef          	jal	bbc <putc>
      state = 0;
     e94:	4981                	li	s3,0
     e96:	b51d                	j	cbc <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
     e98:	8bce                	mv	s7,s3
      state = 0;
     e9a:	4981                	li	s3,0
     e9c:	b505                	j	cbc <vprintf+0x44>
     e9e:	6906                	ld	s2,64(sp)
     ea0:	79e2                	ld	s3,56(sp)
     ea2:	7a42                	ld	s4,48(sp)
     ea4:	7aa2                	ld	s5,40(sp)
     ea6:	7b02                	ld	s6,32(sp)
     ea8:	6be2                	ld	s7,24(sp)
     eaa:	6c42                	ld	s8,16(sp)
    }
  }
}
     eac:	60e6                	ld	ra,88(sp)
     eae:	6446                	ld	s0,80(sp)
     eb0:	64a6                	ld	s1,72(sp)
     eb2:	6125                	addi	sp,sp,96
     eb4:	8082                	ret
      if (c0 == 'd') {
     eb6:	06400713          	li	a4,100
     eba:	e4e78fe3          	beq	a5,a4,d18 <vprintf+0xa0>
      } else if (c0 == 'l' && c1 == 'd') {
     ebe:	f9478693          	addi	a3,a5,-108
     ec2:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
     ec6:	85b2                	mv	a1,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
     ec8:	4701                	li	a4,0
      } else if (c0 == 'u') {
     eca:	07500513          	li	a0,117
     ece:	e8a78ce3          	beq	a5,a0,d66 <vprintf+0xee>
      } else if (c0 == 'l' && c1 == 'u') {
     ed2:	f8b60513          	addi	a0,a2,-117
     ed6:	e119                	bnez	a0,edc <vprintf+0x264>
     ed8:	ea0693e3          	bnez	a3,d7e <vprintf+0x106>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
     edc:	f8b58513          	addi	a0,a1,-117
     ee0:	e119                	bnez	a0,ee6 <vprintf+0x26e>
     ee2:	ea071be3          	bnez	a4,d98 <vprintf+0x120>
      } else if (c0 == 'x') {
     ee6:	07800513          	li	a0,120
     eea:	eca784e3          	beq	a5,a0,db2 <vprintf+0x13a>
      } else if (c0 == 'l' && c1 == 'x') {
     eee:	f8860613          	addi	a2,a2,-120
     ef2:	e219                	bnez	a2,ef8 <vprintf+0x280>
     ef4:	ec069be3          	bnez	a3,dca <vprintf+0x152>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
     ef8:	f8858593          	addi	a1,a1,-120
     efc:	e199                	bnez	a1,f02 <vprintf+0x28a>
     efe:	ee0713e3          	bnez	a4,de4 <vprintf+0x16c>
      } else if (c0 == 'p') {
     f02:	07000713          	li	a4,112
     f06:	eee78ce3          	beq	a5,a4,dfe <vprintf+0x186>
      } else if (c0 == 'c') {
     f0a:	06300713          	li	a4,99
     f0e:	f2e78ce3          	beq	a5,a4,e46 <vprintf+0x1ce>
      } else if (c0 == 's') {
     f12:	07300713          	li	a4,115
     f16:	f4e782e3          	beq	a5,a4,e5a <vprintf+0x1e2>
      } else if (c0 == '%') {
     f1a:	02500713          	li	a4,37
     f1e:	f6e787e3          	beq	a5,a4,e8c <vprintf+0x214>
        putc(fd, '%');
     f22:	02500593          	li	a1,37
     f26:	855a                	mv	a0,s6
     f28:	c95ff0ef          	jal	bbc <putc>
        putc(fd, c0);
     f2c:	85a6                	mv	a1,s1
     f2e:	855a                	mv	a0,s6
     f30:	c8dff0ef          	jal	bbc <putc>
      state = 0;
     f34:	4981                	li	s3,0
     f36:	b359                	j	cbc <vprintf+0x44>

0000000000000f38 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
     f38:	715d                	addi	sp,sp,-80
     f3a:	ec06                	sd	ra,24(sp)
     f3c:	e822                	sd	s0,16(sp)
     f3e:	1000                	addi	s0,sp,32
     f40:	e010                	sd	a2,0(s0)
     f42:	e414                	sd	a3,8(s0)
     f44:	e818                	sd	a4,16(s0)
     f46:	ec1c                	sd	a5,24(s0)
     f48:	03043023          	sd	a6,32(s0)
     f4c:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
     f50:	8622                	mv	a2,s0
     f52:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
     f56:	d23ff0ef          	jal	c78 <vprintf>
}
     f5a:	60e2                	ld	ra,24(sp)
     f5c:	6442                	ld	s0,16(sp)
     f5e:	6161                	addi	sp,sp,80
     f60:	8082                	ret

0000000000000f62 <printf>:

void
printf(const char *fmt, ...)
{
     f62:	711d                	addi	sp,sp,-96
     f64:	ec06                	sd	ra,24(sp)
     f66:	e822                	sd	s0,16(sp)
     f68:	1000                	addi	s0,sp,32
     f6a:	e40c                	sd	a1,8(s0)
     f6c:	e810                	sd	a2,16(s0)
     f6e:	ec14                	sd	a3,24(s0)
     f70:	f018                	sd	a4,32(s0)
     f72:	f41c                	sd	a5,40(s0)
     f74:	03043823          	sd	a6,48(s0)
     f78:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
     f7c:	00840613          	addi	a2,s0,8
     f80:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
     f84:	85aa                	mv	a1,a0
     f86:	4505                	li	a0,1
     f88:	cf1ff0ef          	jal	c78 <vprintf>
}
     f8c:	60e2                	ld	ra,24(sp)
     f8e:	6442                	ld	s0,16(sp)
     f90:	6125                	addi	sp,sp,96
     f92:	8082                	ret

0000000000000f94 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
     f94:	1141                	addi	sp,sp,-16
     f96:	e406                	sd	ra,8(sp)
     f98:	e022                	sd	s0,0(sp)
     f9a:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
     f9c:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
     fa0:	00001797          	auipc	a5,0x1
     fa4:	0f07b783          	ld	a5,240(a5) # 2090 <freep>
     fa8:	a039                	j	fb6 <free+0x22>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
     faa:	6398                	ld	a4,0(a5)
     fac:	00e7e463          	bltu	a5,a4,fb4 <free+0x20>
     fb0:	00e6ea63          	bltu	a3,a4,fc4 <free+0x30>
{
     fb4:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
     fb6:	fed7fae3          	bgeu	a5,a3,faa <free+0x16>
     fba:	6398                	ld	a4,0(a5)
     fbc:	00e6e463          	bltu	a3,a4,fc4 <free+0x30>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
     fc0:	fee7eae3          	bltu	a5,a4,fb4 <free+0x20>
      break;
  if (bp + bp->s.size == p->s.ptr) {
     fc4:	ff852583          	lw	a1,-8(a0)
     fc8:	6390                	ld	a2,0(a5)
     fca:	02059813          	slli	a6,a1,0x20
     fce:	01c85713          	srli	a4,a6,0x1c
     fd2:	9736                	add	a4,a4,a3
     fd4:	02e60563          	beq	a2,a4,ffe <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
     fd8:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
     fdc:	4790                	lw	a2,8(a5)
     fde:	02061593          	slli	a1,a2,0x20
     fe2:	01c5d713          	srli	a4,a1,0x1c
     fe6:	973e                	add	a4,a4,a5
     fe8:	02e68263          	beq	a3,a4,100c <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
     fec:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
     fee:	00001717          	auipc	a4,0x1
     ff2:	0af73123          	sd	a5,162(a4) # 2090 <freep>
}
     ff6:	60a2                	ld	ra,8(sp)
     ff8:	6402                	ld	s0,0(sp)
     ffa:	0141                	addi	sp,sp,16
     ffc:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
     ffe:	4618                	lw	a4,8(a2)
    1000:	9f2d                	addw	a4,a4,a1
    1002:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    1006:	6398                	ld	a4,0(a5)
    1008:	6310                	ld	a2,0(a4)
    100a:	b7f9                	j	fd8 <free+0x44>
    p->s.size += bp->s.size;
    100c:	ff852703          	lw	a4,-8(a0)
    1010:	9f31                	addw	a4,a4,a2
    1012:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    1014:	ff053683          	ld	a3,-16(a0)
    1018:	bfd1                	j	fec <free+0x58>

000000000000101a <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
    101a:	7139                	addi	sp,sp,-64
    101c:	fc06                	sd	ra,56(sp)
    101e:	f822                	sd	s0,48(sp)
    1020:	f04a                	sd	s2,32(sp)
    1022:	ec4e                	sd	s3,24(sp)
    1024:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
    1026:	02051993          	slli	s3,a0,0x20
    102a:	0209d993          	srli	s3,s3,0x20
    102e:	09bd                	addi	s3,s3,15
    1030:	0049d993          	srli	s3,s3,0x4
    1034:	2985                	addiw	s3,s3,1
    1036:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
    1038:	00001517          	auipc	a0,0x1
    103c:	05853503          	ld	a0,88(a0) # 2090 <freep>
    1040:	c905                	beqz	a0,1070 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    1042:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    1044:	4798                	lw	a4,8(a5)
    1046:	09377663          	bgeu	a4,s3,10d2 <malloc+0xb8>
    104a:	f426                	sd	s1,40(sp)
    104c:	e852                	sd	s4,16(sp)
    104e:	e456                	sd	s5,8(sp)
    1050:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
    1052:	8a4e                	mv	s4,s3
    1054:	6705                	lui	a4,0x1
    1056:	00e9f363          	bgeu	s3,a4,105c <malloc+0x42>
    105a:	6a05                	lui	s4,0x1
    105c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    1060:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
    1064:	00001497          	auipc	s1,0x1
    1068:	02c48493          	addi	s1,s1,44 # 2090 <freep>
  if (p == SBRK_ERROR)
    106c:	5afd                	li	s5,-1
    106e:	a83d                	j	10ac <malloc+0x92>
    1070:	f426                	sd	s1,40(sp)
    1072:	e852                	sd	s4,16(sp)
    1074:	e456                	sd	s5,8(sp)
    1076:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    1078:	00001797          	auipc	a5,0x1
    107c:	08078793          	addi	a5,a5,128 # 20f8 <base>
    1080:	00001717          	auipc	a4,0x1
    1084:	00f73823          	sd	a5,16(a4) # 2090 <freep>
    1088:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    108a:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
    108e:	b7d1                	j	1052 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    1090:	6398                	ld	a4,0(a5)
    1092:	e118                	sd	a4,0(a0)
    1094:	a899                	j	10ea <malloc+0xd0>
  hp->s.size = nu;
    1096:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
    109a:	0541                	addi	a0,a0,16
    109c:	ef9ff0ef          	jal	f94 <free>
  return freep;
    10a0:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
    10a2:	c125                	beqz	a0,1102 <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    10a4:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    10a6:	4798                	lw	a4,8(a5)
    10a8:	03277163          	bgeu	a4,s2,10ca <malloc+0xb0>
    if (p == freep)
    10ac:	6098                	ld	a4,0(s1)
    10ae:	853e                	mv	a0,a5
    10b0:	fef71ae3          	bne	a4,a5,10a4 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    10b4:	8552                	mv	a0,s4
    10b6:	9f3ff0ef          	jal	aa8 <sbrk>
  if (p == SBRK_ERROR)
    10ba:	fd551ee3          	bne	a0,s5,1096 <malloc+0x7c>
        return 0;
    10be:	4501                	li	a0,0
    10c0:	74a2                	ld	s1,40(sp)
    10c2:	6a42                	ld	s4,16(sp)
    10c4:	6aa2                	ld	s5,8(sp)
    10c6:	6b02                	ld	s6,0(sp)
    10c8:	a03d                	j	10f6 <malloc+0xdc>
    10ca:	74a2                	ld	s1,40(sp)
    10cc:	6a42                	ld	s4,16(sp)
    10ce:	6aa2                	ld	s5,8(sp)
    10d0:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
    10d2:	fae90fe3          	beq	s2,a4,1090 <malloc+0x76>
        p->s.size -= nunits;
    10d6:	4137073b          	subw	a4,a4,s3
    10da:	c798                	sw	a4,8(a5)
        p += p->s.size;
    10dc:	02071693          	slli	a3,a4,0x20
    10e0:	01c6d713          	srli	a4,a3,0x1c
    10e4:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    10e6:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    10ea:	00001717          	auipc	a4,0x1
    10ee:	faa73323          	sd	a0,-90(a4) # 2090 <freep>
      return (void *)(p + 1);
    10f2:	01078513          	addi	a0,a5,16
  }
}
    10f6:	70e2                	ld	ra,56(sp)
    10f8:	7442                	ld	s0,48(sp)
    10fa:	7902                	ld	s2,32(sp)
    10fc:	69e2                	ld	s3,24(sp)
    10fe:	6121                	addi	sp,sp,64
    1100:	8082                	ret
    1102:	74a2                	ld	s1,40(sp)
    1104:	6a42                	ld	s4,16(sp)
    1106:	6aa2                	ld	s5,8(sp)
    1108:	6b02                	ld	s6,0(sp)
    110a:	b7f5                	j	10f6 <malloc+0xdc>
