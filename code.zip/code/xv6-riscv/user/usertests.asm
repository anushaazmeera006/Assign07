
user/_usertests:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <copyinstr1>:
}

// what if you pass ridiculous string pointers to system calls?
void
copyinstr1(char *s)
{
       0:	711d                	addi	sp,sp,-96
       2:	ec86                	sd	ra,88(sp)
       4:	e8a2                	sd	s0,80(sp)
       6:	e4a6                	sd	s1,72(sp)
       8:	e0ca                	sd	s2,64(sp)
       a:	fc4e                	sd	s3,56(sp)
       c:	f852                	sd	s4,48(sp)
       e:	1080                	addi	s0,sp,96
  uint64 addrs[] = {0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
      10:	00008797          	auipc	a5,0x8
      14:	2f878793          	addi	a5,a5,760 # 8308 <malloc+0x292e>
      18:	638c                	ld	a1,0(a5)
      1a:	6790                	ld	a2,8(a5)
      1c:	6b94                	ld	a3,16(a5)
      1e:	6f98                	ld	a4,24(a5)
      20:	fab43423          	sd	a1,-88(s0)
      24:	fac43823          	sd	a2,-80(s0)
      28:	fad43c23          	sd	a3,-72(s0)
      2c:	fce43023          	sd	a4,-64(s0)
      30:	739c                	ld	a5,32(a5)
      32:	fcf43423          	sd	a5,-56(s0)
                    0xffffffffffffffff};

  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
      36:	fa840493          	addi	s1,s0,-88
      3a:	fd040a13          	addi	s4,s0,-48
    uint64 addr = addrs[ai];

    int fd = open((char *)addr, O_CREATE | O_WRONLY);
      3e:	20100993          	li	s3,513
      42:	0004b903          	ld	s2,0(s1)
      46:	85ce                	mv	a1,s3
      48:	854a                	mv	a0,s2
      4a:	492050ef          	jal	54dc <open>
    if (fd >= 0) {
      4e:	00055d63          	bgez	a0,68 <copyinstr1+0x68>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
      52:	04a1                	addi	s1,s1,8
      54:	ff4497e3          	bne	s1,s4,42 <copyinstr1+0x42>
      printf("open(%p) returned %d, not -1\n", (void *)addr, fd);
      exit(1);
    }
  }
}
      58:	60e6                	ld	ra,88(sp)
      5a:	6446                	ld	s0,80(sp)
      5c:	64a6                	ld	s1,72(sp)
      5e:	6906                	ld	s2,64(sp)
      60:	79e2                	ld	s3,56(sp)
      62:	7a42                	ld	s4,48(sp)
      64:	6125                	addi	sp,sp,96
      66:	8082                	ret
      printf("open(%p) returned %d, not -1\n", (void *)addr, fd);
      68:	862a                	mv	a2,a0
      6a:	85ca                	mv	a1,s2
      6c:	00006517          	auipc	a0,0x6
      70:	a6450513          	addi	a0,a0,-1436 # 5ad0 <malloc+0xf6>
      74:	0af050ef          	jal	5922 <printf>
      exit(1);
      78:	4505                	li	a0,1
      7a:	422050ef          	jal	549c <exit>

000000000000007e <bsstest>:
void
bsstest(char *s)
{
  int i;

  for (i = 0; i < sizeof(uninit); i++) {
      7e:	0000b797          	auipc	a5,0xb
      82:	55a78793          	addi	a5,a5,1370 # b5d8 <uninit>
      86:	0000e697          	auipc	a3,0xe
      8a:	c6268693          	addi	a3,a3,-926 # dce8 <buf>
    if (uninit[i] != '\0') {
      8e:	0007c703          	lbu	a4,0(a5)
      92:	e709                	bnez	a4,9c <bsstest+0x1e>
  for (i = 0; i < sizeof(uninit); i++) {
      94:	0785                	addi	a5,a5,1
      96:	fed79ce3          	bne	a5,a3,8e <bsstest+0x10>
      9a:	8082                	ret
{
      9c:	1141                	addi	sp,sp,-16
      9e:	e406                	sd	ra,8(sp)
      a0:	e022                	sd	s0,0(sp)
      a2:	0800                	addi	s0,sp,16
      printf("%s: bss test failed\n", s);
      a4:	85aa                	mv	a1,a0
      a6:	00006517          	auipc	a0,0x6
      aa:	a4a50513          	addi	a0,a0,-1462 # 5af0 <malloc+0x116>
      ae:	075050ef          	jal	5922 <printf>
      exit(1);
      b2:	4505                	li	a0,1
      b4:	3e8050ef          	jal	549c <exit>

00000000000000b8 <opentest>:
{
      b8:	1101                	addi	sp,sp,-32
      ba:	ec06                	sd	ra,24(sp)
      bc:	e822                	sd	s0,16(sp)
      be:	e426                	sd	s1,8(sp)
      c0:	1000                	addi	s0,sp,32
      c2:	84aa                	mv	s1,a0
  fd = open("echo", 0);
      c4:	4581                	li	a1,0
      c6:	00006517          	auipc	a0,0x6
      ca:	a4250513          	addi	a0,a0,-1470 # 5b08 <malloc+0x12e>
      ce:	40e050ef          	jal	54dc <open>
  if (fd < 0) {
      d2:	02054263          	bltz	a0,f6 <opentest+0x3e>
  close(fd);
      d6:	3ee050ef          	jal	54c4 <close>
  fd = open("doesnotexist", 0);
      da:	4581                	li	a1,0
      dc:	00006517          	auipc	a0,0x6
      e0:	a4c50513          	addi	a0,a0,-1460 # 5b28 <malloc+0x14e>
      e4:	3f8050ef          	jal	54dc <open>
  if (fd >= 0) {
      e8:	02055163          	bgez	a0,10a <opentest+0x52>
}
      ec:	60e2                	ld	ra,24(sp)
      ee:	6442                	ld	s0,16(sp)
      f0:	64a2                	ld	s1,8(sp)
      f2:	6105                	addi	sp,sp,32
      f4:	8082                	ret
    printf("%s: open echo failed!\n", s);
      f6:	85a6                	mv	a1,s1
      f8:	00006517          	auipc	a0,0x6
      fc:	a1850513          	addi	a0,a0,-1512 # 5b10 <malloc+0x136>
     100:	023050ef          	jal	5922 <printf>
    exit(1);
     104:	4505                	li	a0,1
     106:	396050ef          	jal	549c <exit>
    printf("%s: open doesnotexist succeeded!\n", s);
     10a:	85a6                	mv	a1,s1
     10c:	00006517          	auipc	a0,0x6
     110:	a2c50513          	addi	a0,a0,-1492 # 5b38 <malloc+0x15e>
     114:	00f050ef          	jal	5922 <printf>
    exit(1);
     118:	4505                	li	a0,1
     11a:	382050ef          	jal	549c <exit>

000000000000011e <truncate2>:
{
     11e:	7179                	addi	sp,sp,-48
     120:	f406                	sd	ra,40(sp)
     122:	f022                	sd	s0,32(sp)
     124:	ec26                	sd	s1,24(sp)
     126:	e84a                	sd	s2,16(sp)
     128:	e44e                	sd	s3,8(sp)
     12a:	1800                	addi	s0,sp,48
     12c:	89aa                	mv	s3,a0
  unlink("truncfile");
     12e:	00006517          	auipc	a0,0x6
     132:	a3250513          	addi	a0,a0,-1486 # 5b60 <malloc+0x186>
     136:	3b6050ef          	jal	54ec <unlink>
  int fd1 = open("truncfile", O_CREATE | O_TRUNC | O_WRONLY);
     13a:	60100593          	li	a1,1537
     13e:	00006517          	auipc	a0,0x6
     142:	a2250513          	addi	a0,a0,-1502 # 5b60 <malloc+0x186>
     146:	396050ef          	jal	54dc <open>
     14a:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     14c:	4611                	li	a2,4
     14e:	00006597          	auipc	a1,0x6
     152:	a2258593          	addi	a1,a1,-1502 # 5b70 <malloc+0x196>
     156:	366050ef          	jal	54bc <write>
  int fd2 = open("truncfile", O_TRUNC | O_WRONLY);
     15a:	40100593          	li	a1,1025
     15e:	00006517          	auipc	a0,0x6
     162:	a0250513          	addi	a0,a0,-1534 # 5b60 <malloc+0x186>
     166:	376050ef          	jal	54dc <open>
     16a:	892a                	mv	s2,a0
  int n = write(fd1, "x", 1);
     16c:	4605                	li	a2,1
     16e:	00006597          	auipc	a1,0x6
     172:	a0a58593          	addi	a1,a1,-1526 # 5b78 <malloc+0x19e>
     176:	8526                	mv	a0,s1
     178:	344050ef          	jal	54bc <write>
  if (n != -1) {
     17c:	57fd                	li	a5,-1
     17e:	02f51563          	bne	a0,a5,1a8 <truncate2+0x8a>
  unlink("truncfile");
     182:	00006517          	auipc	a0,0x6
     186:	9de50513          	addi	a0,a0,-1570 # 5b60 <malloc+0x186>
     18a:	362050ef          	jal	54ec <unlink>
  close(fd1);
     18e:	8526                	mv	a0,s1
     190:	334050ef          	jal	54c4 <close>
  close(fd2);
     194:	854a                	mv	a0,s2
     196:	32e050ef          	jal	54c4 <close>
}
     19a:	70a2                	ld	ra,40(sp)
     19c:	7402                	ld	s0,32(sp)
     19e:	64e2                	ld	s1,24(sp)
     1a0:	6942                	ld	s2,16(sp)
     1a2:	69a2                	ld	s3,8(sp)
     1a4:	6145                	addi	sp,sp,48
     1a6:	8082                	ret
    printf("%s: write returned %d, expected -1\n", s, n);
     1a8:	862a                	mv	a2,a0
     1aa:	85ce                	mv	a1,s3
     1ac:	00006517          	auipc	a0,0x6
     1b0:	9d450513          	addi	a0,a0,-1580 # 5b80 <malloc+0x1a6>
     1b4:	76e050ef          	jal	5922 <printf>
    exit(1);
     1b8:	4505                	li	a0,1
     1ba:	2e2050ef          	jal	549c <exit>

00000000000001be <createtest>:
{
     1be:	7139                	addi	sp,sp,-64
     1c0:	fc06                	sd	ra,56(sp)
     1c2:	f822                	sd	s0,48(sp)
     1c4:	f426                	sd	s1,40(sp)
     1c6:	f04a                	sd	s2,32(sp)
     1c8:	ec4e                	sd	s3,24(sp)
     1ca:	e852                	sd	s4,16(sp)
     1cc:	0080                	addi	s0,sp,64
  name[0] = 'a';
     1ce:	06100793          	li	a5,97
     1d2:	fcf40423          	sb	a5,-56(s0)
  name[2] = '\0';
     1d6:	fc040523          	sb	zero,-54(s0)
     1da:	03000493          	li	s1,48
    fd = open(name, O_CREATE | O_RDWR);
     1de:	fc840a13          	addi	s4,s0,-56
     1e2:	20200993          	li	s3,514
  for (i = 0; i < N; i++) {
     1e6:	06400913          	li	s2,100
    name[1] = '0' + i;
     1ea:	fc9404a3          	sb	s1,-55(s0)
    fd = open(name, O_CREATE | O_RDWR);
     1ee:	85ce                	mv	a1,s3
     1f0:	8552                	mv	a0,s4
     1f2:	2ea050ef          	jal	54dc <open>
    close(fd);
     1f6:	2ce050ef          	jal	54c4 <close>
  for (i = 0; i < N; i++) {
     1fa:	2485                	addiw	s1,s1,1
     1fc:	0ff4f493          	zext.b	s1,s1
     200:	ff2495e3          	bne	s1,s2,1ea <createtest+0x2c>
  name[0] = 'a';
     204:	06100793          	li	a5,97
     208:	fcf40423          	sb	a5,-56(s0)
  name[2] = '\0';
     20c:	fc040523          	sb	zero,-54(s0)
     210:	03000493          	li	s1,48
    unlink(name);
     214:	fc840993          	addi	s3,s0,-56
  for (i = 0; i < N; i++) {
     218:	06400913          	li	s2,100
    name[1] = '0' + i;
     21c:	fc9404a3          	sb	s1,-55(s0)
    unlink(name);
     220:	854e                	mv	a0,s3
     222:	2ca050ef          	jal	54ec <unlink>
  for (i = 0; i < N; i++) {
     226:	2485                	addiw	s1,s1,1
     228:	0ff4f493          	zext.b	s1,s1
     22c:	ff2498e3          	bne	s1,s2,21c <createtest+0x5e>
}
     230:	70e2                	ld	ra,56(sp)
     232:	7442                	ld	s0,48(sp)
     234:	74a2                	ld	s1,40(sp)
     236:	7902                	ld	s2,32(sp)
     238:	69e2                	ld	s3,24(sp)
     23a:	6a42                	ld	s4,16(sp)
     23c:	6121                	addi	sp,sp,64
     23e:	8082                	ret

0000000000000240 <bigwrite>:
{
     240:	711d                	addi	sp,sp,-96
     242:	ec86                	sd	ra,88(sp)
     244:	e8a2                	sd	s0,80(sp)
     246:	e4a6                	sd	s1,72(sp)
     248:	e0ca                	sd	s2,64(sp)
     24a:	fc4e                	sd	s3,56(sp)
     24c:	f852                	sd	s4,48(sp)
     24e:	f456                	sd	s5,40(sp)
     250:	f05a                	sd	s6,32(sp)
     252:	ec5e                	sd	s7,24(sp)
     254:	e862                	sd	s8,16(sp)
     256:	e466                	sd	s9,8(sp)
     258:	1080                	addi	s0,sp,96
     25a:	8caa                	mv	s9,a0
  unlink("bigwrite");
     25c:	00006517          	auipc	a0,0x6
     260:	94c50513          	addi	a0,a0,-1716 # 5ba8 <malloc+0x1ce>
     264:	288050ef          	jal	54ec <unlink>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     268:	1f300493          	li	s1,499
    fd = open("bigwrite", O_CREATE | O_RDWR);
     26c:	20200b93          	li	s7,514
     270:	00006a17          	auipc	s4,0x6
     274:	938a0a13          	addi	s4,s4,-1736 # 5ba8 <malloc+0x1ce>
     278:	4b09                	li	s6,2
      int cc = write(fd, buf, sz);
     27a:	0000e997          	auipc	s3,0xe
     27e:	a6e98993          	addi	s3,s3,-1426 # dce8 <buf>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     282:	6a8d                	lui	s5,0x3
     284:	1c9a8a93          	addi	s5,s5,457 # 31c9 <rmdot+0x51>
    fd = open("bigwrite", O_CREATE | O_RDWR);
     288:	85de                	mv	a1,s7
     28a:	8552                	mv	a0,s4
     28c:	250050ef          	jal	54dc <open>
     290:	892a                	mv	s2,a0
    if (fd < 0) {
     292:	04054463          	bltz	a0,2da <bigwrite+0x9a>
     296:	8c5a                	mv	s8,s6
      int cc = write(fd, buf, sz);
     298:	8626                	mv	a2,s1
     29a:	85ce                	mv	a1,s3
     29c:	854a                	mv	a0,s2
     29e:	21e050ef          	jal	54bc <write>
      if (cc != sz) {
     2a2:	04951663          	bne	a0,s1,2ee <bigwrite+0xae>
    for (i = 0; i < 2; i++) {
     2a6:	3c7d                	addiw	s8,s8,-1
     2a8:	fe0c18e3          	bnez	s8,298 <bigwrite+0x58>
    close(fd);
     2ac:	854a                	mv	a0,s2
     2ae:	216050ef          	jal	54c4 <close>
    unlink("bigwrite");
     2b2:	8552                	mv	a0,s4
     2b4:	238050ef          	jal	54ec <unlink>
  for (sz = 499; sz < (MAXOPBLOCKS + 2) * BSIZE; sz += 471) {
     2b8:	1d74849b          	addiw	s1,s1,471
     2bc:	fd5496e3          	bne	s1,s5,288 <bigwrite+0x48>
}
     2c0:	60e6                	ld	ra,88(sp)
     2c2:	6446                	ld	s0,80(sp)
     2c4:	64a6                	ld	s1,72(sp)
     2c6:	6906                	ld	s2,64(sp)
     2c8:	79e2                	ld	s3,56(sp)
     2ca:	7a42                	ld	s4,48(sp)
     2cc:	7aa2                	ld	s5,40(sp)
     2ce:	7b02                	ld	s6,32(sp)
     2d0:	6be2                	ld	s7,24(sp)
     2d2:	6c42                	ld	s8,16(sp)
     2d4:	6ca2                	ld	s9,8(sp)
     2d6:	6125                	addi	sp,sp,96
     2d8:	8082                	ret
      printf("%s: cannot create bigwrite\n", s);
     2da:	85e6                	mv	a1,s9
     2dc:	00006517          	auipc	a0,0x6
     2e0:	8dc50513          	addi	a0,a0,-1828 # 5bb8 <malloc+0x1de>
     2e4:	63e050ef          	jal	5922 <printf>
      exit(1);
     2e8:	4505                	li	a0,1
     2ea:	1b2050ef          	jal	549c <exit>
        printf("%s: write(%d) ret %d\n", s, sz, cc);
     2ee:	86aa                	mv	a3,a0
     2f0:	8626                	mv	a2,s1
     2f2:	85e6                	mv	a1,s9
     2f4:	00006517          	auipc	a0,0x6
     2f8:	8e450513          	addi	a0,a0,-1820 # 5bd8 <malloc+0x1fe>
     2fc:	626050ef          	jal	5922 <printf>
        exit(1);
     300:	4505                	li	a0,1
     302:	19a050ef          	jal	549c <exit>

0000000000000306 <badwrite>:
// file is deleted? if the kernel has this bug, it will panic: balloc:
// out of blocks. assumed_free may need to be raised to be more than
// the number of free blocks. this test takes a long time.
void
badwrite(char *s)
{
     306:	7139                	addi	sp,sp,-64
     308:	fc06                	sd	ra,56(sp)
     30a:	f822                	sd	s0,48(sp)
     30c:	f426                	sd	s1,40(sp)
     30e:	f04a                	sd	s2,32(sp)
     310:	ec4e                	sd	s3,24(sp)
     312:	e852                	sd	s4,16(sp)
     314:	e456                	sd	s5,8(sp)
     316:	e05a                	sd	s6,0(sp)
     318:	0080                	addi	s0,sp,64
  int assumed_free = 600;

  unlink("junk");
     31a:	00006517          	auipc	a0,0x6
     31e:	8d650513          	addi	a0,a0,-1834 # 5bf0 <malloc+0x216>
     322:	1ca050ef          	jal	54ec <unlink>
     326:	25800913          	li	s2,600
  for (int i = 0; i < assumed_free; i++) {
    int fd = open("junk", O_CREATE | O_WRONLY);
     32a:	20100a93          	li	s5,513
     32e:	00006997          	auipc	s3,0x6
     332:	8c298993          	addi	s3,s3,-1854 # 5bf0 <malloc+0x216>
    if (fd < 0) {
      printf("open junk failed\n");
      exit(1);
    }
    write(fd, (char *)0xffffffffffL, 1);
     336:	4b05                	li	s6,1
     338:	5a7d                	li	s4,-1
     33a:	018a5a13          	srli	s4,s4,0x18
    int fd = open("junk", O_CREATE | O_WRONLY);
     33e:	85d6                	mv	a1,s5
     340:	854e                	mv	a0,s3
     342:	19a050ef          	jal	54dc <open>
     346:	84aa                	mv	s1,a0
    if (fd < 0) {
     348:	04054d63          	bltz	a0,3a2 <badwrite+0x9c>
    write(fd, (char *)0xffffffffffL, 1);
     34c:	865a                	mv	a2,s6
     34e:	85d2                	mv	a1,s4
     350:	16c050ef          	jal	54bc <write>
    close(fd);
     354:	8526                	mv	a0,s1
     356:	16e050ef          	jal	54c4 <close>
    unlink("junk");
     35a:	854e                	mv	a0,s3
     35c:	190050ef          	jal	54ec <unlink>
  for (int i = 0; i < assumed_free; i++) {
     360:	397d                	addiw	s2,s2,-1
     362:	fc091ee3          	bnez	s2,33e <badwrite+0x38>
  }

  int fd = open("junk", O_CREATE | O_WRONLY);
     366:	20100593          	li	a1,513
     36a:	00006517          	auipc	a0,0x6
     36e:	88650513          	addi	a0,a0,-1914 # 5bf0 <malloc+0x216>
     372:	16a050ef          	jal	54dc <open>
     376:	84aa                	mv	s1,a0
  if (fd < 0) {
     378:	02054e63          	bltz	a0,3b4 <badwrite+0xae>
    printf("open junk failed\n");
    exit(1);
  }
  if (write(fd, "x", 1) != 1) {
     37c:	4605                	li	a2,1
     37e:	00005597          	auipc	a1,0x5
     382:	7fa58593          	addi	a1,a1,2042 # 5b78 <malloc+0x19e>
     386:	136050ef          	jal	54bc <write>
     38a:	4785                	li	a5,1
     38c:	02f50d63          	beq	a0,a5,3c6 <badwrite+0xc0>
    printf("write failed\n");
     390:	00006517          	auipc	a0,0x6
     394:	88050513          	addi	a0,a0,-1920 # 5c10 <malloc+0x236>
     398:	58a050ef          	jal	5922 <printf>
    exit(1);
     39c:	4505                	li	a0,1
     39e:	0fe050ef          	jal	549c <exit>
      printf("open junk failed\n");
     3a2:	00006517          	auipc	a0,0x6
     3a6:	85650513          	addi	a0,a0,-1962 # 5bf8 <malloc+0x21e>
     3aa:	578050ef          	jal	5922 <printf>
      exit(1);
     3ae:	4505                	li	a0,1
     3b0:	0ec050ef          	jal	549c <exit>
    printf("open junk failed\n");
     3b4:	00006517          	auipc	a0,0x6
     3b8:	84450513          	addi	a0,a0,-1980 # 5bf8 <malloc+0x21e>
     3bc:	566050ef          	jal	5922 <printf>
    exit(1);
     3c0:	4505                	li	a0,1
     3c2:	0da050ef          	jal	549c <exit>
  }
  close(fd);
     3c6:	8526                	mv	a0,s1
     3c8:	0fc050ef          	jal	54c4 <close>
  unlink("junk");
     3cc:	00006517          	auipc	a0,0x6
     3d0:	82450513          	addi	a0,a0,-2012 # 5bf0 <malloc+0x216>
     3d4:	118050ef          	jal	54ec <unlink>

  exit(0);
     3d8:	4501                	li	a0,0
     3da:	0c2050ef          	jal	549c <exit>

00000000000003de <outofinodes>:
  }
}

void
outofinodes(char *s)
{
     3de:	711d                	addi	sp,sp,-96
     3e0:	ec86                	sd	ra,88(sp)
     3e2:	e8a2                	sd	s0,80(sp)
     3e4:	e4a6                	sd	s1,72(sp)
     3e6:	e0ca                	sd	s2,64(sp)
     3e8:	fc4e                	sd	s3,56(sp)
     3ea:	f852                	sd	s4,48(sp)
     3ec:	f456                	sd	s5,40(sp)
     3ee:	1080                	addi	s0,sp,96
  int nzz = 32 * 32;
  for (int i = 0; i < nzz; i++) {
     3f0:	4481                	li	s1,0
    char name[32];
    name[0] = 'z';
     3f2:	07a00993          	li	s3,122
    name[1] = 'z';
    name[2] = '0' + (i / 32);
    name[3] = '0' + (i % 32);
    name[4] = '\0';
    unlink(name);
     3f6:	fa040913          	addi	s2,s0,-96
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
     3fa:	60200a13          	li	s4,1538
  for (int i = 0; i < nzz; i++) {
     3fe:	40000a93          	li	s5,1024
    name[0] = 'z';
     402:	fb340023          	sb	s3,-96(s0)
    name[1] = 'z';
     406:	fb3400a3          	sb	s3,-95(s0)
    name[2] = '0' + (i / 32);
     40a:	41f4d71b          	sraiw	a4,s1,0x1f
     40e:	01b7571b          	srliw	a4,a4,0x1b
     412:	009707bb          	addw	a5,a4,s1
     416:	4057d69b          	sraiw	a3,a5,0x5
     41a:	0306869b          	addiw	a3,a3,48
     41e:	fad40123          	sb	a3,-94(s0)
    name[3] = '0' + (i % 32);
     422:	8bfd                	andi	a5,a5,31
     424:	9f99                	subw	a5,a5,a4
     426:	0307879b          	addiw	a5,a5,48
     42a:	faf401a3          	sb	a5,-93(s0)
    name[4] = '\0';
     42e:	fa040223          	sb	zero,-92(s0)
    unlink(name);
     432:	854a                	mv	a0,s2
     434:	0b8050ef          	jal	54ec <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
     438:	85d2                	mv	a1,s4
     43a:	854a                	mv	a0,s2
     43c:	0a0050ef          	jal	54dc <open>
    if (fd < 0) {
     440:	00054763          	bltz	a0,44e <outofinodes+0x70>
      // failure is eventually expected.
      break;
    }
    close(fd);
     444:	080050ef          	jal	54c4 <close>
  for (int i = 0; i < nzz; i++) {
     448:	2485                	addiw	s1,s1,1
     44a:	fb549ce3          	bne	s1,s5,402 <outofinodes+0x24>
     44e:	4481                	li	s1,0
  }

  for (int i = 0; i < nzz; i++) {
    char name[32];
    name[0] = 'z';
     450:	07a00913          	li	s2,122
    name[1] = 'z';
    name[2] = '0' + (i / 32);
    name[3] = '0' + (i % 32);
    name[4] = '\0';
    unlink(name);
     454:	fa040a13          	addi	s4,s0,-96
  for (int i = 0; i < nzz; i++) {
     458:	40000993          	li	s3,1024
    name[0] = 'z';
     45c:	fb240023          	sb	s2,-96(s0)
    name[1] = 'z';
     460:	fb2400a3          	sb	s2,-95(s0)
    name[2] = '0' + (i / 32);
     464:	41f4d71b          	sraiw	a4,s1,0x1f
     468:	01b7571b          	srliw	a4,a4,0x1b
     46c:	009707bb          	addw	a5,a4,s1
     470:	4057d69b          	sraiw	a3,a5,0x5
     474:	0306869b          	addiw	a3,a3,48
     478:	fad40123          	sb	a3,-94(s0)
    name[3] = '0' + (i % 32);
     47c:	8bfd                	andi	a5,a5,31
     47e:	9f99                	subw	a5,a5,a4
     480:	0307879b          	addiw	a5,a5,48
     484:	faf401a3          	sb	a5,-93(s0)
    name[4] = '\0';
     488:	fa040223          	sb	zero,-92(s0)
    unlink(name);
     48c:	8552                	mv	a0,s4
     48e:	05e050ef          	jal	54ec <unlink>
  for (int i = 0; i < nzz; i++) {
     492:	2485                	addiw	s1,s1,1
     494:	fd3494e3          	bne	s1,s3,45c <outofinodes+0x7e>
  }
}
     498:	60e6                	ld	ra,88(sp)
     49a:	6446                	ld	s0,80(sp)
     49c:	64a6                	ld	s1,72(sp)
     49e:	6906                	ld	s2,64(sp)
     4a0:	79e2                	ld	s3,56(sp)
     4a2:	7a42                	ld	s4,48(sp)
     4a4:	7aa2                	ld	s5,40(sp)
     4a6:	6125                	addi	sp,sp,96
     4a8:	8082                	ret

00000000000004aa <copyin>:
{
     4aa:	7175                	addi	sp,sp,-144
     4ac:	e506                	sd	ra,136(sp)
     4ae:	e122                	sd	s0,128(sp)
     4b0:	fca6                	sd	s1,120(sp)
     4b2:	f8ca                	sd	s2,112(sp)
     4b4:	f4ce                	sd	s3,104(sp)
     4b6:	f0d2                	sd	s4,96(sp)
     4b8:	ecd6                	sd	s5,88(sp)
     4ba:	e8da                	sd	s6,80(sp)
     4bc:	e4de                	sd	s7,72(sp)
     4be:	e0e2                	sd	s8,64(sp)
     4c0:	fc66                	sd	s9,56(sp)
     4c2:	0900                	addi	s0,sp,144
  uint64 addrs[] = {0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     4c4:	00008797          	auipc	a5,0x8
     4c8:	e4478793          	addi	a5,a5,-444 # 8308 <malloc+0x292e>
     4cc:	638c                	ld	a1,0(a5)
     4ce:	6790                	ld	a2,8(a5)
     4d0:	6b94                	ld	a3,16(a5)
     4d2:	6f98                	ld	a4,24(a5)
     4d4:	f6b43c23          	sd	a1,-136(s0)
     4d8:	f8c43023          	sd	a2,-128(s0)
     4dc:	f8d43423          	sd	a3,-120(s0)
     4e0:	f8e43823          	sd	a4,-112(s0)
     4e4:	739c                	ld	a5,32(a5)
     4e6:	f8f43c23          	sd	a5,-104(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     4ea:	f7840913          	addi	s2,s0,-136
     4ee:	fa040c93          	addi	s9,s0,-96
    int fd = open("copyin1", O_CREATE | O_WRONLY);
     4f2:	20100b13          	li	s6,513
     4f6:	00005a97          	auipc	s5,0x5
     4fa:	72aa8a93          	addi	s5,s5,1834 # 5c20 <malloc+0x246>
    int n = write(fd, (void *)addr, 8192);
     4fe:	6a09                	lui	s4,0x2
    n = write(1, (char *)addr, 8192);
     500:	4c05                	li	s8,1
    if (pipe(fds) < 0) {
     502:	f7040b93          	addi	s7,s0,-144
    uint64 addr = addrs[ai];
     506:	00093983          	ld	s3,0(s2)
    int fd = open("copyin1", O_CREATE | O_WRONLY);
     50a:	85da                	mv	a1,s6
     50c:	8556                	mv	a0,s5
     50e:	7cf040ef          	jal	54dc <open>
     512:	84aa                	mv	s1,a0
    if (fd < 0) {
     514:	06054a63          	bltz	a0,588 <copyin+0xde>
    int n = write(fd, (void *)addr, 8192);
     518:	8652                	mv	a2,s4
     51a:	85ce                	mv	a1,s3
     51c:	7a1040ef          	jal	54bc <write>
    if (n >= 0) {
     520:	06055d63          	bgez	a0,59a <copyin+0xf0>
    close(fd);
     524:	8526                	mv	a0,s1
     526:	79f040ef          	jal	54c4 <close>
    unlink("copyin1");
     52a:	8556                	mv	a0,s5
     52c:	7c1040ef          	jal	54ec <unlink>
    n = write(1, (char *)addr, 8192);
     530:	8652                	mv	a2,s4
     532:	85ce                	mv	a1,s3
     534:	8562                	mv	a0,s8
     536:	787040ef          	jal	54bc <write>
    if (n > 0) {
     53a:	06a04b63          	bgtz	a0,5b0 <copyin+0x106>
    if (pipe(fds) < 0) {
     53e:	855e                	mv	a0,s7
     540:	76d040ef          	jal	54ac <pipe>
     544:	08054163          	bltz	a0,5c6 <copyin+0x11c>
    n = write(fds[1], (char *)addr, 8192);
     548:	8652                	mv	a2,s4
     54a:	85ce                	mv	a1,s3
     54c:	f7442503          	lw	a0,-140(s0)
     550:	76d040ef          	jal	54bc <write>
    if (n > 0) {
     554:	08a04263          	bgtz	a0,5d8 <copyin+0x12e>
    close(fds[0]);
     558:	f7042503          	lw	a0,-144(s0)
     55c:	769040ef          	jal	54c4 <close>
    close(fds[1]);
     560:	f7442503          	lw	a0,-140(s0)
     564:	761040ef          	jal	54c4 <close>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     568:	0921                	addi	s2,s2,8
     56a:	f9991ee3          	bne	s2,s9,506 <copyin+0x5c>
}
     56e:	60aa                	ld	ra,136(sp)
     570:	640a                	ld	s0,128(sp)
     572:	74e6                	ld	s1,120(sp)
     574:	7946                	ld	s2,112(sp)
     576:	79a6                	ld	s3,104(sp)
     578:	7a06                	ld	s4,96(sp)
     57a:	6ae6                	ld	s5,88(sp)
     57c:	6b46                	ld	s6,80(sp)
     57e:	6ba6                	ld	s7,72(sp)
     580:	6c06                	ld	s8,64(sp)
     582:	7ce2                	ld	s9,56(sp)
     584:	6149                	addi	sp,sp,144
     586:	8082                	ret
      printf("open(copyin1) failed\n");
     588:	00005517          	auipc	a0,0x5
     58c:	6a050513          	addi	a0,a0,1696 # 5c28 <malloc+0x24e>
     590:	392050ef          	jal	5922 <printf>
      exit(1);
     594:	4505                	li	a0,1
     596:	707040ef          	jal	549c <exit>
      printf("write(fd, %p, 8192) returned %d, not -1\n", (void *)addr, n);
     59a:	862a                	mv	a2,a0
     59c:	85ce                	mv	a1,s3
     59e:	00005517          	auipc	a0,0x5
     5a2:	6a250513          	addi	a0,a0,1698 # 5c40 <malloc+0x266>
     5a6:	37c050ef          	jal	5922 <printf>
      exit(1);
     5aa:	4505                	li	a0,1
     5ac:	6f1040ef          	jal	549c <exit>
      printf("write(1, %p, 8192) returned %d, not -1 or 0\n", (void *)addr, n);
     5b0:	862a                	mv	a2,a0
     5b2:	85ce                	mv	a1,s3
     5b4:	00005517          	auipc	a0,0x5
     5b8:	6bc50513          	addi	a0,a0,1724 # 5c70 <malloc+0x296>
     5bc:	366050ef          	jal	5922 <printf>
      exit(1);
     5c0:	4505                	li	a0,1
     5c2:	6db040ef          	jal	549c <exit>
      printf("pipe() failed\n");
     5c6:	00005517          	auipc	a0,0x5
     5ca:	6da50513          	addi	a0,a0,1754 # 5ca0 <malloc+0x2c6>
     5ce:	354050ef          	jal	5922 <printf>
      exit(1);
     5d2:	4505                	li	a0,1
     5d4:	6c9040ef          	jal	549c <exit>
      printf("write(pipe, %p, 8192) returned %d, not -1 or 0\n", (void *)addr,
     5d8:	862a                	mv	a2,a0
     5da:	85ce                	mv	a1,s3
     5dc:	00005517          	auipc	a0,0x5
     5e0:	6d450513          	addi	a0,a0,1748 # 5cb0 <malloc+0x2d6>
     5e4:	33e050ef          	jal	5922 <printf>
      exit(1);
     5e8:	4505                	li	a0,1
     5ea:	6b3040ef          	jal	549c <exit>

00000000000005ee <copyout>:
{
     5ee:	7135                	addi	sp,sp,-160
     5f0:	ed06                	sd	ra,152(sp)
     5f2:	e922                	sd	s0,144(sp)
     5f4:	e526                	sd	s1,136(sp)
     5f6:	e14a                	sd	s2,128(sp)
     5f8:	fcce                	sd	s3,120(sp)
     5fa:	f8d2                	sd	s4,112(sp)
     5fc:	f4d6                	sd	s5,104(sp)
     5fe:	f0da                	sd	s6,96(sp)
     600:	ecde                	sd	s7,88(sp)
     602:	e8e2                	sd	s8,80(sp)
     604:	e4e6                	sd	s9,72(sp)
     606:	1100                	addi	s0,sp,160
  uint64 addrs[] = {0LL,          0x80000000LL, 0x3fffffe000,
     608:	00008797          	auipc	a5,0x8
     60c:	d0078793          	addi	a5,a5,-768 # 8308 <malloc+0x292e>
     610:	7788                	ld	a0,40(a5)
     612:	7b8c                	ld	a1,48(a5)
     614:	7f90                	ld	a2,56(a5)
     616:	63b4                	ld	a3,64(a5)
     618:	67b8                	ld	a4,72(a5)
     61a:	f6a43823          	sd	a0,-144(s0)
     61e:	f6b43c23          	sd	a1,-136(s0)
     622:	f8c43023          	sd	a2,-128(s0)
     626:	f8d43423          	sd	a3,-120(s0)
     62a:	f8e43823          	sd	a4,-112(s0)
     62e:	6bbc                	ld	a5,80(a5)
     630:	f8f43c23          	sd	a5,-104(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     634:	f7040913          	addi	s2,s0,-144
     638:	fa040c93          	addi	s9,s0,-96
    int fd = open("README", 0);
     63c:	00005b17          	auipc	s6,0x5
     640:	6a4b0b13          	addi	s6,s6,1700 # 5ce0 <malloc+0x306>
    int n = read(fd, (void *)addr, 8192);
     644:	6a89                	lui	s5,0x2
    if (pipe(fds) < 0) {
     646:	f6840c13          	addi	s8,s0,-152
    n = write(fds[1], "x", 1);
     64a:	4a05                	li	s4,1
     64c:	00005b97          	auipc	s7,0x5
     650:	52cb8b93          	addi	s7,s7,1324 # 5b78 <malloc+0x19e>
    uint64 addr = addrs[ai];
     654:	00093983          	ld	s3,0(s2)
    int fd = open("README", 0);
     658:	4581                	li	a1,0
     65a:	855a                	mv	a0,s6
     65c:	681040ef          	jal	54dc <open>
     660:	84aa                	mv	s1,a0
    if (fd < 0) {
     662:	06054863          	bltz	a0,6d2 <copyout+0xe4>
    int n = read(fd, (void *)addr, 8192);
     666:	8656                	mv	a2,s5
     668:	85ce                	mv	a1,s3
     66a:	64b040ef          	jal	54b4 <read>
    if (n > 0) {
     66e:	06a04b63          	bgtz	a0,6e4 <copyout+0xf6>
    close(fd);
     672:	8526                	mv	a0,s1
     674:	651040ef          	jal	54c4 <close>
    if (pipe(fds) < 0) {
     678:	8562                	mv	a0,s8
     67a:	633040ef          	jal	54ac <pipe>
     67e:	06054e63          	bltz	a0,6fa <copyout+0x10c>
    n = write(fds[1], "x", 1);
     682:	8652                	mv	a2,s4
     684:	85de                	mv	a1,s7
     686:	f6c42503          	lw	a0,-148(s0)
     68a:	633040ef          	jal	54bc <write>
    if (n != 1) {
     68e:	07451f63          	bne	a0,s4,70c <copyout+0x11e>
    n = read(fds[0], (void *)addr, 8192);
     692:	8656                	mv	a2,s5
     694:	85ce                	mv	a1,s3
     696:	f6842503          	lw	a0,-152(s0)
     69a:	61b040ef          	jal	54b4 <read>
    if (n > 0) {
     69e:	08a04063          	bgtz	a0,71e <copyout+0x130>
    close(fds[0]);
     6a2:	f6842503          	lw	a0,-152(s0)
     6a6:	61f040ef          	jal	54c4 <close>
    close(fds[1]);
     6aa:	f6c42503          	lw	a0,-148(s0)
     6ae:	617040ef          	jal	54c4 <close>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
     6b2:	0921                	addi	s2,s2,8
     6b4:	fb9910e3          	bne	s2,s9,654 <copyout+0x66>
}
     6b8:	60ea                	ld	ra,152(sp)
     6ba:	644a                	ld	s0,144(sp)
     6bc:	64aa                	ld	s1,136(sp)
     6be:	690a                	ld	s2,128(sp)
     6c0:	79e6                	ld	s3,120(sp)
     6c2:	7a46                	ld	s4,112(sp)
     6c4:	7aa6                	ld	s5,104(sp)
     6c6:	7b06                	ld	s6,96(sp)
     6c8:	6be6                	ld	s7,88(sp)
     6ca:	6c46                	ld	s8,80(sp)
     6cc:	6ca6                	ld	s9,72(sp)
     6ce:	610d                	addi	sp,sp,160
     6d0:	8082                	ret
      printf("open(README) failed\n");
     6d2:	00005517          	auipc	a0,0x5
     6d6:	61650513          	addi	a0,a0,1558 # 5ce8 <malloc+0x30e>
     6da:	248050ef          	jal	5922 <printf>
      exit(1);
     6de:	4505                	li	a0,1
     6e0:	5bd040ef          	jal	549c <exit>
      printf("read(fd, %p, 8192) returned %d, not -1 or 0\n", (void *)addr, n);
     6e4:	862a                	mv	a2,a0
     6e6:	85ce                	mv	a1,s3
     6e8:	00005517          	auipc	a0,0x5
     6ec:	61850513          	addi	a0,a0,1560 # 5d00 <malloc+0x326>
     6f0:	232050ef          	jal	5922 <printf>
      exit(1);
     6f4:	4505                	li	a0,1
     6f6:	5a7040ef          	jal	549c <exit>
      printf("pipe() failed\n");
     6fa:	00005517          	auipc	a0,0x5
     6fe:	5a650513          	addi	a0,a0,1446 # 5ca0 <malloc+0x2c6>
     702:	220050ef          	jal	5922 <printf>
      exit(1);
     706:	4505                	li	a0,1
     708:	595040ef          	jal	549c <exit>
      printf("pipe write failed\n");
     70c:	00005517          	auipc	a0,0x5
     710:	62450513          	addi	a0,a0,1572 # 5d30 <malloc+0x356>
     714:	20e050ef          	jal	5922 <printf>
      exit(1);
     718:	4505                	li	a0,1
     71a:	583040ef          	jal	549c <exit>
      printf("read(pipe, %p, 8192) returned %d, not -1 or 0\n", (void *)addr,
     71e:	862a                	mv	a2,a0
     720:	85ce                	mv	a1,s3
     722:	00005517          	auipc	a0,0x5
     726:	62650513          	addi	a0,a0,1574 # 5d48 <malloc+0x36e>
     72a:	1f8050ef          	jal	5922 <printf>
      exit(1);
     72e:	4505                	li	a0,1
     730:	56d040ef          	jal	549c <exit>

0000000000000734 <truncate1>:
{
     734:	711d                	addi	sp,sp,-96
     736:	ec86                	sd	ra,88(sp)
     738:	e8a2                	sd	s0,80(sp)
     73a:	e4a6                	sd	s1,72(sp)
     73c:	e0ca                	sd	s2,64(sp)
     73e:	fc4e                	sd	s3,56(sp)
     740:	f852                	sd	s4,48(sp)
     742:	f456                	sd	s5,40(sp)
     744:	1080                	addi	s0,sp,96
     746:	8a2a                	mv	s4,a0
  unlink("truncfile");
     748:	00005517          	auipc	a0,0x5
     74c:	41850513          	addi	a0,a0,1048 # 5b60 <malloc+0x186>
     750:	59d040ef          	jal	54ec <unlink>
  int fd1 = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
     754:	60100593          	li	a1,1537
     758:	00005517          	auipc	a0,0x5
     75c:	40850513          	addi	a0,a0,1032 # 5b60 <malloc+0x186>
     760:	57d040ef          	jal	54dc <open>
     764:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     766:	4611                	li	a2,4
     768:	00005597          	auipc	a1,0x5
     76c:	40858593          	addi	a1,a1,1032 # 5b70 <malloc+0x196>
     770:	54d040ef          	jal	54bc <write>
  close(fd1);
     774:	8526                	mv	a0,s1
     776:	54f040ef          	jal	54c4 <close>
  int fd2 = open("truncfile", O_RDONLY);
     77a:	4581                	li	a1,0
     77c:	00005517          	auipc	a0,0x5
     780:	3e450513          	addi	a0,a0,996 # 5b60 <malloc+0x186>
     784:	559040ef          	jal	54dc <open>
     788:	84aa                	mv	s1,a0
  int n = read(fd2, buf, sizeof(buf));
     78a:	02000613          	li	a2,32
     78e:	fa040593          	addi	a1,s0,-96
     792:	523040ef          	jal	54b4 <read>
  if (n != 4) {
     796:	4791                	li	a5,4
     798:	0af51863          	bne	a0,a5,848 <truncate1+0x114>
  fd1 = open("truncfile", O_WRONLY | O_TRUNC);
     79c:	40100593          	li	a1,1025
     7a0:	00005517          	auipc	a0,0x5
     7a4:	3c050513          	addi	a0,a0,960 # 5b60 <malloc+0x186>
     7a8:	535040ef          	jal	54dc <open>
     7ac:	89aa                	mv	s3,a0
  int fd3 = open("truncfile", O_RDONLY);
     7ae:	4581                	li	a1,0
     7b0:	00005517          	auipc	a0,0x5
     7b4:	3b050513          	addi	a0,a0,944 # 5b60 <malloc+0x186>
     7b8:	525040ef          	jal	54dc <open>
     7bc:	892a                	mv	s2,a0
  n = read(fd3, buf, sizeof(buf));
     7be:	02000613          	li	a2,32
     7c2:	fa040593          	addi	a1,s0,-96
     7c6:	4ef040ef          	jal	54b4 <read>
     7ca:	8aaa                	mv	s5,a0
  if (n != 0) {
     7cc:	e949                	bnez	a0,85e <truncate1+0x12a>
  n = read(fd2, buf, sizeof(buf));
     7ce:	02000613          	li	a2,32
     7d2:	fa040593          	addi	a1,s0,-96
     7d6:	8526                	mv	a0,s1
     7d8:	4dd040ef          	jal	54b4 <read>
     7dc:	8aaa                	mv	s5,a0
  if (n != 0) {
     7de:	e155                	bnez	a0,882 <truncate1+0x14e>
  write(fd1, "abcdef", 6);
     7e0:	4619                	li	a2,6
     7e2:	00005597          	auipc	a1,0x5
     7e6:	5f658593          	addi	a1,a1,1526 # 5dd8 <malloc+0x3fe>
     7ea:	854e                	mv	a0,s3
     7ec:	4d1040ef          	jal	54bc <write>
  n = read(fd3, buf, sizeof(buf));
     7f0:	02000613          	li	a2,32
     7f4:	fa040593          	addi	a1,s0,-96
     7f8:	854a                	mv	a0,s2
     7fa:	4bb040ef          	jal	54b4 <read>
  if (n != 6) {
     7fe:	4799                	li	a5,6
     800:	0af51363          	bne	a0,a5,8a6 <truncate1+0x172>
  n = read(fd2, buf, sizeof(buf));
     804:	02000613          	li	a2,32
     808:	fa040593          	addi	a1,s0,-96
     80c:	8526                	mv	a0,s1
     80e:	4a7040ef          	jal	54b4 <read>
  if (n != 2) {
     812:	4789                	li	a5,2
     814:	0af51463          	bne	a0,a5,8bc <truncate1+0x188>
  unlink("truncfile");
     818:	00005517          	auipc	a0,0x5
     81c:	34850513          	addi	a0,a0,840 # 5b60 <malloc+0x186>
     820:	4cd040ef          	jal	54ec <unlink>
  close(fd1);
     824:	854e                	mv	a0,s3
     826:	49f040ef          	jal	54c4 <close>
  close(fd2);
     82a:	8526                	mv	a0,s1
     82c:	499040ef          	jal	54c4 <close>
  close(fd3);
     830:	854a                	mv	a0,s2
     832:	493040ef          	jal	54c4 <close>
}
     836:	60e6                	ld	ra,88(sp)
     838:	6446                	ld	s0,80(sp)
     83a:	64a6                	ld	s1,72(sp)
     83c:	6906                	ld	s2,64(sp)
     83e:	79e2                	ld	s3,56(sp)
     840:	7a42                	ld	s4,48(sp)
     842:	7aa2                	ld	s5,40(sp)
     844:	6125                	addi	sp,sp,96
     846:	8082                	ret
    printf("%s: read %d bytes, wanted 4\n", s, n);
     848:	862a                	mv	a2,a0
     84a:	85d2                	mv	a1,s4
     84c:	00005517          	auipc	a0,0x5
     850:	52c50513          	addi	a0,a0,1324 # 5d78 <malloc+0x39e>
     854:	0ce050ef          	jal	5922 <printf>
    exit(1);
     858:	4505                	li	a0,1
     85a:	443040ef          	jal	549c <exit>
    printf("aaa fd3=%d\n", fd3);
     85e:	85ca                	mv	a1,s2
     860:	00005517          	auipc	a0,0x5
     864:	53850513          	addi	a0,a0,1336 # 5d98 <malloc+0x3be>
     868:	0ba050ef          	jal	5922 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     86c:	8656                	mv	a2,s5
     86e:	85d2                	mv	a1,s4
     870:	00005517          	auipc	a0,0x5
     874:	53850513          	addi	a0,a0,1336 # 5da8 <malloc+0x3ce>
     878:	0aa050ef          	jal	5922 <printf>
    exit(1);
     87c:	4505                	li	a0,1
     87e:	41f040ef          	jal	549c <exit>
    printf("bbb fd2=%d\n", fd2);
     882:	85a6                	mv	a1,s1
     884:	00005517          	auipc	a0,0x5
     888:	54450513          	addi	a0,a0,1348 # 5dc8 <malloc+0x3ee>
     88c:	096050ef          	jal	5922 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     890:	8656                	mv	a2,s5
     892:	85d2                	mv	a1,s4
     894:	00005517          	auipc	a0,0x5
     898:	51450513          	addi	a0,a0,1300 # 5da8 <malloc+0x3ce>
     89c:	086050ef          	jal	5922 <printf>
    exit(1);
     8a0:	4505                	li	a0,1
     8a2:	3fb040ef          	jal	549c <exit>
    printf("%s: read %d bytes, wanted 6\n", s, n);
     8a6:	862a                	mv	a2,a0
     8a8:	85d2                	mv	a1,s4
     8aa:	00005517          	auipc	a0,0x5
     8ae:	53650513          	addi	a0,a0,1334 # 5de0 <malloc+0x406>
     8b2:	070050ef          	jal	5922 <printf>
    exit(1);
     8b6:	4505                	li	a0,1
     8b8:	3e5040ef          	jal	549c <exit>
    printf("%s: read %d bytes, wanted 2\n", s, n);
     8bc:	862a                	mv	a2,a0
     8be:	85d2                	mv	a1,s4
     8c0:	00005517          	auipc	a0,0x5
     8c4:	54050513          	addi	a0,a0,1344 # 5e00 <malloc+0x426>
     8c8:	05a050ef          	jal	5922 <printf>
    exit(1);
     8cc:	4505                	li	a0,1
     8ce:	3cf040ef          	jal	549c <exit>

00000000000008d2 <writetest>:
{
     8d2:	715d                	addi	sp,sp,-80
     8d4:	e486                	sd	ra,72(sp)
     8d6:	e0a2                	sd	s0,64(sp)
     8d8:	fc26                	sd	s1,56(sp)
     8da:	f84a                	sd	s2,48(sp)
     8dc:	f44e                	sd	s3,40(sp)
     8de:	f052                	sd	s4,32(sp)
     8e0:	ec56                	sd	s5,24(sp)
     8e2:	e85a                	sd	s6,16(sp)
     8e4:	e45e                	sd	s7,8(sp)
     8e6:	0880                	addi	s0,sp,80
     8e8:	8baa                	mv	s7,a0
  fd = open("small", O_CREATE | O_RDWR);
     8ea:	20200593          	li	a1,514
     8ee:	00005517          	auipc	a0,0x5
     8f2:	53250513          	addi	a0,a0,1330 # 5e20 <malloc+0x446>
     8f6:	3e7040ef          	jal	54dc <open>
  if (fd < 0) {
     8fa:	08054f63          	bltz	a0,998 <writetest+0xc6>
     8fe:	89aa                	mv	s3,a0
     900:	4901                	li	s2,0
    if (write(fd, "aaaaaaaaaa", SZ) != SZ) {
     902:	44a9                	li	s1,10
     904:	00005a17          	auipc	s4,0x5
     908:	544a0a13          	addi	s4,s4,1348 # 5e48 <malloc+0x46e>
    if (write(fd, "bbbbbbbbbb", SZ) != SZ) {
     90c:	00005b17          	auipc	s6,0x5
     910:	574b0b13          	addi	s6,s6,1396 # 5e80 <malloc+0x4a6>
  for (i = 0; i < N; i++) {
     914:	06400a93          	li	s5,100
    if (write(fd, "aaaaaaaaaa", SZ) != SZ) {
     918:	8626                	mv	a2,s1
     91a:	85d2                	mv	a1,s4
     91c:	854e                	mv	a0,s3
     91e:	39f040ef          	jal	54bc <write>
     922:	08951563          	bne	a0,s1,9ac <writetest+0xda>
    if (write(fd, "bbbbbbbbbb", SZ) != SZ) {
     926:	8626                	mv	a2,s1
     928:	85da                	mv	a1,s6
     92a:	854e                	mv	a0,s3
     92c:	391040ef          	jal	54bc <write>
     930:	08951963          	bne	a0,s1,9c2 <writetest+0xf0>
  for (i = 0; i < N; i++) {
     934:	2905                	addiw	s2,s2,1
     936:	ff5911e3          	bne	s2,s5,918 <writetest+0x46>
  close(fd);
     93a:	854e                	mv	a0,s3
     93c:	389040ef          	jal	54c4 <close>
  fd = open("small", O_RDONLY);
     940:	4581                	li	a1,0
     942:	00005517          	auipc	a0,0x5
     946:	4de50513          	addi	a0,a0,1246 # 5e20 <malloc+0x446>
     94a:	393040ef          	jal	54dc <open>
     94e:	84aa                	mv	s1,a0
  if (fd < 0) {
     950:	08054463          	bltz	a0,9d8 <writetest+0x106>
  i = read(fd, buf, N * SZ * 2);
     954:	7d000613          	li	a2,2000
     958:	0000d597          	auipc	a1,0xd
     95c:	39058593          	addi	a1,a1,912 # dce8 <buf>
     960:	355040ef          	jal	54b4 <read>
  if (i != N * SZ * 2) {
     964:	7d000793          	li	a5,2000
     968:	08f51263          	bne	a0,a5,9ec <writetest+0x11a>
  close(fd);
     96c:	8526                	mv	a0,s1
     96e:	357040ef          	jal	54c4 <close>
  if (unlink("small") < 0) {
     972:	00005517          	auipc	a0,0x5
     976:	4ae50513          	addi	a0,a0,1198 # 5e20 <malloc+0x446>
     97a:	373040ef          	jal	54ec <unlink>
     97e:	08054163          	bltz	a0,a00 <writetest+0x12e>
}
     982:	60a6                	ld	ra,72(sp)
     984:	6406                	ld	s0,64(sp)
     986:	74e2                	ld	s1,56(sp)
     988:	7942                	ld	s2,48(sp)
     98a:	79a2                	ld	s3,40(sp)
     98c:	7a02                	ld	s4,32(sp)
     98e:	6ae2                	ld	s5,24(sp)
     990:	6b42                	ld	s6,16(sp)
     992:	6ba2                	ld	s7,8(sp)
     994:	6161                	addi	sp,sp,80
     996:	8082                	ret
    printf("%s: error: creat small failed!\n", s);
     998:	85de                	mv	a1,s7
     99a:	00005517          	auipc	a0,0x5
     99e:	48e50513          	addi	a0,a0,1166 # 5e28 <malloc+0x44e>
     9a2:	781040ef          	jal	5922 <printf>
    exit(1);
     9a6:	4505                	li	a0,1
     9a8:	2f5040ef          	jal	549c <exit>
      printf("%s: error: write aa %d new file failed\n", s, i);
     9ac:	864a                	mv	a2,s2
     9ae:	85de                	mv	a1,s7
     9b0:	00005517          	auipc	a0,0x5
     9b4:	4a850513          	addi	a0,a0,1192 # 5e58 <malloc+0x47e>
     9b8:	76b040ef          	jal	5922 <printf>
      exit(1);
     9bc:	4505                	li	a0,1
     9be:	2df040ef          	jal	549c <exit>
      printf("%s: error: write bb %d new file failed\n", s, i);
     9c2:	864a                	mv	a2,s2
     9c4:	85de                	mv	a1,s7
     9c6:	00005517          	auipc	a0,0x5
     9ca:	4ca50513          	addi	a0,a0,1226 # 5e90 <malloc+0x4b6>
     9ce:	755040ef          	jal	5922 <printf>
      exit(1);
     9d2:	4505                	li	a0,1
     9d4:	2c9040ef          	jal	549c <exit>
    printf("%s: error: open small failed!\n", s);
     9d8:	85de                	mv	a1,s7
     9da:	00005517          	auipc	a0,0x5
     9de:	4de50513          	addi	a0,a0,1246 # 5eb8 <malloc+0x4de>
     9e2:	741040ef          	jal	5922 <printf>
    exit(1);
     9e6:	4505                	li	a0,1
     9e8:	2b5040ef          	jal	549c <exit>
    printf("%s: read failed\n", s);
     9ec:	85de                	mv	a1,s7
     9ee:	00005517          	auipc	a0,0x5
     9f2:	4ea50513          	addi	a0,a0,1258 # 5ed8 <malloc+0x4fe>
     9f6:	72d040ef          	jal	5922 <printf>
    exit(1);
     9fa:	4505                	li	a0,1
     9fc:	2a1040ef          	jal	549c <exit>
    printf("%s: unlink small failed\n", s);
     a00:	85de                	mv	a1,s7
     a02:	00005517          	auipc	a0,0x5
     a06:	4ee50513          	addi	a0,a0,1262 # 5ef0 <malloc+0x516>
     a0a:	719040ef          	jal	5922 <printf>
    exit(1);
     a0e:	4505                	li	a0,1
     a10:	28d040ef          	jal	549c <exit>

0000000000000a14 <writebig>:
{
     a14:	7139                	addi	sp,sp,-64
     a16:	fc06                	sd	ra,56(sp)
     a18:	f822                	sd	s0,48(sp)
     a1a:	f426                	sd	s1,40(sp)
     a1c:	f04a                	sd	s2,32(sp)
     a1e:	ec4e                	sd	s3,24(sp)
     a20:	e852                	sd	s4,16(sp)
     a22:	e456                	sd	s5,8(sp)
     a24:	e05a                	sd	s6,0(sp)
     a26:	0080                	addi	s0,sp,64
     a28:	8b2a                	mv	s6,a0
  fd = open("big", O_CREATE | O_RDWR);
     a2a:	20200593          	li	a1,514
     a2e:	00005517          	auipc	a0,0x5
     a32:	4e250513          	addi	a0,a0,1250 # 5f10 <malloc+0x536>
     a36:	2a7040ef          	jal	54dc <open>
  if (fd < 0) {
     a3a:	06054a63          	bltz	a0,aae <writebig+0x9a>
     a3e:	8a2a                	mv	s4,a0
     a40:	4481                	li	s1,0
    ((int *)buf)[0] = i;
     a42:	0000d997          	auipc	s3,0xd
     a46:	2a698993          	addi	s3,s3,678 # dce8 <buf>
    if (write(fd, buf, BSIZE) != BSIZE) {
     a4a:	40000913          	li	s2,1024
  for (i = 0; i < MAXFILE; i++) {
     a4e:	10c00a93          	li	s5,268
    ((int *)buf)[0] = i;
     a52:	0099a023          	sw	s1,0(s3)
    if (write(fd, buf, BSIZE) != BSIZE) {
     a56:	864a                	mv	a2,s2
     a58:	85ce                	mv	a1,s3
     a5a:	8552                	mv	a0,s4
     a5c:	261040ef          	jal	54bc <write>
     a60:	07251163          	bne	a0,s2,ac2 <writebig+0xae>
  for (i = 0; i < MAXFILE; i++) {
     a64:	2485                	addiw	s1,s1,1
     a66:	ff5496e3          	bne	s1,s5,a52 <writebig+0x3e>
  close(fd);
     a6a:	8552                	mv	a0,s4
     a6c:	259040ef          	jal	54c4 <close>
  fd = open("big", O_RDONLY);
     a70:	4581                	li	a1,0
     a72:	00005517          	auipc	a0,0x5
     a76:	49e50513          	addi	a0,a0,1182 # 5f10 <malloc+0x536>
     a7a:	263040ef          	jal	54dc <open>
     a7e:	8a2a                	mv	s4,a0
  n = 0;
     a80:	4481                	li	s1,0
    i = read(fd, buf, BSIZE);
     a82:	40000993          	li	s3,1024
     a86:	0000d917          	auipc	s2,0xd
     a8a:	26290913          	addi	s2,s2,610 # dce8 <buf>
  if (fd < 0) {
     a8e:	04054563          	bltz	a0,ad8 <writebig+0xc4>
    i = read(fd, buf, BSIZE);
     a92:	864e                	mv	a2,s3
     a94:	85ca                	mv	a1,s2
     a96:	8552                	mv	a0,s4
     a98:	21d040ef          	jal	54b4 <read>
    if (i == 0) {
     a9c:	c921                	beqz	a0,aec <writebig+0xd8>
    } else if (i != BSIZE) {
     a9e:	09351b63          	bne	a0,s3,b34 <writebig+0x120>
    if (((int *)buf)[0] != n) {
     aa2:	00092683          	lw	a3,0(s2)
     aa6:	0a969263          	bne	a3,s1,b4a <writebig+0x136>
    n++;
     aaa:	2485                	addiw	s1,s1,1
    i = read(fd, buf, BSIZE);
     aac:	b7dd                	j	a92 <writebig+0x7e>
    printf("%s: error: creat big failed!\n", s);
     aae:	85da                	mv	a1,s6
     ab0:	00005517          	auipc	a0,0x5
     ab4:	46850513          	addi	a0,a0,1128 # 5f18 <malloc+0x53e>
     ab8:	66b040ef          	jal	5922 <printf>
    exit(1);
     abc:	4505                	li	a0,1
     abe:	1df040ef          	jal	549c <exit>
      printf("%s: error: write big file failed i=%d\n", s, i);
     ac2:	8626                	mv	a2,s1
     ac4:	85da                	mv	a1,s6
     ac6:	00005517          	auipc	a0,0x5
     aca:	47250513          	addi	a0,a0,1138 # 5f38 <malloc+0x55e>
     ace:	655040ef          	jal	5922 <printf>
      exit(1);
     ad2:	4505                	li	a0,1
     ad4:	1c9040ef          	jal	549c <exit>
    printf("%s: error: open big failed!\n", s);
     ad8:	85da                	mv	a1,s6
     ada:	00005517          	auipc	a0,0x5
     ade:	48650513          	addi	a0,a0,1158 # 5f60 <malloc+0x586>
     ae2:	641040ef          	jal	5922 <printf>
    exit(1);
     ae6:	4505                	li	a0,1
     ae8:	1b5040ef          	jal	549c <exit>
      if (n != MAXFILE) {
     aec:	10c00793          	li	a5,268
     af0:	02f49763          	bne	s1,a5,b1e <writebig+0x10a>
  close(fd);
     af4:	8552                	mv	a0,s4
     af6:	1cf040ef          	jal	54c4 <close>
  if (unlink("big") < 0) {
     afa:	00005517          	auipc	a0,0x5
     afe:	41650513          	addi	a0,a0,1046 # 5f10 <malloc+0x536>
     b02:	1eb040ef          	jal	54ec <unlink>
     b06:	04054d63          	bltz	a0,b60 <writebig+0x14c>
}
     b0a:	70e2                	ld	ra,56(sp)
     b0c:	7442                	ld	s0,48(sp)
     b0e:	74a2                	ld	s1,40(sp)
     b10:	7902                	ld	s2,32(sp)
     b12:	69e2                	ld	s3,24(sp)
     b14:	6a42                	ld	s4,16(sp)
     b16:	6aa2                	ld	s5,8(sp)
     b18:	6b02                	ld	s6,0(sp)
     b1a:	6121                	addi	sp,sp,64
     b1c:	8082                	ret
        printf("%s: read only %d blocks from big", s, n);
     b1e:	8626                	mv	a2,s1
     b20:	85da                	mv	a1,s6
     b22:	00005517          	auipc	a0,0x5
     b26:	45e50513          	addi	a0,a0,1118 # 5f80 <malloc+0x5a6>
     b2a:	5f9040ef          	jal	5922 <printf>
        exit(1);
     b2e:	4505                	li	a0,1
     b30:	16d040ef          	jal	549c <exit>
      printf("%s: read failed %d\n", s, i);
     b34:	862a                	mv	a2,a0
     b36:	85da                	mv	a1,s6
     b38:	00005517          	auipc	a0,0x5
     b3c:	47050513          	addi	a0,a0,1136 # 5fa8 <malloc+0x5ce>
     b40:	5e3040ef          	jal	5922 <printf>
      exit(1);
     b44:	4505                	li	a0,1
     b46:	157040ef          	jal	549c <exit>
      printf("%s: read content of block %d is %d\n", s, n, ((int *)buf)[0]);
     b4a:	8626                	mv	a2,s1
     b4c:	85da                	mv	a1,s6
     b4e:	00005517          	auipc	a0,0x5
     b52:	47250513          	addi	a0,a0,1138 # 5fc0 <malloc+0x5e6>
     b56:	5cd040ef          	jal	5922 <printf>
      exit(1);
     b5a:	4505                	li	a0,1
     b5c:	141040ef          	jal	549c <exit>
    printf("%s: unlink big failed\n", s);
     b60:	85da                	mv	a1,s6
     b62:	00005517          	auipc	a0,0x5
     b66:	48650513          	addi	a0,a0,1158 # 5fe8 <malloc+0x60e>
     b6a:	5b9040ef          	jal	5922 <printf>
    exit(1);
     b6e:	4505                	li	a0,1
     b70:	12d040ef          	jal	549c <exit>

0000000000000b74 <unlinkread>:
{
     b74:	7179                	addi	sp,sp,-48
     b76:	f406                	sd	ra,40(sp)
     b78:	f022                	sd	s0,32(sp)
     b7a:	ec26                	sd	s1,24(sp)
     b7c:	e84a                	sd	s2,16(sp)
     b7e:	e44e                	sd	s3,8(sp)
     b80:	1800                	addi	s0,sp,48
     b82:	89aa                	mv	s3,a0
  fd = open("unlinkread", O_CREATE | O_RDWR);
     b84:	20200593          	li	a1,514
     b88:	00005517          	auipc	a0,0x5
     b8c:	47850513          	addi	a0,a0,1144 # 6000 <malloc+0x626>
     b90:	14d040ef          	jal	54dc <open>
  if (fd < 0) {
     b94:	0a054f63          	bltz	a0,c52 <unlinkread+0xde>
     b98:	84aa                	mv	s1,a0
  write(fd, "hello", SZ);
     b9a:	4615                	li	a2,5
     b9c:	00005597          	auipc	a1,0x5
     ba0:	49458593          	addi	a1,a1,1172 # 6030 <malloc+0x656>
     ba4:	119040ef          	jal	54bc <write>
  close(fd);
     ba8:	8526                	mv	a0,s1
     baa:	11b040ef          	jal	54c4 <close>
  fd = open("unlinkread", O_RDWR);
     bae:	4589                	li	a1,2
     bb0:	00005517          	auipc	a0,0x5
     bb4:	45050513          	addi	a0,a0,1104 # 6000 <malloc+0x626>
     bb8:	125040ef          	jal	54dc <open>
     bbc:	84aa                	mv	s1,a0
  if (fd < 0) {
     bbe:	0a054463          	bltz	a0,c66 <unlinkread+0xf2>
  if (unlink("unlinkread") != 0) {
     bc2:	00005517          	auipc	a0,0x5
     bc6:	43e50513          	addi	a0,a0,1086 # 6000 <malloc+0x626>
     bca:	123040ef          	jal	54ec <unlink>
     bce:	e555                	bnez	a0,c7a <unlinkread+0x106>
  fd1 = open("unlinkread", O_CREATE | O_RDWR);
     bd0:	20200593          	li	a1,514
     bd4:	00005517          	auipc	a0,0x5
     bd8:	42c50513          	addi	a0,a0,1068 # 6000 <malloc+0x626>
     bdc:	101040ef          	jal	54dc <open>
     be0:	892a                	mv	s2,a0
  write(fd1, "yyy", 3);
     be2:	460d                	li	a2,3
     be4:	00005597          	auipc	a1,0x5
     be8:	49458593          	addi	a1,a1,1172 # 6078 <malloc+0x69e>
     bec:	0d1040ef          	jal	54bc <write>
  close(fd1);
     bf0:	854a                	mv	a0,s2
     bf2:	0d3040ef          	jal	54c4 <close>
  if (read(fd, buf, sizeof(buf)) != SZ) {
     bf6:	660d                	lui	a2,0x3
     bf8:	0000d597          	auipc	a1,0xd
     bfc:	0f058593          	addi	a1,a1,240 # dce8 <buf>
     c00:	8526                	mv	a0,s1
     c02:	0b3040ef          	jal	54b4 <read>
     c06:	4795                	li	a5,5
     c08:	08f51363          	bne	a0,a5,c8e <unlinkread+0x11a>
  if (buf[0] != 'h') {
     c0c:	0000d717          	auipc	a4,0xd
     c10:	0dc74703          	lbu	a4,220(a4) # dce8 <buf>
     c14:	06800793          	li	a5,104
     c18:	08f71563          	bne	a4,a5,ca2 <unlinkread+0x12e>
  if (write(fd, buf, 10) != 10) {
     c1c:	4629                	li	a2,10
     c1e:	0000d597          	auipc	a1,0xd
     c22:	0ca58593          	addi	a1,a1,202 # dce8 <buf>
     c26:	8526                	mv	a0,s1
     c28:	095040ef          	jal	54bc <write>
     c2c:	47a9                	li	a5,10
     c2e:	08f51463          	bne	a0,a5,cb6 <unlinkread+0x142>
  close(fd);
     c32:	8526                	mv	a0,s1
     c34:	091040ef          	jal	54c4 <close>
  unlink("unlinkread");
     c38:	00005517          	auipc	a0,0x5
     c3c:	3c850513          	addi	a0,a0,968 # 6000 <malloc+0x626>
     c40:	0ad040ef          	jal	54ec <unlink>
}
     c44:	70a2                	ld	ra,40(sp)
     c46:	7402                	ld	s0,32(sp)
     c48:	64e2                	ld	s1,24(sp)
     c4a:	6942                	ld	s2,16(sp)
     c4c:	69a2                	ld	s3,8(sp)
     c4e:	6145                	addi	sp,sp,48
     c50:	8082                	ret
    printf("%s: create unlinkread failed\n", s);
     c52:	85ce                	mv	a1,s3
     c54:	00005517          	auipc	a0,0x5
     c58:	3bc50513          	addi	a0,a0,956 # 6010 <malloc+0x636>
     c5c:	4c7040ef          	jal	5922 <printf>
    exit(1);
     c60:	4505                	li	a0,1
     c62:	03b040ef          	jal	549c <exit>
    printf("%s: open unlinkread failed\n", s);
     c66:	85ce                	mv	a1,s3
     c68:	00005517          	auipc	a0,0x5
     c6c:	3d050513          	addi	a0,a0,976 # 6038 <malloc+0x65e>
     c70:	4b3040ef          	jal	5922 <printf>
    exit(1);
     c74:	4505                	li	a0,1
     c76:	027040ef          	jal	549c <exit>
    printf("%s: unlink unlinkread failed\n", s);
     c7a:	85ce                	mv	a1,s3
     c7c:	00005517          	auipc	a0,0x5
     c80:	3dc50513          	addi	a0,a0,988 # 6058 <malloc+0x67e>
     c84:	49f040ef          	jal	5922 <printf>
    exit(1);
     c88:	4505                	li	a0,1
     c8a:	013040ef          	jal	549c <exit>
    printf("%s: unlinkread read failed", s);
     c8e:	85ce                	mv	a1,s3
     c90:	00005517          	auipc	a0,0x5
     c94:	3f050513          	addi	a0,a0,1008 # 6080 <malloc+0x6a6>
     c98:	48b040ef          	jal	5922 <printf>
    exit(1);
     c9c:	4505                	li	a0,1
     c9e:	7fe040ef          	jal	549c <exit>
    printf("%s: unlinkread wrong data\n", s);
     ca2:	85ce                	mv	a1,s3
     ca4:	00005517          	auipc	a0,0x5
     ca8:	3fc50513          	addi	a0,a0,1020 # 60a0 <malloc+0x6c6>
     cac:	477040ef          	jal	5922 <printf>
    exit(1);
     cb0:	4505                	li	a0,1
     cb2:	7ea040ef          	jal	549c <exit>
    printf("%s: unlinkread write failed\n", s);
     cb6:	85ce                	mv	a1,s3
     cb8:	00005517          	auipc	a0,0x5
     cbc:	40850513          	addi	a0,a0,1032 # 60c0 <malloc+0x6e6>
     cc0:	463040ef          	jal	5922 <printf>
    exit(1);
     cc4:	4505                	li	a0,1
     cc6:	7d6040ef          	jal	549c <exit>

0000000000000cca <linktest>:
{
     cca:	1101                	addi	sp,sp,-32
     ccc:	ec06                	sd	ra,24(sp)
     cce:	e822                	sd	s0,16(sp)
     cd0:	e426                	sd	s1,8(sp)
     cd2:	e04a                	sd	s2,0(sp)
     cd4:	1000                	addi	s0,sp,32
     cd6:	892a                	mv	s2,a0
  unlink("lf1");
     cd8:	00005517          	auipc	a0,0x5
     cdc:	40850513          	addi	a0,a0,1032 # 60e0 <malloc+0x706>
     ce0:	00d040ef          	jal	54ec <unlink>
  unlink("lf2");
     ce4:	00005517          	auipc	a0,0x5
     ce8:	40450513          	addi	a0,a0,1028 # 60e8 <malloc+0x70e>
     cec:	001040ef          	jal	54ec <unlink>
  fd = open("lf1", O_CREATE | O_RDWR);
     cf0:	20200593          	li	a1,514
     cf4:	00005517          	auipc	a0,0x5
     cf8:	3ec50513          	addi	a0,a0,1004 # 60e0 <malloc+0x706>
     cfc:	7e0040ef          	jal	54dc <open>
  if (fd < 0) {
     d00:	0c054f63          	bltz	a0,dde <linktest+0x114>
     d04:	84aa                	mv	s1,a0
  if (write(fd, "hello", SZ) != SZ) {
     d06:	4615                	li	a2,5
     d08:	00005597          	auipc	a1,0x5
     d0c:	32858593          	addi	a1,a1,808 # 6030 <malloc+0x656>
     d10:	7ac040ef          	jal	54bc <write>
     d14:	4795                	li	a5,5
     d16:	0cf51e63          	bne	a0,a5,df2 <linktest+0x128>
  close(fd);
     d1a:	8526                	mv	a0,s1
     d1c:	7a8040ef          	jal	54c4 <close>
  if (link("lf1", "lf2") < 0) {
     d20:	00005597          	auipc	a1,0x5
     d24:	3c858593          	addi	a1,a1,968 # 60e8 <malloc+0x70e>
     d28:	00005517          	auipc	a0,0x5
     d2c:	3b850513          	addi	a0,a0,952 # 60e0 <malloc+0x706>
     d30:	7cc040ef          	jal	54fc <link>
     d34:	0c054963          	bltz	a0,e06 <linktest+0x13c>
  unlink("lf1");
     d38:	00005517          	auipc	a0,0x5
     d3c:	3a850513          	addi	a0,a0,936 # 60e0 <malloc+0x706>
     d40:	7ac040ef          	jal	54ec <unlink>
  if (open("lf1", 0) >= 0) {
     d44:	4581                	li	a1,0
     d46:	00005517          	auipc	a0,0x5
     d4a:	39a50513          	addi	a0,a0,922 # 60e0 <malloc+0x706>
     d4e:	78e040ef          	jal	54dc <open>
     d52:	0c055463          	bgez	a0,e1a <linktest+0x150>
  fd = open("lf2", 0);
     d56:	4581                	li	a1,0
     d58:	00005517          	auipc	a0,0x5
     d5c:	39050513          	addi	a0,a0,912 # 60e8 <malloc+0x70e>
     d60:	77c040ef          	jal	54dc <open>
     d64:	84aa                	mv	s1,a0
  if (fd < 0) {
     d66:	0c054463          	bltz	a0,e2e <linktest+0x164>
  if (read(fd, buf, sizeof(buf)) != SZ) {
     d6a:	660d                	lui	a2,0x3
     d6c:	0000d597          	auipc	a1,0xd
     d70:	f7c58593          	addi	a1,a1,-132 # dce8 <buf>
     d74:	740040ef          	jal	54b4 <read>
     d78:	4795                	li	a5,5
     d7a:	0cf51463          	bne	a0,a5,e42 <linktest+0x178>
  close(fd);
     d7e:	8526                	mv	a0,s1
     d80:	744040ef          	jal	54c4 <close>
  if (link("lf2", "lf2") >= 0) {
     d84:	00005597          	auipc	a1,0x5
     d88:	36458593          	addi	a1,a1,868 # 60e8 <malloc+0x70e>
     d8c:	852e                	mv	a0,a1
     d8e:	76e040ef          	jal	54fc <link>
     d92:	0c055263          	bgez	a0,e56 <linktest+0x18c>
  unlink("lf2");
     d96:	00005517          	auipc	a0,0x5
     d9a:	35250513          	addi	a0,a0,850 # 60e8 <malloc+0x70e>
     d9e:	74e040ef          	jal	54ec <unlink>
  if (link("lf2", "lf1") >= 0) {
     da2:	00005597          	auipc	a1,0x5
     da6:	33e58593          	addi	a1,a1,830 # 60e0 <malloc+0x706>
     daa:	00005517          	auipc	a0,0x5
     dae:	33e50513          	addi	a0,a0,830 # 60e8 <malloc+0x70e>
     db2:	74a040ef          	jal	54fc <link>
     db6:	0a055a63          	bgez	a0,e6a <linktest+0x1a0>
  if (link(".", "lf1") >= 0) {
     dba:	00005597          	auipc	a1,0x5
     dbe:	32658593          	addi	a1,a1,806 # 60e0 <malloc+0x706>
     dc2:	00005517          	auipc	a0,0x5
     dc6:	42e50513          	addi	a0,a0,1070 # 61f0 <malloc+0x816>
     dca:	732040ef          	jal	54fc <link>
     dce:	0a055863          	bgez	a0,e7e <linktest+0x1b4>
}
     dd2:	60e2                	ld	ra,24(sp)
     dd4:	6442                	ld	s0,16(sp)
     dd6:	64a2                	ld	s1,8(sp)
     dd8:	6902                	ld	s2,0(sp)
     dda:	6105                	addi	sp,sp,32
     ddc:	8082                	ret
    printf("%s: create lf1 failed\n", s);
     dde:	85ca                	mv	a1,s2
     de0:	00005517          	auipc	a0,0x5
     de4:	31050513          	addi	a0,a0,784 # 60f0 <malloc+0x716>
     de8:	33b040ef          	jal	5922 <printf>
    exit(1);
     dec:	4505                	li	a0,1
     dee:	6ae040ef          	jal	549c <exit>
    printf("%s: write lf1 failed\n", s);
     df2:	85ca                	mv	a1,s2
     df4:	00005517          	auipc	a0,0x5
     df8:	31450513          	addi	a0,a0,788 # 6108 <malloc+0x72e>
     dfc:	327040ef          	jal	5922 <printf>
    exit(1);
     e00:	4505                	li	a0,1
     e02:	69a040ef          	jal	549c <exit>
    printf("%s: link lf1 lf2 failed\n", s);
     e06:	85ca                	mv	a1,s2
     e08:	00005517          	auipc	a0,0x5
     e0c:	31850513          	addi	a0,a0,792 # 6120 <malloc+0x746>
     e10:	313040ef          	jal	5922 <printf>
    exit(1);
     e14:	4505                	li	a0,1
     e16:	686040ef          	jal	549c <exit>
    printf("%s: unlinked lf1 but it is still there!\n", s);
     e1a:	85ca                	mv	a1,s2
     e1c:	00005517          	auipc	a0,0x5
     e20:	32450513          	addi	a0,a0,804 # 6140 <malloc+0x766>
     e24:	2ff040ef          	jal	5922 <printf>
    exit(1);
     e28:	4505                	li	a0,1
     e2a:	672040ef          	jal	549c <exit>
    printf("%s: open lf2 failed\n", s);
     e2e:	85ca                	mv	a1,s2
     e30:	00005517          	auipc	a0,0x5
     e34:	34050513          	addi	a0,a0,832 # 6170 <malloc+0x796>
     e38:	2eb040ef          	jal	5922 <printf>
    exit(1);
     e3c:	4505                	li	a0,1
     e3e:	65e040ef          	jal	549c <exit>
    printf("%s: read lf2 failed\n", s);
     e42:	85ca                	mv	a1,s2
     e44:	00005517          	auipc	a0,0x5
     e48:	34450513          	addi	a0,a0,836 # 6188 <malloc+0x7ae>
     e4c:	2d7040ef          	jal	5922 <printf>
    exit(1);
     e50:	4505                	li	a0,1
     e52:	64a040ef          	jal	549c <exit>
    printf("%s: link lf2 lf2 succeeded! oops\n", s);
     e56:	85ca                	mv	a1,s2
     e58:	00005517          	auipc	a0,0x5
     e5c:	34850513          	addi	a0,a0,840 # 61a0 <malloc+0x7c6>
     e60:	2c3040ef          	jal	5922 <printf>
    exit(1);
     e64:	4505                	li	a0,1
     e66:	636040ef          	jal	549c <exit>
    printf("%s: link non-existent succeeded! oops\n", s);
     e6a:	85ca                	mv	a1,s2
     e6c:	00005517          	auipc	a0,0x5
     e70:	35c50513          	addi	a0,a0,860 # 61c8 <malloc+0x7ee>
     e74:	2af040ef          	jal	5922 <printf>
    exit(1);
     e78:	4505                	li	a0,1
     e7a:	622040ef          	jal	549c <exit>
    printf("%s: link . lf1 succeeded! oops\n", s);
     e7e:	85ca                	mv	a1,s2
     e80:	00005517          	auipc	a0,0x5
     e84:	37850513          	addi	a0,a0,888 # 61f8 <malloc+0x81e>
     e88:	29b040ef          	jal	5922 <printf>
    exit(1);
     e8c:	4505                	li	a0,1
     e8e:	60e040ef          	jal	549c <exit>

0000000000000e92 <validatetest>:
{
     e92:	7139                	addi	sp,sp,-64
     e94:	fc06                	sd	ra,56(sp)
     e96:	f822                	sd	s0,48(sp)
     e98:	f426                	sd	s1,40(sp)
     e9a:	f04a                	sd	s2,32(sp)
     e9c:	ec4e                	sd	s3,24(sp)
     e9e:	e852                	sd	s4,16(sp)
     ea0:	e456                	sd	s5,8(sp)
     ea2:	e05a                	sd	s6,0(sp)
     ea4:	0080                	addi	s0,sp,64
     ea6:	8b2a                	mv	s6,a0
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     ea8:	4481                	li	s1,0
    if (link("nosuchfile", (char *)p) != -1) {
     eaa:	00005997          	auipc	s3,0x5
     eae:	36e98993          	addi	s3,s3,878 # 6218 <malloc+0x83e>
     eb2:	597d                	li	s2,-1
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     eb4:	6a85                	lui	s5,0x1
     eb6:	00114a37          	lui	s4,0x114
    if (link("nosuchfile", (char *)p) != -1) {
     eba:	85a6                	mv	a1,s1
     ebc:	854e                	mv	a0,s3
     ebe:	63e040ef          	jal	54fc <link>
     ec2:	01251f63          	bne	a0,s2,ee0 <validatetest+0x4e>
  for (p = 0; p <= (uint)hi; p += PGSIZE) {
     ec6:	94d6                	add	s1,s1,s5
     ec8:	ff4499e3          	bne	s1,s4,eba <validatetest+0x28>
}
     ecc:	70e2                	ld	ra,56(sp)
     ece:	7442                	ld	s0,48(sp)
     ed0:	74a2                	ld	s1,40(sp)
     ed2:	7902                	ld	s2,32(sp)
     ed4:	69e2                	ld	s3,24(sp)
     ed6:	6a42                	ld	s4,16(sp)
     ed8:	6aa2                	ld	s5,8(sp)
     eda:	6b02                	ld	s6,0(sp)
     edc:	6121                	addi	sp,sp,64
     ede:	8082                	ret
      printf("%s: link should not succeed\n", s);
     ee0:	85da                	mv	a1,s6
     ee2:	00005517          	auipc	a0,0x5
     ee6:	34650513          	addi	a0,a0,838 # 6228 <malloc+0x84e>
     eea:	239040ef          	jal	5922 <printf>
      exit(1);
     eee:	4505                	li	a0,1
     ef0:	5ac040ef          	jal	549c <exit>

0000000000000ef4 <bigdir>:
{
     ef4:	711d                	addi	sp,sp,-96
     ef6:	ec86                	sd	ra,88(sp)
     ef8:	e8a2                	sd	s0,80(sp)
     efa:	e4a6                	sd	s1,72(sp)
     efc:	e0ca                	sd	s2,64(sp)
     efe:	fc4e                	sd	s3,56(sp)
     f00:	f852                	sd	s4,48(sp)
     f02:	f456                	sd	s5,40(sp)
     f04:	f05a                	sd	s6,32(sp)
     f06:	ec5e                	sd	s7,24(sp)
     f08:	1080                	addi	s0,sp,96
     f0a:	8baa                	mv	s7,a0
  unlink("bd");
     f0c:	00005517          	auipc	a0,0x5
     f10:	33c50513          	addi	a0,a0,828 # 6248 <malloc+0x86e>
     f14:	5d8040ef          	jal	54ec <unlink>
  fd = open("bd", O_CREATE);
     f18:	20000593          	li	a1,512
     f1c:	00005517          	auipc	a0,0x5
     f20:	32c50513          	addi	a0,a0,812 # 6248 <malloc+0x86e>
     f24:	5b8040ef          	jal	54dc <open>
  if (fd < 0) {
     f28:	0c054463          	bltz	a0,ff0 <bigdir+0xfc>
  close(fd);
     f2c:	598040ef          	jal	54c4 <close>
  for (i = 0; i < N; i++) {
     f30:	4901                	li	s2,0
    name[0] = 'x';
     f32:	07800a93          	li	s5,120
    if (link("bd", name) != 0) {
     f36:	fa040a13          	addi	s4,s0,-96
     f3a:	00005997          	auipc	s3,0x5
     f3e:	30e98993          	addi	s3,s3,782 # 6248 <malloc+0x86e>
  for (i = 0; i < N; i++) {
     f42:	1f400b13          	li	s6,500
    name[0] = 'x';
     f46:	fb540023          	sb	s5,-96(s0)
    name[1] = '0' + (i / 64);
     f4a:	41f9571b          	sraiw	a4,s2,0x1f
     f4e:	01a7571b          	srliw	a4,a4,0x1a
     f52:	012707bb          	addw	a5,a4,s2
     f56:	4067d69b          	sraiw	a3,a5,0x6
     f5a:	0306869b          	addiw	a3,a3,48
     f5e:	fad400a3          	sb	a3,-95(s0)
    name[2] = '0' + (i % 64);
     f62:	03f7f793          	andi	a5,a5,63
     f66:	9f99                	subw	a5,a5,a4
     f68:	0307879b          	addiw	a5,a5,48
     f6c:	faf40123          	sb	a5,-94(s0)
    name[3] = '\0';
     f70:	fa0401a3          	sb	zero,-93(s0)
    if (link("bd", name) != 0) {
     f74:	85d2                	mv	a1,s4
     f76:	854e                	mv	a0,s3
     f78:	584040ef          	jal	54fc <link>
     f7c:	84aa                	mv	s1,a0
     f7e:	e159                	bnez	a0,1004 <bigdir+0x110>
  for (i = 0; i < N; i++) {
     f80:	2905                	addiw	s2,s2,1
     f82:	fd6912e3          	bne	s2,s6,f46 <bigdir+0x52>
  unlink("bd");
     f86:	00005517          	auipc	a0,0x5
     f8a:	2c250513          	addi	a0,a0,706 # 6248 <malloc+0x86e>
     f8e:	55e040ef          	jal	54ec <unlink>
    name[0] = 'x';
     f92:	07800993          	li	s3,120
    if (unlink(name) != 0) {
     f96:	fa040913          	addi	s2,s0,-96
  for (i = 0; i < N; i++) {
     f9a:	1f400a13          	li	s4,500
    name[0] = 'x';
     f9e:	fb340023          	sb	s3,-96(s0)
    name[1] = '0' + (i / 64);
     fa2:	41f4d71b          	sraiw	a4,s1,0x1f
     fa6:	01a7571b          	srliw	a4,a4,0x1a
     faa:	009707bb          	addw	a5,a4,s1
     fae:	4067d69b          	sraiw	a3,a5,0x6
     fb2:	0306869b          	addiw	a3,a3,48
     fb6:	fad400a3          	sb	a3,-95(s0)
    name[2] = '0' + (i % 64);
     fba:	03f7f793          	andi	a5,a5,63
     fbe:	9f99                	subw	a5,a5,a4
     fc0:	0307879b          	addiw	a5,a5,48
     fc4:	faf40123          	sb	a5,-94(s0)
    name[3] = '\0';
     fc8:	fa0401a3          	sb	zero,-93(s0)
    if (unlink(name) != 0) {
     fcc:	854a                	mv	a0,s2
     fce:	51e040ef          	jal	54ec <unlink>
     fd2:	e531                	bnez	a0,101e <bigdir+0x12a>
  for (i = 0; i < N; i++) {
     fd4:	2485                	addiw	s1,s1,1
     fd6:	fd4494e3          	bne	s1,s4,f9e <bigdir+0xaa>
}
     fda:	60e6                	ld	ra,88(sp)
     fdc:	6446                	ld	s0,80(sp)
     fde:	64a6                	ld	s1,72(sp)
     fe0:	6906                	ld	s2,64(sp)
     fe2:	79e2                	ld	s3,56(sp)
     fe4:	7a42                	ld	s4,48(sp)
     fe6:	7aa2                	ld	s5,40(sp)
     fe8:	7b02                	ld	s6,32(sp)
     fea:	6be2                	ld	s7,24(sp)
     fec:	6125                	addi	sp,sp,96
     fee:	8082                	ret
    printf("%s: bigdir create failed\n", s);
     ff0:	85de                	mv	a1,s7
     ff2:	00005517          	auipc	a0,0x5
     ff6:	25e50513          	addi	a0,a0,606 # 6250 <malloc+0x876>
     ffa:	129040ef          	jal	5922 <printf>
    exit(1);
     ffe:	4505                	li	a0,1
    1000:	49c040ef          	jal	549c <exit>
      printf("%s: bigdir i=%d link(bd, %s) failed\n", s, i, name);
    1004:	fa040693          	addi	a3,s0,-96
    1008:	864a                	mv	a2,s2
    100a:	85de                	mv	a1,s7
    100c:	00005517          	auipc	a0,0x5
    1010:	26450513          	addi	a0,a0,612 # 6270 <malloc+0x896>
    1014:	10f040ef          	jal	5922 <printf>
      exit(1);
    1018:	4505                	li	a0,1
    101a:	482040ef          	jal	549c <exit>
      printf("%s: bigdir unlink failed", s);
    101e:	85de                	mv	a1,s7
    1020:	00005517          	auipc	a0,0x5
    1024:	27850513          	addi	a0,a0,632 # 6298 <malloc+0x8be>
    1028:	0fb040ef          	jal	5922 <printf>
      exit(1);
    102c:	4505                	li	a0,1
    102e:	46e040ef          	jal	549c <exit>

0000000000001032 <pgbug>:
{
    1032:	7179                	addi	sp,sp,-48
    1034:	f406                	sd	ra,40(sp)
    1036:	f022                	sd	s0,32(sp)
    1038:	ec26                	sd	s1,24(sp)
    103a:	1800                	addi	s0,sp,48
  argv[0] = 0;
    103c:	fc043c23          	sd	zero,-40(s0)
  exec(big, argv);
    1040:	00009497          	auipc	s1,0x9
    1044:	fc048493          	addi	s1,s1,-64 # a000 <big>
    1048:	fd840593          	addi	a1,s0,-40
    104c:	6088                	ld	a0,0(s1)
    104e:	486040ef          	jal	54d4 <exec>
  pipe(big);
    1052:	6088                	ld	a0,0(s1)
    1054:	458040ef          	jal	54ac <pipe>
  exit(0);
    1058:	4501                	li	a0,0
    105a:	442040ef          	jal	549c <exit>

000000000000105e <badarg>:
{
    105e:	7139                	addi	sp,sp,-64
    1060:	fc06                	sd	ra,56(sp)
    1062:	f822                	sd	s0,48(sp)
    1064:	f426                	sd	s1,40(sp)
    1066:	f04a                	sd	s2,32(sp)
    1068:	ec4e                	sd	s3,24(sp)
    106a:	e852                	sd	s4,16(sp)
    106c:	0080                	addi	s0,sp,64
    106e:	64b1                	lui	s1,0xc
    1070:	35048493          	addi	s1,s1,848 # c350 <uninit+0xd78>
    argv[0] = (char *)0xffffffff;
    1074:	597d                	li	s2,-1
    1076:	02095913          	srli	s2,s2,0x20
    exec("echo", argv);
    107a:	fc040a13          	addi	s4,s0,-64
    107e:	00005997          	auipc	s3,0x5
    1082:	a8a98993          	addi	s3,s3,-1398 # 5b08 <malloc+0x12e>
    argv[0] = (char *)0xffffffff;
    1086:	fd243023          	sd	s2,-64(s0)
    argv[1] = 0;
    108a:	fc043423          	sd	zero,-56(s0)
    exec("echo", argv);
    108e:	85d2                	mv	a1,s4
    1090:	854e                	mv	a0,s3
    1092:	442040ef          	jal	54d4 <exec>
  for (int i = 0; i < 50000; i++) {
    1096:	34fd                	addiw	s1,s1,-1
    1098:	f4fd                	bnez	s1,1086 <badarg+0x28>
  exit(0);
    109a:	4501                	li	a0,0
    109c:	400040ef          	jal	549c <exit>

00000000000010a0 <copyinstr2>:
{
    10a0:	7155                	addi	sp,sp,-208
    10a2:	e586                	sd	ra,200(sp)
    10a4:	e1a2                	sd	s0,192(sp)
    10a6:	0980                	addi	s0,sp,208
  for (int i = 0; i < MAXPATH; i++)
    10a8:	f6840793          	addi	a5,s0,-152
    10ac:	fe840693          	addi	a3,s0,-24
    b[i] = 'x';
    10b0:	07800713          	li	a4,120
    10b4:	00e78023          	sb	a4,0(a5)
  for (int i = 0; i < MAXPATH; i++)
    10b8:	0785                	addi	a5,a5,1
    10ba:	fed79de3          	bne	a5,a3,10b4 <copyinstr2+0x14>
  b[MAXPATH] = '\0';
    10be:	fe040423          	sb	zero,-24(s0)
  int ret = unlink(b);
    10c2:	f6840513          	addi	a0,s0,-152
    10c6:	426040ef          	jal	54ec <unlink>
  if (ret != -1) {
    10ca:	57fd                	li	a5,-1
    10cc:	0cf51263          	bne	a0,a5,1190 <copyinstr2+0xf0>
  int fd = open(b, O_CREATE | O_WRONLY);
    10d0:	20100593          	li	a1,513
    10d4:	f6840513          	addi	a0,s0,-152
    10d8:	404040ef          	jal	54dc <open>
  if (fd != -1) {
    10dc:	57fd                	li	a5,-1
    10de:	0cf51563          	bne	a0,a5,11a8 <copyinstr2+0x108>
  ret = link(b, b);
    10e2:	f6840513          	addi	a0,s0,-152
    10e6:	85aa                	mv	a1,a0
    10e8:	414040ef          	jal	54fc <link>
  if (ret != -1) {
    10ec:	57fd                	li	a5,-1
    10ee:	0cf51963          	bne	a0,a5,11c0 <copyinstr2+0x120>
  char *args[] = {"xx", 0};
    10f2:	00006797          	auipc	a5,0x6
    10f6:	28e78793          	addi	a5,a5,654 # 7380 <malloc+0x19a6>
    10fa:	f4f43c23          	sd	a5,-168(s0)
    10fe:	f6043023          	sd	zero,-160(s0)
  ret = exec(b, args);
    1102:	f5840593          	addi	a1,s0,-168
    1106:	f6840513          	addi	a0,s0,-152
    110a:	3ca040ef          	jal	54d4 <exec>
  if (ret != -1) {
    110e:	57fd                	li	a5,-1
    1110:	0cf51563          	bne	a0,a5,11da <copyinstr2+0x13a>
  int pid = fork();
    1114:	380040ef          	jal	5494 <fork>
  if (pid < 0) {
    1118:	0c054d63          	bltz	a0,11f2 <copyinstr2+0x152>
  if (pid == 0) {
    111c:	0e051863          	bnez	a0,120c <copyinstr2+0x16c>
    1120:	00009797          	auipc	a5,0x9
    1124:	4b078793          	addi	a5,a5,1200 # a5d0 <big.0>
    1128:	0000a697          	auipc	a3,0xa
    112c:	4a868693          	addi	a3,a3,1192 # b5d0 <big.0+0x1000>
      big[i] = 'x';
    1130:	07800713          	li	a4,120
    1134:	00e78023          	sb	a4,0(a5)
    for (int i = 0; i < PGSIZE; i++)
    1138:	0785                	addi	a5,a5,1
    113a:	fed79de3          	bne	a5,a3,1134 <copyinstr2+0x94>
    big[PGSIZE] = '\0';
    113e:	0000a797          	auipc	a5,0xa
    1142:	48078923          	sb	zero,1170(a5) # b5d0 <big.0+0x1000>
    char *args2[] = {big, big, big, 0};
    1146:	00007797          	auipc	a5,0x7
    114a:	1c278793          	addi	a5,a5,450 # 8308 <malloc+0x292e>
    114e:	6fb0                	ld	a2,88(a5)
    1150:	73b4                	ld	a3,96(a5)
    1152:	77b8                	ld	a4,104(a5)
    1154:	f2c43823          	sd	a2,-208(s0)
    1158:	f2d43c23          	sd	a3,-200(s0)
    115c:	f4e43023          	sd	a4,-192(s0)
    1160:	7bbc                	ld	a5,112(a5)
    1162:	f4f43423          	sd	a5,-184(s0)
    ret = exec("echo", args2);
    1166:	f3040593          	addi	a1,s0,-208
    116a:	00005517          	auipc	a0,0x5
    116e:	99e50513          	addi	a0,a0,-1634 # 5b08 <malloc+0x12e>
    1172:	362040ef          	jal	54d4 <exec>
    if (ret != -1) {
    1176:	57fd                	li	a5,-1
    1178:	08f50663          	beq	a0,a5,1204 <copyinstr2+0x164>
      printf("exec(echo, BIG) returned %d, not -1\n", fd);
    117c:	85be                	mv	a1,a5
    117e:	00005517          	auipc	a0,0x5
    1182:	1c250513          	addi	a0,a0,450 # 6340 <malloc+0x966>
    1186:	79c040ef          	jal	5922 <printf>
      exit(1);
    118a:	4505                	li	a0,1
    118c:	310040ef          	jal	549c <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1190:	862a                	mv	a2,a0
    1192:	f6840593          	addi	a1,s0,-152
    1196:	00005517          	auipc	a0,0x5
    119a:	12250513          	addi	a0,a0,290 # 62b8 <malloc+0x8de>
    119e:	784040ef          	jal	5922 <printf>
    exit(1);
    11a2:	4505                	li	a0,1
    11a4:	2f8040ef          	jal	549c <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    11a8:	862a                	mv	a2,a0
    11aa:	f6840593          	addi	a1,s0,-152
    11ae:	00005517          	auipc	a0,0x5
    11b2:	12a50513          	addi	a0,a0,298 # 62d8 <malloc+0x8fe>
    11b6:	76c040ef          	jal	5922 <printf>
    exit(1);
    11ba:	4505                	li	a0,1
    11bc:	2e0040ef          	jal	549c <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    11c0:	f6840593          	addi	a1,s0,-152
    11c4:	86aa                	mv	a3,a0
    11c6:	862e                	mv	a2,a1
    11c8:	00005517          	auipc	a0,0x5
    11cc:	13050513          	addi	a0,a0,304 # 62f8 <malloc+0x91e>
    11d0:	752040ef          	jal	5922 <printf>
    exit(1);
    11d4:	4505                	li	a0,1
    11d6:	2c6040ef          	jal	549c <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    11da:	863e                	mv	a2,a5
    11dc:	f6840593          	addi	a1,s0,-152
    11e0:	00005517          	auipc	a0,0x5
    11e4:	14050513          	addi	a0,a0,320 # 6320 <malloc+0x946>
    11e8:	73a040ef          	jal	5922 <printf>
    exit(1);
    11ec:	4505                	li	a0,1
    11ee:	2ae040ef          	jal	549c <exit>
    printf("fork failed\n");
    11f2:	00007517          	auipc	a0,0x7
    11f6:	86650513          	addi	a0,a0,-1946 # 7a58 <malloc+0x207e>
    11fa:	728040ef          	jal	5922 <printf>
    exit(1);
    11fe:	4505                	li	a0,1
    1200:	29c040ef          	jal	549c <exit>
    exit(747); // OK
    1204:	2eb00513          	li	a0,747
    1208:	294040ef          	jal	549c <exit>
  int st = 0;
    120c:	f4042a23          	sw	zero,-172(s0)
  wait(&st);
    1210:	f5440513          	addi	a0,s0,-172
    1214:	290040ef          	jal	54a4 <wait>
  if (st != 747) {
    1218:	f5442703          	lw	a4,-172(s0)
    121c:	2eb00793          	li	a5,747
    1220:	00f71663          	bne	a4,a5,122c <copyinstr2+0x18c>
}
    1224:	60ae                	ld	ra,200(sp)
    1226:	640e                	ld	s0,192(sp)
    1228:	6169                	addi	sp,sp,208
    122a:	8082                	ret
    printf("exec(echo, BIG) succeeded, should have failed\n");
    122c:	00005517          	auipc	a0,0x5
    1230:	13c50513          	addi	a0,a0,316 # 6368 <malloc+0x98e>
    1234:	6ee040ef          	jal	5922 <printf>
    exit(1);
    1238:	4505                	li	a0,1
    123a:	262040ef          	jal	549c <exit>

000000000000123e <truncate3>:
{
    123e:	7175                	addi	sp,sp,-144
    1240:	e506                	sd	ra,136(sp)
    1242:	e122                	sd	s0,128(sp)
    1244:	fc66                	sd	s9,56(sp)
    1246:	0900                	addi	s0,sp,144
    1248:	8caa                	mv	s9,a0
  close(open("truncfile", O_CREATE | O_TRUNC | O_WRONLY));
    124a:	60100593          	li	a1,1537
    124e:	00005517          	auipc	a0,0x5
    1252:	91250513          	addi	a0,a0,-1774 # 5b60 <malloc+0x186>
    1256:	286040ef          	jal	54dc <open>
    125a:	26a040ef          	jal	54c4 <close>
  pid = fork();
    125e:	236040ef          	jal	5494 <fork>
  if (pid < 0) {
    1262:	06054d63          	bltz	a0,12dc <truncate3+0x9e>
  if (pid == 0) {
    1266:	e171                	bnez	a0,132a <truncate3+0xec>
    1268:	fca6                	sd	s1,120(sp)
    126a:	f8ca                	sd	s2,112(sp)
    126c:	f4ce                	sd	s3,104(sp)
    126e:	f0d2                	sd	s4,96(sp)
    1270:	ecd6                	sd	s5,88(sp)
    1272:	e8da                	sd	s6,80(sp)
    1274:	e4de                	sd	s7,72(sp)
    1276:	e0e2                	sd	s8,64(sp)
    1278:	06400913          	li	s2,100
      int fd = open("truncfile", O_WRONLY);
    127c:	4a85                	li	s5,1
    127e:	00005997          	auipc	s3,0x5
    1282:	8e298993          	addi	s3,s3,-1822 # 5b60 <malloc+0x186>
      int n = write(fd, "1234567890", 10);
    1286:	4a29                	li	s4,10
    1288:	00005b17          	auipc	s6,0x5
    128c:	140b0b13          	addi	s6,s6,320 # 63c8 <malloc+0x9ee>
      read(fd, buf, sizeof(buf));
    1290:	f7840c13          	addi	s8,s0,-136
    1294:	02000b93          	li	s7,32
      int fd = open("truncfile", O_WRONLY);
    1298:	85d6                	mv	a1,s5
    129a:	854e                	mv	a0,s3
    129c:	240040ef          	jal	54dc <open>
    12a0:	84aa                	mv	s1,a0
      if (fd < 0) {
    12a2:	04054f63          	bltz	a0,1300 <truncate3+0xc2>
      int n = write(fd, "1234567890", 10);
    12a6:	8652                	mv	a2,s4
    12a8:	85da                	mv	a1,s6
    12aa:	212040ef          	jal	54bc <write>
      if (n != 10) {
    12ae:	07451363          	bne	a0,s4,1314 <truncate3+0xd6>
      close(fd);
    12b2:	8526                	mv	a0,s1
    12b4:	210040ef          	jal	54c4 <close>
      fd = open("truncfile", O_RDONLY);
    12b8:	4581                	li	a1,0
    12ba:	854e                	mv	a0,s3
    12bc:	220040ef          	jal	54dc <open>
    12c0:	84aa                	mv	s1,a0
      read(fd, buf, sizeof(buf));
    12c2:	865e                	mv	a2,s7
    12c4:	85e2                	mv	a1,s8
    12c6:	1ee040ef          	jal	54b4 <read>
      close(fd);
    12ca:	8526                	mv	a0,s1
    12cc:	1f8040ef          	jal	54c4 <close>
    for (int i = 0; i < 100; i++) {
    12d0:	397d                	addiw	s2,s2,-1
    12d2:	fc0913e3          	bnez	s2,1298 <truncate3+0x5a>
    exit(0);
    12d6:	4501                	li	a0,0
    12d8:	1c4040ef          	jal	549c <exit>
    12dc:	fca6                	sd	s1,120(sp)
    12de:	f8ca                	sd	s2,112(sp)
    12e0:	f4ce                	sd	s3,104(sp)
    12e2:	f0d2                	sd	s4,96(sp)
    12e4:	ecd6                	sd	s5,88(sp)
    12e6:	e8da                	sd	s6,80(sp)
    12e8:	e4de                	sd	s7,72(sp)
    12ea:	e0e2                	sd	s8,64(sp)
    printf("%s: fork failed\n", s);
    12ec:	85e6                	mv	a1,s9
    12ee:	00005517          	auipc	a0,0x5
    12f2:	0aa50513          	addi	a0,a0,170 # 6398 <malloc+0x9be>
    12f6:	62c040ef          	jal	5922 <printf>
    exit(1);
    12fa:	4505                	li	a0,1
    12fc:	1a0040ef          	jal	549c <exit>
        printf("%s: open failed\n", s);
    1300:	85e6                	mv	a1,s9
    1302:	00005517          	auipc	a0,0x5
    1306:	0ae50513          	addi	a0,a0,174 # 63b0 <malloc+0x9d6>
    130a:	618040ef          	jal	5922 <printf>
        exit(1);
    130e:	4505                	li	a0,1
    1310:	18c040ef          	jal	549c <exit>
        printf("%s: write got %d, expected 10\n", s, n);
    1314:	862a                	mv	a2,a0
    1316:	85e6                	mv	a1,s9
    1318:	00005517          	auipc	a0,0x5
    131c:	0c050513          	addi	a0,a0,192 # 63d8 <malloc+0x9fe>
    1320:	602040ef          	jal	5922 <printf>
        exit(1);
    1324:	4505                	li	a0,1
    1326:	176040ef          	jal	549c <exit>
    132a:	fca6                	sd	s1,120(sp)
    132c:	f8ca                	sd	s2,112(sp)
    132e:	f4ce                	sd	s3,104(sp)
    1330:	f0d2                	sd	s4,96(sp)
    1332:	ecd6                	sd	s5,88(sp)
    1334:	e8da                	sd	s6,80(sp)
    1336:	09600913          	li	s2,150
    int fd = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
    133a:	60100a93          	li	s5,1537
    133e:	00005a17          	auipc	s4,0x5
    1342:	822a0a13          	addi	s4,s4,-2014 # 5b60 <malloc+0x186>
    int n = write(fd, "xxx", 3);
    1346:	498d                	li	s3,3
    1348:	00005b17          	auipc	s6,0x5
    134c:	0b0b0b13          	addi	s6,s6,176 # 63f8 <malloc+0xa1e>
    int fd = open("truncfile", O_CREATE | O_WRONLY | O_TRUNC);
    1350:	85d6                	mv	a1,s5
    1352:	8552                	mv	a0,s4
    1354:	188040ef          	jal	54dc <open>
    1358:	84aa                	mv	s1,a0
    if (fd < 0) {
    135a:	02054e63          	bltz	a0,1396 <truncate3+0x158>
    int n = write(fd, "xxx", 3);
    135e:	864e                	mv	a2,s3
    1360:	85da                	mv	a1,s6
    1362:	15a040ef          	jal	54bc <write>
    if (n != 3) {
    1366:	05351463          	bne	a0,s3,13ae <truncate3+0x170>
    close(fd);
    136a:	8526                	mv	a0,s1
    136c:	158040ef          	jal	54c4 <close>
  for (int i = 0; i < 150; i++) {
    1370:	397d                	addiw	s2,s2,-1
    1372:	fc091fe3          	bnez	s2,1350 <truncate3+0x112>
    1376:	e4de                	sd	s7,72(sp)
    1378:	e0e2                	sd	s8,64(sp)
  wait(&xstatus);
    137a:	f9c40513          	addi	a0,s0,-100
    137e:	126040ef          	jal	54a4 <wait>
  unlink("truncfile");
    1382:	00004517          	auipc	a0,0x4
    1386:	7de50513          	addi	a0,a0,2014 # 5b60 <malloc+0x186>
    138a:	162040ef          	jal	54ec <unlink>
  exit(xstatus);
    138e:	f9c42503          	lw	a0,-100(s0)
    1392:	10a040ef          	jal	549c <exit>
    1396:	e4de                	sd	s7,72(sp)
    1398:	e0e2                	sd	s8,64(sp)
      printf("%s: open failed\n", s);
    139a:	85e6                	mv	a1,s9
    139c:	00005517          	auipc	a0,0x5
    13a0:	01450513          	addi	a0,a0,20 # 63b0 <malloc+0x9d6>
    13a4:	57e040ef          	jal	5922 <printf>
      exit(1);
    13a8:	4505                	li	a0,1
    13aa:	0f2040ef          	jal	549c <exit>
    13ae:	e4de                	sd	s7,72(sp)
    13b0:	e0e2                	sd	s8,64(sp)
      printf("%s: write got %d, expected 3\n", s, n);
    13b2:	862a                	mv	a2,a0
    13b4:	85e6                	mv	a1,s9
    13b6:	00005517          	auipc	a0,0x5
    13ba:	04a50513          	addi	a0,a0,74 # 6400 <malloc+0xa26>
    13be:	564040ef          	jal	5922 <printf>
      exit(1);
    13c2:	4505                	li	a0,1
    13c4:	0d8040ef          	jal	549c <exit>

00000000000013c8 <pipe1>:
{
    13c8:	711d                	addi	sp,sp,-96
    13ca:	ec86                	sd	ra,88(sp)
    13cc:	e8a2                	sd	s0,80(sp)
    13ce:	e862                	sd	s8,16(sp)
    13d0:	1080                	addi	s0,sp,96
    13d2:	8c2a                	mv	s8,a0
  if (pipe(fds) != 0) {
    13d4:	fa840513          	addi	a0,s0,-88
    13d8:	0d4040ef          	jal	54ac <pipe>
    13dc:	e925                	bnez	a0,144c <pipe1+0x84>
    13de:	e4a6                	sd	s1,72(sp)
    13e0:	fc4e                	sd	s3,56(sp)
    13e2:	84aa                	mv	s1,a0
  pid = fork();
    13e4:	0b0040ef          	jal	5494 <fork>
    13e8:	89aa                	mv	s3,a0
  if (pid == 0) {
    13ea:	c151                	beqz	a0,146e <pipe1+0xa6>
  } else if (pid > 0) {
    13ec:	16a05063          	blez	a0,154c <pipe1+0x184>
    13f0:	e0ca                	sd	s2,64(sp)
    13f2:	f852                	sd	s4,48(sp)
    close(fds[1]);
    13f4:	fac42503          	lw	a0,-84(s0)
    13f8:	0cc040ef          	jal	54c4 <close>
    total = 0;
    13fc:	89a6                	mv	s3,s1
    cc = 1;
    13fe:	4905                	li	s2,1
    while ((n = read(fds[0], buf, cc)) > 0) {
    1400:	0000da17          	auipc	s4,0xd
    1404:	8e8a0a13          	addi	s4,s4,-1816 # dce8 <buf>
    1408:	864a                	mv	a2,s2
    140a:	85d2                	mv	a1,s4
    140c:	fa842503          	lw	a0,-88(s0)
    1410:	0a4040ef          	jal	54b4 <read>
    1414:	85aa                	mv	a1,a0
    1416:	0ea05963          	blez	a0,1508 <pipe1+0x140>
    141a:	0000d797          	auipc	a5,0xd
    141e:	8ce78793          	addi	a5,a5,-1842 # dce8 <buf>
    1422:	00b4863b          	addw	a2,s1,a1
        if ((buf[i] & 0xff) != (seq++ & 0xff)) {
    1426:	0007c683          	lbu	a3,0(a5)
    142a:	0ff4f713          	zext.b	a4,s1
    142e:	0ae69d63          	bne	a3,a4,14e8 <pipe1+0x120>
    1432:	2485                	addiw	s1,s1,1
      for (i = 0; i < n; i++) {
    1434:	0785                	addi	a5,a5,1
    1436:	fec498e3          	bne	s1,a2,1426 <pipe1+0x5e>
      total += n;
    143a:	00b989bb          	addw	s3,s3,a1
      cc = cc * 2;
    143e:	0019191b          	slliw	s2,s2,0x1
      if (cc > sizeof(buf))
    1442:	678d                	lui	a5,0x3
    1444:	fd27f2e3          	bgeu	a5,s2,1408 <pipe1+0x40>
        cc = sizeof(buf);
    1448:	893e                	mv	s2,a5
    144a:	bf7d                	j	1408 <pipe1+0x40>
    144c:	e4a6                	sd	s1,72(sp)
    144e:	e0ca                	sd	s2,64(sp)
    1450:	fc4e                	sd	s3,56(sp)
    1452:	f852                	sd	s4,48(sp)
    1454:	f456                	sd	s5,40(sp)
    1456:	f05a                	sd	s6,32(sp)
    1458:	ec5e                	sd	s7,24(sp)
    printf("%s: pipe() failed\n", s);
    145a:	85e2                	mv	a1,s8
    145c:	00005517          	auipc	a0,0x5
    1460:	fc450513          	addi	a0,a0,-60 # 6420 <malloc+0xa46>
    1464:	4be040ef          	jal	5922 <printf>
    exit(1);
    1468:	4505                	li	a0,1
    146a:	032040ef          	jal	549c <exit>
    146e:	e0ca                	sd	s2,64(sp)
    1470:	f852                	sd	s4,48(sp)
    1472:	f456                	sd	s5,40(sp)
    1474:	f05a                	sd	s6,32(sp)
    1476:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    1478:	fa842503          	lw	a0,-88(s0)
    147c:	048040ef          	jal	54c4 <close>
    for (n = 0; n < N; n++) {
    1480:	0000db17          	auipc	s6,0xd
    1484:	868b0b13          	addi	s6,s6,-1944 # dce8 <buf>
    1488:	416004bb          	negw	s1,s6
    148c:	0ff4f493          	zext.b	s1,s1
    1490:	409b0913          	addi	s2,s6,1033
      if (write(fds[1], buf, SZ) != SZ) {
    1494:	40900a13          	li	s4,1033
    1498:	8bda                	mv	s7,s6
    for (n = 0; n < N; n++) {
    149a:	6a85                	lui	s5,0x1
    149c:	42da8a93          	addi	s5,s5,1069 # 142d <pipe1+0x65>
{
    14a0:	87da                	mv	a5,s6
        buf[i] = seq++;
    14a2:	0097873b          	addw	a4,a5,s1
    14a6:	00e78023          	sb	a4,0(a5) # 3000 <subdir+0x476>
      for (i = 0; i < SZ; i++)
    14aa:	0785                	addi	a5,a5,1
    14ac:	ff279be3          	bne	a5,s2,14a2 <pipe1+0xda>
      if (write(fds[1], buf, SZ) != SZ) {
    14b0:	8652                	mv	a2,s4
    14b2:	85de                	mv	a1,s7
    14b4:	fac42503          	lw	a0,-84(s0)
    14b8:	004040ef          	jal	54bc <write>
    14bc:	01451c63          	bne	a0,s4,14d4 <pipe1+0x10c>
    14c0:	4099899b          	addiw	s3,s3,1033
    for (n = 0; n < N; n++) {
    14c4:	24a5                	addiw	s1,s1,9
    14c6:	0ff4f493          	zext.b	s1,s1
    14ca:	fd599be3          	bne	s3,s5,14a0 <pipe1+0xd8>
    exit(0);
    14ce:	4501                	li	a0,0
    14d0:	7cd030ef          	jal	549c <exit>
        printf("%s: pipe1 oops 1\n", s);
    14d4:	85e2                	mv	a1,s8
    14d6:	00005517          	auipc	a0,0x5
    14da:	f6250513          	addi	a0,a0,-158 # 6438 <malloc+0xa5e>
    14de:	444040ef          	jal	5922 <printf>
        exit(1);
    14e2:	4505                	li	a0,1
    14e4:	7b9030ef          	jal	549c <exit>
          printf("%s: pipe1 oops 2\n", s);
    14e8:	85e2                	mv	a1,s8
    14ea:	00005517          	auipc	a0,0x5
    14ee:	f6650513          	addi	a0,a0,-154 # 6450 <malloc+0xa76>
    14f2:	430040ef          	jal	5922 <printf>
          return;
    14f6:	64a6                	ld	s1,72(sp)
    14f8:	6906                	ld	s2,64(sp)
    14fa:	79e2                	ld	s3,56(sp)
    14fc:	7a42                	ld	s4,48(sp)
}
    14fe:	60e6                	ld	ra,88(sp)
    1500:	6446                	ld	s0,80(sp)
    1502:	6c42                	ld	s8,16(sp)
    1504:	6125                	addi	sp,sp,96
    1506:	8082                	ret
    if (total != N * SZ) {
    1508:	6785                	lui	a5,0x1
    150a:	42d78793          	addi	a5,a5,1069 # 142d <pipe1+0x65>
    150e:	02f98063          	beq	s3,a5,152e <pipe1+0x166>
    1512:	f456                	sd	s5,40(sp)
    1514:	f05a                	sd	s6,32(sp)
    1516:	ec5e                	sd	s7,24(sp)
      printf("%s: pipe1 oops 3 total %d\n", s, total);
    1518:	864e                	mv	a2,s3
    151a:	85e2                	mv	a1,s8
    151c:	00005517          	auipc	a0,0x5
    1520:	f4c50513          	addi	a0,a0,-180 # 6468 <malloc+0xa8e>
    1524:	3fe040ef          	jal	5922 <printf>
      exit(1);
    1528:	4505                	li	a0,1
    152a:	773030ef          	jal	549c <exit>
    152e:	f456                	sd	s5,40(sp)
    1530:	f05a                	sd	s6,32(sp)
    1532:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    1534:	fa842503          	lw	a0,-88(s0)
    1538:	78d030ef          	jal	54c4 <close>
    wait(&xstatus);
    153c:	fa440513          	addi	a0,s0,-92
    1540:	765030ef          	jal	54a4 <wait>
    exit(xstatus);
    1544:	fa442503          	lw	a0,-92(s0)
    1548:	755030ef          	jal	549c <exit>
    154c:	e0ca                	sd	s2,64(sp)
    154e:	f852                	sd	s4,48(sp)
    1550:	f456                	sd	s5,40(sp)
    1552:	f05a                	sd	s6,32(sp)
    1554:	ec5e                	sd	s7,24(sp)
    printf("%s: fork() failed\n", s);
    1556:	85e2                	mv	a1,s8
    1558:	00005517          	auipc	a0,0x5
    155c:	f3050513          	addi	a0,a0,-208 # 6488 <malloc+0xaae>
    1560:	3c2040ef          	jal	5922 <printf>
    exit(1);
    1564:	4505                	li	a0,1
    1566:	737030ef          	jal	549c <exit>

000000000000156a <exitwait>:
{
    156a:	715d                	addi	sp,sp,-80
    156c:	e486                	sd	ra,72(sp)
    156e:	e0a2                	sd	s0,64(sp)
    1570:	fc26                	sd	s1,56(sp)
    1572:	f84a                	sd	s2,48(sp)
    1574:	f44e                	sd	s3,40(sp)
    1576:	f052                	sd	s4,32(sp)
    1578:	ec56                	sd	s5,24(sp)
    157a:	0880                	addi	s0,sp,80
    157c:	8aaa                	mv	s5,a0
  for (i = 0; i < 100; i++) {
    157e:	4901                	li	s2,0
      if (wait(&xstate) != pid) {
    1580:	fbc40993          	addi	s3,s0,-68
  for (i = 0; i < 100; i++) {
    1584:	06400a13          	li	s4,100
    pid = fork();
    1588:	70d030ef          	jal	5494 <fork>
    158c:	84aa                	mv	s1,a0
    if (pid < 0) {
    158e:	02054863          	bltz	a0,15be <exitwait+0x54>
    if (pid) {
    1592:	c525                	beqz	a0,15fa <exitwait+0x90>
      if (wait(&xstate) != pid) {
    1594:	854e                	mv	a0,s3
    1596:	70f030ef          	jal	54a4 <wait>
    159a:	02951c63          	bne	a0,s1,15d2 <exitwait+0x68>
      if (i != xstate) {
    159e:	fbc42783          	lw	a5,-68(s0)
    15a2:	05279263          	bne	a5,s2,15e6 <exitwait+0x7c>
  for (i = 0; i < 100; i++) {
    15a6:	2905                	addiw	s2,s2,1
    15a8:	ff4910e3          	bne	s2,s4,1588 <exitwait+0x1e>
}
    15ac:	60a6                	ld	ra,72(sp)
    15ae:	6406                	ld	s0,64(sp)
    15b0:	74e2                	ld	s1,56(sp)
    15b2:	7942                	ld	s2,48(sp)
    15b4:	79a2                	ld	s3,40(sp)
    15b6:	7a02                	ld	s4,32(sp)
    15b8:	6ae2                	ld	s5,24(sp)
    15ba:	6161                	addi	sp,sp,80
    15bc:	8082                	ret
      printf("%s: fork failed\n", s);
    15be:	85d6                	mv	a1,s5
    15c0:	00005517          	auipc	a0,0x5
    15c4:	dd850513          	addi	a0,a0,-552 # 6398 <malloc+0x9be>
    15c8:	35a040ef          	jal	5922 <printf>
      exit(1);
    15cc:	4505                	li	a0,1
    15ce:	6cf030ef          	jal	549c <exit>
        printf("%s: wait wrong pid\n", s);
    15d2:	85d6                	mv	a1,s5
    15d4:	00005517          	auipc	a0,0x5
    15d8:	ecc50513          	addi	a0,a0,-308 # 64a0 <malloc+0xac6>
    15dc:	346040ef          	jal	5922 <printf>
        exit(1);
    15e0:	4505                	li	a0,1
    15e2:	6bb030ef          	jal	549c <exit>
        printf("%s: wait wrong exit status\n", s);
    15e6:	85d6                	mv	a1,s5
    15e8:	00005517          	auipc	a0,0x5
    15ec:	ed050513          	addi	a0,a0,-304 # 64b8 <malloc+0xade>
    15f0:	332040ef          	jal	5922 <printf>
        exit(1);
    15f4:	4505                	li	a0,1
    15f6:	6a7030ef          	jal	549c <exit>
      exit(i);
    15fa:	854a                	mv	a0,s2
    15fc:	6a1030ef          	jal	549c <exit>

0000000000001600 <twochildren>:
{
    1600:	1101                	addi	sp,sp,-32
    1602:	ec06                	sd	ra,24(sp)
    1604:	e822                	sd	s0,16(sp)
    1606:	e426                	sd	s1,8(sp)
    1608:	e04a                	sd	s2,0(sp)
    160a:	1000                	addi	s0,sp,32
    160c:	892a                	mv	s2,a0
    160e:	3e800493          	li	s1,1000
    int pid1 = fork();
    1612:	683030ef          	jal	5494 <fork>
    if (pid1 < 0) {
    1616:	02054663          	bltz	a0,1642 <twochildren+0x42>
    if (pid1 == 0) {
    161a:	cd15                	beqz	a0,1656 <twochildren+0x56>
      int pid2 = fork();
    161c:	679030ef          	jal	5494 <fork>
      if (pid2 < 0) {
    1620:	02054d63          	bltz	a0,165a <twochildren+0x5a>
      if (pid2 == 0) {
    1624:	c529                	beqz	a0,166e <twochildren+0x6e>
        wait(0);
    1626:	4501                	li	a0,0
    1628:	67d030ef          	jal	54a4 <wait>
        wait(0);
    162c:	4501                	li	a0,0
    162e:	677030ef          	jal	54a4 <wait>
  for (int i = 0; i < 1000; i++) {
    1632:	34fd                	addiw	s1,s1,-1
    1634:	fcf9                	bnez	s1,1612 <twochildren+0x12>
}
    1636:	60e2                	ld	ra,24(sp)
    1638:	6442                	ld	s0,16(sp)
    163a:	64a2                	ld	s1,8(sp)
    163c:	6902                	ld	s2,0(sp)
    163e:	6105                	addi	sp,sp,32
    1640:	8082                	ret
      printf("%s: fork failed\n", s);
    1642:	85ca                	mv	a1,s2
    1644:	00005517          	auipc	a0,0x5
    1648:	d5450513          	addi	a0,a0,-684 # 6398 <malloc+0x9be>
    164c:	2d6040ef          	jal	5922 <printf>
      exit(1);
    1650:	4505                	li	a0,1
    1652:	64b030ef          	jal	549c <exit>
      exit(0);
    1656:	647030ef          	jal	549c <exit>
        printf("%s: fork failed\n", s);
    165a:	85ca                	mv	a1,s2
    165c:	00005517          	auipc	a0,0x5
    1660:	d3c50513          	addi	a0,a0,-708 # 6398 <malloc+0x9be>
    1664:	2be040ef          	jal	5922 <printf>
        exit(1);
    1668:	4505                	li	a0,1
    166a:	633030ef          	jal	549c <exit>
        exit(0);
    166e:	62f030ef          	jal	549c <exit>

0000000000001672 <forkfork>:
{
    1672:	7179                	addi	sp,sp,-48
    1674:	f406                	sd	ra,40(sp)
    1676:	f022                	sd	s0,32(sp)
    1678:	ec26                	sd	s1,24(sp)
    167a:	1800                	addi	s0,sp,48
    167c:	84aa                	mv	s1,a0
    int pid = fork();
    167e:	617030ef          	jal	5494 <fork>
    if (pid < 0) {
    1682:	02054b63          	bltz	a0,16b8 <forkfork+0x46>
    if (pid == 0) {
    1686:	c139                	beqz	a0,16cc <forkfork+0x5a>
    int pid = fork();
    1688:	60d030ef          	jal	5494 <fork>
    if (pid < 0) {
    168c:	02054663          	bltz	a0,16b8 <forkfork+0x46>
    if (pid == 0) {
    1690:	cd15                	beqz	a0,16cc <forkfork+0x5a>
    wait(&xstatus);
    1692:	fdc40513          	addi	a0,s0,-36
    1696:	60f030ef          	jal	54a4 <wait>
    if (xstatus != 0) {
    169a:	fdc42783          	lw	a5,-36(s0)
    169e:	ebb9                	bnez	a5,16f4 <forkfork+0x82>
    wait(&xstatus);
    16a0:	fdc40513          	addi	a0,s0,-36
    16a4:	601030ef          	jal	54a4 <wait>
    if (xstatus != 0) {
    16a8:	fdc42783          	lw	a5,-36(s0)
    16ac:	e7a1                	bnez	a5,16f4 <forkfork+0x82>
}
    16ae:	70a2                	ld	ra,40(sp)
    16b0:	7402                	ld	s0,32(sp)
    16b2:	64e2                	ld	s1,24(sp)
    16b4:	6145                	addi	sp,sp,48
    16b6:	8082                	ret
      printf("%s: fork failed", s);
    16b8:	85a6                	mv	a1,s1
    16ba:	00005517          	auipc	a0,0x5
    16be:	e1e50513          	addi	a0,a0,-482 # 64d8 <malloc+0xafe>
    16c2:	260040ef          	jal	5922 <printf>
      exit(1);
    16c6:	4505                	li	a0,1
    16c8:	5d5030ef          	jal	549c <exit>
{
    16cc:	0c800493          	li	s1,200
        int pid1 = fork();
    16d0:	5c5030ef          	jal	5494 <fork>
        if (pid1 < 0) {
    16d4:	00054b63          	bltz	a0,16ea <forkfork+0x78>
        if (pid1 == 0) {
    16d8:	cd01                	beqz	a0,16f0 <forkfork+0x7e>
        wait(0);
    16da:	4501                	li	a0,0
    16dc:	5c9030ef          	jal	54a4 <wait>
      for (int j = 0; j < 200; j++) {
    16e0:	34fd                	addiw	s1,s1,-1
    16e2:	f4fd                	bnez	s1,16d0 <forkfork+0x5e>
      exit(0);
    16e4:	4501                	li	a0,0
    16e6:	5b7030ef          	jal	549c <exit>
          exit(1);
    16ea:	4505                	li	a0,1
    16ec:	5b1030ef          	jal	549c <exit>
          exit(0);
    16f0:	5ad030ef          	jal	549c <exit>
      printf("%s: fork in child failed", s);
    16f4:	85a6                	mv	a1,s1
    16f6:	00005517          	auipc	a0,0x5
    16fa:	df250513          	addi	a0,a0,-526 # 64e8 <malloc+0xb0e>
    16fe:	224040ef          	jal	5922 <printf>
      exit(1);
    1702:	4505                	li	a0,1
    1704:	599030ef          	jal	549c <exit>

0000000000001708 <reparent2>:
{
    1708:	1101                	addi	sp,sp,-32
    170a:	ec06                	sd	ra,24(sp)
    170c:	e822                	sd	s0,16(sp)
    170e:	e426                	sd	s1,8(sp)
    1710:	1000                	addi	s0,sp,32
    1712:	32000493          	li	s1,800
    int pid1 = fork();
    1716:	57f030ef          	jal	5494 <fork>
    if (pid1 < 0) {
    171a:	00054b63          	bltz	a0,1730 <reparent2+0x28>
    if (pid1 == 0) {
    171e:	c115                	beqz	a0,1742 <reparent2+0x3a>
    wait(0);
    1720:	4501                	li	a0,0
    1722:	583030ef          	jal	54a4 <wait>
  for (int i = 0; i < 800; i++) {
    1726:	34fd                	addiw	s1,s1,-1
    1728:	f4fd                	bnez	s1,1716 <reparent2+0xe>
  exit(0);
    172a:	4501                	li	a0,0
    172c:	571030ef          	jal	549c <exit>
      printf("fork failed\n");
    1730:	00006517          	auipc	a0,0x6
    1734:	32850513          	addi	a0,a0,808 # 7a58 <malloc+0x207e>
    1738:	1ea040ef          	jal	5922 <printf>
      exit(1);
    173c:	4505                	li	a0,1
    173e:	55f030ef          	jal	549c <exit>
      fork();
    1742:	553030ef          	jal	5494 <fork>
      fork();
    1746:	54f030ef          	jal	5494 <fork>
      exit(0);
    174a:	4501                	li	a0,0
    174c:	551030ef          	jal	549c <exit>

0000000000001750 <createdelete>:
{
    1750:	7135                	addi	sp,sp,-160
    1752:	ed06                	sd	ra,152(sp)
    1754:	e922                	sd	s0,144(sp)
    1756:	e526                	sd	s1,136(sp)
    1758:	e14a                	sd	s2,128(sp)
    175a:	fcce                	sd	s3,120(sp)
    175c:	f8d2                	sd	s4,112(sp)
    175e:	f4d6                	sd	s5,104(sp)
    1760:	f0da                	sd	s6,96(sp)
    1762:	ecde                	sd	s7,88(sp)
    1764:	e8e2                	sd	s8,80(sp)
    1766:	e4e6                	sd	s9,72(sp)
    1768:	e0ea                	sd	s10,64(sp)
    176a:	fc6e                	sd	s11,56(sp)
    176c:	1100                	addi	s0,sp,160
    176e:	8daa                	mv	s11,a0
  for (pi = 0; pi < NCHILD; pi++) {
    1770:	4901                	li	s2,0
    1772:	4991                	li	s3,4
    pid = fork();
    1774:	521030ef          	jal	5494 <fork>
    1778:	84aa                	mv	s1,a0
    if (pid < 0) {
    177a:	04054063          	bltz	a0,17ba <createdelete+0x6a>
    if (pid == 0) {
    177e:	c921                	beqz	a0,17ce <createdelete+0x7e>
  for (pi = 0; pi < NCHILD; pi++) {
    1780:	2905                	addiw	s2,s2,1
    1782:	ff3919e3          	bne	s2,s3,1774 <createdelete+0x24>
    1786:	4491                	li	s1,4
    wait(&xstatus);
    1788:	f6c40913          	addi	s2,s0,-148
    178c:	854a                	mv	a0,s2
    178e:	517030ef          	jal	54a4 <wait>
    if (xstatus != 0)
    1792:	f6c42a83          	lw	s5,-148(s0)
    1796:	0c0a9263          	bnez	s5,185a <createdelete+0x10a>
  for (pi = 0; pi < NCHILD; pi++) {
    179a:	34fd                	addiw	s1,s1,-1
    179c:	f8e5                	bnez	s1,178c <createdelete+0x3c>
  name[0] = name[1] = name[2] = 0;
    179e:	f6040923          	sb	zero,-142(s0)
    17a2:	03000913          	li	s2,48
    17a6:	5a7d                	li	s4,-1
      if ((i == 0 || i >= N / 2) && fd < 0) {
    17a8:	4d25                	li	s10,9
    17aa:	07000c93          	li	s9,112
      fd = open(name, 0);
    17ae:	f7040c13          	addi	s8,s0,-144
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    17b2:	4ba1                	li	s7,8
    for (pi = 0; pi < NCHILD; pi++) {
    17b4:	07400b13          	li	s6,116
    17b8:	aa39                	j	18d6 <createdelete+0x186>
      printf("%s: fork failed\n", s);
    17ba:	85ee                	mv	a1,s11
    17bc:	00005517          	auipc	a0,0x5
    17c0:	bdc50513          	addi	a0,a0,-1060 # 6398 <malloc+0x9be>
    17c4:	15e040ef          	jal	5922 <printf>
      exit(1);
    17c8:	4505                	li	a0,1
    17ca:	4d3030ef          	jal	549c <exit>
      name[0] = 'p' + pi;
    17ce:	0709091b          	addiw	s2,s2,112
    17d2:	f7240823          	sb	s2,-144(s0)
      name[2] = '\0';
    17d6:	f6040923          	sb	zero,-142(s0)
        fd = open(name, O_CREATE | O_RDWR);
    17da:	f7040913          	addi	s2,s0,-144
    17de:	20200993          	li	s3,514
      for (i = 0; i < N; i++) {
    17e2:	4a51                	li	s4,20
    17e4:	a815                	j	1818 <createdelete+0xc8>
          printf("%s: create failed\n", s);
    17e6:	85ee                	mv	a1,s11
    17e8:	00005517          	auipc	a0,0x5
    17ec:	d2050513          	addi	a0,a0,-736 # 6508 <malloc+0xb2e>
    17f0:	132040ef          	jal	5922 <printf>
          exit(1);
    17f4:	4505                	li	a0,1
    17f6:	4a7030ef          	jal	549c <exit>
          name[1] = '0' + (i / 2);
    17fa:	01f4d79b          	srliw	a5,s1,0x1f
    17fe:	9fa5                	addw	a5,a5,s1
    1800:	4017d79b          	sraiw	a5,a5,0x1
    1804:	0307879b          	addiw	a5,a5,48
    1808:	f6f408a3          	sb	a5,-143(s0)
          if (unlink(name) < 0) {
    180c:	854a                	mv	a0,s2
    180e:	4df030ef          	jal	54ec <unlink>
    1812:	02054a63          	bltz	a0,1846 <createdelete+0xf6>
      for (i = 0; i < N; i++) {
    1816:	2485                	addiw	s1,s1,1
        name[1] = '0' + i;
    1818:	0304879b          	addiw	a5,s1,48
    181c:	f6f408a3          	sb	a5,-143(s0)
        fd = open(name, O_CREATE | O_RDWR);
    1820:	85ce                	mv	a1,s3
    1822:	854a                	mv	a0,s2
    1824:	4b9030ef          	jal	54dc <open>
        if (fd < 0) {
    1828:	fa054fe3          	bltz	a0,17e6 <createdelete+0x96>
        close(fd);
    182c:	499030ef          	jal	54c4 <close>
        if (i > 0 && (i % 2) == 0) {
    1830:	fe9053e3          	blez	s1,1816 <createdelete+0xc6>
    1834:	0014f793          	andi	a5,s1,1
    1838:	d3e9                	beqz	a5,17fa <createdelete+0xaa>
      for (i = 0; i < N; i++) {
    183a:	2485                	addiw	s1,s1,1
    183c:	fd449ee3          	bne	s1,s4,1818 <createdelete+0xc8>
      exit(0);
    1840:	4501                	li	a0,0
    1842:	45b030ef          	jal	549c <exit>
            printf("%s: unlink failed\n", s);
    1846:	85ee                	mv	a1,s11
    1848:	00005517          	auipc	a0,0x5
    184c:	cd850513          	addi	a0,a0,-808 # 6520 <malloc+0xb46>
    1850:	0d2040ef          	jal	5922 <printf>
            exit(1);
    1854:	4505                	li	a0,1
    1856:	447030ef          	jal	549c <exit>
      exit(1);
    185a:	4505                	li	a0,1
    185c:	441030ef          	jal	549c <exit>
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    1860:	054bf263          	bgeu	s7,s4,18a4 <createdelete+0x154>
      if (fd >= 0)
    1864:	04055e63          	bgez	a0,18c0 <createdelete+0x170>
    for (pi = 0; pi < NCHILD; pi++) {
    1868:	2485                	addiw	s1,s1,1
    186a:	0ff4f493          	zext.b	s1,s1
    186e:	05648c63          	beq	s1,s6,18c6 <createdelete+0x176>
      name[0] = 'p' + pi;
    1872:	f6940823          	sb	s1,-144(s0)
      name[1] = '0' + i;
    1876:	f72408a3          	sb	s2,-143(s0)
      fd = open(name, 0);
    187a:	4581                	li	a1,0
    187c:	8562                	mv	a0,s8
    187e:	45f030ef          	jal	54dc <open>
      if ((i == 0 || i >= N / 2) && fd < 0) {
    1882:	01f5579b          	srliw	a5,a0,0x1f
    1886:	dfe9                	beqz	a5,1860 <createdelete+0x110>
    1888:	fc098ce3          	beqz	s3,1860 <createdelete+0x110>
        printf("%s: oops createdelete %s didn't exist\n", s, name);
    188c:	f7040613          	addi	a2,s0,-144
    1890:	85ee                	mv	a1,s11
    1892:	00005517          	auipc	a0,0x5
    1896:	ca650513          	addi	a0,a0,-858 # 6538 <malloc+0xb5e>
    189a:	088040ef          	jal	5922 <printf>
        exit(1);
    189e:	4505                	li	a0,1
    18a0:	3fd030ef          	jal	549c <exit>
      } else if ((i >= 1 && i < N / 2) && fd >= 0) {
    18a4:	fc0542e3          	bltz	a0,1868 <createdelete+0x118>
        printf("%s: oops createdelete %s did exist\n", s, name);
    18a8:	f7040613          	addi	a2,s0,-144
    18ac:	85ee                	mv	a1,s11
    18ae:	00005517          	auipc	a0,0x5
    18b2:	cb250513          	addi	a0,a0,-846 # 6560 <malloc+0xb86>
    18b6:	06c040ef          	jal	5922 <printf>
        exit(1);
    18ba:	4505                	li	a0,1
    18bc:	3e1030ef          	jal	549c <exit>
        close(fd);
    18c0:	405030ef          	jal	54c4 <close>
    18c4:	b755                	j	1868 <createdelete+0x118>
  for (i = 0; i < N; i++) {
    18c6:	2a85                	addiw	s5,s5,1
    18c8:	2a05                	addiw	s4,s4,1
    18ca:	2905                	addiw	s2,s2,1
    18cc:	0ff97913          	zext.b	s2,s2
    18d0:	47d1                	li	a5,20
    18d2:	00fa8a63          	beq	s5,a5,18e6 <createdelete+0x196>
      if ((i == 0 || i >= N / 2) && fd < 0) {
    18d6:	001ab993          	seqz	s3,s5
    18da:	015d27b3          	slt	a5,s10,s5
    18de:	00f9e9b3          	or	s3,s3,a5
    18e2:	84e6                	mv	s1,s9
    18e4:	b779                	j	1872 <createdelete+0x122>
    18e6:	03000913          	li	s2,48
  name[0] = name[1] = name[2] = 0;
    18ea:	07000b13          	li	s6,112
      unlink(name);
    18ee:	f7040a13          	addi	s4,s0,-144
    for (pi = 0; pi < NCHILD; pi++) {
    18f2:	07400993          	li	s3,116
  for (i = 0; i < N; i++) {
    18f6:	04400a93          	li	s5,68
  name[0] = name[1] = name[2] = 0;
    18fa:	84da                	mv	s1,s6
      name[0] = 'p' + pi;
    18fc:	f6940823          	sb	s1,-144(s0)
      name[1] = '0' + i;
    1900:	f72408a3          	sb	s2,-143(s0)
      unlink(name);
    1904:	8552                	mv	a0,s4
    1906:	3e7030ef          	jal	54ec <unlink>
    for (pi = 0; pi < NCHILD; pi++) {
    190a:	2485                	addiw	s1,s1,1
    190c:	0ff4f493          	zext.b	s1,s1
    1910:	ff3496e3          	bne	s1,s3,18fc <createdelete+0x1ac>
  for (i = 0; i < N; i++) {
    1914:	2905                	addiw	s2,s2,1
    1916:	0ff97913          	zext.b	s2,s2
    191a:	ff5910e3          	bne	s2,s5,18fa <createdelete+0x1aa>
}
    191e:	60ea                	ld	ra,152(sp)
    1920:	644a                	ld	s0,144(sp)
    1922:	64aa                	ld	s1,136(sp)
    1924:	690a                	ld	s2,128(sp)
    1926:	79e6                	ld	s3,120(sp)
    1928:	7a46                	ld	s4,112(sp)
    192a:	7aa6                	ld	s5,104(sp)
    192c:	7b06                	ld	s6,96(sp)
    192e:	6be6                	ld	s7,88(sp)
    1930:	6c46                	ld	s8,80(sp)
    1932:	6ca6                	ld	s9,72(sp)
    1934:	6d06                	ld	s10,64(sp)
    1936:	7de2                	ld	s11,56(sp)
    1938:	610d                	addi	sp,sp,160
    193a:	8082                	ret

000000000000193c <linkunlink>:
{
    193c:	711d                	addi	sp,sp,-96
    193e:	ec86                	sd	ra,88(sp)
    1940:	e8a2                	sd	s0,80(sp)
    1942:	e4a6                	sd	s1,72(sp)
    1944:	e0ca                	sd	s2,64(sp)
    1946:	fc4e                	sd	s3,56(sp)
    1948:	f852                	sd	s4,48(sp)
    194a:	f456                	sd	s5,40(sp)
    194c:	f05a                	sd	s6,32(sp)
    194e:	ec5e                	sd	s7,24(sp)
    1950:	e862                	sd	s8,16(sp)
    1952:	e466                	sd	s9,8(sp)
    1954:	e06a                	sd	s10,0(sp)
    1956:	1080                	addi	s0,sp,96
    1958:	84aa                	mv	s1,a0
  unlink("x");
    195a:	00004517          	auipc	a0,0x4
    195e:	21e50513          	addi	a0,a0,542 # 5b78 <malloc+0x19e>
    1962:	38b030ef          	jal	54ec <unlink>
  pid = fork();
    1966:	32f030ef          	jal	5494 <fork>
  if (pid < 0) {
    196a:	04054363          	bltz	a0,19b0 <linkunlink+0x74>
    196e:	8d2a                	mv	s10,a0
  unsigned int x = (pid ? 1 : 97);
    1970:	06100913          	li	s2,97
    1974:	c111                	beqz	a0,1978 <linkunlink+0x3c>
    1976:	4905                	li	s2,1
    1978:	06400493          	li	s1,100
    x = x * 1103515245 + 12345;
    197c:	41c65ab7          	lui	s5,0x41c65
    1980:	e6da8a9b          	addiw	s5,s5,-403 # 41c64e6d <base+0x41c54185>
    1984:	6a0d                	lui	s4,0x3
    1986:	039a0a1b          	addiw	s4,s4,57 # 3039 <subdir+0x4af>
    if ((x % 3) == 0) {
    198a:	000ab9b7          	lui	s3,0xab
    198e:	aab98993          	addi	s3,s3,-1365 # aaaab <base+0x99dc3>
    1992:	09b2                	slli	s3,s3,0xc
    1994:	aab98993          	addi	s3,s3,-1365
    } else if ((x % 3) == 1) {
    1998:	4b85                	li	s7,1
      unlink("x");
    199a:	00004b17          	auipc	s6,0x4
    199e:	1deb0b13          	addi	s6,s6,478 # 5b78 <malloc+0x19e>
      link("cat", "x");
    19a2:	00005c97          	auipc	s9,0x5
    19a6:	be6c8c93          	addi	s9,s9,-1050 # 6588 <malloc+0xbae>
      close(open("x", O_RDWR | O_CREATE));
    19aa:	20200c13          	li	s8,514
    19ae:	a03d                	j	19dc <linkunlink+0xa0>
    printf("%s: fork failed\n", s);
    19b0:	85a6                	mv	a1,s1
    19b2:	00005517          	auipc	a0,0x5
    19b6:	9e650513          	addi	a0,a0,-1562 # 6398 <malloc+0x9be>
    19ba:	769030ef          	jal	5922 <printf>
    exit(1);
    19be:	4505                	li	a0,1
    19c0:	2dd030ef          	jal	549c <exit>
      close(open("x", O_RDWR | O_CREATE));
    19c4:	85e2                	mv	a1,s8
    19c6:	855a                	mv	a0,s6
    19c8:	315030ef          	jal	54dc <open>
    19cc:	2f9030ef          	jal	54c4 <close>
    19d0:	a021                	j	19d8 <linkunlink+0x9c>
      unlink("x");
    19d2:	855a                	mv	a0,s6
    19d4:	319030ef          	jal	54ec <unlink>
  for (i = 0; i < 100; i++) {
    19d8:	34fd                	addiw	s1,s1,-1
    19da:	c885                	beqz	s1,1a0a <linkunlink+0xce>
    x = x * 1103515245 + 12345;
    19dc:	035907bb          	mulw	a5,s2,s5
    19e0:	00fa07bb          	addw	a5,s4,a5
    19e4:	893e                	mv	s2,a5
    if ((x % 3) == 0) {
    19e6:	02079713          	slli	a4,a5,0x20
    19ea:	9301                	srli	a4,a4,0x20
    19ec:	03370733          	mul	a4,a4,s3
    19f0:	9305                	srli	a4,a4,0x21
    19f2:	0017169b          	slliw	a3,a4,0x1
    19f6:	9f35                	addw	a4,a4,a3
    19f8:	9f99                	subw	a5,a5,a4
    19fa:	d7e9                	beqz	a5,19c4 <linkunlink+0x88>
    } else if ((x % 3) == 1) {
    19fc:	fd779be3          	bne	a5,s7,19d2 <linkunlink+0x96>
      link("cat", "x");
    1a00:	85da                	mv	a1,s6
    1a02:	8566                	mv	a0,s9
    1a04:	2f9030ef          	jal	54fc <link>
    1a08:	bfc1                	j	19d8 <linkunlink+0x9c>
  if (pid)
    1a0a:	020d0363          	beqz	s10,1a30 <linkunlink+0xf4>
    wait(0);
    1a0e:	4501                	li	a0,0
    1a10:	295030ef          	jal	54a4 <wait>
}
    1a14:	60e6                	ld	ra,88(sp)
    1a16:	6446                	ld	s0,80(sp)
    1a18:	64a6                	ld	s1,72(sp)
    1a1a:	6906                	ld	s2,64(sp)
    1a1c:	79e2                	ld	s3,56(sp)
    1a1e:	7a42                	ld	s4,48(sp)
    1a20:	7aa2                	ld	s5,40(sp)
    1a22:	7b02                	ld	s6,32(sp)
    1a24:	6be2                	ld	s7,24(sp)
    1a26:	6c42                	ld	s8,16(sp)
    1a28:	6ca2                	ld	s9,8(sp)
    1a2a:	6d02                	ld	s10,0(sp)
    1a2c:	6125                	addi	sp,sp,96
    1a2e:	8082                	ret
    exit(0);
    1a30:	4501                	li	a0,0
    1a32:	26b030ef          	jal	549c <exit>

0000000000001a36 <forktest>:
{
    1a36:	7179                	addi	sp,sp,-48
    1a38:	f406                	sd	ra,40(sp)
    1a3a:	f022                	sd	s0,32(sp)
    1a3c:	ec26                	sd	s1,24(sp)
    1a3e:	e84a                	sd	s2,16(sp)
    1a40:	e44e                	sd	s3,8(sp)
    1a42:	1800                	addi	s0,sp,48
    1a44:	89aa                	mv	s3,a0
  for (n = 0; n < N; n++) {
    1a46:	4481                	li	s1,0
    1a48:	3e800913          	li	s2,1000
    pid = fork();
    1a4c:	249030ef          	jal	5494 <fork>
    if (pid < 0)
    1a50:	06054063          	bltz	a0,1ab0 <forktest+0x7a>
    if (pid == 0)
    1a54:	cd11                	beqz	a0,1a70 <forktest+0x3a>
  for (n = 0; n < N; n++) {
    1a56:	2485                	addiw	s1,s1,1
    1a58:	ff249ae3          	bne	s1,s2,1a4c <forktest+0x16>
    printf("%s: fork claimed to work 1000 times!\n", s);
    1a5c:	85ce                	mv	a1,s3
    1a5e:	00005517          	auipc	a0,0x5
    1a62:	b7a50513          	addi	a0,a0,-1158 # 65d8 <malloc+0xbfe>
    1a66:	6bd030ef          	jal	5922 <printf>
    exit(1);
    1a6a:	4505                	li	a0,1
    1a6c:	231030ef          	jal	549c <exit>
      exit(0);
    1a70:	22d030ef          	jal	549c <exit>
    printf("%s: no fork at all!\n", s);
    1a74:	85ce                	mv	a1,s3
    1a76:	00005517          	auipc	a0,0x5
    1a7a:	b1a50513          	addi	a0,a0,-1254 # 6590 <malloc+0xbb6>
    1a7e:	6a5030ef          	jal	5922 <printf>
    exit(1);
    1a82:	4505                	li	a0,1
    1a84:	219030ef          	jal	549c <exit>
      printf("%s: wait stopped early\n", s);
    1a88:	85ce                	mv	a1,s3
    1a8a:	00005517          	auipc	a0,0x5
    1a8e:	b1e50513          	addi	a0,a0,-1250 # 65a8 <malloc+0xbce>
    1a92:	691030ef          	jal	5922 <printf>
      exit(1);
    1a96:	4505                	li	a0,1
    1a98:	205030ef          	jal	549c <exit>
    printf("%s: wait got too many\n", s);
    1a9c:	85ce                	mv	a1,s3
    1a9e:	00005517          	auipc	a0,0x5
    1aa2:	b2250513          	addi	a0,a0,-1246 # 65c0 <malloc+0xbe6>
    1aa6:	67d030ef          	jal	5922 <printf>
    exit(1);
    1aaa:	4505                	li	a0,1
    1aac:	1f1030ef          	jal	549c <exit>
  if (n == 0) {
    1ab0:	d0f1                	beqz	s1,1a74 <forktest+0x3e>
  for (; n > 0; n--) {
    1ab2:	00905963          	blez	s1,1ac4 <forktest+0x8e>
    if (wait(0) < 0) {
    1ab6:	4501                	li	a0,0
    1ab8:	1ed030ef          	jal	54a4 <wait>
    1abc:	fc0546e3          	bltz	a0,1a88 <forktest+0x52>
  for (; n > 0; n--) {
    1ac0:	34fd                	addiw	s1,s1,-1
    1ac2:	f8f5                	bnez	s1,1ab6 <forktest+0x80>
  if (wait(0) != -1) {
    1ac4:	4501                	li	a0,0
    1ac6:	1df030ef          	jal	54a4 <wait>
    1aca:	57fd                	li	a5,-1
    1acc:	fcf518e3          	bne	a0,a5,1a9c <forktest+0x66>
}
    1ad0:	70a2                	ld	ra,40(sp)
    1ad2:	7402                	ld	s0,32(sp)
    1ad4:	64e2                	ld	s1,24(sp)
    1ad6:	6942                	ld	s2,16(sp)
    1ad8:	69a2                	ld	s3,8(sp)
    1ada:	6145                	addi	sp,sp,48
    1adc:	8082                	ret

0000000000001ade <kernmem>:
{
    1ade:	715d                	addi	sp,sp,-80
    1ae0:	e486                	sd	ra,72(sp)
    1ae2:	e0a2                	sd	s0,64(sp)
    1ae4:	fc26                	sd	s1,56(sp)
    1ae6:	f84a                	sd	s2,48(sp)
    1ae8:	f44e                	sd	s3,40(sp)
    1aea:	f052                	sd	s4,32(sp)
    1aec:	ec56                	sd	s5,24(sp)
    1aee:	e85a                	sd	s6,16(sp)
    1af0:	0880                	addi	s0,sp,80
    1af2:	8b2a                	mv	s6,a0
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1af4:	4485                	li	s1,1
    1af6:	04fe                	slli	s1,s1,0x1f
    wait(&xstatus);
    1af8:	fbc40a93          	addi	s5,s0,-68
    if (xstatus != -1) // did kernel kill child?
    1afc:	5a7d                	li	s4,-1
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1afe:	69b1                	lui	s3,0xc
    1b00:	35098993          	addi	s3,s3,848 # c350 <uninit+0xd78>
    1b04:	1003d937          	lui	s2,0x1003d
    1b08:	090e                	slli	s2,s2,0x3
    1b0a:	48090913          	addi	s2,s2,1152 # 1003d480 <base+0x1002c798>
    pid = fork();
    1b0e:	187030ef          	jal	5494 <fork>
    if (pid < 0) {
    1b12:	02054763          	bltz	a0,1b40 <kernmem+0x62>
    if (pid == 0) {
    1b16:	cd1d                	beqz	a0,1b54 <kernmem+0x76>
    wait(&xstatus);
    1b18:	8556                	mv	a0,s5
    1b1a:	18b030ef          	jal	54a4 <wait>
    if (xstatus != -1) // did kernel kill child?
    1b1e:	fbc42783          	lw	a5,-68(s0)
    1b22:	05479663          	bne	a5,s4,1b6e <kernmem+0x90>
  for (a = (char *)(KERNBASE); a < (char *)(KERNBASE + 2000000); a += 50000) {
    1b26:	94ce                	add	s1,s1,s3
    1b28:	ff2493e3          	bne	s1,s2,1b0e <kernmem+0x30>
}
    1b2c:	60a6                	ld	ra,72(sp)
    1b2e:	6406                	ld	s0,64(sp)
    1b30:	74e2                	ld	s1,56(sp)
    1b32:	7942                	ld	s2,48(sp)
    1b34:	79a2                	ld	s3,40(sp)
    1b36:	7a02                	ld	s4,32(sp)
    1b38:	6ae2                	ld	s5,24(sp)
    1b3a:	6b42                	ld	s6,16(sp)
    1b3c:	6161                	addi	sp,sp,80
    1b3e:	8082                	ret
      printf("%s: fork failed\n", s);
    1b40:	85da                	mv	a1,s6
    1b42:	00005517          	auipc	a0,0x5
    1b46:	85650513          	addi	a0,a0,-1962 # 6398 <malloc+0x9be>
    1b4a:	5d9030ef          	jal	5922 <printf>
      exit(1);
    1b4e:	4505                	li	a0,1
    1b50:	14d030ef          	jal	549c <exit>
      printf("%s: oops could read %p = %x\n", s, a, *a);
    1b54:	0004c683          	lbu	a3,0(s1)
    1b58:	8626                	mv	a2,s1
    1b5a:	85da                	mv	a1,s6
    1b5c:	00005517          	auipc	a0,0x5
    1b60:	aa450513          	addi	a0,a0,-1372 # 6600 <malloc+0xc26>
    1b64:	5bf030ef          	jal	5922 <printf>
      exit(1);
    1b68:	4505                	li	a0,1
    1b6a:	133030ef          	jal	549c <exit>
      exit(1);
    1b6e:	4505                	li	a0,1
    1b70:	12d030ef          	jal	549c <exit>

0000000000001b74 <MAXVAplus>:
{
    1b74:	7139                	addi	sp,sp,-64
    1b76:	fc06                	sd	ra,56(sp)
    1b78:	f822                	sd	s0,48(sp)
    1b7a:	0080                	addi	s0,sp,64
  volatile uint64 a = MAXVA;
    1b7c:	4785                	li	a5,1
    1b7e:	179a                	slli	a5,a5,0x26
    1b80:	fcf43423          	sd	a5,-56(s0)
  for (; a != 0; a <<= 1) {
    1b84:	fc843783          	ld	a5,-56(s0)
    1b88:	cf9d                	beqz	a5,1bc6 <MAXVAplus+0x52>
    1b8a:	f426                	sd	s1,40(sp)
    1b8c:	f04a                	sd	s2,32(sp)
    1b8e:	ec4e                	sd	s3,24(sp)
    1b90:	89aa                	mv	s3,a0
    wait(&xstatus);
    1b92:	fc440913          	addi	s2,s0,-60
    if (xstatus != -1) // did kernel kill child?
    1b96:	54fd                	li	s1,-1
    pid = fork();
    1b98:	0fd030ef          	jal	5494 <fork>
    if (pid < 0) {
    1b9c:	02054963          	bltz	a0,1bce <MAXVAplus+0x5a>
    if (pid == 0) {
    1ba0:	c129                	beqz	a0,1be2 <MAXVAplus+0x6e>
    wait(&xstatus);
    1ba2:	854a                	mv	a0,s2
    1ba4:	101030ef          	jal	54a4 <wait>
    if (xstatus != -1) // did kernel kill child?
    1ba8:	fc442783          	lw	a5,-60(s0)
    1bac:	04979d63          	bne	a5,s1,1c06 <MAXVAplus+0x92>
  for (; a != 0; a <<= 1) {
    1bb0:	fc843783          	ld	a5,-56(s0)
    1bb4:	0786                	slli	a5,a5,0x1
    1bb6:	fcf43423          	sd	a5,-56(s0)
    1bba:	fc843783          	ld	a5,-56(s0)
    1bbe:	ffe9                	bnez	a5,1b98 <MAXVAplus+0x24>
    1bc0:	74a2                	ld	s1,40(sp)
    1bc2:	7902                	ld	s2,32(sp)
    1bc4:	69e2                	ld	s3,24(sp)
}
    1bc6:	70e2                	ld	ra,56(sp)
    1bc8:	7442                	ld	s0,48(sp)
    1bca:	6121                	addi	sp,sp,64
    1bcc:	8082                	ret
      printf("%s: fork failed\n", s);
    1bce:	85ce                	mv	a1,s3
    1bd0:	00004517          	auipc	a0,0x4
    1bd4:	7c850513          	addi	a0,a0,1992 # 6398 <malloc+0x9be>
    1bd8:	54b030ef          	jal	5922 <printf>
      exit(1);
    1bdc:	4505                	li	a0,1
    1bde:	0bf030ef          	jal	549c <exit>
      *(char *)a = 99;
    1be2:	fc843783          	ld	a5,-56(s0)
    1be6:	06300713          	li	a4,99
    1bea:	00e78023          	sb	a4,0(a5)
      printf("%s: oops wrote %p\n", s, (void *)a);
    1bee:	fc843603          	ld	a2,-56(s0)
    1bf2:	85ce                	mv	a1,s3
    1bf4:	00005517          	auipc	a0,0x5
    1bf8:	a2c50513          	addi	a0,a0,-1492 # 6620 <malloc+0xc46>
    1bfc:	527030ef          	jal	5922 <printf>
      exit(1);
    1c00:	4505                	li	a0,1
    1c02:	09b030ef          	jal	549c <exit>
      exit(1);
    1c06:	4505                	li	a0,1
    1c08:	095030ef          	jal	549c <exit>

0000000000001c0c <stacktest>:
{
    1c0c:	7179                	addi	sp,sp,-48
    1c0e:	f406                	sd	ra,40(sp)
    1c10:	f022                	sd	s0,32(sp)
    1c12:	ec26                	sd	s1,24(sp)
    1c14:	1800                	addi	s0,sp,48
    1c16:	84aa                	mv	s1,a0
  pid = fork();
    1c18:	07d030ef          	jal	5494 <fork>
  if (pid == 0) {
    1c1c:	cd11                	beqz	a0,1c38 <stacktest+0x2c>
  } else if (pid < 0) {
    1c1e:	02054c63          	bltz	a0,1c56 <stacktest+0x4a>
  wait(&xstatus);
    1c22:	fdc40513          	addi	a0,s0,-36
    1c26:	07f030ef          	jal	54a4 <wait>
  if (xstatus == -1) // kernel killed child?
    1c2a:	fdc42503          	lw	a0,-36(s0)
    1c2e:	57fd                	li	a5,-1
    1c30:	02f50d63          	beq	a0,a5,1c6a <stacktest+0x5e>
    exit(xstatus);
    1c34:	069030ef          	jal	549c <exit>

static inline uint64
r_sp()
{
  uint64 x;
  asm volatile("mv %0, sp" : "=r"(x));
    1c38:	878a                	mv	a5,sp
    printf("%s: stacktest: read below stack %d\n", s, *sp);
    1c3a:	80078793          	addi	a5,a5,-2048
    1c3e:	8007c603          	lbu	a2,-2048(a5)
    1c42:	85a6                	mv	a1,s1
    1c44:	00005517          	auipc	a0,0x5
    1c48:	9f450513          	addi	a0,a0,-1548 # 6638 <malloc+0xc5e>
    1c4c:	4d7030ef          	jal	5922 <printf>
    exit(1);
    1c50:	4505                	li	a0,1
    1c52:	04b030ef          	jal	549c <exit>
    printf("%s: fork failed\n", s);
    1c56:	85a6                	mv	a1,s1
    1c58:	00004517          	auipc	a0,0x4
    1c5c:	74050513          	addi	a0,a0,1856 # 6398 <malloc+0x9be>
    1c60:	4c3030ef          	jal	5922 <printf>
    exit(1);
    1c64:	4505                	li	a0,1
    1c66:	037030ef          	jal	549c <exit>
    exit(0);
    1c6a:	4501                	li	a0,0
    1c6c:	031030ef          	jal	549c <exit>

0000000000001c70 <nowrite>:
{
    1c70:	7159                	addi	sp,sp,-112
    1c72:	f486                	sd	ra,104(sp)
    1c74:	f0a2                	sd	s0,96(sp)
    1c76:	eca6                	sd	s1,88(sp)
    1c78:	e8ca                	sd	s2,80(sp)
    1c7a:	e4ce                	sd	s3,72(sp)
    1c7c:	e0d2                	sd	s4,64(sp)
    1c7e:	1880                	addi	s0,sp,112
    1c80:	8a2a                	mv	s4,a0
  uint64 addrs[] = {0,
    1c82:	00006797          	auipc	a5,0x6
    1c86:	68678793          	addi	a5,a5,1670 # 8308 <malloc+0x292e>
    1c8a:	7788                	ld	a0,40(a5)
    1c8c:	7b8c                	ld	a1,48(a5)
    1c8e:	7f90                	ld	a2,56(a5)
    1c90:	63b4                	ld	a3,64(a5)
    1c92:	67b8                	ld	a4,72(a5)
    1c94:	f8a43c23          	sd	a0,-104(s0)
    1c98:	fab43023          	sd	a1,-96(s0)
    1c9c:	fac43423          	sd	a2,-88(s0)
    1ca0:	fad43823          	sd	a3,-80(s0)
    1ca4:	fae43c23          	sd	a4,-72(s0)
    1ca8:	6bbc                	ld	a5,80(a5)
    1caa:	fcf43023          	sd	a5,-64(s0)
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1cae:	4481                	li	s1,0
    wait(&xstatus);
    1cb0:	fcc40913          	addi	s2,s0,-52
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1cb4:	4999                	li	s3,6
    pid = fork();
    1cb6:	7de030ef          	jal	5494 <fork>
    if (pid == 0) {
    1cba:	cd19                	beqz	a0,1cd8 <nowrite+0x68>
    } else if (pid < 0) {
    1cbc:	04054163          	bltz	a0,1cfe <nowrite+0x8e>
    wait(&xstatus);
    1cc0:	854a                	mv	a0,s2
    1cc2:	7e2030ef          	jal	54a4 <wait>
    if (xstatus == 0) {
    1cc6:	fcc42783          	lw	a5,-52(s0)
    1cca:	c7a1                	beqz	a5,1d12 <nowrite+0xa2>
  for (int ai = 0; ai < sizeof(addrs) / sizeof(addrs[0]); ai++) {
    1ccc:	2485                	addiw	s1,s1,1
    1cce:	ff3494e3          	bne	s1,s3,1cb6 <nowrite+0x46>
  exit(0);
    1cd2:	4501                	li	a0,0
    1cd4:	7c8030ef          	jal	549c <exit>
      volatile int *addr = (int *)addrs[ai];
    1cd8:	048e                	slli	s1,s1,0x3
    1cda:	fd048793          	addi	a5,s1,-48
    1cde:	008784b3          	add	s1,a5,s0
    1ce2:	fc84b603          	ld	a2,-56(s1)
      *addr = 10;
    1ce6:	47a9                	li	a5,10
    1ce8:	c21c                	sw	a5,0(a2)
      printf("%s: write to %p did not fail!\n", s, addr);
    1cea:	85d2                	mv	a1,s4
    1cec:	00005517          	auipc	a0,0x5
    1cf0:	97450513          	addi	a0,a0,-1676 # 6660 <malloc+0xc86>
    1cf4:	42f030ef          	jal	5922 <printf>
      exit(0);
    1cf8:	4501                	li	a0,0
    1cfa:	7a2030ef          	jal	549c <exit>
      printf("%s: fork failed\n", s);
    1cfe:	85d2                	mv	a1,s4
    1d00:	00004517          	auipc	a0,0x4
    1d04:	69850513          	addi	a0,a0,1688 # 6398 <malloc+0x9be>
    1d08:	41b030ef          	jal	5922 <printf>
      exit(1);
    1d0c:	4505                	li	a0,1
    1d0e:	78e030ef          	jal	549c <exit>
      exit(1);
    1d12:	4505                	li	a0,1
    1d14:	788030ef          	jal	549c <exit>

0000000000001d18 <manywrites>:
{
    1d18:	7159                	addi	sp,sp,-112
    1d1a:	f486                	sd	ra,104(sp)
    1d1c:	f0a2                	sd	s0,96(sp)
    1d1e:	eca6                	sd	s1,88(sp)
    1d20:	e8ca                	sd	s2,80(sp)
    1d22:	e4ce                	sd	s3,72(sp)
    1d24:	ec66                	sd	s9,24(sp)
    1d26:	1880                	addi	s0,sp,112
    1d28:	8caa                	mv	s9,a0
  for (int ci = 0; ci < nchildren; ci++) {
    1d2a:	4901                	li	s2,0
    1d2c:	4991                	li	s3,4
    int pid = fork();
    1d2e:	766030ef          	jal	5494 <fork>
    1d32:	84aa                	mv	s1,a0
    if (pid < 0) {
    1d34:	02054c63          	bltz	a0,1d6c <manywrites+0x54>
    if (pid == 0) {
    1d38:	c929                	beqz	a0,1d8a <manywrites+0x72>
  for (int ci = 0; ci < nchildren; ci++) {
    1d3a:	2905                	addiw	s2,s2,1
    1d3c:	ff3919e3          	bne	s2,s3,1d2e <manywrites+0x16>
    1d40:	4491                	li	s1,4
    wait(&st);
    1d42:	f9840913          	addi	s2,s0,-104
    int st = 0;
    1d46:	f8042c23          	sw	zero,-104(s0)
    wait(&st);
    1d4a:	854a                	mv	a0,s2
    1d4c:	758030ef          	jal	54a4 <wait>
    if (st != 0)
    1d50:	f9842503          	lw	a0,-104(s0)
    1d54:	0e051763          	bnez	a0,1e42 <manywrites+0x12a>
  for (int ci = 0; ci < nchildren; ci++) {
    1d58:	34fd                	addiw	s1,s1,-1
    1d5a:	f4f5                	bnez	s1,1d46 <manywrites+0x2e>
    1d5c:	e0d2                	sd	s4,64(sp)
    1d5e:	fc56                	sd	s5,56(sp)
    1d60:	f85a                	sd	s6,48(sp)
    1d62:	f45e                	sd	s7,40(sp)
    1d64:	f062                	sd	s8,32(sp)
    1d66:	e86a                	sd	s10,16(sp)
  exit(0);
    1d68:	734030ef          	jal	549c <exit>
    1d6c:	e0d2                	sd	s4,64(sp)
    1d6e:	fc56                	sd	s5,56(sp)
    1d70:	f85a                	sd	s6,48(sp)
    1d72:	f45e                	sd	s7,40(sp)
    1d74:	f062                	sd	s8,32(sp)
    1d76:	e86a                	sd	s10,16(sp)
      printf("fork failed\n");
    1d78:	00006517          	auipc	a0,0x6
    1d7c:	ce050513          	addi	a0,a0,-800 # 7a58 <malloc+0x207e>
    1d80:	3a3030ef          	jal	5922 <printf>
      exit(1);
    1d84:	4505                	li	a0,1
    1d86:	716030ef          	jal	549c <exit>
    1d8a:	e0d2                	sd	s4,64(sp)
    1d8c:	fc56                	sd	s5,56(sp)
    1d8e:	f85a                	sd	s6,48(sp)
    1d90:	f45e                	sd	s7,40(sp)
    1d92:	f062                	sd	s8,32(sp)
    1d94:	e86a                	sd	s10,16(sp)
      name[0] = 'b';
    1d96:	06200793          	li	a5,98
    1d9a:	f8f40c23          	sb	a5,-104(s0)
      name[1] = 'a' + ci;
    1d9e:	0619079b          	addiw	a5,s2,97
    1da2:	f8f40ca3          	sb	a5,-103(s0)
      name[2] = '\0';
    1da6:	f8040d23          	sb	zero,-102(s0)
      unlink(name);
    1daa:	f9840513          	addi	a0,s0,-104
    1dae:	73e030ef          	jal	54ec <unlink>
    1db2:	47f9                	li	a5,30
    1db4:	8d3e                	mv	s10,a5
          int fd = open(name, O_CREATE | O_RDWR);
    1db6:	f9840b93          	addi	s7,s0,-104
    1dba:	20200b13          	li	s6,514
          int cc = write(fd, buf, sz);
    1dbe:	6a8d                	lui	s5,0x3
    1dc0:	0000cc17          	auipc	s8,0xc
    1dc4:	f28c0c13          	addi	s8,s8,-216 # dce8 <buf>
        for (int i = 0; i < ci + 1; i++) {
    1dc8:	8a26                	mv	s4,s1
    1dca:	02094563          	bltz	s2,1df4 <manywrites+0xdc>
          int fd = open(name, O_CREATE | O_RDWR);
    1dce:	85da                	mv	a1,s6
    1dd0:	855e                	mv	a0,s7
    1dd2:	70a030ef          	jal	54dc <open>
    1dd6:	89aa                	mv	s3,a0
          if (fd < 0) {
    1dd8:	02054d63          	bltz	a0,1e12 <manywrites+0xfa>
          int cc = write(fd, buf, sz);
    1ddc:	8656                	mv	a2,s5
    1dde:	85e2                	mv	a1,s8
    1de0:	6dc030ef          	jal	54bc <write>
          if (cc != sz) {
    1de4:	05551363          	bne	a0,s5,1e2a <manywrites+0x112>
          close(fd);
    1de8:	854e                	mv	a0,s3
    1dea:	6da030ef          	jal	54c4 <close>
        for (int i = 0; i < ci + 1; i++) {
    1dee:	2a05                	addiw	s4,s4,1
    1df0:	fd495fe3          	bge	s2,s4,1dce <manywrites+0xb6>
        unlink(name);
    1df4:	f9840513          	addi	a0,s0,-104
    1df8:	6f4030ef          	jal	54ec <unlink>
      for (int iters = 0; iters < howmany; iters++) {
    1dfc:	fffd079b          	addiw	a5,s10,-1
    1e00:	8d3e                	mv	s10,a5
    1e02:	f3f9                	bnez	a5,1dc8 <manywrites+0xb0>
      unlink(name);
    1e04:	f9840513          	addi	a0,s0,-104
    1e08:	6e4030ef          	jal	54ec <unlink>
      exit(0);
    1e0c:	4501                	li	a0,0
    1e0e:	68e030ef          	jal	549c <exit>
            printf("%s: cannot create %s\n", s, name);
    1e12:	f9840613          	addi	a2,s0,-104
    1e16:	85e6                	mv	a1,s9
    1e18:	00005517          	auipc	a0,0x5
    1e1c:	86850513          	addi	a0,a0,-1944 # 6680 <malloc+0xca6>
    1e20:	303030ef          	jal	5922 <printf>
            exit(1);
    1e24:	4505                	li	a0,1
    1e26:	676030ef          	jal	549c <exit>
            printf("%s: write(%d) ret %d\n", s, sz, cc);
    1e2a:	86aa                	mv	a3,a0
    1e2c:	660d                	lui	a2,0x3
    1e2e:	85e6                	mv	a1,s9
    1e30:	00004517          	auipc	a0,0x4
    1e34:	da850513          	addi	a0,a0,-600 # 5bd8 <malloc+0x1fe>
    1e38:	2eb030ef          	jal	5922 <printf>
            exit(1);
    1e3c:	4505                	li	a0,1
    1e3e:	65e030ef          	jal	549c <exit>
    1e42:	e0d2                	sd	s4,64(sp)
    1e44:	fc56                	sd	s5,56(sp)
    1e46:	f85a                	sd	s6,48(sp)
    1e48:	f45e                	sd	s7,40(sp)
    1e4a:	f062                	sd	s8,32(sp)
    1e4c:	e86a                	sd	s10,16(sp)
      exit(st);
    1e4e:	64e030ef          	jal	549c <exit>

0000000000001e52 <copyinstr3>:
{
    1e52:	7179                	addi	sp,sp,-48
    1e54:	f406                	sd	ra,40(sp)
    1e56:	f022                	sd	s0,32(sp)
    1e58:	ec26                	sd	s1,24(sp)
    1e5a:	1800                	addi	s0,sp,48
  sbrk(8192);
    1e5c:	6509                	lui	a0,0x2
    1e5e:	60a030ef          	jal	5468 <sbrk>
  uint64 top = (uint64)sbrk(0);
    1e62:	4501                	li	a0,0
    1e64:	604030ef          	jal	5468 <sbrk>
  if ((top % PGSIZE) != 0) {
    1e68:	03451793          	slli	a5,a0,0x34
    1e6c:	e7bd                	bnez	a5,1eda <copyinstr3+0x88>
  top = (uint64)sbrk(0);
    1e6e:	4501                	li	a0,0
    1e70:	5f8030ef          	jal	5468 <sbrk>
  if (top % PGSIZE) {
    1e74:	03451793          	slli	a5,a0,0x34
    1e78:	ebad                	bnez	a5,1eea <copyinstr3+0x98>
  char *b = (char *)(top - 1);
    1e7a:	fff50493          	addi	s1,a0,-1 # 1fff <rwsbrk+0xa9>
  *b = 'x';
    1e7e:	07800793          	li	a5,120
    1e82:	fef50fa3          	sb	a5,-1(a0)
  int ret = unlink(b);
    1e86:	8526                	mv	a0,s1
    1e88:	664030ef          	jal	54ec <unlink>
  if (ret != -1) {
    1e8c:	57fd                	li	a5,-1
    1e8e:	06f51763          	bne	a0,a5,1efc <copyinstr3+0xaa>
  int fd = open(b, O_CREATE | O_WRONLY);
    1e92:	20100593          	li	a1,513
    1e96:	8526                	mv	a0,s1
    1e98:	644030ef          	jal	54dc <open>
  if (fd != -1) {
    1e9c:	57fd                	li	a5,-1
    1e9e:	06f51a63          	bne	a0,a5,1f12 <copyinstr3+0xc0>
  ret = link(b, b);
    1ea2:	85a6                	mv	a1,s1
    1ea4:	8526                	mv	a0,s1
    1ea6:	656030ef          	jal	54fc <link>
  if (ret != -1) {
    1eaa:	57fd                	li	a5,-1
    1eac:	06f51e63          	bne	a0,a5,1f28 <copyinstr3+0xd6>
  char *args[] = {"xx", 0};
    1eb0:	00005797          	auipc	a5,0x5
    1eb4:	4d078793          	addi	a5,a5,1232 # 7380 <malloc+0x19a6>
    1eb8:	fcf43823          	sd	a5,-48(s0)
    1ebc:	fc043c23          	sd	zero,-40(s0)
  ret = exec(b, args);
    1ec0:	fd040593          	addi	a1,s0,-48
    1ec4:	8526                	mv	a0,s1
    1ec6:	60e030ef          	jal	54d4 <exec>
  if (ret != -1) {
    1eca:	57fd                	li	a5,-1
    1ecc:	06f51a63          	bne	a0,a5,1f40 <copyinstr3+0xee>
}
    1ed0:	70a2                	ld	ra,40(sp)
    1ed2:	7402                	ld	s0,32(sp)
    1ed4:	64e2                	ld	s1,24(sp)
    1ed6:	6145                	addi	sp,sp,48
    1ed8:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    1eda:	0347d513          	srli	a0,a5,0x34
    1ede:	6785                	lui	a5,0x1
    1ee0:	40a7853b          	subw	a0,a5,a0
    1ee4:	584030ef          	jal	5468 <sbrk>
    1ee8:	b759                	j	1e6e <copyinstr3+0x1c>
    printf("oops\n");
    1eea:	00004517          	auipc	a0,0x4
    1eee:	7ae50513          	addi	a0,a0,1966 # 6698 <malloc+0xcbe>
    1ef2:	231030ef          	jal	5922 <printf>
    exit(1);
    1ef6:	4505                	li	a0,1
    1ef8:	5a4030ef          	jal	549c <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1efc:	862a                	mv	a2,a0
    1efe:	85a6                	mv	a1,s1
    1f00:	00004517          	auipc	a0,0x4
    1f04:	3b850513          	addi	a0,a0,952 # 62b8 <malloc+0x8de>
    1f08:	21b030ef          	jal	5922 <printf>
    exit(1);
    1f0c:	4505                	li	a0,1
    1f0e:	58e030ef          	jal	549c <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    1f12:	862a                	mv	a2,a0
    1f14:	85a6                	mv	a1,s1
    1f16:	00004517          	auipc	a0,0x4
    1f1a:	3c250513          	addi	a0,a0,962 # 62d8 <malloc+0x8fe>
    1f1e:	205030ef          	jal	5922 <printf>
    exit(1);
    1f22:	4505                	li	a0,1
    1f24:	578030ef          	jal	549c <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    1f28:	86aa                	mv	a3,a0
    1f2a:	8626                	mv	a2,s1
    1f2c:	85a6                	mv	a1,s1
    1f2e:	00004517          	auipc	a0,0x4
    1f32:	3ca50513          	addi	a0,a0,970 # 62f8 <malloc+0x91e>
    1f36:	1ed030ef          	jal	5922 <printf>
    exit(1);
    1f3a:	4505                	li	a0,1
    1f3c:	560030ef          	jal	549c <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    1f40:	863e                	mv	a2,a5
    1f42:	85a6                	mv	a1,s1
    1f44:	00004517          	auipc	a0,0x4
    1f48:	3dc50513          	addi	a0,a0,988 # 6320 <malloc+0x946>
    1f4c:	1d7030ef          	jal	5922 <printf>
    exit(1);
    1f50:	4505                	li	a0,1
    1f52:	54a030ef          	jal	549c <exit>

0000000000001f56 <rwsbrk>:
{
    1f56:	1101                	addi	sp,sp,-32
    1f58:	ec06                	sd	ra,24(sp)
    1f5a:	e822                	sd	s0,16(sp)
    1f5c:	1000                	addi	s0,sp,32
  uint64 a = (uint64)sbrk(8192);
    1f5e:	6509                	lui	a0,0x2
    1f60:	508030ef          	jal	5468 <sbrk>
  if (a == (uint64)SBRK_ERROR) {
    1f64:	57fd                	li	a5,-1
    1f66:	04f50a63          	beq	a0,a5,1fba <rwsbrk+0x64>
    1f6a:	e426                	sd	s1,8(sp)
    1f6c:	84aa                	mv	s1,a0
  if (sbrk(-8192) == SBRK_ERROR) {
    1f6e:	7579                	lui	a0,0xffffe
    1f70:	4f8030ef          	jal	5468 <sbrk>
    1f74:	57fd                	li	a5,-1
    1f76:	04f50d63          	beq	a0,a5,1fd0 <rwsbrk+0x7a>
    1f7a:	e04a                	sd	s2,0(sp)
  fd = open("rwsbrk", O_CREATE | O_WRONLY);
    1f7c:	20100593          	li	a1,513
    1f80:	00004517          	auipc	a0,0x4
    1f84:	75850513          	addi	a0,a0,1880 # 66d8 <malloc+0xcfe>
    1f88:	554030ef          	jal	54dc <open>
    1f8c:	892a                	mv	s2,a0
  if (fd < 0) {
    1f8e:	04054b63          	bltz	a0,1fe4 <rwsbrk+0x8e>
  n = write(fd, (void *)(a + PGSIZE), 1024);
    1f92:	6785                	lui	a5,0x1
    1f94:	94be                	add	s1,s1,a5
    1f96:	40000613          	li	a2,1024
    1f9a:	85a6                	mv	a1,s1
    1f9c:	520030ef          	jal	54bc <write>
    1fa0:	862a                	mv	a2,a0
  if (n >= 0) {
    1fa2:	04054a63          	bltz	a0,1ff6 <rwsbrk+0xa0>
    printf("write(fd, %p, 1024) returned %d, not -1\n", (void *)a + PGSIZE, n);
    1fa6:	85a6                	mv	a1,s1
    1fa8:	00004517          	auipc	a0,0x4
    1fac:	75050513          	addi	a0,a0,1872 # 66f8 <malloc+0xd1e>
    1fb0:	173030ef          	jal	5922 <printf>
    exit(1);
    1fb4:	4505                	li	a0,1
    1fb6:	4e6030ef          	jal	549c <exit>
    1fba:	e426                	sd	s1,8(sp)
    1fbc:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) failed\n");
    1fbe:	00004517          	auipc	a0,0x4
    1fc2:	6e250513          	addi	a0,a0,1762 # 66a0 <malloc+0xcc6>
    1fc6:	15d030ef          	jal	5922 <printf>
    exit(1);
    1fca:	4505                	li	a0,1
    1fcc:	4d0030ef          	jal	549c <exit>
    1fd0:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) shrink failed\n");
    1fd2:	00004517          	auipc	a0,0x4
    1fd6:	6e650513          	addi	a0,a0,1766 # 66b8 <malloc+0xcde>
    1fda:	149030ef          	jal	5922 <printf>
    exit(1);
    1fde:	4505                	li	a0,1
    1fe0:	4bc030ef          	jal	549c <exit>
    printf("open(rwsbrk) failed\n");
    1fe4:	00004517          	auipc	a0,0x4
    1fe8:	6fc50513          	addi	a0,a0,1788 # 66e0 <malloc+0xd06>
    1fec:	137030ef          	jal	5922 <printf>
    exit(1);
    1ff0:	4505                	li	a0,1
    1ff2:	4aa030ef          	jal	549c <exit>
  close(fd);
    1ff6:	854a                	mv	a0,s2
    1ff8:	4cc030ef          	jal	54c4 <close>
  unlink("rwsbrk");
    1ffc:	00004517          	auipc	a0,0x4
    2000:	6dc50513          	addi	a0,a0,1756 # 66d8 <malloc+0xcfe>
    2004:	4e8030ef          	jal	54ec <unlink>
  fd = open("README", O_RDONLY);
    2008:	4581                	li	a1,0
    200a:	00004517          	auipc	a0,0x4
    200e:	cd650513          	addi	a0,a0,-810 # 5ce0 <malloc+0x306>
    2012:	4ca030ef          	jal	54dc <open>
    2016:	892a                	mv	s2,a0
  if (fd < 0) {
    2018:	02054363          	bltz	a0,203e <rwsbrk+0xe8>
  n = read(fd, (void *)(a + PGSIZE), 10);
    201c:	4629                	li	a2,10
    201e:	85a6                	mv	a1,s1
    2020:	494030ef          	jal	54b4 <read>
    2024:	862a                	mv	a2,a0
  if (n >= 0) {
    2026:	02054563          	bltz	a0,2050 <rwsbrk+0xfa>
    printf("read(fd, %p, 10) returned %d, not -1\n", (void *)a + PGSIZE, n);
    202a:	85a6                	mv	a1,s1
    202c:	00004517          	auipc	a0,0x4
    2030:	6fc50513          	addi	a0,a0,1788 # 6728 <malloc+0xd4e>
    2034:	0ef030ef          	jal	5922 <printf>
    exit(1);
    2038:	4505                	li	a0,1
    203a:	462030ef          	jal	549c <exit>
    printf("open(README) failed\n");
    203e:	00004517          	auipc	a0,0x4
    2042:	caa50513          	addi	a0,a0,-854 # 5ce8 <malloc+0x30e>
    2046:	0dd030ef          	jal	5922 <printf>
    exit(1);
    204a:	4505                	li	a0,1
    204c:	450030ef          	jal	549c <exit>
  close(fd);
    2050:	854a                	mv	a0,s2
    2052:	472030ef          	jal	54c4 <close>
  exit(0);
    2056:	4501                	li	a0,0
    2058:	444030ef          	jal	549c <exit>

000000000000205c <sbrkbasic>:
{
    205c:	715d                	addi	sp,sp,-80
    205e:	e486                	sd	ra,72(sp)
    2060:	e0a2                	sd	s0,64(sp)
    2062:	ec56                	sd	s5,24(sp)
    2064:	0880                	addi	s0,sp,80
    2066:	8aaa                	mv	s5,a0
  pid = fork();
    2068:	42c030ef          	jal	5494 <fork>
  if (pid < 0) {
    206c:	02054c63          	bltz	a0,20a4 <sbrkbasic+0x48>
  if (pid == 0) {
    2070:	ed31                	bnez	a0,20cc <sbrkbasic+0x70>
    a = sbrk(TOOMUCH);
    2072:	40000537          	lui	a0,0x40000
    2076:	3f2030ef          	jal	5468 <sbrk>
    if (a == (char *)SBRK_ERROR) {
    207a:	57fd                	li	a5,-1
    207c:	04f50163          	beq	a0,a5,20be <sbrkbasic+0x62>
    2080:	fc26                	sd	s1,56(sp)
    2082:	f84a                	sd	s2,48(sp)
    2084:	f44e                	sd	s3,40(sp)
    2086:	f052                	sd	s4,32(sp)
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    2088:	400007b7          	lui	a5,0x40000
    208c:	97aa                	add	a5,a5,a0
      *b = 99;
    208e:	06300693          	li	a3,99
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    2092:	6705                	lui	a4,0x1
      *b = 99;
    2094:	00d50023          	sb	a3,0(a0) # 40000000 <base+0x3ffef318>
    for (b = a; b < a + TOOMUCH; b += PGSIZE) {
    2098:	953a                	add	a0,a0,a4
    209a:	fef51de3          	bne	a0,a5,2094 <sbrkbasic+0x38>
    exit(1);
    209e:	4505                	li	a0,1
    20a0:	3fc030ef          	jal	549c <exit>
    20a4:	fc26                	sd	s1,56(sp)
    20a6:	f84a                	sd	s2,48(sp)
    20a8:	f44e                	sd	s3,40(sp)
    20aa:	f052                	sd	s4,32(sp)
    printf("fork failed in sbrkbasic\n");
    20ac:	00004517          	auipc	a0,0x4
    20b0:	6a450513          	addi	a0,a0,1700 # 6750 <malloc+0xd76>
    20b4:	06f030ef          	jal	5922 <printf>
    exit(1);
    20b8:	4505                	li	a0,1
    20ba:	3e2030ef          	jal	549c <exit>
    20be:	fc26                	sd	s1,56(sp)
    20c0:	f84a                	sd	s2,48(sp)
    20c2:	f44e                	sd	s3,40(sp)
    20c4:	f052                	sd	s4,32(sp)
      exit(0);
    20c6:	4501                	li	a0,0
    20c8:	3d4030ef          	jal	549c <exit>
  wait(&xstatus);
    20cc:	fbc40513          	addi	a0,s0,-68
    20d0:	3d4030ef          	jal	54a4 <wait>
  if (xstatus == 1) {
    20d4:	fbc42703          	lw	a4,-68(s0)
    20d8:	4785                	li	a5,1
    20da:	02f70063          	beq	a4,a5,20fa <sbrkbasic+0x9e>
    20de:	fc26                	sd	s1,56(sp)
    20e0:	f84a                	sd	s2,48(sp)
    20e2:	f44e                	sd	s3,40(sp)
    20e4:	f052                	sd	s4,32(sp)
  a = sbrk(0);
    20e6:	4501                	li	a0,0
    20e8:	380030ef          	jal	5468 <sbrk>
    20ec:	84aa                	mv	s1,a0
  for (i = 0; i < 5000; i++) {
    20ee:	4901                	li	s2,0
    b = sbrk(1);
    20f0:	4985                	li	s3,1
  for (i = 0; i < 5000; i++) {
    20f2:	6a05                	lui	s4,0x1
    20f4:	388a0a13          	addi	s4,s4,904 # 1388 <truncate3+0x14a>
    20f8:	a005                	j	2118 <sbrkbasic+0xbc>
    20fa:	fc26                	sd	s1,56(sp)
    20fc:	f84a                	sd	s2,48(sp)
    20fe:	f44e                	sd	s3,40(sp)
    2100:	f052                	sd	s4,32(sp)
    printf("%s: too much memory allocated!\n", s);
    2102:	85d6                	mv	a1,s5
    2104:	00004517          	auipc	a0,0x4
    2108:	66c50513          	addi	a0,a0,1644 # 6770 <malloc+0xd96>
    210c:	017030ef          	jal	5922 <printf>
    exit(1);
    2110:	4505                	li	a0,1
    2112:	38a030ef          	jal	549c <exit>
    2116:	84be                	mv	s1,a5
    b = sbrk(1);
    2118:	854e                	mv	a0,s3
    211a:	34e030ef          	jal	5468 <sbrk>
    if (b != a) {
    211e:	04951163          	bne	a0,s1,2160 <sbrkbasic+0x104>
    *b = 1;
    2122:	01348023          	sb	s3,0(s1)
    a = b + 1;
    2126:	00148793          	addi	a5,s1,1
  for (i = 0; i < 5000; i++) {
    212a:	2905                	addiw	s2,s2,1
    212c:	ff4915e3          	bne	s2,s4,2116 <sbrkbasic+0xba>
  pid = fork();
    2130:	364030ef          	jal	5494 <fork>
    2134:	892a                	mv	s2,a0
  if (pid < 0) {
    2136:	04054263          	bltz	a0,217a <sbrkbasic+0x11e>
  c = sbrk(1);
    213a:	4505                	li	a0,1
    213c:	32c030ef          	jal	5468 <sbrk>
  c = sbrk(1);
    2140:	4505                	li	a0,1
    2142:	326030ef          	jal	5468 <sbrk>
  if (c != a + 1) {
    2146:	0489                	addi	s1,s1,2
    2148:	04950363          	beq	a0,s1,218e <sbrkbasic+0x132>
    printf("%s: sbrk test failed post-fork\n", s);
    214c:	85d6                	mv	a1,s5
    214e:	00004517          	auipc	a0,0x4
    2152:	68250513          	addi	a0,a0,1666 # 67d0 <malloc+0xdf6>
    2156:	7cc030ef          	jal	5922 <printf>
    exit(1);
    215a:	4505                	li	a0,1
    215c:	340030ef          	jal	549c <exit>
      printf("%s: sbrk test failed %d %p %p\n", s, i, a, b);
    2160:	872a                	mv	a4,a0
    2162:	86a6                	mv	a3,s1
    2164:	864a                	mv	a2,s2
    2166:	85d6                	mv	a1,s5
    2168:	00004517          	auipc	a0,0x4
    216c:	62850513          	addi	a0,a0,1576 # 6790 <malloc+0xdb6>
    2170:	7b2030ef          	jal	5922 <printf>
      exit(1);
    2174:	4505                	li	a0,1
    2176:	326030ef          	jal	549c <exit>
    printf("%s: sbrk test fork failed\n", s);
    217a:	85d6                	mv	a1,s5
    217c:	00004517          	auipc	a0,0x4
    2180:	63450513          	addi	a0,a0,1588 # 67b0 <malloc+0xdd6>
    2184:	79e030ef          	jal	5922 <printf>
    exit(1);
    2188:	4505                	li	a0,1
    218a:	312030ef          	jal	549c <exit>
  if (pid == 0)
    218e:	00091563          	bnez	s2,2198 <sbrkbasic+0x13c>
    exit(0);
    2192:	4501                	li	a0,0
    2194:	308030ef          	jal	549c <exit>
  wait(&xstatus);
    2198:	fbc40513          	addi	a0,s0,-68
    219c:	308030ef          	jal	54a4 <wait>
  exit(xstatus);
    21a0:	fbc42503          	lw	a0,-68(s0)
    21a4:	2f8030ef          	jal	549c <exit>

00000000000021a8 <sbrkmuch>:
{
    21a8:	7179                	addi	sp,sp,-48
    21aa:	f406                	sd	ra,40(sp)
    21ac:	f022                	sd	s0,32(sp)
    21ae:	ec26                	sd	s1,24(sp)
    21b0:	e84a                	sd	s2,16(sp)
    21b2:	e44e                	sd	s3,8(sp)
    21b4:	e052                	sd	s4,0(sp)
    21b6:	1800                	addi	s0,sp,48
    21b8:	89aa                	mv	s3,a0
  oldbrk = sbrk(0);
    21ba:	4501                	li	a0,0
    21bc:	2ac030ef          	jal	5468 <sbrk>
    21c0:	892a                	mv	s2,a0
  a = sbrk(0);
    21c2:	4501                	li	a0,0
    21c4:	2a4030ef          	jal	5468 <sbrk>
    21c8:	84aa                	mv	s1,a0
  p = sbrk(amt);
    21ca:	06400537          	lui	a0,0x6400
    21ce:	9d05                	subw	a0,a0,s1
    21d0:	298030ef          	jal	5468 <sbrk>
  if (p != a) {
    21d4:	08a49963          	bne	s1,a0,2266 <sbrkmuch+0xbe>
  *lastaddr = 99;
    21d8:	064007b7          	lui	a5,0x6400
    21dc:	06300713          	li	a4,99
    21e0:	fee78fa3          	sb	a4,-1(a5) # 63fffff <base+0x63ef317>
  a = sbrk(0);
    21e4:	4501                	li	a0,0
    21e6:	282030ef          	jal	5468 <sbrk>
    21ea:	84aa                	mv	s1,a0
  c = sbrk(-PGSIZE);
    21ec:	757d                	lui	a0,0xfffff
    21ee:	27a030ef          	jal	5468 <sbrk>
  if (c == (char *)SBRK_ERROR) {
    21f2:	57fd                	li	a5,-1
    21f4:	08f50363          	beq	a0,a5,227a <sbrkmuch+0xd2>
  c = sbrk(0);
    21f8:	4501                	li	a0,0
    21fa:	26e030ef          	jal	5468 <sbrk>
  if (c != a - PGSIZE) {
    21fe:	80048793          	addi	a5,s1,-2048
    2202:	80078793          	addi	a5,a5,-2048
    2206:	08f51463          	bne	a0,a5,228e <sbrkmuch+0xe6>
  a = sbrk(0);
    220a:	4501                	li	a0,0
    220c:	25c030ef          	jal	5468 <sbrk>
    2210:	84aa                	mv	s1,a0
  c = sbrk(PGSIZE);
    2212:	6505                	lui	a0,0x1
    2214:	254030ef          	jal	5468 <sbrk>
    2218:	8a2a                	mv	s4,a0
  if (c != a || sbrk(0) != a + PGSIZE) {
    221a:	08a49663          	bne	s1,a0,22a6 <sbrkmuch+0xfe>
    221e:	4501                	li	a0,0
    2220:	248030ef          	jal	5468 <sbrk>
    2224:	6785                	lui	a5,0x1
    2226:	97a6                	add	a5,a5,s1
    2228:	06f51f63          	bne	a0,a5,22a6 <sbrkmuch+0xfe>
  if (*lastaddr == 99) {
    222c:	064007b7          	lui	a5,0x6400
    2230:	fff7c703          	lbu	a4,-1(a5) # 63fffff <base+0x63ef317>
    2234:	06300793          	li	a5,99
    2238:	08f70363          	beq	a4,a5,22be <sbrkmuch+0x116>
  a = sbrk(0);
    223c:	4501                	li	a0,0
    223e:	22a030ef          	jal	5468 <sbrk>
    2242:	84aa                	mv	s1,a0
  c = sbrk(-(sbrk(0) - oldbrk));
    2244:	4501                	li	a0,0
    2246:	222030ef          	jal	5468 <sbrk>
    224a:	40a9053b          	subw	a0,s2,a0
    224e:	21a030ef          	jal	5468 <sbrk>
  if (c != a) {
    2252:	08a49063          	bne	s1,a0,22d2 <sbrkmuch+0x12a>
}
    2256:	70a2                	ld	ra,40(sp)
    2258:	7402                	ld	s0,32(sp)
    225a:	64e2                	ld	s1,24(sp)
    225c:	6942                	ld	s2,16(sp)
    225e:	69a2                	ld	s3,8(sp)
    2260:	6a02                	ld	s4,0(sp)
    2262:	6145                	addi	sp,sp,48
    2264:	8082                	ret
    printf("%s: sbrk test failed to grow big address space; enough phys mem?\n",
    2266:	85ce                	mv	a1,s3
    2268:	00004517          	auipc	a0,0x4
    226c:	58850513          	addi	a0,a0,1416 # 67f0 <malloc+0xe16>
    2270:	6b2030ef          	jal	5922 <printf>
    exit(1);
    2274:	4505                	li	a0,1
    2276:	226030ef          	jal	549c <exit>
    printf("%s: sbrk could not deallocate\n", s);
    227a:	85ce                	mv	a1,s3
    227c:	00004517          	auipc	a0,0x4
    2280:	5bc50513          	addi	a0,a0,1468 # 6838 <malloc+0xe5e>
    2284:	69e030ef          	jal	5922 <printf>
    exit(1);
    2288:	4505                	li	a0,1
    228a:	212030ef          	jal	549c <exit>
    printf("%s: sbrk deallocation produced wrong address, a %p c %p\n", s, a,
    228e:	86aa                	mv	a3,a0
    2290:	8626                	mv	a2,s1
    2292:	85ce                	mv	a1,s3
    2294:	00004517          	auipc	a0,0x4
    2298:	5c450513          	addi	a0,a0,1476 # 6858 <malloc+0xe7e>
    229c:	686030ef          	jal	5922 <printf>
    exit(1);
    22a0:	4505                	li	a0,1
    22a2:	1fa030ef          	jal	549c <exit>
    printf("%s: sbrk re-allocation failed, a %p c %p\n", s, a, c);
    22a6:	86d2                	mv	a3,s4
    22a8:	8626                	mv	a2,s1
    22aa:	85ce                	mv	a1,s3
    22ac:	00004517          	auipc	a0,0x4
    22b0:	5ec50513          	addi	a0,a0,1516 # 6898 <malloc+0xebe>
    22b4:	66e030ef          	jal	5922 <printf>
    exit(1);
    22b8:	4505                	li	a0,1
    22ba:	1e2030ef          	jal	549c <exit>
    printf("%s: sbrk de-allocation didn't really deallocate\n", s);
    22be:	85ce                	mv	a1,s3
    22c0:	00004517          	auipc	a0,0x4
    22c4:	60850513          	addi	a0,a0,1544 # 68c8 <malloc+0xeee>
    22c8:	65a030ef          	jal	5922 <printf>
    exit(1);
    22cc:	4505                	li	a0,1
    22ce:	1ce030ef          	jal	549c <exit>
    printf("%s: sbrk downsize failed, a %p c %p\n", s, a, c);
    22d2:	86aa                	mv	a3,a0
    22d4:	8626                	mv	a2,s1
    22d6:	85ce                	mv	a1,s3
    22d8:	00004517          	auipc	a0,0x4
    22dc:	62850513          	addi	a0,a0,1576 # 6900 <malloc+0xf26>
    22e0:	642030ef          	jal	5922 <printf>
    exit(1);
    22e4:	4505                	li	a0,1
    22e6:	1b6030ef          	jal	549c <exit>

00000000000022ea <sbrkarg>:
{
    22ea:	7179                	addi	sp,sp,-48
    22ec:	f406                	sd	ra,40(sp)
    22ee:	f022                	sd	s0,32(sp)
    22f0:	ec26                	sd	s1,24(sp)
    22f2:	e84a                	sd	s2,16(sp)
    22f4:	e44e                	sd	s3,8(sp)
    22f6:	1800                	addi	s0,sp,48
    22f8:	89aa                	mv	s3,a0
  a = sbrk(PGSIZE);
    22fa:	6505                	lui	a0,0x1
    22fc:	16c030ef          	jal	5468 <sbrk>
    2300:	892a                	mv	s2,a0
  fd = open("sbrk", O_CREATE | O_WRONLY);
    2302:	20100593          	li	a1,513
    2306:	00004517          	auipc	a0,0x4
    230a:	62250513          	addi	a0,a0,1570 # 6928 <malloc+0xf4e>
    230e:	1ce030ef          	jal	54dc <open>
    2312:	84aa                	mv	s1,a0
  unlink("sbrk");
    2314:	00004517          	auipc	a0,0x4
    2318:	61450513          	addi	a0,a0,1556 # 6928 <malloc+0xf4e>
    231c:	1d0030ef          	jal	54ec <unlink>
  if (fd < 0) {
    2320:	0204c963          	bltz	s1,2352 <sbrkarg+0x68>
  if ((n = write(fd, a, PGSIZE)) < 0) {
    2324:	6605                	lui	a2,0x1
    2326:	85ca                	mv	a1,s2
    2328:	8526                	mv	a0,s1
    232a:	192030ef          	jal	54bc <write>
    232e:	02054c63          	bltz	a0,2366 <sbrkarg+0x7c>
  close(fd);
    2332:	8526                	mv	a0,s1
    2334:	190030ef          	jal	54c4 <close>
  a = sbrk(PGSIZE);
    2338:	6505                	lui	a0,0x1
    233a:	12e030ef          	jal	5468 <sbrk>
  if (pipe((int *)a) != 0) {
    233e:	16e030ef          	jal	54ac <pipe>
    2342:	ed05                	bnez	a0,237a <sbrkarg+0x90>
}
    2344:	70a2                	ld	ra,40(sp)
    2346:	7402                	ld	s0,32(sp)
    2348:	64e2                	ld	s1,24(sp)
    234a:	6942                	ld	s2,16(sp)
    234c:	69a2                	ld	s3,8(sp)
    234e:	6145                	addi	sp,sp,48
    2350:	8082                	ret
    printf("%s: open sbrk failed\n", s);
    2352:	85ce                	mv	a1,s3
    2354:	00004517          	auipc	a0,0x4
    2358:	5dc50513          	addi	a0,a0,1500 # 6930 <malloc+0xf56>
    235c:	5c6030ef          	jal	5922 <printf>
    exit(1);
    2360:	4505                	li	a0,1
    2362:	13a030ef          	jal	549c <exit>
    printf("%s: write sbrk failed\n", s);
    2366:	85ce                	mv	a1,s3
    2368:	00004517          	auipc	a0,0x4
    236c:	5e050513          	addi	a0,a0,1504 # 6948 <malloc+0xf6e>
    2370:	5b2030ef          	jal	5922 <printf>
    exit(1);
    2374:	4505                	li	a0,1
    2376:	126030ef          	jal	549c <exit>
    printf("%s: pipe() failed\n", s);
    237a:	85ce                	mv	a1,s3
    237c:	00004517          	auipc	a0,0x4
    2380:	0a450513          	addi	a0,a0,164 # 6420 <malloc+0xa46>
    2384:	59e030ef          	jal	5922 <printf>
    exit(1);
    2388:	4505                	li	a0,1
    238a:	112030ef          	jal	549c <exit>

000000000000238e <argptest>:
{
    238e:	1101                	addi	sp,sp,-32
    2390:	ec06                	sd	ra,24(sp)
    2392:	e822                	sd	s0,16(sp)
    2394:	e426                	sd	s1,8(sp)
    2396:	e04a                	sd	s2,0(sp)
    2398:	1000                	addi	s0,sp,32
    239a:	892a                	mv	s2,a0
  fd = open("init", O_RDONLY);
    239c:	4581                	li	a1,0
    239e:	00004517          	auipc	a0,0x4
    23a2:	5c250513          	addi	a0,a0,1474 # 6960 <malloc+0xf86>
    23a6:	136030ef          	jal	54dc <open>
  if (fd < 0) {
    23aa:	02054563          	bltz	a0,23d4 <argptest+0x46>
    23ae:	84aa                	mv	s1,a0
  read(fd, sbrk(0) - 1, -1);
    23b0:	4501                	li	a0,0
    23b2:	0b6030ef          	jal	5468 <sbrk>
    23b6:	567d                	li	a2,-1
    23b8:	00c505b3          	add	a1,a0,a2
    23bc:	8526                	mv	a0,s1
    23be:	0f6030ef          	jal	54b4 <read>
  close(fd);
    23c2:	8526                	mv	a0,s1
    23c4:	100030ef          	jal	54c4 <close>
}
    23c8:	60e2                	ld	ra,24(sp)
    23ca:	6442                	ld	s0,16(sp)
    23cc:	64a2                	ld	s1,8(sp)
    23ce:	6902                	ld	s2,0(sp)
    23d0:	6105                	addi	sp,sp,32
    23d2:	8082                	ret
    printf("%s: open failed\n", s);
    23d4:	85ca                	mv	a1,s2
    23d6:	00004517          	auipc	a0,0x4
    23da:	fda50513          	addi	a0,a0,-38 # 63b0 <malloc+0x9d6>
    23de:	544030ef          	jal	5922 <printf>
    exit(1);
    23e2:	4505                	li	a0,1
    23e4:	0b8030ef          	jal	549c <exit>

00000000000023e8 <sbrkbugs>:
{
    23e8:	1141                	addi	sp,sp,-16
    23ea:	e406                	sd	ra,8(sp)
    23ec:	e022                	sd	s0,0(sp)
    23ee:	0800                	addi	s0,sp,16
  int pid = fork();
    23f0:	0a4030ef          	jal	5494 <fork>
  if (pid < 0) {
    23f4:	00054c63          	bltz	a0,240c <sbrkbugs+0x24>
  if (pid == 0) {
    23f8:	e11d                	bnez	a0,241e <sbrkbugs+0x36>
    int sz = (uint64)sbrk(0);
    23fa:	06e030ef          	jal	5468 <sbrk>
    sbrk(-sz);
    23fe:	40a0053b          	negw	a0,a0
    2402:	066030ef          	jal	5468 <sbrk>
    exit(0);
    2406:	4501                	li	a0,0
    2408:	094030ef          	jal	549c <exit>
    printf("fork failed\n");
    240c:	00005517          	auipc	a0,0x5
    2410:	64c50513          	addi	a0,a0,1612 # 7a58 <malloc+0x207e>
    2414:	50e030ef          	jal	5922 <printf>
    exit(1);
    2418:	4505                	li	a0,1
    241a:	082030ef          	jal	549c <exit>
  wait(0);
    241e:	4501                	li	a0,0
    2420:	084030ef          	jal	54a4 <wait>
  pid = fork();
    2424:	070030ef          	jal	5494 <fork>
  if (pid < 0) {
    2428:	00054f63          	bltz	a0,2446 <sbrkbugs+0x5e>
  if (pid == 0) {
    242c:	e515                	bnez	a0,2458 <sbrkbugs+0x70>
    int sz = (uint64)sbrk(0);
    242e:	03a030ef          	jal	5468 <sbrk>
    sbrk(-(sz - 3500));
    2432:	6785                	lui	a5,0x1
    2434:	dac7879b          	addiw	a5,a5,-596 # dac <linktest+0xe2>
    2438:	40a7853b          	subw	a0,a5,a0
    243c:	02c030ef          	jal	5468 <sbrk>
    exit(0);
    2440:	4501                	li	a0,0
    2442:	05a030ef          	jal	549c <exit>
    printf("fork failed\n");
    2446:	00005517          	auipc	a0,0x5
    244a:	61250513          	addi	a0,a0,1554 # 7a58 <malloc+0x207e>
    244e:	4d4030ef          	jal	5922 <printf>
    exit(1);
    2452:	4505                	li	a0,1
    2454:	048030ef          	jal	549c <exit>
  wait(0);
    2458:	4501                	li	a0,0
    245a:	04a030ef          	jal	54a4 <wait>
  pid = fork();
    245e:	036030ef          	jal	5494 <fork>
  if (pid < 0) {
    2462:	02054263          	bltz	a0,2486 <sbrkbugs+0x9e>
  if (pid == 0) {
    2466:	e90d                	bnez	a0,2498 <sbrkbugs+0xb0>
    sbrk((10 * PGSIZE + 2048) - (uint64)sbrk(0));
    2468:	000030ef          	jal	5468 <sbrk>
    246c:	67ad                	lui	a5,0xb
    246e:	8007879b          	addiw	a5,a5,-2048 # a800 <big.0+0x230>
    2472:	40a7853b          	subw	a0,a5,a0
    2476:	7f3020ef          	jal	5468 <sbrk>
    sbrk(-10);
    247a:	5559                	li	a0,-10
    247c:	7ed020ef          	jal	5468 <sbrk>
    exit(0);
    2480:	4501                	li	a0,0
    2482:	01a030ef          	jal	549c <exit>
    printf("fork failed\n");
    2486:	00005517          	auipc	a0,0x5
    248a:	5d250513          	addi	a0,a0,1490 # 7a58 <malloc+0x207e>
    248e:	494030ef          	jal	5922 <printf>
    exit(1);
    2492:	4505                	li	a0,1
    2494:	008030ef          	jal	549c <exit>
  wait(0);
    2498:	4501                	li	a0,0
    249a:	00a030ef          	jal	54a4 <wait>
  exit(0);
    249e:	4501                	li	a0,0
    24a0:	7fd020ef          	jal	549c <exit>

00000000000024a4 <sbrklast>:
{
    24a4:	7179                	addi	sp,sp,-48
    24a6:	f406                	sd	ra,40(sp)
    24a8:	f022                	sd	s0,32(sp)
    24aa:	ec26                	sd	s1,24(sp)
    24ac:	e84a                	sd	s2,16(sp)
    24ae:	e44e                	sd	s3,8(sp)
    24b0:	e052                	sd	s4,0(sp)
    24b2:	1800                	addi	s0,sp,48
  uint64 top = (uint64)sbrk(0);
    24b4:	4501                	li	a0,0
    24b6:	7b3020ef          	jal	5468 <sbrk>
  if ((top % PGSIZE) != 0)
    24ba:	03451793          	slli	a5,a0,0x34
    24be:	ebad                	bnez	a5,2530 <sbrklast+0x8c>
  sbrk(PGSIZE);
    24c0:	6505                	lui	a0,0x1
    24c2:	7a7020ef          	jal	5468 <sbrk>
  sbrk(10);
    24c6:	4529                	li	a0,10
    24c8:	7a1020ef          	jal	5468 <sbrk>
  sbrk(-20);
    24cc:	5531                	li	a0,-20
    24ce:	79b020ef          	jal	5468 <sbrk>
  top = (uint64)sbrk(0);
    24d2:	4501                	li	a0,0
    24d4:	795020ef          	jal	5468 <sbrk>
    24d8:	84aa                	mv	s1,a0
  char *p = (char *)(top - 64);
    24da:	fc050913          	addi	s2,a0,-64 # fc0 <bigdir+0xcc>
  p[0] = 'x';
    24de:	07800993          	li	s3,120
    24e2:	fd350023          	sb	s3,-64(a0)
  p[1] = '\0';
    24e6:	fc0500a3          	sb	zero,-63(a0)
  int fd = open(p, O_RDWR | O_CREATE);
    24ea:	20200593          	li	a1,514
    24ee:	854a                	mv	a0,s2
    24f0:	7ed020ef          	jal	54dc <open>
    24f4:	8a2a                	mv	s4,a0
  write(fd, p, 1);
    24f6:	4605                	li	a2,1
    24f8:	85ca                	mv	a1,s2
    24fa:	7c3020ef          	jal	54bc <write>
  close(fd);
    24fe:	8552                	mv	a0,s4
    2500:	7c5020ef          	jal	54c4 <close>
  fd = open(p, O_RDWR);
    2504:	4589                	li	a1,2
    2506:	854a                	mv	a0,s2
    2508:	7d5020ef          	jal	54dc <open>
  p[0] = '\0';
    250c:	fc048023          	sb	zero,-64(s1)
  read(fd, p, 1);
    2510:	4605                	li	a2,1
    2512:	85ca                	mv	a1,s2
    2514:	7a1020ef          	jal	54b4 <read>
  if (p[0] != 'x')
    2518:	fc04c783          	lbu	a5,-64(s1)
    251c:	03379263          	bne	a5,s3,2540 <sbrklast+0x9c>
}
    2520:	70a2                	ld	ra,40(sp)
    2522:	7402                	ld	s0,32(sp)
    2524:	64e2                	ld	s1,24(sp)
    2526:	6942                	ld	s2,16(sp)
    2528:	69a2                	ld	s3,8(sp)
    252a:	6a02                	ld	s4,0(sp)
    252c:	6145                	addi	sp,sp,48
    252e:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    2530:	0347d513          	srli	a0,a5,0x34
    2534:	6785                	lui	a5,0x1
    2536:	40a7853b          	subw	a0,a5,a0
    253a:	72f020ef          	jal	5468 <sbrk>
    253e:	b749                	j	24c0 <sbrklast+0x1c>
    exit(1);
    2540:	4505                	li	a0,1
    2542:	75b020ef          	jal	549c <exit>

0000000000002546 <sbrk8000>:
{
    2546:	1141                	addi	sp,sp,-16
    2548:	e406                	sd	ra,8(sp)
    254a:	e022                	sd	s0,0(sp)
    254c:	0800                	addi	s0,sp,16
  sbrk(0x80000004);
    254e:	80000537          	lui	a0,0x80000
    2552:	0511                	addi	a0,a0,4 # ffffffff80000004 <base+0xffffffff7ffef31c>
    2554:	715020ef          	jal	5468 <sbrk>
  volatile char *top = sbrk(0);
    2558:	4501                	li	a0,0
    255a:	70f020ef          	jal	5468 <sbrk>
  *(top - 1) = *(top - 1) + 1;
    255e:	fff54783          	lbu	a5,-1(a0)
    2562:	0785                	addi	a5,a5,1 # 1001 <bigdir+0x10d>
    2564:	0ff7f793          	zext.b	a5,a5
    2568:	fef50fa3          	sb	a5,-1(a0)
}
    256c:	60a2                	ld	ra,8(sp)
    256e:	6402                	ld	s0,0(sp)
    2570:	0141                	addi	sp,sp,16
    2572:	8082                	ret

0000000000002574 <execout>:
{
    2574:	711d                	addi	sp,sp,-96
    2576:	ec86                	sd	ra,88(sp)
    2578:	e8a2                	sd	s0,80(sp)
    257a:	e4a6                	sd	s1,72(sp)
    257c:	e0ca                	sd	s2,64(sp)
    257e:	fc4e                	sd	s3,56(sp)
    2580:	1080                	addi	s0,sp,96
  for (int avail = 0; avail < 15; avail++) {
    2582:	4901                	li	s2,0
    2584:	49bd                	li	s3,15
    int pid = fork();
    2586:	70f020ef          	jal	5494 <fork>
    258a:	84aa                	mv	s1,a0
    if (pid < 0) {
    258c:	00054e63          	bltz	a0,25a8 <execout+0x34>
    } else if (pid == 0) {
    2590:	c51d                	beqz	a0,25be <execout+0x4a>
      wait((int *)0);
    2592:	4501                	li	a0,0
    2594:	711020ef          	jal	54a4 <wait>
  for (int avail = 0; avail < 15; avail++) {
    2598:	2905                	addiw	s2,s2,1
    259a:	ff3916e3          	bne	s2,s3,2586 <execout+0x12>
    259e:	f852                	sd	s4,48(sp)
    25a0:	f456                	sd	s5,40(sp)
  exit(0);
    25a2:	4501                	li	a0,0
    25a4:	6f9020ef          	jal	549c <exit>
    25a8:	f852                	sd	s4,48(sp)
    25aa:	f456                	sd	s5,40(sp)
      printf("fork failed\n");
    25ac:	00005517          	auipc	a0,0x5
    25b0:	4ac50513          	addi	a0,a0,1196 # 7a58 <malloc+0x207e>
    25b4:	36e030ef          	jal	5922 <printf>
      exit(1);
    25b8:	4505                	li	a0,1
    25ba:	6e3020ef          	jal	549c <exit>
    25be:	f852                	sd	s4,48(sp)
    25c0:	f456                	sd	s5,40(sp)
        char *a = sbrk(PGSIZE);
    25c2:	6985                	lui	s3,0x1
        if (a == SBRK_ERROR)
    25c4:	5a7d                	li	s4,-1
        *(a + PGSIZE - 1) = 1;
    25c6:	4a85                	li	s5,1
        char *a = sbrk(PGSIZE);
    25c8:	854e                	mv	a0,s3
    25ca:	69f020ef          	jal	5468 <sbrk>
        if (a == SBRK_ERROR)
    25ce:	01450663          	beq	a0,s4,25da <execout+0x66>
        *(a + PGSIZE - 1) = 1;
    25d2:	954e                	add	a0,a0,s3
    25d4:	ff550fa3          	sb	s5,-1(a0)
      while (1) {
    25d8:	bfc5                	j	25c8 <execout+0x54>
        sbrk(-PGSIZE);
    25da:	79fd                	lui	s3,0xfffff
      for (int i = 0; i < avail; i++)
    25dc:	01205863          	blez	s2,25ec <execout+0x78>
        sbrk(-PGSIZE);
    25e0:	854e                	mv	a0,s3
    25e2:	687020ef          	jal	5468 <sbrk>
      for (int i = 0; i < avail; i++)
    25e6:	2485                	addiw	s1,s1,1
    25e8:	ff249ce3          	bne	s1,s2,25e0 <execout+0x6c>
      close(1);
    25ec:	4505                	li	a0,1
    25ee:	6d7020ef          	jal	54c4 <close>
      char *args[] = {"echo", "x", 0};
    25f2:	00003797          	auipc	a5,0x3
    25f6:	51678793          	addi	a5,a5,1302 # 5b08 <malloc+0x12e>
    25fa:	faf43423          	sd	a5,-88(s0)
    25fe:	00003797          	auipc	a5,0x3
    2602:	57a78793          	addi	a5,a5,1402 # 5b78 <malloc+0x19e>
    2606:	faf43823          	sd	a5,-80(s0)
    260a:	fa043c23          	sd	zero,-72(s0)
      exec("echo", args);
    260e:	fa840593          	addi	a1,s0,-88
    2612:	00003517          	auipc	a0,0x3
    2616:	4f650513          	addi	a0,a0,1270 # 5b08 <malloc+0x12e>
    261a:	6bb020ef          	jal	54d4 <exec>
      exit(0);
    261e:	4501                	li	a0,0
    2620:	67d020ef          	jal	549c <exit>

0000000000002624 <fourteen>:
{
    2624:	1101                	addi	sp,sp,-32
    2626:	ec06                	sd	ra,24(sp)
    2628:	e822                	sd	s0,16(sp)
    262a:	e426                	sd	s1,8(sp)
    262c:	1000                	addi	s0,sp,32
    262e:	84aa                	mv	s1,a0
  if (mkdir("12345678901234") != 0) {
    2630:	00004517          	auipc	a0,0x4
    2634:	50850513          	addi	a0,a0,1288 # 6b38 <malloc+0x115e>
    2638:	6cd020ef          	jal	5504 <mkdir>
    263c:	e555                	bnez	a0,26e8 <fourteen+0xc4>
  if (mkdir("12345678901234/123456789012345") != 0) {
    263e:	00004517          	auipc	a0,0x4
    2642:	35250513          	addi	a0,a0,850 # 6990 <malloc+0xfb6>
    2646:	6bf020ef          	jal	5504 <mkdir>
    264a:	e94d                	bnez	a0,26fc <fourteen+0xd8>
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    264c:	20000593          	li	a1,512
    2650:	00004517          	auipc	a0,0x4
    2654:	39850513          	addi	a0,a0,920 # 69e8 <malloc+0x100e>
    2658:	685020ef          	jal	54dc <open>
  if (fd < 0) {
    265c:	0a054a63          	bltz	a0,2710 <fourteen+0xec>
  close(fd);
    2660:	665020ef          	jal	54c4 <close>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    2664:	4581                	li	a1,0
    2666:	00004517          	auipc	a0,0x4
    266a:	3fa50513          	addi	a0,a0,1018 # 6a60 <malloc+0x1086>
    266e:	66f020ef          	jal	54dc <open>
  if (fd < 0) {
    2672:	0a054963          	bltz	a0,2724 <fourteen+0x100>
  close(fd);
    2676:	64f020ef          	jal	54c4 <close>
  if (mkdir("12345678901234/12345678901234") == 0) {
    267a:	00004517          	auipc	a0,0x4
    267e:	45650513          	addi	a0,a0,1110 # 6ad0 <malloc+0x10f6>
    2682:	683020ef          	jal	5504 <mkdir>
    2686:	c94d                	beqz	a0,2738 <fourteen+0x114>
  if (mkdir("123456789012345/12345678901234") == 0) {
    2688:	00004517          	auipc	a0,0x4
    268c:	4a050513          	addi	a0,a0,1184 # 6b28 <malloc+0x114e>
    2690:	675020ef          	jal	5504 <mkdir>
    2694:	cd45                	beqz	a0,274c <fourteen+0x128>
  unlink("123456789012345/12345678901234");
    2696:	00004517          	auipc	a0,0x4
    269a:	49250513          	addi	a0,a0,1170 # 6b28 <malloc+0x114e>
    269e:	64f020ef          	jal	54ec <unlink>
  unlink("12345678901234/12345678901234");
    26a2:	00004517          	auipc	a0,0x4
    26a6:	42e50513          	addi	a0,a0,1070 # 6ad0 <malloc+0x10f6>
    26aa:	643020ef          	jal	54ec <unlink>
  unlink("12345678901234/12345678901234/12345678901234");
    26ae:	00004517          	auipc	a0,0x4
    26b2:	3b250513          	addi	a0,a0,946 # 6a60 <malloc+0x1086>
    26b6:	637020ef          	jal	54ec <unlink>
  unlink("123456789012345/123456789012345/123456789012345");
    26ba:	00004517          	auipc	a0,0x4
    26be:	32e50513          	addi	a0,a0,814 # 69e8 <malloc+0x100e>
    26c2:	62b020ef          	jal	54ec <unlink>
  unlink("12345678901234/123456789012345");
    26c6:	00004517          	auipc	a0,0x4
    26ca:	2ca50513          	addi	a0,a0,714 # 6990 <malloc+0xfb6>
    26ce:	61f020ef          	jal	54ec <unlink>
  unlink("12345678901234");
    26d2:	00004517          	auipc	a0,0x4
    26d6:	46650513          	addi	a0,a0,1126 # 6b38 <malloc+0x115e>
    26da:	613020ef          	jal	54ec <unlink>
}
    26de:	60e2                	ld	ra,24(sp)
    26e0:	6442                	ld	s0,16(sp)
    26e2:	64a2                	ld	s1,8(sp)
    26e4:	6105                	addi	sp,sp,32
    26e6:	8082                	ret
    printf("%s: mkdir 12345678901234 failed\n", s);
    26e8:	85a6                	mv	a1,s1
    26ea:	00004517          	auipc	a0,0x4
    26ee:	27e50513          	addi	a0,a0,638 # 6968 <malloc+0xf8e>
    26f2:	230030ef          	jal	5922 <printf>
    exit(1);
    26f6:	4505                	li	a0,1
    26f8:	5a5020ef          	jal	549c <exit>
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    26fc:	85a6                	mv	a1,s1
    26fe:	00004517          	auipc	a0,0x4
    2702:	2b250513          	addi	a0,a0,690 # 69b0 <malloc+0xfd6>
    2706:	21c030ef          	jal	5922 <printf>
    exit(1);
    270a:	4505                	li	a0,1
    270c:	591020ef          	jal	549c <exit>
    printf(
    2710:	85a6                	mv	a1,s1
    2712:	00004517          	auipc	a0,0x4
    2716:	30650513          	addi	a0,a0,774 # 6a18 <malloc+0x103e>
    271a:	208030ef          	jal	5922 <printf>
    exit(1);
    271e:	4505                	li	a0,1
    2720:	57d020ef          	jal	549c <exit>
    printf("%s: open 12345678901234/12345678901234/12345678901234 failed\n", s);
    2724:	85a6                	mv	a1,s1
    2726:	00004517          	auipc	a0,0x4
    272a:	36a50513          	addi	a0,a0,874 # 6a90 <malloc+0x10b6>
    272e:	1f4030ef          	jal	5922 <printf>
    exit(1);
    2732:	4505                	li	a0,1
    2734:	569020ef          	jal	549c <exit>
    printf("%s: mkdir 12345678901234/12345678901234 succeeded!\n", s);
    2738:	85a6                	mv	a1,s1
    273a:	00004517          	auipc	a0,0x4
    273e:	3b650513          	addi	a0,a0,950 # 6af0 <malloc+0x1116>
    2742:	1e0030ef          	jal	5922 <printf>
    exit(1);
    2746:	4505                	li	a0,1
    2748:	555020ef          	jal	549c <exit>
    printf("%s: mkdir 12345678901234/123456789012345 succeeded!\n", s);
    274c:	85a6                	mv	a1,s1
    274e:	00004517          	auipc	a0,0x4
    2752:	3fa50513          	addi	a0,a0,1018 # 6b48 <malloc+0x116e>
    2756:	1cc030ef          	jal	5922 <printf>
    exit(1);
    275a:	4505                	li	a0,1
    275c:	541020ef          	jal	549c <exit>

0000000000002760 <diskfull>:
{
    2760:	b6010113          	addi	sp,sp,-1184
    2764:	48113c23          	sd	ra,1176(sp)
    2768:	48813823          	sd	s0,1168(sp)
    276c:	48913423          	sd	s1,1160(sp)
    2770:	49213023          	sd	s2,1152(sp)
    2774:	47313c23          	sd	s3,1144(sp)
    2778:	47413823          	sd	s4,1136(sp)
    277c:	47513423          	sd	s5,1128(sp)
    2780:	47613023          	sd	s6,1120(sp)
    2784:	45713c23          	sd	s7,1112(sp)
    2788:	45813823          	sd	s8,1104(sp)
    278c:	45913423          	sd	s9,1096(sp)
    2790:	45a13023          	sd	s10,1088(sp)
    2794:	43b13c23          	sd	s11,1080(sp)
    2798:	4a010413          	addi	s0,sp,1184
    279c:	b6a43423          	sd	a0,-1176(s0)
  unlink("diskfulldir");
    27a0:	00004517          	auipc	a0,0x4
    27a4:	3e050513          	addi	a0,a0,992 # 6b80 <malloc+0x11a6>
    27a8:	545020ef          	jal	54ec <unlink>
    27ac:	03000a93          	li	s5,48
    name[0] = 'b';
    27b0:	06200d13          	li	s10,98
    name[1] = 'i';
    27b4:	06900c93          	li	s9,105
    name[2] = 'g';
    27b8:	06700c13          	li	s8,103
    unlink(name);
    27bc:	b7040b13          	addi	s6,s0,-1168
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    27c0:	60200b93          	li	s7,1538
    27c4:	10c00d93          	li	s11,268
      if (write(fd, buf, BSIZE) != BSIZE) {
    27c8:	b9040a13          	addi	s4,s0,-1136
    27cc:	aa8d                	j	293e <diskfull+0x1de>
      printf("%s: could not create file %s\n", s, name);
    27ce:	b7040613          	addi	a2,s0,-1168
    27d2:	b6843583          	ld	a1,-1176(s0)
    27d6:	00004517          	auipc	a0,0x4
    27da:	3ba50513          	addi	a0,a0,954 # 6b90 <malloc+0x11b6>
    27de:	144030ef          	jal	5922 <printf>
      break;
    27e2:	a039                	j	27f0 <diskfull+0x90>
        close(fd);
    27e4:	854e                	mv	a0,s3
    27e6:	4df020ef          	jal	54c4 <close>
    close(fd);
    27ea:	854e                	mv	a0,s3
    27ec:	4d9020ef          	jal	54c4 <close>
  for (int i = 0; i < nzz; i++) {
    27f0:	4481                	li	s1,0
    name[0] = 'z';
    27f2:	07a00993          	li	s3,122
    unlink(name);
    27f6:	b9040913          	addi	s2,s0,-1136
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    27fa:	60200a13          	li	s4,1538
  for (int i = 0; i < nzz; i++) {
    27fe:	08000a93          	li	s5,128
    name[0] = 'z';
    2802:	b9340823          	sb	s3,-1136(s0)
    name[1] = 'z';
    2806:	b93408a3          	sb	s3,-1135(s0)
    name[2] = '0' + (i / 32);
    280a:	41f4d71b          	sraiw	a4,s1,0x1f
    280e:	01b7571b          	srliw	a4,a4,0x1b
    2812:	009707bb          	addw	a5,a4,s1
    2816:	4057d69b          	sraiw	a3,a5,0x5
    281a:	0306869b          	addiw	a3,a3,48
    281e:	b8d40923          	sb	a3,-1134(s0)
    name[3] = '0' + (i % 32);
    2822:	8bfd                	andi	a5,a5,31
    2824:	9f99                	subw	a5,a5,a4
    2826:	0307879b          	addiw	a5,a5,48
    282a:	b8f409a3          	sb	a5,-1133(s0)
    name[4] = '\0';
    282e:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    2832:	854a                	mv	a0,s2
    2834:	4b9020ef          	jal	54ec <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    2838:	85d2                	mv	a1,s4
    283a:	854a                	mv	a0,s2
    283c:	4a1020ef          	jal	54dc <open>
    if (fd < 0)
    2840:	00054763          	bltz	a0,284e <diskfull+0xee>
    close(fd);
    2844:	481020ef          	jal	54c4 <close>
  for (int i = 0; i < nzz; i++) {
    2848:	2485                	addiw	s1,s1,1
    284a:	fb549ce3          	bne	s1,s5,2802 <diskfull+0xa2>
  if (mkdir("diskfulldir") == 0)
    284e:	00004517          	auipc	a0,0x4
    2852:	33250513          	addi	a0,a0,818 # 6b80 <malloc+0x11a6>
    2856:	4af020ef          	jal	5504 <mkdir>
    285a:	12050363          	beqz	a0,2980 <diskfull+0x220>
  unlink("diskfulldir");
    285e:	00004517          	auipc	a0,0x4
    2862:	32250513          	addi	a0,a0,802 # 6b80 <malloc+0x11a6>
    2866:	487020ef          	jal	54ec <unlink>
  for (int i = 0; i < nzz; i++) {
    286a:	4481                	li	s1,0
    name[0] = 'z';
    286c:	07a00913          	li	s2,122
    unlink(name);
    2870:	b9040a13          	addi	s4,s0,-1136
  for (int i = 0; i < nzz; i++) {
    2874:	08000993          	li	s3,128
    name[0] = 'z';
    2878:	b9240823          	sb	s2,-1136(s0)
    name[1] = 'z';
    287c:	b92408a3          	sb	s2,-1135(s0)
    name[2] = '0' + (i / 32);
    2880:	41f4d71b          	sraiw	a4,s1,0x1f
    2884:	01b7571b          	srliw	a4,a4,0x1b
    2888:	009707bb          	addw	a5,a4,s1
    288c:	4057d69b          	sraiw	a3,a5,0x5
    2890:	0306869b          	addiw	a3,a3,48
    2894:	b8d40923          	sb	a3,-1134(s0)
    name[3] = '0' + (i % 32);
    2898:	8bfd                	andi	a5,a5,31
    289a:	9f99                	subw	a5,a5,a4
    289c:	0307879b          	addiw	a5,a5,48
    28a0:	b8f409a3          	sb	a5,-1133(s0)
    name[4] = '\0';
    28a4:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    28a8:	8552                	mv	a0,s4
    28aa:	443020ef          	jal	54ec <unlink>
  for (int i = 0; i < nzz; i++) {
    28ae:	2485                	addiw	s1,s1,1
    28b0:	fd3494e3          	bne	s1,s3,2878 <diskfull+0x118>
    28b4:	03000493          	li	s1,48
    name[0] = 'b';
    28b8:	06200b13          	li	s6,98
    name[1] = 'i';
    28bc:	06900a93          	li	s5,105
    name[2] = 'g';
    28c0:	06700a13          	li	s4,103
    unlink(name);
    28c4:	b9040993          	addi	s3,s0,-1136
  for (int i = 0; '0' + i < 0177; i++) {
    28c8:	07f00913          	li	s2,127
    name[0] = 'b';
    28cc:	b9640823          	sb	s6,-1136(s0)
    name[1] = 'i';
    28d0:	b95408a3          	sb	s5,-1135(s0)
    name[2] = 'g';
    28d4:	b9440923          	sb	s4,-1134(s0)
    name[3] = '0' + i;
    28d8:	b89409a3          	sb	s1,-1133(s0)
    name[4] = '\0';
    28dc:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    28e0:	854e                	mv	a0,s3
    28e2:	40b020ef          	jal	54ec <unlink>
  for (int i = 0; '0' + i < 0177; i++) {
    28e6:	2485                	addiw	s1,s1,1
    28e8:	0ff4f493          	zext.b	s1,s1
    28ec:	ff2490e3          	bne	s1,s2,28cc <diskfull+0x16c>
}
    28f0:	49813083          	ld	ra,1176(sp)
    28f4:	49013403          	ld	s0,1168(sp)
    28f8:	48813483          	ld	s1,1160(sp)
    28fc:	48013903          	ld	s2,1152(sp)
    2900:	47813983          	ld	s3,1144(sp)
    2904:	47013a03          	ld	s4,1136(sp)
    2908:	46813a83          	ld	s5,1128(sp)
    290c:	46013b03          	ld	s6,1120(sp)
    2910:	45813b83          	ld	s7,1112(sp)
    2914:	45013c03          	ld	s8,1104(sp)
    2918:	44813c83          	ld	s9,1096(sp)
    291c:	44013d03          	ld	s10,1088(sp)
    2920:	43813d83          	ld	s11,1080(sp)
    2924:	4a010113          	addi	sp,sp,1184
    2928:	8082                	ret
    close(fd);
    292a:	854e                	mv	a0,s3
    292c:	399020ef          	jal	54c4 <close>
  for (fi = 0; done == 0 && '0' + fi < 0177; fi++) {
    2930:	2a85                	addiw	s5,s5,1 # 3001 <subdir+0x477>
    2932:	0ffafa93          	zext.b	s5,s5
    2936:	07f00793          	li	a5,127
    293a:	eafa8be3          	beq	s5,a5,27f0 <diskfull+0x90>
    name[0] = 'b';
    293e:	b7a40823          	sb	s10,-1168(s0)
    name[1] = 'i';
    2942:	b79408a3          	sb	s9,-1167(s0)
    name[2] = 'g';
    2946:	b7840923          	sb	s8,-1166(s0)
    name[3] = '0' + fi;
    294a:	b75409a3          	sb	s5,-1165(s0)
    name[4] = '\0';
    294e:	b6040a23          	sb	zero,-1164(s0)
    unlink(name);
    2952:	855a                	mv	a0,s6
    2954:	399020ef          	jal	54ec <unlink>
    int fd = open(name, O_CREATE | O_RDWR | O_TRUNC);
    2958:	85de                	mv	a1,s7
    295a:	855a                	mv	a0,s6
    295c:	381020ef          	jal	54dc <open>
    2960:	89aa                	mv	s3,a0
    if (fd < 0) {
    2962:	e60546e3          	bltz	a0,27ce <diskfull+0x6e>
    2966:	84ee                	mv	s1,s11
      if (write(fd, buf, BSIZE) != BSIZE) {
    2968:	40000913          	li	s2,1024
    296c:	864a                	mv	a2,s2
    296e:	85d2                	mv	a1,s4
    2970:	854e                	mv	a0,s3
    2972:	34b020ef          	jal	54bc <write>
    2976:	e72517e3          	bne	a0,s2,27e4 <diskfull+0x84>
    for (int i = 0; i < MAXFILE; i++) {
    297a:	34fd                	addiw	s1,s1,-1
    297c:	f8e5                	bnez	s1,296c <diskfull+0x20c>
    297e:	b775                	j	292a <diskfull+0x1ca>
    printf("%s: mkdir(diskfulldir) unexpectedly succeeded!\n", s);
    2980:	b6843583          	ld	a1,-1176(s0)
    2984:	00004517          	auipc	a0,0x4
    2988:	22c50513          	addi	a0,a0,556 # 6bb0 <malloc+0x11d6>
    298c:	797020ef          	jal	5922 <printf>
    2990:	b5f9                	j	285e <diskfull+0xfe>

0000000000002992 <iputtest>:
{
    2992:	1101                	addi	sp,sp,-32
    2994:	ec06                	sd	ra,24(sp)
    2996:	e822                	sd	s0,16(sp)
    2998:	e426                	sd	s1,8(sp)
    299a:	1000                	addi	s0,sp,32
    299c:	84aa                	mv	s1,a0
  if (mkdir("iputdir") < 0) {
    299e:	00004517          	auipc	a0,0x4
    29a2:	24250513          	addi	a0,a0,578 # 6be0 <malloc+0x1206>
    29a6:	35f020ef          	jal	5504 <mkdir>
    29aa:	02054f63          	bltz	a0,29e8 <iputtest+0x56>
  if (chdir("iputdir") < 0) {
    29ae:	00004517          	auipc	a0,0x4
    29b2:	23250513          	addi	a0,a0,562 # 6be0 <malloc+0x1206>
    29b6:	357020ef          	jal	550c <chdir>
    29ba:	04054163          	bltz	a0,29fc <iputtest+0x6a>
  if (unlink("../iputdir") < 0) {
    29be:	00004517          	auipc	a0,0x4
    29c2:	26250513          	addi	a0,a0,610 # 6c20 <malloc+0x1246>
    29c6:	327020ef          	jal	54ec <unlink>
    29ca:	04054363          	bltz	a0,2a10 <iputtest+0x7e>
  if (chdir("/") < 0) {
    29ce:	00004517          	auipc	a0,0x4
    29d2:	28250513          	addi	a0,a0,642 # 6c50 <malloc+0x1276>
    29d6:	337020ef          	jal	550c <chdir>
    29da:	04054563          	bltz	a0,2a24 <iputtest+0x92>
}
    29de:	60e2                	ld	ra,24(sp)
    29e0:	6442                	ld	s0,16(sp)
    29e2:	64a2                	ld	s1,8(sp)
    29e4:	6105                	addi	sp,sp,32
    29e6:	8082                	ret
    printf("%s: mkdir failed\n", s);
    29e8:	85a6                	mv	a1,s1
    29ea:	00004517          	auipc	a0,0x4
    29ee:	1fe50513          	addi	a0,a0,510 # 6be8 <malloc+0x120e>
    29f2:	731020ef          	jal	5922 <printf>
    exit(1);
    29f6:	4505                	li	a0,1
    29f8:	2a5020ef          	jal	549c <exit>
    printf("%s: chdir iputdir failed\n", s);
    29fc:	85a6                	mv	a1,s1
    29fe:	00004517          	auipc	a0,0x4
    2a02:	20250513          	addi	a0,a0,514 # 6c00 <malloc+0x1226>
    2a06:	71d020ef          	jal	5922 <printf>
    exit(1);
    2a0a:	4505                	li	a0,1
    2a0c:	291020ef          	jal	549c <exit>
    printf("%s: unlink ../iputdir failed\n", s);
    2a10:	85a6                	mv	a1,s1
    2a12:	00004517          	auipc	a0,0x4
    2a16:	21e50513          	addi	a0,a0,542 # 6c30 <malloc+0x1256>
    2a1a:	709020ef          	jal	5922 <printf>
    exit(1);
    2a1e:	4505                	li	a0,1
    2a20:	27d020ef          	jal	549c <exit>
    printf("%s: chdir / failed\n", s);
    2a24:	85a6                	mv	a1,s1
    2a26:	00004517          	auipc	a0,0x4
    2a2a:	23250513          	addi	a0,a0,562 # 6c58 <malloc+0x127e>
    2a2e:	6f5020ef          	jal	5922 <printf>
    exit(1);
    2a32:	4505                	li	a0,1
    2a34:	269020ef          	jal	549c <exit>

0000000000002a38 <exitiputtest>:
{
    2a38:	7179                	addi	sp,sp,-48
    2a3a:	f406                	sd	ra,40(sp)
    2a3c:	f022                	sd	s0,32(sp)
    2a3e:	ec26                	sd	s1,24(sp)
    2a40:	1800                	addi	s0,sp,48
    2a42:	84aa                	mv	s1,a0
  pid = fork();
    2a44:	251020ef          	jal	5494 <fork>
  if (pid < 0) {
    2a48:	02054e63          	bltz	a0,2a84 <exitiputtest+0x4c>
  if (pid == 0) {
    2a4c:	e541                	bnez	a0,2ad4 <exitiputtest+0x9c>
    if (mkdir("iputdir") < 0) {
    2a4e:	00004517          	auipc	a0,0x4
    2a52:	19250513          	addi	a0,a0,402 # 6be0 <malloc+0x1206>
    2a56:	2af020ef          	jal	5504 <mkdir>
    2a5a:	02054f63          	bltz	a0,2a98 <exitiputtest+0x60>
    if (chdir("iputdir") < 0) {
    2a5e:	00004517          	auipc	a0,0x4
    2a62:	18250513          	addi	a0,a0,386 # 6be0 <malloc+0x1206>
    2a66:	2a7020ef          	jal	550c <chdir>
    2a6a:	04054163          	bltz	a0,2aac <exitiputtest+0x74>
    if (unlink("../iputdir") < 0) {
    2a6e:	00004517          	auipc	a0,0x4
    2a72:	1b250513          	addi	a0,a0,434 # 6c20 <malloc+0x1246>
    2a76:	277020ef          	jal	54ec <unlink>
    2a7a:	04054363          	bltz	a0,2ac0 <exitiputtest+0x88>
    exit(0);
    2a7e:	4501                	li	a0,0
    2a80:	21d020ef          	jal	549c <exit>
    printf("%s: fork failed\n", s);
    2a84:	85a6                	mv	a1,s1
    2a86:	00004517          	auipc	a0,0x4
    2a8a:	91250513          	addi	a0,a0,-1774 # 6398 <malloc+0x9be>
    2a8e:	695020ef          	jal	5922 <printf>
    exit(1);
    2a92:	4505                	li	a0,1
    2a94:	209020ef          	jal	549c <exit>
      printf("%s: mkdir failed\n", s);
    2a98:	85a6                	mv	a1,s1
    2a9a:	00004517          	auipc	a0,0x4
    2a9e:	14e50513          	addi	a0,a0,334 # 6be8 <malloc+0x120e>
    2aa2:	681020ef          	jal	5922 <printf>
      exit(1);
    2aa6:	4505                	li	a0,1
    2aa8:	1f5020ef          	jal	549c <exit>
      printf("%s: child chdir failed\n", s);
    2aac:	85a6                	mv	a1,s1
    2aae:	00004517          	auipc	a0,0x4
    2ab2:	1c250513          	addi	a0,a0,450 # 6c70 <malloc+0x1296>
    2ab6:	66d020ef          	jal	5922 <printf>
      exit(1);
    2aba:	4505                	li	a0,1
    2abc:	1e1020ef          	jal	549c <exit>
      printf("%s: unlink ../iputdir failed\n", s);
    2ac0:	85a6                	mv	a1,s1
    2ac2:	00004517          	auipc	a0,0x4
    2ac6:	16e50513          	addi	a0,a0,366 # 6c30 <malloc+0x1256>
    2aca:	659020ef          	jal	5922 <printf>
      exit(1);
    2ace:	4505                	li	a0,1
    2ad0:	1cd020ef          	jal	549c <exit>
  wait(&xstatus);
    2ad4:	fdc40513          	addi	a0,s0,-36
    2ad8:	1cd020ef          	jal	54a4 <wait>
  exit(xstatus);
    2adc:	fdc42503          	lw	a0,-36(s0)
    2ae0:	1bd020ef          	jal	549c <exit>

0000000000002ae4 <dirtest>:
{
    2ae4:	1101                	addi	sp,sp,-32
    2ae6:	ec06                	sd	ra,24(sp)
    2ae8:	e822                	sd	s0,16(sp)
    2aea:	e426                	sd	s1,8(sp)
    2aec:	1000                	addi	s0,sp,32
    2aee:	84aa                	mv	s1,a0
  if (mkdir("dir0") < 0) {
    2af0:	00004517          	auipc	a0,0x4
    2af4:	19850513          	addi	a0,a0,408 # 6c88 <malloc+0x12ae>
    2af8:	20d020ef          	jal	5504 <mkdir>
    2afc:	02054f63          	bltz	a0,2b3a <dirtest+0x56>
  if (chdir("dir0") < 0) {
    2b00:	00004517          	auipc	a0,0x4
    2b04:	18850513          	addi	a0,a0,392 # 6c88 <malloc+0x12ae>
    2b08:	205020ef          	jal	550c <chdir>
    2b0c:	04054163          	bltz	a0,2b4e <dirtest+0x6a>
  if (chdir("..") < 0) {
    2b10:	00004517          	auipc	a0,0x4
    2b14:	19850513          	addi	a0,a0,408 # 6ca8 <malloc+0x12ce>
    2b18:	1f5020ef          	jal	550c <chdir>
    2b1c:	04054363          	bltz	a0,2b62 <dirtest+0x7e>
  if (unlink("dir0") < 0) {
    2b20:	00004517          	auipc	a0,0x4
    2b24:	16850513          	addi	a0,a0,360 # 6c88 <malloc+0x12ae>
    2b28:	1c5020ef          	jal	54ec <unlink>
    2b2c:	04054563          	bltz	a0,2b76 <dirtest+0x92>
}
    2b30:	60e2                	ld	ra,24(sp)
    2b32:	6442                	ld	s0,16(sp)
    2b34:	64a2                	ld	s1,8(sp)
    2b36:	6105                	addi	sp,sp,32
    2b38:	8082                	ret
    printf("%s: mkdir failed\n", s);
    2b3a:	85a6                	mv	a1,s1
    2b3c:	00004517          	auipc	a0,0x4
    2b40:	0ac50513          	addi	a0,a0,172 # 6be8 <malloc+0x120e>
    2b44:	5df020ef          	jal	5922 <printf>
    exit(1);
    2b48:	4505                	li	a0,1
    2b4a:	153020ef          	jal	549c <exit>
    printf("%s: chdir dir0 failed\n", s);
    2b4e:	85a6                	mv	a1,s1
    2b50:	00004517          	auipc	a0,0x4
    2b54:	14050513          	addi	a0,a0,320 # 6c90 <malloc+0x12b6>
    2b58:	5cb020ef          	jal	5922 <printf>
    exit(1);
    2b5c:	4505                	li	a0,1
    2b5e:	13f020ef          	jal	549c <exit>
    printf("%s: chdir .. failed\n", s);
    2b62:	85a6                	mv	a1,s1
    2b64:	00004517          	auipc	a0,0x4
    2b68:	14c50513          	addi	a0,a0,332 # 6cb0 <malloc+0x12d6>
    2b6c:	5b7020ef          	jal	5922 <printf>
    exit(1);
    2b70:	4505                	li	a0,1
    2b72:	12b020ef          	jal	549c <exit>
    printf("%s: unlink dir0 failed\n", s);
    2b76:	85a6                	mv	a1,s1
    2b78:	00004517          	auipc	a0,0x4
    2b7c:	15050513          	addi	a0,a0,336 # 6cc8 <malloc+0x12ee>
    2b80:	5a3020ef          	jal	5922 <printf>
    exit(1);
    2b84:	4505                	li	a0,1
    2b86:	117020ef          	jal	549c <exit>

0000000000002b8a <subdir>:
{
    2b8a:	1101                	addi	sp,sp,-32
    2b8c:	ec06                	sd	ra,24(sp)
    2b8e:	e822                	sd	s0,16(sp)
    2b90:	e426                	sd	s1,8(sp)
    2b92:	e04a                	sd	s2,0(sp)
    2b94:	1000                	addi	s0,sp,32
    2b96:	892a                	mv	s2,a0
  unlink("ff");
    2b98:	00004517          	auipc	a0,0x4
    2b9c:	27850513          	addi	a0,a0,632 # 6e10 <malloc+0x1436>
    2ba0:	14d020ef          	jal	54ec <unlink>
  if (mkdir("dd") != 0) {
    2ba4:	00004517          	auipc	a0,0x4
    2ba8:	13c50513          	addi	a0,a0,316 # 6ce0 <malloc+0x1306>
    2bac:	159020ef          	jal	5504 <mkdir>
    2bb0:	2e051263          	bnez	a0,2e94 <subdir+0x30a>
  fd = open("dd/ff", O_CREATE | O_RDWR);
    2bb4:	20200593          	li	a1,514
    2bb8:	00004517          	auipc	a0,0x4
    2bbc:	14850513          	addi	a0,a0,328 # 6d00 <malloc+0x1326>
    2bc0:	11d020ef          	jal	54dc <open>
    2bc4:	84aa                	mv	s1,a0
  if (fd < 0) {
    2bc6:	2e054163          	bltz	a0,2ea8 <subdir+0x31e>
  write(fd, "ff", 2);
    2bca:	4609                	li	a2,2
    2bcc:	00004597          	auipc	a1,0x4
    2bd0:	24458593          	addi	a1,a1,580 # 6e10 <malloc+0x1436>
    2bd4:	0e9020ef          	jal	54bc <write>
  close(fd);
    2bd8:	8526                	mv	a0,s1
    2bda:	0eb020ef          	jal	54c4 <close>
  if (unlink("dd") >= 0) {
    2bde:	00004517          	auipc	a0,0x4
    2be2:	10250513          	addi	a0,a0,258 # 6ce0 <malloc+0x1306>
    2be6:	107020ef          	jal	54ec <unlink>
    2bea:	2c055963          	bgez	a0,2ebc <subdir+0x332>
  if (mkdir("/dd/dd") != 0) {
    2bee:	00004517          	auipc	a0,0x4
    2bf2:	16a50513          	addi	a0,a0,362 # 6d58 <malloc+0x137e>
    2bf6:	10f020ef          	jal	5504 <mkdir>
    2bfa:	2c051b63          	bnez	a0,2ed0 <subdir+0x346>
  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    2bfe:	20200593          	li	a1,514
    2c02:	00004517          	auipc	a0,0x4
    2c06:	17e50513          	addi	a0,a0,382 # 6d80 <malloc+0x13a6>
    2c0a:	0d3020ef          	jal	54dc <open>
    2c0e:	84aa                	mv	s1,a0
  if (fd < 0) {
    2c10:	2c054a63          	bltz	a0,2ee4 <subdir+0x35a>
  write(fd, "FF", 2);
    2c14:	4609                	li	a2,2
    2c16:	00004597          	auipc	a1,0x4
    2c1a:	19a58593          	addi	a1,a1,410 # 6db0 <malloc+0x13d6>
    2c1e:	09f020ef          	jal	54bc <write>
  close(fd);
    2c22:	8526                	mv	a0,s1
    2c24:	0a1020ef          	jal	54c4 <close>
  fd = open("dd/dd/../ff", 0);
    2c28:	4581                	li	a1,0
    2c2a:	00004517          	auipc	a0,0x4
    2c2e:	18e50513          	addi	a0,a0,398 # 6db8 <malloc+0x13de>
    2c32:	0ab020ef          	jal	54dc <open>
    2c36:	84aa                	mv	s1,a0
  if (fd < 0) {
    2c38:	2c054063          	bltz	a0,2ef8 <subdir+0x36e>
  cc = read(fd, buf, sizeof(buf));
    2c3c:	660d                	lui	a2,0x3
    2c3e:	0000b597          	auipc	a1,0xb
    2c42:	0aa58593          	addi	a1,a1,170 # dce8 <buf>
    2c46:	06f020ef          	jal	54b4 <read>
  if (cc != 2 || buf[0] != 'f') {
    2c4a:	4789                	li	a5,2
    2c4c:	2cf51063          	bne	a0,a5,2f0c <subdir+0x382>
    2c50:	0000b717          	auipc	a4,0xb
    2c54:	09874703          	lbu	a4,152(a4) # dce8 <buf>
    2c58:	06600793          	li	a5,102
    2c5c:	2af71863          	bne	a4,a5,2f0c <subdir+0x382>
  close(fd);
    2c60:	8526                	mv	a0,s1
    2c62:	063020ef          	jal	54c4 <close>
  if (link("dd/dd/ff", "dd/dd/ffff") != 0) {
    2c66:	00004597          	auipc	a1,0x4
    2c6a:	1a258593          	addi	a1,a1,418 # 6e08 <malloc+0x142e>
    2c6e:	00004517          	auipc	a0,0x4
    2c72:	11250513          	addi	a0,a0,274 # 6d80 <malloc+0x13a6>
    2c76:	087020ef          	jal	54fc <link>
    2c7a:	2a051363          	bnez	a0,2f20 <subdir+0x396>
  if (unlink("dd/dd/ff") != 0) {
    2c7e:	00004517          	auipc	a0,0x4
    2c82:	10250513          	addi	a0,a0,258 # 6d80 <malloc+0x13a6>
    2c86:	067020ef          	jal	54ec <unlink>
    2c8a:	2a051563          	bnez	a0,2f34 <subdir+0x3aa>
  if (open("dd/dd/ff", O_RDONLY) >= 0) {
    2c8e:	4581                	li	a1,0
    2c90:	00004517          	auipc	a0,0x4
    2c94:	0f050513          	addi	a0,a0,240 # 6d80 <malloc+0x13a6>
    2c98:	045020ef          	jal	54dc <open>
    2c9c:	2a055663          	bgez	a0,2f48 <subdir+0x3be>
  if (chdir("dd") != 0) {
    2ca0:	00004517          	auipc	a0,0x4
    2ca4:	04050513          	addi	a0,a0,64 # 6ce0 <malloc+0x1306>
    2ca8:	065020ef          	jal	550c <chdir>
    2cac:	2a051863          	bnez	a0,2f5c <subdir+0x3d2>
  if (chdir("dd/../../dd") != 0) {
    2cb0:	00004517          	auipc	a0,0x4
    2cb4:	1f050513          	addi	a0,a0,496 # 6ea0 <malloc+0x14c6>
    2cb8:	055020ef          	jal	550c <chdir>
    2cbc:	2a051a63          	bnez	a0,2f70 <subdir+0x3e6>
  if (chdir("dd/../../../dd") != 0) {
    2cc0:	00004517          	auipc	a0,0x4
    2cc4:	21050513          	addi	a0,a0,528 # 6ed0 <malloc+0x14f6>
    2cc8:	045020ef          	jal	550c <chdir>
    2ccc:	2a051c63          	bnez	a0,2f84 <subdir+0x3fa>
  if (chdir("./..") != 0) {
    2cd0:	00004517          	auipc	a0,0x4
    2cd4:	23850513          	addi	a0,a0,568 # 6f08 <malloc+0x152e>
    2cd8:	035020ef          	jal	550c <chdir>
    2cdc:	2a051e63          	bnez	a0,2f98 <subdir+0x40e>
  fd = open("dd/dd/ffff", 0);
    2ce0:	4581                	li	a1,0
    2ce2:	00004517          	auipc	a0,0x4
    2ce6:	12650513          	addi	a0,a0,294 # 6e08 <malloc+0x142e>
    2cea:	7f2020ef          	jal	54dc <open>
    2cee:	84aa                	mv	s1,a0
  if (fd < 0) {
    2cf0:	2a054e63          	bltz	a0,2fac <subdir+0x422>
  if (read(fd, buf, sizeof(buf)) != 2) {
    2cf4:	660d                	lui	a2,0x3
    2cf6:	0000b597          	auipc	a1,0xb
    2cfa:	ff258593          	addi	a1,a1,-14 # dce8 <buf>
    2cfe:	7b6020ef          	jal	54b4 <read>
    2d02:	4789                	li	a5,2
    2d04:	2af51e63          	bne	a0,a5,2fc0 <subdir+0x436>
  close(fd);
    2d08:	8526                	mv	a0,s1
    2d0a:	7ba020ef          	jal	54c4 <close>
  if (open("dd/dd/ff", O_RDONLY) >= 0) {
    2d0e:	4581                	li	a1,0
    2d10:	00004517          	auipc	a0,0x4
    2d14:	07050513          	addi	a0,a0,112 # 6d80 <malloc+0x13a6>
    2d18:	7c4020ef          	jal	54dc <open>
    2d1c:	2a055c63          	bgez	a0,2fd4 <subdir+0x44a>
  if (open("dd/ff/ff", O_CREATE | O_RDWR) >= 0) {
    2d20:	20200593          	li	a1,514
    2d24:	00004517          	auipc	a0,0x4
    2d28:	27450513          	addi	a0,a0,628 # 6f98 <malloc+0x15be>
    2d2c:	7b0020ef          	jal	54dc <open>
    2d30:	2a055c63          	bgez	a0,2fe8 <subdir+0x45e>
  if (open("dd/xx/ff", O_CREATE | O_RDWR) >= 0) {
    2d34:	20200593          	li	a1,514
    2d38:	00004517          	auipc	a0,0x4
    2d3c:	29050513          	addi	a0,a0,656 # 6fc8 <malloc+0x15ee>
    2d40:	79c020ef          	jal	54dc <open>
    2d44:	2a055c63          	bgez	a0,2ffc <subdir+0x472>
  if (open("dd", O_CREATE) >= 0) {
    2d48:	20000593          	li	a1,512
    2d4c:	00004517          	auipc	a0,0x4
    2d50:	f9450513          	addi	a0,a0,-108 # 6ce0 <malloc+0x1306>
    2d54:	788020ef          	jal	54dc <open>
    2d58:	2a055c63          	bgez	a0,3010 <subdir+0x486>
  if (open("dd", O_RDWR) >= 0) {
    2d5c:	4589                	li	a1,2
    2d5e:	00004517          	auipc	a0,0x4
    2d62:	f8250513          	addi	a0,a0,-126 # 6ce0 <malloc+0x1306>
    2d66:	776020ef          	jal	54dc <open>
    2d6a:	2a055d63          	bgez	a0,3024 <subdir+0x49a>
  if (open("dd", O_WRONLY) >= 0) {
    2d6e:	4585                	li	a1,1
    2d70:	00004517          	auipc	a0,0x4
    2d74:	f7050513          	addi	a0,a0,-144 # 6ce0 <malloc+0x1306>
    2d78:	764020ef          	jal	54dc <open>
    2d7c:	2a055e63          	bgez	a0,3038 <subdir+0x4ae>
  if (link("dd/ff/ff", "dd/dd/xx") == 0) {
    2d80:	00004597          	auipc	a1,0x4
    2d84:	2d858593          	addi	a1,a1,728 # 7058 <malloc+0x167e>
    2d88:	00004517          	auipc	a0,0x4
    2d8c:	21050513          	addi	a0,a0,528 # 6f98 <malloc+0x15be>
    2d90:	76c020ef          	jal	54fc <link>
    2d94:	2a050c63          	beqz	a0,304c <subdir+0x4c2>
  if (link("dd/xx/ff", "dd/dd/xx") == 0) {
    2d98:	00004597          	auipc	a1,0x4
    2d9c:	2c058593          	addi	a1,a1,704 # 7058 <malloc+0x167e>
    2da0:	00004517          	auipc	a0,0x4
    2da4:	22850513          	addi	a0,a0,552 # 6fc8 <malloc+0x15ee>
    2da8:	754020ef          	jal	54fc <link>
    2dac:	2a050a63          	beqz	a0,3060 <subdir+0x4d6>
  if (link("dd/ff", "dd/dd/ffff") == 0) {
    2db0:	00004597          	auipc	a1,0x4
    2db4:	05858593          	addi	a1,a1,88 # 6e08 <malloc+0x142e>
    2db8:	00004517          	auipc	a0,0x4
    2dbc:	f4850513          	addi	a0,a0,-184 # 6d00 <malloc+0x1326>
    2dc0:	73c020ef          	jal	54fc <link>
    2dc4:	2a050863          	beqz	a0,3074 <subdir+0x4ea>
  if (mkdir("dd/ff/ff") == 0) {
    2dc8:	00004517          	auipc	a0,0x4
    2dcc:	1d050513          	addi	a0,a0,464 # 6f98 <malloc+0x15be>
    2dd0:	734020ef          	jal	5504 <mkdir>
    2dd4:	2a050a63          	beqz	a0,3088 <subdir+0x4fe>
  if (mkdir("dd/xx/ff") == 0) {
    2dd8:	00004517          	auipc	a0,0x4
    2ddc:	1f050513          	addi	a0,a0,496 # 6fc8 <malloc+0x15ee>
    2de0:	724020ef          	jal	5504 <mkdir>
    2de4:	2a050c63          	beqz	a0,309c <subdir+0x512>
  if (mkdir("dd/dd/ffff") == 0) {
    2de8:	00004517          	auipc	a0,0x4
    2dec:	02050513          	addi	a0,a0,32 # 6e08 <malloc+0x142e>
    2df0:	714020ef          	jal	5504 <mkdir>
    2df4:	2a050e63          	beqz	a0,30b0 <subdir+0x526>
  if (unlink("dd/xx/ff") == 0) {
    2df8:	00004517          	auipc	a0,0x4
    2dfc:	1d050513          	addi	a0,a0,464 # 6fc8 <malloc+0x15ee>
    2e00:	6ec020ef          	jal	54ec <unlink>
    2e04:	2c050063          	beqz	a0,30c4 <subdir+0x53a>
  if (unlink("dd/ff/ff") == 0) {
    2e08:	00004517          	auipc	a0,0x4
    2e0c:	19050513          	addi	a0,a0,400 # 6f98 <malloc+0x15be>
    2e10:	6dc020ef          	jal	54ec <unlink>
    2e14:	2c050263          	beqz	a0,30d8 <subdir+0x54e>
  if (chdir("dd/ff") == 0) {
    2e18:	00004517          	auipc	a0,0x4
    2e1c:	ee850513          	addi	a0,a0,-280 # 6d00 <malloc+0x1326>
    2e20:	6ec020ef          	jal	550c <chdir>
    2e24:	2c050463          	beqz	a0,30ec <subdir+0x562>
  if (chdir("dd/xx") == 0) {
    2e28:	00004517          	auipc	a0,0x4
    2e2c:	38050513          	addi	a0,a0,896 # 71a8 <malloc+0x17ce>
    2e30:	6dc020ef          	jal	550c <chdir>
    2e34:	2c050663          	beqz	a0,3100 <subdir+0x576>
  if (unlink("dd/dd/ffff") != 0) {
    2e38:	00004517          	auipc	a0,0x4
    2e3c:	fd050513          	addi	a0,a0,-48 # 6e08 <malloc+0x142e>
    2e40:	6ac020ef          	jal	54ec <unlink>
    2e44:	2c051863          	bnez	a0,3114 <subdir+0x58a>
  if (unlink("dd/ff") != 0) {
    2e48:	00004517          	auipc	a0,0x4
    2e4c:	eb850513          	addi	a0,a0,-328 # 6d00 <malloc+0x1326>
    2e50:	69c020ef          	jal	54ec <unlink>
    2e54:	2c051a63          	bnez	a0,3128 <subdir+0x59e>
  if (unlink("dd") == 0) {
    2e58:	00004517          	auipc	a0,0x4
    2e5c:	e8850513          	addi	a0,a0,-376 # 6ce0 <malloc+0x1306>
    2e60:	68c020ef          	jal	54ec <unlink>
    2e64:	2c050c63          	beqz	a0,313c <subdir+0x5b2>
  if (unlink("dd/dd") < 0) {
    2e68:	00004517          	auipc	a0,0x4
    2e6c:	3b050513          	addi	a0,a0,944 # 7218 <malloc+0x183e>
    2e70:	67c020ef          	jal	54ec <unlink>
    2e74:	2c054e63          	bltz	a0,3150 <subdir+0x5c6>
  if (unlink("dd") < 0) {
    2e78:	00004517          	auipc	a0,0x4
    2e7c:	e6850513          	addi	a0,a0,-408 # 6ce0 <malloc+0x1306>
    2e80:	66c020ef          	jal	54ec <unlink>
    2e84:	2e054063          	bltz	a0,3164 <subdir+0x5da>
}
    2e88:	60e2                	ld	ra,24(sp)
    2e8a:	6442                	ld	s0,16(sp)
    2e8c:	64a2                	ld	s1,8(sp)
    2e8e:	6902                	ld	s2,0(sp)
    2e90:	6105                	addi	sp,sp,32
    2e92:	8082                	ret
    printf("%s: mkdir dd failed\n", s);
    2e94:	85ca                	mv	a1,s2
    2e96:	00004517          	auipc	a0,0x4
    2e9a:	e5250513          	addi	a0,a0,-430 # 6ce8 <malloc+0x130e>
    2e9e:	285020ef          	jal	5922 <printf>
    exit(1);
    2ea2:	4505                	li	a0,1
    2ea4:	5f8020ef          	jal	549c <exit>
    printf("%s: create dd/ff failed\n", s);
    2ea8:	85ca                	mv	a1,s2
    2eaa:	00004517          	auipc	a0,0x4
    2eae:	e5e50513          	addi	a0,a0,-418 # 6d08 <malloc+0x132e>
    2eb2:	271020ef          	jal	5922 <printf>
    exit(1);
    2eb6:	4505                	li	a0,1
    2eb8:	5e4020ef          	jal	549c <exit>
    printf("%s: unlink dd (non-empty dir) succeeded!\n", s);
    2ebc:	85ca                	mv	a1,s2
    2ebe:	00004517          	auipc	a0,0x4
    2ec2:	e6a50513          	addi	a0,a0,-406 # 6d28 <malloc+0x134e>
    2ec6:	25d020ef          	jal	5922 <printf>
    exit(1);
    2eca:	4505                	li	a0,1
    2ecc:	5d0020ef          	jal	549c <exit>
    printf("%s: subdir mkdir dd/dd failed\n", s);
    2ed0:	85ca                	mv	a1,s2
    2ed2:	00004517          	auipc	a0,0x4
    2ed6:	e8e50513          	addi	a0,a0,-370 # 6d60 <malloc+0x1386>
    2eda:	249020ef          	jal	5922 <printf>
    exit(1);
    2ede:	4505                	li	a0,1
    2ee0:	5bc020ef          	jal	549c <exit>
    printf("%s: create dd/dd/ff failed\n", s);
    2ee4:	85ca                	mv	a1,s2
    2ee6:	00004517          	auipc	a0,0x4
    2eea:	eaa50513          	addi	a0,a0,-342 # 6d90 <malloc+0x13b6>
    2eee:	235020ef          	jal	5922 <printf>
    exit(1);
    2ef2:	4505                	li	a0,1
    2ef4:	5a8020ef          	jal	549c <exit>
    printf("%s: open dd/dd/../ff failed\n", s);
    2ef8:	85ca                	mv	a1,s2
    2efa:	00004517          	auipc	a0,0x4
    2efe:	ece50513          	addi	a0,a0,-306 # 6dc8 <malloc+0x13ee>
    2f02:	221020ef          	jal	5922 <printf>
    exit(1);
    2f06:	4505                	li	a0,1
    2f08:	594020ef          	jal	549c <exit>
    printf("%s: dd/dd/../ff wrong content\n", s);
    2f0c:	85ca                	mv	a1,s2
    2f0e:	00004517          	auipc	a0,0x4
    2f12:	eda50513          	addi	a0,a0,-294 # 6de8 <malloc+0x140e>
    2f16:	20d020ef          	jal	5922 <printf>
    exit(1);
    2f1a:	4505                	li	a0,1
    2f1c:	580020ef          	jal	549c <exit>
    printf("%s: link dd/dd/ff dd/dd/ffff failed\n", s);
    2f20:	85ca                	mv	a1,s2
    2f22:	00004517          	auipc	a0,0x4
    2f26:	ef650513          	addi	a0,a0,-266 # 6e18 <malloc+0x143e>
    2f2a:	1f9020ef          	jal	5922 <printf>
    exit(1);
    2f2e:	4505                	li	a0,1
    2f30:	56c020ef          	jal	549c <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    2f34:	85ca                	mv	a1,s2
    2f36:	00004517          	auipc	a0,0x4
    2f3a:	f0a50513          	addi	a0,a0,-246 # 6e40 <malloc+0x1466>
    2f3e:	1e5020ef          	jal	5922 <printf>
    exit(1);
    2f42:	4505                	li	a0,1
    2f44:	558020ef          	jal	549c <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded\n", s);
    2f48:	85ca                	mv	a1,s2
    2f4a:	00004517          	auipc	a0,0x4
    2f4e:	f1650513          	addi	a0,a0,-234 # 6e60 <malloc+0x1486>
    2f52:	1d1020ef          	jal	5922 <printf>
    exit(1);
    2f56:	4505                	li	a0,1
    2f58:	544020ef          	jal	549c <exit>
    printf("%s: chdir dd failed\n", s);
    2f5c:	85ca                	mv	a1,s2
    2f5e:	00004517          	auipc	a0,0x4
    2f62:	f2a50513          	addi	a0,a0,-214 # 6e88 <malloc+0x14ae>
    2f66:	1bd020ef          	jal	5922 <printf>
    exit(1);
    2f6a:	4505                	li	a0,1
    2f6c:	530020ef          	jal	549c <exit>
    printf("%s: chdir dd/../../dd failed\n", s);
    2f70:	85ca                	mv	a1,s2
    2f72:	00004517          	auipc	a0,0x4
    2f76:	f3e50513          	addi	a0,a0,-194 # 6eb0 <malloc+0x14d6>
    2f7a:	1a9020ef          	jal	5922 <printf>
    exit(1);
    2f7e:	4505                	li	a0,1
    2f80:	51c020ef          	jal	549c <exit>
    printf("%s: chdir dd/../../../dd failed\n", s);
    2f84:	85ca                	mv	a1,s2
    2f86:	00004517          	auipc	a0,0x4
    2f8a:	f5a50513          	addi	a0,a0,-166 # 6ee0 <malloc+0x1506>
    2f8e:	195020ef          	jal	5922 <printf>
    exit(1);
    2f92:	4505                	li	a0,1
    2f94:	508020ef          	jal	549c <exit>
    printf("%s: chdir ./.. failed\n", s);
    2f98:	85ca                	mv	a1,s2
    2f9a:	00004517          	auipc	a0,0x4
    2f9e:	f7650513          	addi	a0,a0,-138 # 6f10 <malloc+0x1536>
    2fa2:	181020ef          	jal	5922 <printf>
    exit(1);
    2fa6:	4505                	li	a0,1
    2fa8:	4f4020ef          	jal	549c <exit>
    printf("%s: open dd/dd/ffff failed\n", s);
    2fac:	85ca                	mv	a1,s2
    2fae:	00004517          	auipc	a0,0x4
    2fb2:	f7a50513          	addi	a0,a0,-134 # 6f28 <malloc+0x154e>
    2fb6:	16d020ef          	jal	5922 <printf>
    exit(1);
    2fba:	4505                	li	a0,1
    2fbc:	4e0020ef          	jal	549c <exit>
    printf("%s: read dd/dd/ffff wrong len\n", s);
    2fc0:	85ca                	mv	a1,s2
    2fc2:	00004517          	auipc	a0,0x4
    2fc6:	f8650513          	addi	a0,a0,-122 # 6f48 <malloc+0x156e>
    2fca:	159020ef          	jal	5922 <printf>
    exit(1);
    2fce:	4505                	li	a0,1
    2fd0:	4cc020ef          	jal	549c <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded!\n", s);
    2fd4:	85ca                	mv	a1,s2
    2fd6:	00004517          	auipc	a0,0x4
    2fda:	f9250513          	addi	a0,a0,-110 # 6f68 <malloc+0x158e>
    2fde:	145020ef          	jal	5922 <printf>
    exit(1);
    2fe2:	4505                	li	a0,1
    2fe4:	4b8020ef          	jal	549c <exit>
    printf("%s: create dd/ff/ff succeeded!\n", s);
    2fe8:	85ca                	mv	a1,s2
    2fea:	00004517          	auipc	a0,0x4
    2fee:	fbe50513          	addi	a0,a0,-66 # 6fa8 <malloc+0x15ce>
    2ff2:	131020ef          	jal	5922 <printf>
    exit(1);
    2ff6:	4505                	li	a0,1
    2ff8:	4a4020ef          	jal	549c <exit>
    printf("%s: create dd/xx/ff succeeded!\n", s);
    2ffc:	85ca                	mv	a1,s2
    2ffe:	00004517          	auipc	a0,0x4
    3002:	fda50513          	addi	a0,a0,-38 # 6fd8 <malloc+0x15fe>
    3006:	11d020ef          	jal	5922 <printf>
    exit(1);
    300a:	4505                	li	a0,1
    300c:	490020ef          	jal	549c <exit>
    printf("%s: create dd succeeded!\n", s);
    3010:	85ca                	mv	a1,s2
    3012:	00004517          	auipc	a0,0x4
    3016:	fe650513          	addi	a0,a0,-26 # 6ff8 <malloc+0x161e>
    301a:	109020ef          	jal	5922 <printf>
    exit(1);
    301e:	4505                	li	a0,1
    3020:	47c020ef          	jal	549c <exit>
    printf("%s: open dd rdwr succeeded!\n", s);
    3024:	85ca                	mv	a1,s2
    3026:	00004517          	auipc	a0,0x4
    302a:	ff250513          	addi	a0,a0,-14 # 7018 <malloc+0x163e>
    302e:	0f5020ef          	jal	5922 <printf>
    exit(1);
    3032:	4505                	li	a0,1
    3034:	468020ef          	jal	549c <exit>
    printf("%s: open dd wronly succeeded!\n", s);
    3038:	85ca                	mv	a1,s2
    303a:	00004517          	auipc	a0,0x4
    303e:	ffe50513          	addi	a0,a0,-2 # 7038 <malloc+0x165e>
    3042:	0e1020ef          	jal	5922 <printf>
    exit(1);
    3046:	4505                	li	a0,1
    3048:	454020ef          	jal	549c <exit>
    printf("%s: link dd/ff/ff dd/dd/xx succeeded!\n", s);
    304c:	85ca                	mv	a1,s2
    304e:	00004517          	auipc	a0,0x4
    3052:	01a50513          	addi	a0,a0,26 # 7068 <malloc+0x168e>
    3056:	0cd020ef          	jal	5922 <printf>
    exit(1);
    305a:	4505                	li	a0,1
    305c:	440020ef          	jal	549c <exit>
    printf("%s: link dd/xx/ff dd/dd/xx succeeded!\n", s);
    3060:	85ca                	mv	a1,s2
    3062:	00004517          	auipc	a0,0x4
    3066:	02e50513          	addi	a0,a0,46 # 7090 <malloc+0x16b6>
    306a:	0b9020ef          	jal	5922 <printf>
    exit(1);
    306e:	4505                	li	a0,1
    3070:	42c020ef          	jal	549c <exit>
    printf("%s: link dd/ff dd/dd/ffff succeeded!\n", s);
    3074:	85ca                	mv	a1,s2
    3076:	00004517          	auipc	a0,0x4
    307a:	04250513          	addi	a0,a0,66 # 70b8 <malloc+0x16de>
    307e:	0a5020ef          	jal	5922 <printf>
    exit(1);
    3082:	4505                	li	a0,1
    3084:	418020ef          	jal	549c <exit>
    printf("%s: mkdir dd/ff/ff succeeded!\n", s);
    3088:	85ca                	mv	a1,s2
    308a:	00004517          	auipc	a0,0x4
    308e:	05650513          	addi	a0,a0,86 # 70e0 <malloc+0x1706>
    3092:	091020ef          	jal	5922 <printf>
    exit(1);
    3096:	4505                	li	a0,1
    3098:	404020ef          	jal	549c <exit>
    printf("%s: mkdir dd/xx/ff succeeded!\n", s);
    309c:	85ca                	mv	a1,s2
    309e:	00004517          	auipc	a0,0x4
    30a2:	06250513          	addi	a0,a0,98 # 7100 <malloc+0x1726>
    30a6:	07d020ef          	jal	5922 <printf>
    exit(1);
    30aa:	4505                	li	a0,1
    30ac:	3f0020ef          	jal	549c <exit>
    printf("%s: mkdir dd/dd/ffff succeeded!\n", s);
    30b0:	85ca                	mv	a1,s2
    30b2:	00004517          	auipc	a0,0x4
    30b6:	06e50513          	addi	a0,a0,110 # 7120 <malloc+0x1746>
    30ba:	069020ef          	jal	5922 <printf>
    exit(1);
    30be:	4505                	li	a0,1
    30c0:	3dc020ef          	jal	549c <exit>
    printf("%s: unlink dd/xx/ff succeeded!\n", s);
    30c4:	85ca                	mv	a1,s2
    30c6:	00004517          	auipc	a0,0x4
    30ca:	08250513          	addi	a0,a0,130 # 7148 <malloc+0x176e>
    30ce:	055020ef          	jal	5922 <printf>
    exit(1);
    30d2:	4505                	li	a0,1
    30d4:	3c8020ef          	jal	549c <exit>
    printf("%s: unlink dd/ff/ff succeeded!\n", s);
    30d8:	85ca                	mv	a1,s2
    30da:	00004517          	auipc	a0,0x4
    30de:	08e50513          	addi	a0,a0,142 # 7168 <malloc+0x178e>
    30e2:	041020ef          	jal	5922 <printf>
    exit(1);
    30e6:	4505                	li	a0,1
    30e8:	3b4020ef          	jal	549c <exit>
    printf("%s: chdir dd/ff succeeded!\n", s);
    30ec:	85ca                	mv	a1,s2
    30ee:	00004517          	auipc	a0,0x4
    30f2:	09a50513          	addi	a0,a0,154 # 7188 <malloc+0x17ae>
    30f6:	02d020ef          	jal	5922 <printf>
    exit(1);
    30fa:	4505                	li	a0,1
    30fc:	3a0020ef          	jal	549c <exit>
    printf("%s: chdir dd/xx succeeded!\n", s);
    3100:	85ca                	mv	a1,s2
    3102:	00004517          	auipc	a0,0x4
    3106:	0ae50513          	addi	a0,a0,174 # 71b0 <malloc+0x17d6>
    310a:	019020ef          	jal	5922 <printf>
    exit(1);
    310e:	4505                	li	a0,1
    3110:	38c020ef          	jal	549c <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    3114:	85ca                	mv	a1,s2
    3116:	00004517          	auipc	a0,0x4
    311a:	d2a50513          	addi	a0,a0,-726 # 6e40 <malloc+0x1466>
    311e:	005020ef          	jal	5922 <printf>
    exit(1);
    3122:	4505                	li	a0,1
    3124:	378020ef          	jal	549c <exit>
    printf("%s: unlink dd/ff failed\n", s);
    3128:	85ca                	mv	a1,s2
    312a:	00004517          	auipc	a0,0x4
    312e:	0a650513          	addi	a0,a0,166 # 71d0 <malloc+0x17f6>
    3132:	7f0020ef          	jal	5922 <printf>
    exit(1);
    3136:	4505                	li	a0,1
    3138:	364020ef          	jal	549c <exit>
    printf("%s: unlink non-empty dd succeeded!\n", s);
    313c:	85ca                	mv	a1,s2
    313e:	00004517          	auipc	a0,0x4
    3142:	0b250513          	addi	a0,a0,178 # 71f0 <malloc+0x1816>
    3146:	7dc020ef          	jal	5922 <printf>
    exit(1);
    314a:	4505                	li	a0,1
    314c:	350020ef          	jal	549c <exit>
    printf("%s: unlink dd/dd failed\n", s);
    3150:	85ca                	mv	a1,s2
    3152:	00004517          	auipc	a0,0x4
    3156:	0ce50513          	addi	a0,a0,206 # 7220 <malloc+0x1846>
    315a:	7c8020ef          	jal	5922 <printf>
    exit(1);
    315e:	4505                	li	a0,1
    3160:	33c020ef          	jal	549c <exit>
    printf("%s: unlink dd failed\n", s);
    3164:	85ca                	mv	a1,s2
    3166:	00004517          	auipc	a0,0x4
    316a:	0da50513          	addi	a0,a0,218 # 7240 <malloc+0x1866>
    316e:	7b4020ef          	jal	5922 <printf>
    exit(1);
    3172:	4505                	li	a0,1
    3174:	328020ef          	jal	549c <exit>

0000000000003178 <rmdot>:
{
    3178:	1101                	addi	sp,sp,-32
    317a:	ec06                	sd	ra,24(sp)
    317c:	e822                	sd	s0,16(sp)
    317e:	e426                	sd	s1,8(sp)
    3180:	1000                	addi	s0,sp,32
    3182:	84aa                	mv	s1,a0
  if (mkdir("dots") != 0) {
    3184:	00004517          	auipc	a0,0x4
    3188:	0d450513          	addi	a0,a0,212 # 7258 <malloc+0x187e>
    318c:	378020ef          	jal	5504 <mkdir>
    3190:	e53d                	bnez	a0,31fe <rmdot+0x86>
  if (chdir("dots") != 0) {
    3192:	00004517          	auipc	a0,0x4
    3196:	0c650513          	addi	a0,a0,198 # 7258 <malloc+0x187e>
    319a:	372020ef          	jal	550c <chdir>
    319e:	e935                	bnez	a0,3212 <rmdot+0x9a>
  if (unlink(".") == 0) {
    31a0:	00003517          	auipc	a0,0x3
    31a4:	05050513          	addi	a0,a0,80 # 61f0 <malloc+0x816>
    31a8:	344020ef          	jal	54ec <unlink>
    31ac:	cd2d                	beqz	a0,3226 <rmdot+0xae>
  if (unlink("..") == 0) {
    31ae:	00004517          	auipc	a0,0x4
    31b2:	afa50513          	addi	a0,a0,-1286 # 6ca8 <malloc+0x12ce>
    31b6:	336020ef          	jal	54ec <unlink>
    31ba:	c141                	beqz	a0,323a <rmdot+0xc2>
  if (chdir("/") != 0) {
    31bc:	00004517          	auipc	a0,0x4
    31c0:	a9450513          	addi	a0,a0,-1388 # 6c50 <malloc+0x1276>
    31c4:	348020ef          	jal	550c <chdir>
    31c8:	e159                	bnez	a0,324e <rmdot+0xd6>
  if (unlink("dots/.") == 0) {
    31ca:	00004517          	auipc	a0,0x4
    31ce:	0f650513          	addi	a0,a0,246 # 72c0 <malloc+0x18e6>
    31d2:	31a020ef          	jal	54ec <unlink>
    31d6:	c551                	beqz	a0,3262 <rmdot+0xea>
  if (unlink("dots/..") == 0) {
    31d8:	00004517          	auipc	a0,0x4
    31dc:	11050513          	addi	a0,a0,272 # 72e8 <malloc+0x190e>
    31e0:	30c020ef          	jal	54ec <unlink>
    31e4:	c949                	beqz	a0,3276 <rmdot+0xfe>
  if (unlink("dots") != 0) {
    31e6:	00004517          	auipc	a0,0x4
    31ea:	07250513          	addi	a0,a0,114 # 7258 <malloc+0x187e>
    31ee:	2fe020ef          	jal	54ec <unlink>
    31f2:	ed41                	bnez	a0,328a <rmdot+0x112>
}
    31f4:	60e2                	ld	ra,24(sp)
    31f6:	6442                	ld	s0,16(sp)
    31f8:	64a2                	ld	s1,8(sp)
    31fa:	6105                	addi	sp,sp,32
    31fc:	8082                	ret
    printf("%s: mkdir dots failed\n", s);
    31fe:	85a6                	mv	a1,s1
    3200:	00004517          	auipc	a0,0x4
    3204:	06050513          	addi	a0,a0,96 # 7260 <malloc+0x1886>
    3208:	71a020ef          	jal	5922 <printf>
    exit(1);
    320c:	4505                	li	a0,1
    320e:	28e020ef          	jal	549c <exit>
    printf("%s: chdir dots failed\n", s);
    3212:	85a6                	mv	a1,s1
    3214:	00004517          	auipc	a0,0x4
    3218:	06450513          	addi	a0,a0,100 # 7278 <malloc+0x189e>
    321c:	706020ef          	jal	5922 <printf>
    exit(1);
    3220:	4505                	li	a0,1
    3222:	27a020ef          	jal	549c <exit>
    printf("%s: rm . worked!\n", s);
    3226:	85a6                	mv	a1,s1
    3228:	00004517          	auipc	a0,0x4
    322c:	06850513          	addi	a0,a0,104 # 7290 <malloc+0x18b6>
    3230:	6f2020ef          	jal	5922 <printf>
    exit(1);
    3234:	4505                	li	a0,1
    3236:	266020ef          	jal	549c <exit>
    printf("%s: rm .. worked!\n", s);
    323a:	85a6                	mv	a1,s1
    323c:	00004517          	auipc	a0,0x4
    3240:	06c50513          	addi	a0,a0,108 # 72a8 <malloc+0x18ce>
    3244:	6de020ef          	jal	5922 <printf>
    exit(1);
    3248:	4505                	li	a0,1
    324a:	252020ef          	jal	549c <exit>
    printf("%s: chdir / failed\n", s);
    324e:	85a6                	mv	a1,s1
    3250:	00004517          	auipc	a0,0x4
    3254:	a0850513          	addi	a0,a0,-1528 # 6c58 <malloc+0x127e>
    3258:	6ca020ef          	jal	5922 <printf>
    exit(1);
    325c:	4505                	li	a0,1
    325e:	23e020ef          	jal	549c <exit>
    printf("%s: unlink dots/. worked!\n", s);
    3262:	85a6                	mv	a1,s1
    3264:	00004517          	auipc	a0,0x4
    3268:	06450513          	addi	a0,a0,100 # 72c8 <malloc+0x18ee>
    326c:	6b6020ef          	jal	5922 <printf>
    exit(1);
    3270:	4505                	li	a0,1
    3272:	22a020ef          	jal	549c <exit>
    printf("%s: unlink dots/.. worked!\n", s);
    3276:	85a6                	mv	a1,s1
    3278:	00004517          	auipc	a0,0x4
    327c:	07850513          	addi	a0,a0,120 # 72f0 <malloc+0x1916>
    3280:	6a2020ef          	jal	5922 <printf>
    exit(1);
    3284:	4505                	li	a0,1
    3286:	216020ef          	jal	549c <exit>
    printf("%s: unlink dots failed!\n", s);
    328a:	85a6                	mv	a1,s1
    328c:	00004517          	auipc	a0,0x4
    3290:	08450513          	addi	a0,a0,132 # 7310 <malloc+0x1936>
    3294:	68e020ef          	jal	5922 <printf>
    exit(1);
    3298:	4505                	li	a0,1
    329a:	202020ef          	jal	549c <exit>

000000000000329e <dirfile>:
{
    329e:	1101                	addi	sp,sp,-32
    32a0:	ec06                	sd	ra,24(sp)
    32a2:	e822                	sd	s0,16(sp)
    32a4:	e426                	sd	s1,8(sp)
    32a6:	e04a                	sd	s2,0(sp)
    32a8:	1000                	addi	s0,sp,32
    32aa:	892a                	mv	s2,a0
  fd = open("dirfile", O_CREATE);
    32ac:	20000593          	li	a1,512
    32b0:	00004517          	auipc	a0,0x4
    32b4:	08050513          	addi	a0,a0,128 # 7330 <malloc+0x1956>
    32b8:	224020ef          	jal	54dc <open>
  if (fd < 0) {
    32bc:	0c054563          	bltz	a0,3386 <dirfile+0xe8>
  close(fd);
    32c0:	204020ef          	jal	54c4 <close>
  if (chdir("dirfile") == 0) {
    32c4:	00004517          	auipc	a0,0x4
    32c8:	06c50513          	addi	a0,a0,108 # 7330 <malloc+0x1956>
    32cc:	240020ef          	jal	550c <chdir>
    32d0:	c569                	beqz	a0,339a <dirfile+0xfc>
  fd = open("dirfile/xx", 0);
    32d2:	4581                	li	a1,0
    32d4:	00004517          	auipc	a0,0x4
    32d8:	0a450513          	addi	a0,a0,164 # 7378 <malloc+0x199e>
    32dc:	200020ef          	jal	54dc <open>
  if (fd >= 0) {
    32e0:	0c055763          	bgez	a0,33ae <dirfile+0x110>
  fd = open("dirfile/xx", O_CREATE);
    32e4:	20000593          	li	a1,512
    32e8:	00004517          	auipc	a0,0x4
    32ec:	09050513          	addi	a0,a0,144 # 7378 <malloc+0x199e>
    32f0:	1ec020ef          	jal	54dc <open>
  if (fd >= 0) {
    32f4:	0c055763          	bgez	a0,33c2 <dirfile+0x124>
  if (mkdir("dirfile/xx") == 0) {
    32f8:	00004517          	auipc	a0,0x4
    32fc:	08050513          	addi	a0,a0,128 # 7378 <malloc+0x199e>
    3300:	204020ef          	jal	5504 <mkdir>
    3304:	0c050963          	beqz	a0,33d6 <dirfile+0x138>
  if (unlink("dirfile/xx") == 0) {
    3308:	00004517          	auipc	a0,0x4
    330c:	07050513          	addi	a0,a0,112 # 7378 <malloc+0x199e>
    3310:	1dc020ef          	jal	54ec <unlink>
    3314:	0c050b63          	beqz	a0,33ea <dirfile+0x14c>
  if (link("README", "dirfile/xx") == 0) {
    3318:	00004597          	auipc	a1,0x4
    331c:	06058593          	addi	a1,a1,96 # 7378 <malloc+0x199e>
    3320:	00003517          	auipc	a0,0x3
    3324:	9c050513          	addi	a0,a0,-1600 # 5ce0 <malloc+0x306>
    3328:	1d4020ef          	jal	54fc <link>
    332c:	0c050963          	beqz	a0,33fe <dirfile+0x160>
  if (unlink("dirfile") != 0) {
    3330:	00004517          	auipc	a0,0x4
    3334:	00050513          	mv	a0,a0
    3338:	1b4020ef          	jal	54ec <unlink>
    333c:	0c051b63          	bnez	a0,3412 <dirfile+0x174>
  fd = open(".", O_RDWR);
    3340:	4589                	li	a1,2
    3342:	00003517          	auipc	a0,0x3
    3346:	eae50513          	addi	a0,a0,-338 # 61f0 <malloc+0x816>
    334a:	192020ef          	jal	54dc <open>
  if (fd >= 0) {
    334e:	0c055c63          	bgez	a0,3426 <dirfile+0x188>
  fd = open(".", 0);
    3352:	4581                	li	a1,0
    3354:	00003517          	auipc	a0,0x3
    3358:	e9c50513          	addi	a0,a0,-356 # 61f0 <malloc+0x816>
    335c:	180020ef          	jal	54dc <open>
    3360:	84aa                	mv	s1,a0
  if (write(fd, "x", 1) > 0) {
    3362:	4605                	li	a2,1
    3364:	00003597          	auipc	a1,0x3
    3368:	81458593          	addi	a1,a1,-2028 # 5b78 <malloc+0x19e>
    336c:	150020ef          	jal	54bc <write>
    3370:	0ca04563          	bgtz	a0,343a <dirfile+0x19c>
  close(fd);
    3374:	8526                	mv	a0,s1
    3376:	14e020ef          	jal	54c4 <close>
}
    337a:	60e2                	ld	ra,24(sp)
    337c:	6442                	ld	s0,16(sp)
    337e:	64a2                	ld	s1,8(sp)
    3380:	6902                	ld	s2,0(sp)
    3382:	6105                	addi	sp,sp,32
    3384:	8082                	ret
    printf("%s: create dirfile failed\n", s);
    3386:	85ca                	mv	a1,s2
    3388:	00004517          	auipc	a0,0x4
    338c:	fb050513          	addi	a0,a0,-80 # 7338 <malloc+0x195e>
    3390:	592020ef          	jal	5922 <printf>
    exit(1);
    3394:	4505                	li	a0,1
    3396:	106020ef          	jal	549c <exit>
    printf("%s: chdir dirfile succeeded!\n", s);
    339a:	85ca                	mv	a1,s2
    339c:	00004517          	auipc	a0,0x4
    33a0:	fbc50513          	addi	a0,a0,-68 # 7358 <malloc+0x197e>
    33a4:	57e020ef          	jal	5922 <printf>
    exit(1);
    33a8:	4505                	li	a0,1
    33aa:	0f2020ef          	jal	549c <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    33ae:	85ca                	mv	a1,s2
    33b0:	00004517          	auipc	a0,0x4
    33b4:	fd850513          	addi	a0,a0,-40 # 7388 <malloc+0x19ae>
    33b8:	56a020ef          	jal	5922 <printf>
    exit(1);
    33bc:	4505                	li	a0,1
    33be:	0de020ef          	jal	549c <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    33c2:	85ca                	mv	a1,s2
    33c4:	00004517          	auipc	a0,0x4
    33c8:	fc450513          	addi	a0,a0,-60 # 7388 <malloc+0x19ae>
    33cc:	556020ef          	jal	5922 <printf>
    exit(1);
    33d0:	4505                	li	a0,1
    33d2:	0ca020ef          	jal	549c <exit>
    printf("%s: mkdir dirfile/xx succeeded!\n", s);
    33d6:	85ca                	mv	a1,s2
    33d8:	00004517          	auipc	a0,0x4
    33dc:	fd850513          	addi	a0,a0,-40 # 73b0 <malloc+0x19d6>
    33e0:	542020ef          	jal	5922 <printf>
    exit(1);
    33e4:	4505                	li	a0,1
    33e6:	0b6020ef          	jal	549c <exit>
    printf("%s: unlink dirfile/xx succeeded!\n", s);
    33ea:	85ca                	mv	a1,s2
    33ec:	00004517          	auipc	a0,0x4
    33f0:	fec50513          	addi	a0,a0,-20 # 73d8 <malloc+0x19fe>
    33f4:	52e020ef          	jal	5922 <printf>
    exit(1);
    33f8:	4505                	li	a0,1
    33fa:	0a2020ef          	jal	549c <exit>
    printf("%s: link to dirfile/xx succeeded!\n", s);
    33fe:	85ca                	mv	a1,s2
    3400:	00004517          	auipc	a0,0x4
    3404:	00050513          	mv	a0,a0
    3408:	51a020ef          	jal	5922 <printf>
    exit(1);
    340c:	4505                	li	a0,1
    340e:	08e020ef          	jal	549c <exit>
    printf("%s: unlink dirfile failed!\n", s);
    3412:	85ca                	mv	a1,s2
    3414:	00004517          	auipc	a0,0x4
    3418:	01450513          	addi	a0,a0,20 # 7428 <malloc+0x1a4e>
    341c:	506020ef          	jal	5922 <printf>
    exit(1);
    3420:	4505                	li	a0,1
    3422:	07a020ef          	jal	549c <exit>
    printf("%s: open . for writing succeeded!\n", s);
    3426:	85ca                	mv	a1,s2
    3428:	00004517          	auipc	a0,0x4
    342c:	02050513          	addi	a0,a0,32 # 7448 <malloc+0x1a6e>
    3430:	4f2020ef          	jal	5922 <printf>
    exit(1);
    3434:	4505                	li	a0,1
    3436:	066020ef          	jal	549c <exit>
    printf("%s: write . succeeded!\n", s);
    343a:	85ca                	mv	a1,s2
    343c:	00004517          	auipc	a0,0x4
    3440:	03450513          	addi	a0,a0,52 # 7470 <malloc+0x1a96>
    3444:	4de020ef          	jal	5922 <printf>
    exit(1);
    3448:	4505                	li	a0,1
    344a:	052020ef          	jal	549c <exit>

000000000000344e <iref>:
{
    344e:	715d                	addi	sp,sp,-80
    3450:	e486                	sd	ra,72(sp)
    3452:	e0a2                	sd	s0,64(sp)
    3454:	fc26                	sd	s1,56(sp)
    3456:	f84a                	sd	s2,48(sp)
    3458:	f44e                	sd	s3,40(sp)
    345a:	f052                	sd	s4,32(sp)
    345c:	ec56                	sd	s5,24(sp)
    345e:	e85a                	sd	s6,16(sp)
    3460:	e45e                	sd	s7,8(sp)
    3462:	0880                	addi	s0,sp,80
    3464:	8baa                	mv	s7,a0
    3466:	03300913          	li	s2,51
    if (mkdir("irefd") != 0) {
    346a:	00004a97          	auipc	s5,0x4
    346e:	01ea8a93          	addi	s5,s5,30 # 7488 <malloc+0x1aae>
    mkdir("");
    3472:	00004497          	auipc	s1,0x4
    3476:	b1e48493          	addi	s1,s1,-1250 # 6f90 <malloc+0x15b6>
    link("README", "");
    347a:	00003b17          	auipc	s6,0x3
    347e:	866b0b13          	addi	s6,s6,-1946 # 5ce0 <malloc+0x306>
    fd = open("", O_CREATE);
    3482:	20000a13          	li	s4,512
    fd = open("xx", O_CREATE);
    3486:	00004997          	auipc	s3,0x4
    348a:	efa98993          	addi	s3,s3,-262 # 7380 <malloc+0x19a6>
    348e:	a835                	j	34ca <iref+0x7c>
      printf("%s: mkdir irefd failed\n", s);
    3490:	85de                	mv	a1,s7
    3492:	00004517          	auipc	a0,0x4
    3496:	ffe50513          	addi	a0,a0,-2 # 7490 <malloc+0x1ab6>
    349a:	488020ef          	jal	5922 <printf>
      exit(1);
    349e:	4505                	li	a0,1
    34a0:	7fd010ef          	jal	549c <exit>
      printf("%s: chdir irefd failed\n", s);
    34a4:	85de                	mv	a1,s7
    34a6:	00004517          	auipc	a0,0x4
    34aa:	00250513          	addi	a0,a0,2 # 74a8 <malloc+0x1ace>
    34ae:	474020ef          	jal	5922 <printf>
      exit(1);
    34b2:	4505                	li	a0,1
    34b4:	7e9010ef          	jal	549c <exit>
      close(fd);
    34b8:	00c020ef          	jal	54c4 <close>
    34bc:	a825                	j	34f4 <iref+0xa6>
    unlink("xx");
    34be:	854e                	mv	a0,s3
    34c0:	02c020ef          	jal	54ec <unlink>
  for (i = 0; i < NINODE + 1; i++) {
    34c4:	397d                	addiw	s2,s2,-1
    34c6:	04090063          	beqz	s2,3506 <iref+0xb8>
    if (mkdir("irefd") != 0) {
    34ca:	8556                	mv	a0,s5
    34cc:	038020ef          	jal	5504 <mkdir>
    34d0:	f161                	bnez	a0,3490 <iref+0x42>
    if (chdir("irefd") != 0) {
    34d2:	8556                	mv	a0,s5
    34d4:	038020ef          	jal	550c <chdir>
    34d8:	f571                	bnez	a0,34a4 <iref+0x56>
    mkdir("");
    34da:	8526                	mv	a0,s1
    34dc:	028020ef          	jal	5504 <mkdir>
    link("README", "");
    34e0:	85a6                	mv	a1,s1
    34e2:	855a                	mv	a0,s6
    34e4:	018020ef          	jal	54fc <link>
    fd = open("", O_CREATE);
    34e8:	85d2                	mv	a1,s4
    34ea:	8526                	mv	a0,s1
    34ec:	7f1010ef          	jal	54dc <open>
    if (fd >= 0)
    34f0:	fc0554e3          	bgez	a0,34b8 <iref+0x6a>
    fd = open("xx", O_CREATE);
    34f4:	85d2                	mv	a1,s4
    34f6:	854e                	mv	a0,s3
    34f8:	7e5010ef          	jal	54dc <open>
    if (fd >= 0)
    34fc:	fc0541e3          	bltz	a0,34be <iref+0x70>
      close(fd);
    3500:	7c5010ef          	jal	54c4 <close>
    3504:	bf6d                	j	34be <iref+0x70>
    3506:	03300493          	li	s1,51
    chdir("..");
    350a:	00003997          	auipc	s3,0x3
    350e:	79e98993          	addi	s3,s3,1950 # 6ca8 <malloc+0x12ce>
    unlink("irefd");
    3512:	00004917          	auipc	s2,0x4
    3516:	f7690913          	addi	s2,s2,-138 # 7488 <malloc+0x1aae>
    chdir("..");
    351a:	854e                	mv	a0,s3
    351c:	7f1010ef          	jal	550c <chdir>
    unlink("irefd");
    3520:	854a                	mv	a0,s2
    3522:	7cb010ef          	jal	54ec <unlink>
  for (i = 0; i < NINODE + 1; i++) {
    3526:	34fd                	addiw	s1,s1,-1
    3528:	f8ed                	bnez	s1,351a <iref+0xcc>
  chdir("/");
    352a:	00003517          	auipc	a0,0x3
    352e:	72650513          	addi	a0,a0,1830 # 6c50 <malloc+0x1276>
    3532:	7db010ef          	jal	550c <chdir>
}
    3536:	60a6                	ld	ra,72(sp)
    3538:	6406                	ld	s0,64(sp)
    353a:	74e2                	ld	s1,56(sp)
    353c:	7942                	ld	s2,48(sp)
    353e:	79a2                	ld	s3,40(sp)
    3540:	7a02                	ld	s4,32(sp)
    3542:	6ae2                	ld	s5,24(sp)
    3544:	6b42                	ld	s6,16(sp)
    3546:	6ba2                	ld	s7,8(sp)
    3548:	6161                	addi	sp,sp,80
    354a:	8082                	ret

000000000000354c <unlinkcwd>:
{
    354c:	1101                	addi	sp,sp,-32
    354e:	ec06                	sd	ra,24(sp)
    3550:	e822                	sd	s0,16(sp)
    3552:	e426                	sd	s1,8(sp)
    3554:	1000                	addi	s0,sp,32
    3556:	84aa                	mv	s1,a0
  if (mkdir("/a") < 0) {
    3558:	00004517          	auipc	a0,0x4
    355c:	f6850513          	addi	a0,a0,-152 # 74c0 <malloc+0x1ae6>
    3560:	7a5010ef          	jal	5504 <mkdir>
    3564:	06054a63          	bltz	a0,35d8 <unlinkcwd+0x8c>
  if (mkdir("/a/b") < 0) {
    3568:	00004517          	auipc	a0,0x4
    356c:	f7850513          	addi	a0,a0,-136 # 74e0 <malloc+0x1b06>
    3570:	795010ef          	jal	5504 <mkdir>
    3574:	06054c63          	bltz	a0,35ec <unlinkcwd+0xa0>
  if (chdir("/a/b") < 0) {
    3578:	00004517          	auipc	a0,0x4
    357c:	f6850513          	addi	a0,a0,-152 # 74e0 <malloc+0x1b06>
    3580:	78d010ef          	jal	550c <chdir>
    3584:	06054e63          	bltz	a0,3600 <unlinkcwd+0xb4>
  if (unlink("/a/b") < 0) {
    3588:	00004517          	auipc	a0,0x4
    358c:	f5850513          	addi	a0,a0,-168 # 74e0 <malloc+0x1b06>
    3590:	75d010ef          	jal	54ec <unlink>
    3594:	08054063          	bltz	a0,3614 <unlinkcwd+0xc8>
  if (unlink("/a") < 0) {
    3598:	00004517          	auipc	a0,0x4
    359c:	f2850513          	addi	a0,a0,-216 # 74c0 <malloc+0x1ae6>
    35a0:	74d010ef          	jal	54ec <unlink>
    35a4:	08054263          	bltz	a0,3628 <unlinkcwd+0xdc>
  if (open("../", O_RDONLY) > 0) {
    35a8:	4581                	li	a1,0
    35aa:	00004517          	auipc	a0,0x4
    35ae:	f9e50513          	addi	a0,a0,-98 # 7548 <malloc+0x1b6e>
    35b2:	72b010ef          	jal	54dc <open>
    35b6:	08a04363          	bgtz	a0,363c <unlinkcwd+0xf0>
  if (open("../c", O_CREATE) > 0) {
    35ba:	20000593          	li	a1,512
    35be:	00004517          	auipc	a0,0x4
    35c2:	fba50513          	addi	a0,a0,-70 # 7578 <malloc+0x1b9e>
    35c6:	717010ef          	jal	54dc <open>
    35ca:	08a04163          	bgtz	a0,364c <unlinkcwd+0x100>
}
    35ce:	60e2                	ld	ra,24(sp)
    35d0:	6442                	ld	s0,16(sp)
    35d2:	64a2                	ld	s1,8(sp)
    35d4:	6105                	addi	sp,sp,32
    35d6:	8082                	ret
    printf("%s: mkdir /a failed\n", s);
    35d8:	85a6                	mv	a1,s1
    35da:	00004517          	auipc	a0,0x4
    35de:	eee50513          	addi	a0,a0,-274 # 74c8 <malloc+0x1aee>
    35e2:	340020ef          	jal	5922 <printf>
    exit(1);
    35e6:	4505                	li	a0,1
    35e8:	6b5010ef          	jal	549c <exit>
    printf("%s: mkdir /a/b failed\n", s);
    35ec:	85a6                	mv	a1,s1
    35ee:	00004517          	auipc	a0,0x4
    35f2:	efa50513          	addi	a0,a0,-262 # 74e8 <malloc+0x1b0e>
    35f6:	32c020ef          	jal	5922 <printf>
    exit(1);
    35fa:	4505                	li	a0,1
    35fc:	6a1010ef          	jal	549c <exit>
    printf("%s: chdir failed\n", s);
    3600:	85a6                	mv	a1,s1
    3602:	00004517          	auipc	a0,0x4
    3606:	efe50513          	addi	a0,a0,-258 # 7500 <malloc+0x1b26>
    360a:	318020ef          	jal	5922 <printf>
    exit(1);
    360e:	4505                	li	a0,1
    3610:	68d010ef          	jal	549c <exit>
    printf("%s: unlink /a/b failed\n", s);
    3614:	85a6                	mv	a1,s1
    3616:	00004517          	auipc	a0,0x4
    361a:	f0250513          	addi	a0,a0,-254 # 7518 <malloc+0x1b3e>
    361e:	304020ef          	jal	5922 <printf>
    exit(1);
    3622:	4505                	li	a0,1
    3624:	679010ef          	jal	549c <exit>
    printf("%s: unlink /a failed\n", s);
    3628:	85a6                	mv	a1,s1
    362a:	00004517          	auipc	a0,0x4
    362e:	f0650513          	addi	a0,a0,-250 # 7530 <malloc+0x1b56>
    3632:	2f0020ef          	jal	5922 <printf>
    exit(1);
    3636:	4505                	li	a0,1
    3638:	665010ef          	jal	549c <exit>
    printf("%s: open ../ non-existing directory\n", s);
    363c:	85a6                	mv	a1,s1
    363e:	00004517          	auipc	a0,0x4
    3642:	f1250513          	addi	a0,a0,-238 # 7550 <malloc+0x1b76>
    3646:	2dc020ef          	jal	5922 <printf>
    364a:	bf85                	j	35ba <unlinkcwd+0x6e>
    printf("%s: create ../c non-existing file\n", s);
    364c:	85a6                	mv	a1,s1
    364e:	00004517          	auipc	a0,0x4
    3652:	f3250513          	addi	a0,a0,-206 # 7580 <malloc+0x1ba6>
    3656:	2cc020ef          	jal	5922 <printf>
}
    365a:	bf95                	j	35ce <unlinkcwd+0x82>

000000000000365c <openiputtest>:
{
    365c:	7179                	addi	sp,sp,-48
    365e:	f406                	sd	ra,40(sp)
    3660:	f022                	sd	s0,32(sp)
    3662:	ec26                	sd	s1,24(sp)
    3664:	1800                	addi	s0,sp,48
    3666:	84aa                	mv	s1,a0
  if (mkdir("oidir") < 0) {
    3668:	00004517          	auipc	a0,0x4
    366c:	f4050513          	addi	a0,a0,-192 # 75a8 <malloc+0x1bce>
    3670:	695010ef          	jal	5504 <mkdir>
    3674:	02054a63          	bltz	a0,36a8 <openiputtest+0x4c>
  pid = fork();
    3678:	61d010ef          	jal	5494 <fork>
  if (pid < 0) {
    367c:	04054063          	bltz	a0,36bc <openiputtest+0x60>
  if (pid == 0) {
    3680:	e939                	bnez	a0,36d6 <openiputtest+0x7a>
    int fd = open("oidir", O_RDWR);
    3682:	4589                	li	a1,2
    3684:	00004517          	auipc	a0,0x4
    3688:	f2450513          	addi	a0,a0,-220 # 75a8 <malloc+0x1bce>
    368c:	651010ef          	jal	54dc <open>
    if (fd >= 0) {
    3690:	04054063          	bltz	a0,36d0 <openiputtest+0x74>
      printf("%s: open directory for write succeeded\n", s);
    3694:	85a6                	mv	a1,s1
    3696:	00004517          	auipc	a0,0x4
    369a:	f3250513          	addi	a0,a0,-206 # 75c8 <malloc+0x1bee>
    369e:	284020ef          	jal	5922 <printf>
      exit(1);
    36a2:	4505                	li	a0,1
    36a4:	5f9010ef          	jal	549c <exit>
    printf("%s: mkdir oidir failed\n", s);
    36a8:	85a6                	mv	a1,s1
    36aa:	00004517          	auipc	a0,0x4
    36ae:	f0650513          	addi	a0,a0,-250 # 75b0 <malloc+0x1bd6>
    36b2:	270020ef          	jal	5922 <printf>
    exit(1);
    36b6:	4505                	li	a0,1
    36b8:	5e5010ef          	jal	549c <exit>
    printf("%s: fork failed\n", s);
    36bc:	85a6                	mv	a1,s1
    36be:	00003517          	auipc	a0,0x3
    36c2:	cda50513          	addi	a0,a0,-806 # 6398 <malloc+0x9be>
    36c6:	25c020ef          	jal	5922 <printf>
    exit(1);
    36ca:	4505                	li	a0,1
    36cc:	5d1010ef          	jal	549c <exit>
    exit(0);
    36d0:	4501                	li	a0,0
    36d2:	5cb010ef          	jal	549c <exit>
  pause(1);
    36d6:	4505                	li	a0,1
    36d8:	655010ef          	jal	552c <pause>
  if (unlink("oidir") != 0) {
    36dc:	00004517          	auipc	a0,0x4
    36e0:	ecc50513          	addi	a0,a0,-308 # 75a8 <malloc+0x1bce>
    36e4:	609010ef          	jal	54ec <unlink>
    36e8:	c919                	beqz	a0,36fe <openiputtest+0xa2>
    printf("%s: unlink failed\n", s);
    36ea:	85a6                	mv	a1,s1
    36ec:	00003517          	auipc	a0,0x3
    36f0:	e3450513          	addi	a0,a0,-460 # 6520 <malloc+0xb46>
    36f4:	22e020ef          	jal	5922 <printf>
    exit(1);
    36f8:	4505                	li	a0,1
    36fa:	5a3010ef          	jal	549c <exit>
  wait(&xstatus);
    36fe:	fdc40513          	addi	a0,s0,-36
    3702:	5a3010ef          	jal	54a4 <wait>
  exit(xstatus);
    3706:	fdc42503          	lw	a0,-36(s0)
    370a:	593010ef          	jal	549c <exit>

000000000000370e <forkforkfork>:
{
    370e:	1101                	addi	sp,sp,-32
    3710:	ec06                	sd	ra,24(sp)
    3712:	e822                	sd	s0,16(sp)
    3714:	e426                	sd	s1,8(sp)
    3716:	1000                	addi	s0,sp,32
    3718:	84aa                	mv	s1,a0
  unlink("stopforking");
    371a:	00004517          	auipc	a0,0x4
    371e:	ed650513          	addi	a0,a0,-298 # 75f0 <malloc+0x1c16>
    3722:	5cb010ef          	jal	54ec <unlink>
  int pid = fork();
    3726:	56f010ef          	jal	5494 <fork>
  if (pid < 0) {
    372a:	02054b63          	bltz	a0,3760 <forkforkfork+0x52>
  if (pid == 0) {
    372e:	c139                	beqz	a0,3774 <forkforkfork+0x66>
  pause(20); // two seconds
    3730:	4551                	li	a0,20
    3732:	5fb010ef          	jal	552c <pause>
  close(open("stopforking", O_CREATE | O_RDWR));
    3736:	20200593          	li	a1,514
    373a:	00004517          	auipc	a0,0x4
    373e:	eb650513          	addi	a0,a0,-330 # 75f0 <malloc+0x1c16>
    3742:	59b010ef          	jal	54dc <open>
    3746:	57f010ef          	jal	54c4 <close>
  wait(0);
    374a:	4501                	li	a0,0
    374c:	559010ef          	jal	54a4 <wait>
  pause(10); // one second
    3750:	4529                	li	a0,10
    3752:	5db010ef          	jal	552c <pause>
}
    3756:	60e2                	ld	ra,24(sp)
    3758:	6442                	ld	s0,16(sp)
    375a:	64a2                	ld	s1,8(sp)
    375c:	6105                	addi	sp,sp,32
    375e:	8082                	ret
    printf("%s: fork failed", s);
    3760:	85a6                	mv	a1,s1
    3762:	00003517          	auipc	a0,0x3
    3766:	d7650513          	addi	a0,a0,-650 # 64d8 <malloc+0xafe>
    376a:	1b8020ef          	jal	5922 <printf>
    exit(1);
    376e:	4505                	li	a0,1
    3770:	52d010ef          	jal	549c <exit>
      int fd = open("stopforking", 0);
    3774:	4581                	li	a1,0
    3776:	00004517          	auipc	a0,0x4
    377a:	e7a50513          	addi	a0,a0,-390 # 75f0 <malloc+0x1c16>
    377e:	55f010ef          	jal	54dc <open>
      if (fd >= 0) {
    3782:	02055163          	bgez	a0,37a4 <forkforkfork+0x96>
      if (fork() < 0) {
    3786:	50f010ef          	jal	5494 <fork>
    378a:	fe0555e3          	bgez	a0,3774 <forkforkfork+0x66>
        close(open("stopforking", O_CREATE | O_RDWR));
    378e:	20200593          	li	a1,514
    3792:	00004517          	auipc	a0,0x4
    3796:	e5e50513          	addi	a0,a0,-418 # 75f0 <malloc+0x1c16>
    379a:	543010ef          	jal	54dc <open>
    379e:	527010ef          	jal	54c4 <close>
    37a2:	bfc9                	j	3774 <forkforkfork+0x66>
        exit(0);
    37a4:	4501                	li	a0,0
    37a6:	4f7010ef          	jal	549c <exit>

00000000000037aa <exectest>:
{
    37aa:	711d                	addi	sp,sp,-96
    37ac:	ec86                	sd	ra,88(sp)
    37ae:	e8a2                	sd	s0,80(sp)
    37b0:	e0ca                	sd	s2,64(sp)
    37b2:	1080                	addi	s0,sp,96
    37b4:	892a                	mv	s2,a0
  char *echoargv[] = {"echo", "OK", 0};
    37b6:	00002797          	auipc	a5,0x2
    37ba:	35278793          	addi	a5,a5,850 # 5b08 <malloc+0x12e>
    37be:	faf43823          	sd	a5,-80(s0)
    37c2:	00004797          	auipc	a5,0x4
    37c6:	e3e78793          	addi	a5,a5,-450 # 7600 <malloc+0x1c26>
    37ca:	faf43c23          	sd	a5,-72(s0)
    37ce:	fc043023          	sd	zero,-64(s0)
  unlink("echo-ok");
    37d2:	00004517          	auipc	a0,0x4
    37d6:	e3650513          	addi	a0,a0,-458 # 7608 <malloc+0x1c2e>
    37da:	513010ef          	jal	54ec <unlink>
  pid = fork();
    37de:	4b7010ef          	jal	5494 <fork>
  if (pid < 0) {
    37e2:	04054763          	bltz	a0,3830 <exectest+0x86>
    37e6:	e4a6                	sd	s1,72(sp)
    37e8:	fc4e                	sd	s3,56(sp)
    37ea:	84aa                	mv	s1,a0
  if (pid == 0) {
    37ec:	ed49                	bnez	a0,3886 <exectest+0xdc>
    int errfd = dup(1);
    37ee:	4505                	li	a0,1
    37f0:	525010ef          	jal	5514 <dup>
    37f4:	89aa                	mv	s3,a0
    if (errfd < 0) {
    37f6:	04054963          	bltz	a0,3848 <exectest+0x9e>
    close(1);
    37fa:	4505                	li	a0,1
    37fc:	4c9010ef          	jal	54c4 <close>
    fd = open("echo-ok", O_CREATE | O_WRONLY);
    3800:	20100593          	li	a1,513
    3804:	00004517          	auipc	a0,0x4
    3808:	e0450513          	addi	a0,a0,-508 # 7608 <malloc+0x1c2e>
    380c:	4d1010ef          	jal	54dc <open>
    if (fd < 0) {
    3810:	04054663          	bltz	a0,385c <exectest+0xb2>
    if (fd != 1) {
    3814:	4785                	li	a5,1
    3816:	04f50e63          	beq	a0,a5,3872 <exectest+0xc8>
      fprintf(errfd, "%s: wrong fd\n", s);
    381a:	864a                	mv	a2,s2
    381c:	00004597          	auipc	a1,0x4
    3820:	e0458593          	addi	a1,a1,-508 # 7620 <malloc+0x1c46>
    3824:	854e                	mv	a0,s3
    3826:	0d2020ef          	jal	58f8 <fprintf>
      exit(1);
    382a:	4505                	li	a0,1
    382c:	471010ef          	jal	549c <exit>
    3830:	e4a6                	sd	s1,72(sp)
    3832:	fc4e                	sd	s3,56(sp)
    printf("%s: fork failed\n", s);
    3834:	85ca                	mv	a1,s2
    3836:	00003517          	auipc	a0,0x3
    383a:	b6250513          	addi	a0,a0,-1182 # 6398 <malloc+0x9be>
    383e:	0e4020ef          	jal	5922 <printf>
    exit(1);
    3842:	4505                	li	a0,1
    3844:	459010ef          	jal	549c <exit>
      printf("%s: dup failed\n", s);
    3848:	85ca                	mv	a1,s2
    384a:	00004517          	auipc	a0,0x4
    384e:	dc650513          	addi	a0,a0,-570 # 7610 <malloc+0x1c36>
    3852:	0d0020ef          	jal	5922 <printf>
      exit(1);
    3856:	4505                	li	a0,1
    3858:	445010ef          	jal	549c <exit>
      fprintf(errfd, "%s: create failed\n", s);
    385c:	864a                	mv	a2,s2
    385e:	00003597          	auipc	a1,0x3
    3862:	caa58593          	addi	a1,a1,-854 # 6508 <malloc+0xb2e>
    3866:	854e                	mv	a0,s3
    3868:	090020ef          	jal	58f8 <fprintf>
      exit(1);
    386c:	4505                	li	a0,1
    386e:	42f010ef          	jal	549c <exit>
    if (exec("echo", echoargv) < 0) {
    3872:	fb040593          	addi	a1,s0,-80
    3876:	00002517          	auipc	a0,0x2
    387a:	29250513          	addi	a0,a0,658 # 5b08 <malloc+0x12e>
    387e:	457010ef          	jal	54d4 <exec>
    3882:	02054563          	bltz	a0,38ac <exectest+0x102>
  if (wait(&xstatus) != pid) {
    3886:	fcc40513          	addi	a0,s0,-52
    388a:	41b010ef          	jal	54a4 <wait>
    388e:	02951a63          	bne	a0,s1,38c2 <exectest+0x118>
  if (xstatus != 0) {
    3892:	fcc42603          	lw	a2,-52(s0)
    3896:	ce15                	beqz	a2,38d2 <exectest+0x128>
    printf("%s: nonzero wait status %d\n", s, xstatus);
    3898:	85ca                	mv	a1,s2
    389a:	00004517          	auipc	a0,0x4
    389e:	dc650513          	addi	a0,a0,-570 # 7660 <malloc+0x1c86>
    38a2:	080020ef          	jal	5922 <printf>
    exit(1);
    38a6:	4505                	li	a0,1
    38a8:	3f5010ef          	jal	549c <exit>
      fprintf(errfd, "%s: exec echo failed\n", s);
    38ac:	864a                	mv	a2,s2
    38ae:	00004597          	auipc	a1,0x4
    38b2:	d8258593          	addi	a1,a1,-638 # 7630 <malloc+0x1c56>
    38b6:	854e                	mv	a0,s3
    38b8:	040020ef          	jal	58f8 <fprintf>
      exit(1);
    38bc:	4505                	li	a0,1
    38be:	3df010ef          	jal	549c <exit>
    printf("%s: wait failed!\n", s);
    38c2:	85ca                	mv	a1,s2
    38c4:	00004517          	auipc	a0,0x4
    38c8:	d8450513          	addi	a0,a0,-636 # 7648 <malloc+0x1c6e>
    38cc:	056020ef          	jal	5922 <printf>
    38d0:	b7c9                	j	3892 <exectest+0xe8>
  fd = open("echo-ok", O_RDONLY);
    38d2:	4581                	li	a1,0
    38d4:	00004517          	auipc	a0,0x4
    38d8:	d3450513          	addi	a0,a0,-716 # 7608 <malloc+0x1c2e>
    38dc:	401010ef          	jal	54dc <open>
  if (fd < 0) {
    38e0:	02054463          	bltz	a0,3908 <exectest+0x15e>
  if (read(fd, buf, 2) != 2) {
    38e4:	4609                	li	a2,2
    38e6:	fa840593          	addi	a1,s0,-88
    38ea:	3cb010ef          	jal	54b4 <read>
    38ee:	4789                	li	a5,2
    38f0:	02f50663          	beq	a0,a5,391c <exectest+0x172>
    printf("%s: read failed\n", s);
    38f4:	85ca                	mv	a1,s2
    38f6:	00002517          	auipc	a0,0x2
    38fa:	5e250513          	addi	a0,a0,1506 # 5ed8 <malloc+0x4fe>
    38fe:	024020ef          	jal	5922 <printf>
    exit(1);
    3902:	4505                	li	a0,1
    3904:	399010ef          	jal	549c <exit>
    printf("%s: open failed\n", s);
    3908:	85ca                	mv	a1,s2
    390a:	00003517          	auipc	a0,0x3
    390e:	aa650513          	addi	a0,a0,-1370 # 63b0 <malloc+0x9d6>
    3912:	010020ef          	jal	5922 <printf>
    exit(1);
    3916:	4505                	li	a0,1
    3918:	385010ef          	jal	549c <exit>
  unlink("echo-ok");
    391c:	00004517          	auipc	a0,0x4
    3920:	cec50513          	addi	a0,a0,-788 # 7608 <malloc+0x1c2e>
    3924:	3c9010ef          	jal	54ec <unlink>
  if (buf[0] == 'O' && buf[1] == 'K')
    3928:	fa844703          	lbu	a4,-88(s0)
    392c:	04f00793          	li	a5,79
    3930:	00f71863          	bne	a4,a5,3940 <exectest+0x196>
    3934:	fa944703          	lbu	a4,-87(s0)
    3938:	04b00793          	li	a5,75
    393c:	00f70c63          	beq	a4,a5,3954 <exectest+0x1aa>
    printf("%s: wrong output\n", s);
    3940:	85ca                	mv	a1,s2
    3942:	00004517          	auipc	a0,0x4
    3946:	d3e50513          	addi	a0,a0,-706 # 7680 <malloc+0x1ca6>
    394a:	7d9010ef          	jal	5922 <printf>
    exit(1);
    394e:	4505                	li	a0,1
    3950:	34d010ef          	jal	549c <exit>
    exit(0);
    3954:	4501                	li	a0,0
    3956:	347010ef          	jal	549c <exit>

000000000000395a <killstatus>:
{
    395a:	715d                	addi	sp,sp,-80
    395c:	e486                	sd	ra,72(sp)
    395e:	e0a2                	sd	s0,64(sp)
    3960:	fc26                	sd	s1,56(sp)
    3962:	f84a                	sd	s2,48(sp)
    3964:	f44e                	sd	s3,40(sp)
    3966:	f052                	sd	s4,32(sp)
    3968:	ec56                	sd	s5,24(sp)
    396a:	e85a                	sd	s6,16(sp)
    396c:	0880                	addi	s0,sp,80
    396e:	8b2a                	mv	s6,a0
    3970:	06400913          	li	s2,100
    pause(1);
    3974:	4a85                	li	s5,1
    wait(&xst);
    3976:	fbc40a13          	addi	s4,s0,-68
    if (xst != -1) {
    397a:	59fd                	li	s3,-1
    int pid1 = fork();
    397c:	319010ef          	jal	5494 <fork>
    3980:	84aa                	mv	s1,a0
    if (pid1 < 0) {
    3982:	02054663          	bltz	a0,39ae <killstatus+0x54>
    if (pid1 == 0) {
    3986:	cd15                	beqz	a0,39c2 <killstatus+0x68>
    pause(1);
    3988:	8556                	mv	a0,s5
    398a:	3a3010ef          	jal	552c <pause>
    kill(pid1);
    398e:	8526                	mv	a0,s1
    3990:	33d010ef          	jal	54cc <kill>
    wait(&xst);
    3994:	8552                	mv	a0,s4
    3996:	30f010ef          	jal	54a4 <wait>
    if (xst != -1) {
    399a:	fbc42783          	lw	a5,-68(s0)
    399e:	03379563          	bne	a5,s3,39c8 <killstatus+0x6e>
  for (int i = 0; i < 100; i++) {
    39a2:	397d                	addiw	s2,s2,-1
    39a4:	fc091ce3          	bnez	s2,397c <killstatus+0x22>
  exit(0);
    39a8:	4501                	li	a0,0
    39aa:	2f3010ef          	jal	549c <exit>
      printf("%s: fork failed\n", s);
    39ae:	85da                	mv	a1,s6
    39b0:	00003517          	auipc	a0,0x3
    39b4:	9e850513          	addi	a0,a0,-1560 # 6398 <malloc+0x9be>
    39b8:	76b010ef          	jal	5922 <printf>
      exit(1);
    39bc:	4505                	li	a0,1
    39be:	2df010ef          	jal	549c <exit>
        getpid();
    39c2:	35b010ef          	jal	551c <getpid>
      while (1) {
    39c6:	bff5                	j	39c2 <killstatus+0x68>
      printf("%s: status should be -1\n", s);
    39c8:	85da                	mv	a1,s6
    39ca:	00004517          	auipc	a0,0x4
    39ce:	cce50513          	addi	a0,a0,-818 # 7698 <malloc+0x1cbe>
    39d2:	751010ef          	jal	5922 <printf>
      exit(1);
    39d6:	4505                	li	a0,1
    39d8:	2c5010ef          	jal	549c <exit>

00000000000039dc <preempt>:
{
    39dc:	7139                	addi	sp,sp,-64
    39de:	fc06                	sd	ra,56(sp)
    39e0:	f822                	sd	s0,48(sp)
    39e2:	f426                	sd	s1,40(sp)
    39e4:	f04a                	sd	s2,32(sp)
    39e6:	ec4e                	sd	s3,24(sp)
    39e8:	e852                	sd	s4,16(sp)
    39ea:	0080                	addi	s0,sp,64
    39ec:	892a                	mv	s2,a0
  pid1 = fork();
    39ee:	2a7010ef          	jal	5494 <fork>
  if (pid1 < 0) {
    39f2:	00054563          	bltz	a0,39fc <preempt+0x20>
    39f6:	84aa                	mv	s1,a0
  if (pid1 == 0)
    39f8:	ed01                	bnez	a0,3a10 <preempt+0x34>
    for (;;)
    39fa:	a001                	j	39fa <preempt+0x1e>
    printf("%s: fork failed", s);
    39fc:	85ca                	mv	a1,s2
    39fe:	00003517          	auipc	a0,0x3
    3a02:	ada50513          	addi	a0,a0,-1318 # 64d8 <malloc+0xafe>
    3a06:	71d010ef          	jal	5922 <printf>
    exit(1);
    3a0a:	4505                	li	a0,1
    3a0c:	291010ef          	jal	549c <exit>
  pid2 = fork();
    3a10:	285010ef          	jal	5494 <fork>
    3a14:	89aa                	mv	s3,a0
  if (pid2 < 0) {
    3a16:	00054463          	bltz	a0,3a1e <preempt+0x42>
  if (pid2 == 0)
    3a1a:	ed01                	bnez	a0,3a32 <preempt+0x56>
    for (;;)
    3a1c:	a001                	j	3a1c <preempt+0x40>
    printf("%s: fork failed\n", s);
    3a1e:	85ca                	mv	a1,s2
    3a20:	00003517          	auipc	a0,0x3
    3a24:	97850513          	addi	a0,a0,-1672 # 6398 <malloc+0x9be>
    3a28:	6fb010ef          	jal	5922 <printf>
    exit(1);
    3a2c:	4505                	li	a0,1
    3a2e:	26f010ef          	jal	549c <exit>
  pipe(pfds);
    3a32:	fc840513          	addi	a0,s0,-56
    3a36:	277010ef          	jal	54ac <pipe>
  pid3 = fork();
    3a3a:	25b010ef          	jal	5494 <fork>
    3a3e:	8a2a                	mv	s4,a0
  if (pid3 < 0) {
    3a40:	02054863          	bltz	a0,3a70 <preempt+0x94>
  if (pid3 == 0) {
    3a44:	e921                	bnez	a0,3a94 <preempt+0xb8>
    close(pfds[0]);
    3a46:	fc842503          	lw	a0,-56(s0)
    3a4a:	27b010ef          	jal	54c4 <close>
    if (write(pfds[1], "x", 1) != 1)
    3a4e:	4605                	li	a2,1
    3a50:	00002597          	auipc	a1,0x2
    3a54:	12858593          	addi	a1,a1,296 # 5b78 <malloc+0x19e>
    3a58:	fcc42503          	lw	a0,-52(s0)
    3a5c:	261010ef          	jal	54bc <write>
    3a60:	4785                	li	a5,1
    3a62:	02f51163          	bne	a0,a5,3a84 <preempt+0xa8>
    close(pfds[1]);
    3a66:	fcc42503          	lw	a0,-52(s0)
    3a6a:	25b010ef          	jal	54c4 <close>
    for (;;)
    3a6e:	a001                	j	3a6e <preempt+0x92>
    printf("%s: fork failed\n", s);
    3a70:	85ca                	mv	a1,s2
    3a72:	00003517          	auipc	a0,0x3
    3a76:	92650513          	addi	a0,a0,-1754 # 6398 <malloc+0x9be>
    3a7a:	6a9010ef          	jal	5922 <printf>
    exit(1);
    3a7e:	4505                	li	a0,1
    3a80:	21d010ef          	jal	549c <exit>
      printf("%s: preempt write error", s);
    3a84:	85ca                	mv	a1,s2
    3a86:	00004517          	auipc	a0,0x4
    3a8a:	c3250513          	addi	a0,a0,-974 # 76b8 <malloc+0x1cde>
    3a8e:	695010ef          	jal	5922 <printf>
    3a92:	bfd1                	j	3a66 <preempt+0x8a>
  close(pfds[1]);
    3a94:	fcc42503          	lw	a0,-52(s0)
    3a98:	22d010ef          	jal	54c4 <close>
  if (read(pfds[0], buf, sizeof(buf)) != 1) {
    3a9c:	660d                	lui	a2,0x3
    3a9e:	0000a597          	auipc	a1,0xa
    3aa2:	24a58593          	addi	a1,a1,586 # dce8 <buf>
    3aa6:	fc842503          	lw	a0,-56(s0)
    3aaa:	20b010ef          	jal	54b4 <read>
    3aae:	4785                	li	a5,1
    3ab0:	02f50163          	beq	a0,a5,3ad2 <preempt+0xf6>
    printf("%s: preempt read error", s);
    3ab4:	85ca                	mv	a1,s2
    3ab6:	00004517          	auipc	a0,0x4
    3aba:	c1a50513          	addi	a0,a0,-998 # 76d0 <malloc+0x1cf6>
    3abe:	665010ef          	jal	5922 <printf>
}
    3ac2:	70e2                	ld	ra,56(sp)
    3ac4:	7442                	ld	s0,48(sp)
    3ac6:	74a2                	ld	s1,40(sp)
    3ac8:	7902                	ld	s2,32(sp)
    3aca:	69e2                	ld	s3,24(sp)
    3acc:	6a42                	ld	s4,16(sp)
    3ace:	6121                	addi	sp,sp,64
    3ad0:	8082                	ret
  close(pfds[0]);
    3ad2:	fc842503          	lw	a0,-56(s0)
    3ad6:	1ef010ef          	jal	54c4 <close>
  printf("kill... ");
    3ada:	00004517          	auipc	a0,0x4
    3ade:	c0e50513          	addi	a0,a0,-1010 # 76e8 <malloc+0x1d0e>
    3ae2:	641010ef          	jal	5922 <printf>
  kill(pid1);
    3ae6:	8526                	mv	a0,s1
    3ae8:	1e5010ef          	jal	54cc <kill>
  kill(pid2);
    3aec:	854e                	mv	a0,s3
    3aee:	1df010ef          	jal	54cc <kill>
  kill(pid3);
    3af2:	8552                	mv	a0,s4
    3af4:	1d9010ef          	jal	54cc <kill>
  printf("wait... ");
    3af8:	00004517          	auipc	a0,0x4
    3afc:	c0050513          	addi	a0,a0,-1024 # 76f8 <malloc+0x1d1e>
    3b00:	623010ef          	jal	5922 <printf>
  wait(0);
    3b04:	4501                	li	a0,0
    3b06:	19f010ef          	jal	54a4 <wait>
  wait(0);
    3b0a:	4501                	li	a0,0
    3b0c:	199010ef          	jal	54a4 <wait>
  wait(0);
    3b10:	4501                	li	a0,0
    3b12:	193010ef          	jal	54a4 <wait>
    3b16:	b775                	j	3ac2 <preempt+0xe6>

0000000000003b18 <reparent>:
{
    3b18:	7179                	addi	sp,sp,-48
    3b1a:	f406                	sd	ra,40(sp)
    3b1c:	f022                	sd	s0,32(sp)
    3b1e:	ec26                	sd	s1,24(sp)
    3b20:	e84a                	sd	s2,16(sp)
    3b22:	e44e                	sd	s3,8(sp)
    3b24:	e052                	sd	s4,0(sp)
    3b26:	1800                	addi	s0,sp,48
    3b28:	89aa                	mv	s3,a0
  int master_pid = getpid();
    3b2a:	1f3010ef          	jal	551c <getpid>
    3b2e:	8a2a                	mv	s4,a0
    3b30:	0c800913          	li	s2,200
    int pid = fork();
    3b34:	161010ef          	jal	5494 <fork>
    3b38:	84aa                	mv	s1,a0
    if (pid < 0) {
    3b3a:	00054e63          	bltz	a0,3b56 <reparent+0x3e>
    if (pid) {
    3b3e:	c121                	beqz	a0,3b7e <reparent+0x66>
      if (wait(0) != pid) {
    3b40:	4501                	li	a0,0
    3b42:	163010ef          	jal	54a4 <wait>
    3b46:	02951263          	bne	a0,s1,3b6a <reparent+0x52>
  for (int i = 0; i < 200; i++) {
    3b4a:	397d                	addiw	s2,s2,-1
    3b4c:	fe0914e3          	bnez	s2,3b34 <reparent+0x1c>
  exit(0);
    3b50:	4501                	li	a0,0
    3b52:	14b010ef          	jal	549c <exit>
      printf("%s: fork failed\n", s);
    3b56:	85ce                	mv	a1,s3
    3b58:	00003517          	auipc	a0,0x3
    3b5c:	84050513          	addi	a0,a0,-1984 # 6398 <malloc+0x9be>
    3b60:	5c3010ef          	jal	5922 <printf>
      exit(1);
    3b64:	4505                	li	a0,1
    3b66:	137010ef          	jal	549c <exit>
        printf("%s: wait wrong pid\n", s);
    3b6a:	85ce                	mv	a1,s3
    3b6c:	00003517          	auipc	a0,0x3
    3b70:	93450513          	addi	a0,a0,-1740 # 64a0 <malloc+0xac6>
    3b74:	5af010ef          	jal	5922 <printf>
        exit(1);
    3b78:	4505                	li	a0,1
    3b7a:	123010ef          	jal	549c <exit>
      int pid2 = fork();
    3b7e:	117010ef          	jal	5494 <fork>
      if (pid2 < 0) {
    3b82:	00054563          	bltz	a0,3b8c <reparent+0x74>
      exit(0);
    3b86:	4501                	li	a0,0
    3b88:	115010ef          	jal	549c <exit>
        kill(master_pid);
    3b8c:	8552                	mv	a0,s4
    3b8e:	13f010ef          	jal	54cc <kill>
        exit(1);
    3b92:	4505                	li	a0,1
    3b94:	109010ef          	jal	549c <exit>

0000000000003b98 <sbrkfail>:
{
    3b98:	7175                	addi	sp,sp,-144
    3b9a:	e506                	sd	ra,136(sp)
    3b9c:	e122                	sd	s0,128(sp)
    3b9e:	fca6                	sd	s1,120(sp)
    3ba0:	f8ca                	sd	s2,112(sp)
    3ba2:	f4ce                	sd	s3,104(sp)
    3ba4:	f0d2                	sd	s4,96(sp)
    3ba6:	ecd6                	sd	s5,88(sp)
    3ba8:	e8da                	sd	s6,80(sp)
    3baa:	e4de                	sd	s7,72(sp)
    3bac:	e0e2                	sd	s8,64(sp)
    3bae:	0900                	addi	s0,sp,144
    3bb0:	8c2a                	mv	s8,a0
  if (pipe(fds) != 0) {
    3bb2:	fa040513          	addi	a0,s0,-96
    3bb6:	0f7010ef          	jal	54ac <pipe>
    3bba:	ed01                	bnez	a0,3bd2 <sbrkfail+0x3a>
    3bbc:	8baa                	mv	s7,a0
    3bbe:	f7040493          	addi	s1,s0,-144
    3bc2:	f9840993          	addi	s3,s0,-104
    3bc6:	8926                	mv	s2,s1
    if (pids[i] != -1) {
    3bc8:	5a7d                	li	s4,-1
      read(fds[0], &scratch, 1);
    3bca:	f9f40b13          	addi	s6,s0,-97
    3bce:	4a85                	li	s5,1
    3bd0:	a095                	j	3c34 <sbrkfail+0x9c>
    printf("%s: pipe() failed\n", s);
    3bd2:	85e2                	mv	a1,s8
    3bd4:	00003517          	auipc	a0,0x3
    3bd8:	84c50513          	addi	a0,a0,-1972 # 6420 <malloc+0xa46>
    3bdc:	547010ef          	jal	5922 <printf>
    exit(1);
    3be0:	4505                	li	a0,1
    3be2:	0bb010ef          	jal	549c <exit>
      if (sbrk(BIG - (uint64)sbrk(0)) == (char *)SBRK_ERROR)
    3be6:	083010ef          	jal	5468 <sbrk>
    3bea:	064007b7          	lui	a5,0x6400
    3bee:	40a7853b          	subw	a0,a5,a0
    3bf2:	077010ef          	jal	5468 <sbrk>
    3bf6:	57fd                	li	a5,-1
    3bf8:	02f50163          	beq	a0,a5,3c1a <sbrkfail+0x82>
        write(fds[1], "1", 1);
    3bfc:	4605                	li	a2,1
    3bfe:	00004597          	auipc	a1,0x4
    3c02:	3fa58593          	addi	a1,a1,1018 # 7ff8 <malloc+0x261e>
    3c06:	fa442503          	lw	a0,-92(s0)
    3c0a:	0b3010ef          	jal	54bc <write>
        pause(1000);
    3c0e:	3e800493          	li	s1,1000
    3c12:	8526                	mv	a0,s1
    3c14:	119010ef          	jal	552c <pause>
      for (;;)
    3c18:	bfed                	j	3c12 <sbrkfail+0x7a>
        write(fds[1], "0", 1);
    3c1a:	4605                	li	a2,1
    3c1c:	00004597          	auipc	a1,0x4
    3c20:	aec58593          	addi	a1,a1,-1300 # 7708 <malloc+0x1d2e>
    3c24:	fa442503          	lw	a0,-92(s0)
    3c28:	095010ef          	jal	54bc <write>
    3c2c:	b7cd                	j	3c0e <sbrkfail+0x76>
  for (i = 0; i < sizeof(pids) / sizeof(pids[0]); i++) {
    3c2e:	0911                	addi	s2,s2,4
    3c30:	03390a63          	beq	s2,s3,3c64 <sbrkfail+0xcc>
    if ((pids[i] = fork()) == 0) {
    3c34:	061010ef          	jal	5494 <fork>
    3c38:	00a92023          	sw	a0,0(s2)
    3c3c:	d54d                	beqz	a0,3be6 <sbrkfail+0x4e>
    if (pids[i] != -1) {
    3c3e:	ff4508e3          	beq	a0,s4,3c2e <sbrkfail+0x96>
      read(fds[0], &scratch, 1);
    3c42:	8656                	mv	a2,s5
    3c44:	85da                	mv	a1,s6
    3c46:	fa042503          	lw	a0,-96(s0)
    3c4a:	06b010ef          	jal	54b4 <read>
      if (scratch == '0')
    3c4e:	f9f44783          	lbu	a5,-97(s0)
    3c52:	fd078793          	addi	a5,a5,-48 # 63fffd0 <base+0x63ef2e8>
    3c56:	0017b793          	seqz	a5,a5
    3c5a:	00fbe7b3          	or	a5,s7,a5
    3c5e:	00078b9b          	sext.w	s7,a5
    3c62:	b7f1                	j	3c2e <sbrkfail+0x96>
  if (!failed) {
    3c64:	000b8863          	beqz	s7,3c74 <sbrkfail+0xdc>
  c = sbrk(PGSIZE);
    3c68:	6505                	lui	a0,0x1
    3c6a:	7fe010ef          	jal	5468 <sbrk>
    3c6e:	8a2a                	mv	s4,a0
    if (pids[i] == -1)
    3c70:	597d                	li	s2,-1
    3c72:	a821                	j	3c8a <sbrkfail+0xf2>
    printf("%s: no allocation failed; allocate more?\n", s);
    3c74:	85e2                	mv	a1,s8
    3c76:	00004517          	auipc	a0,0x4
    3c7a:	a9a50513          	addi	a0,a0,-1382 # 7710 <malloc+0x1d36>
    3c7e:	4a5010ef          	jal	5922 <printf>
    3c82:	b7dd                	j	3c68 <sbrkfail+0xd0>
  for (i = 0; i < sizeof(pids) / sizeof(pids[0]); i++) {
    3c84:	0491                	addi	s1,s1,4
    3c86:	01348b63          	beq	s1,s3,3c9c <sbrkfail+0x104>
    if (pids[i] == -1)
    3c8a:	4088                	lw	a0,0(s1)
    3c8c:	ff250ce3          	beq	a0,s2,3c84 <sbrkfail+0xec>
    kill(pids[i]);
    3c90:	03d010ef          	jal	54cc <kill>
    wait(0);
    3c94:	4501                	li	a0,0
    3c96:	00f010ef          	jal	54a4 <wait>
    3c9a:	b7ed                	j	3c84 <sbrkfail+0xec>
  if (c == (char *)SBRK_ERROR) {
    3c9c:	57fd                	li	a5,-1
    3c9e:	02fa0a63          	beq	s4,a5,3cd2 <sbrkfail+0x13a>
  pid = fork();
    3ca2:	7f2010ef          	jal	5494 <fork>
  if (pid < 0) {
    3ca6:	04054063          	bltz	a0,3ce6 <sbrkfail+0x14e>
  if (pid == 0) {
    3caa:	e939                	bnez	a0,3d00 <sbrkfail+0x168>
    a = sbrk(10 * BIG);
    3cac:	3e800537          	lui	a0,0x3e800
    3cb0:	7b8010ef          	jal	5468 <sbrk>
    if (a == (char *)SBRK_ERROR) {
    3cb4:	57fd                	li	a5,-1
    3cb6:	04f50263          	beq	a0,a5,3cfa <sbrkfail+0x162>
    printf("%s: allocate a lot of memory succeeded %d\n", s, 10 * BIG);
    3cba:	3e800637          	lui	a2,0x3e800
    3cbe:	85e2                	mv	a1,s8
    3cc0:	00004517          	auipc	a0,0x4
    3cc4:	aa050513          	addi	a0,a0,-1376 # 7760 <malloc+0x1d86>
    3cc8:	45b010ef          	jal	5922 <printf>
    exit(1);
    3ccc:	4505                	li	a0,1
    3cce:	7ce010ef          	jal	549c <exit>
    printf("%s: failed sbrk leaked memory\n", s);
    3cd2:	85e2                	mv	a1,s8
    3cd4:	00004517          	auipc	a0,0x4
    3cd8:	a6c50513          	addi	a0,a0,-1428 # 7740 <malloc+0x1d66>
    3cdc:	447010ef          	jal	5922 <printf>
    exit(1);
    3ce0:	4505                	li	a0,1
    3ce2:	7ba010ef          	jal	549c <exit>
    printf("%s: fork failed\n", s);
    3ce6:	85e2                	mv	a1,s8
    3ce8:	00002517          	auipc	a0,0x2
    3cec:	6b050513          	addi	a0,a0,1712 # 6398 <malloc+0x9be>
    3cf0:	433010ef          	jal	5922 <printf>
    exit(1);
    3cf4:	4505                	li	a0,1
    3cf6:	7a6010ef          	jal	549c <exit>
      exit(0);
    3cfa:	4501                	li	a0,0
    3cfc:	7a0010ef          	jal	549c <exit>
  wait(&xstatus);
    3d00:	fac40513          	addi	a0,s0,-84
    3d04:	7a0010ef          	jal	54a4 <wait>
  if (xstatus != 0)
    3d08:	fac42783          	lw	a5,-84(s0)
    3d0c:	ef89                	bnez	a5,3d26 <sbrkfail+0x18e>
}
    3d0e:	60aa                	ld	ra,136(sp)
    3d10:	640a                	ld	s0,128(sp)
    3d12:	74e6                	ld	s1,120(sp)
    3d14:	7946                	ld	s2,112(sp)
    3d16:	79a6                	ld	s3,104(sp)
    3d18:	7a06                	ld	s4,96(sp)
    3d1a:	6ae6                	ld	s5,88(sp)
    3d1c:	6b46                	ld	s6,80(sp)
    3d1e:	6ba6                	ld	s7,72(sp)
    3d20:	6c06                	ld	s8,64(sp)
    3d22:	6149                	addi	sp,sp,144
    3d24:	8082                	ret
    exit(1);
    3d26:	4505                	li	a0,1
    3d28:	774010ef          	jal	549c <exit>

0000000000003d2c <mem>:
{
    3d2c:	7139                	addi	sp,sp,-64
    3d2e:	fc06                	sd	ra,56(sp)
    3d30:	f822                	sd	s0,48(sp)
    3d32:	f426                	sd	s1,40(sp)
    3d34:	f04a                	sd	s2,32(sp)
    3d36:	ec4e                	sd	s3,24(sp)
    3d38:	0080                	addi	s0,sp,64
    3d3a:	89aa                	mv	s3,a0
  if ((pid = fork()) == 0) {
    3d3c:	758010ef          	jal	5494 <fork>
    m1 = 0;
    3d40:	4481                	li	s1,0
    while ((m2 = malloc(10001)) != 0) {
    3d42:	6909                	lui	s2,0x2
    3d44:	71190913          	addi	s2,s2,1809 # 2711 <fourteen+0xed>
  if ((pid = fork()) == 0) {
    3d48:	cd11                	beqz	a0,3d64 <mem+0x38>
    wait(&xstatus);
    3d4a:	fcc40513          	addi	a0,s0,-52
    3d4e:	756010ef          	jal	54a4 <wait>
    if (xstatus == -1) {
    3d52:	fcc42503          	lw	a0,-52(s0)
    3d56:	57fd                	li	a5,-1
    3d58:	04f50363          	beq	a0,a5,3d9e <mem+0x72>
    exit(xstatus);
    3d5c:	740010ef          	jal	549c <exit>
      *(char **)m2 = m1;
    3d60:	e104                	sd	s1,0(a0)
      m1 = m2;
    3d62:	84aa                	mv	s1,a0
    while ((m2 = malloc(10001)) != 0) {
    3d64:	854a                	mv	a0,s2
    3d66:	475010ef          	jal	59da <malloc>
    3d6a:	f97d                	bnez	a0,3d60 <mem+0x34>
    while (m1) {
    3d6c:	c491                	beqz	s1,3d78 <mem+0x4c>
      m2 = *(char **)m1;
    3d6e:	8526                	mv	a0,s1
    3d70:	6084                	ld	s1,0(s1)
      free(m1);
    3d72:	3e3010ef          	jal	5954 <free>
    while (m1) {
    3d76:	fce5                	bnez	s1,3d6e <mem+0x42>
    m1 = malloc(1024 * 20);
    3d78:	6515                	lui	a0,0x5
    3d7a:	461010ef          	jal	59da <malloc>
    if (m1 == 0) {
    3d7e:	c511                	beqz	a0,3d8a <mem+0x5e>
    free(m1);
    3d80:	3d5010ef          	jal	5954 <free>
    exit(0);
    3d84:	4501                	li	a0,0
    3d86:	716010ef          	jal	549c <exit>
      printf("%s: couldn't allocate mem?!!\n", s);
    3d8a:	85ce                	mv	a1,s3
    3d8c:	00004517          	auipc	a0,0x4
    3d90:	a0450513          	addi	a0,a0,-1532 # 7790 <malloc+0x1db6>
    3d94:	38f010ef          	jal	5922 <printf>
      exit(1);
    3d98:	4505                	li	a0,1
    3d9a:	702010ef          	jal	549c <exit>
      exit(0);
    3d9e:	4501                	li	a0,0
    3da0:	6fc010ef          	jal	549c <exit>

0000000000003da4 <sharedfd>:
{
    3da4:	7159                	addi	sp,sp,-112
    3da6:	f486                	sd	ra,104(sp)
    3da8:	f0a2                	sd	s0,96(sp)
    3daa:	eca6                	sd	s1,88(sp)
    3dac:	f85a                	sd	s6,48(sp)
    3dae:	1880                	addi	s0,sp,112
    3db0:	84aa                	mv	s1,a0
    3db2:	8b2a                	mv	s6,a0
  unlink("sharedfd");
    3db4:	00004517          	auipc	a0,0x4
    3db8:	9fc50513          	addi	a0,a0,-1540 # 77b0 <malloc+0x1dd6>
    3dbc:	730010ef          	jal	54ec <unlink>
  fd = open("sharedfd", O_CREATE | O_RDWR);
    3dc0:	20200593          	li	a1,514
    3dc4:	00004517          	auipc	a0,0x4
    3dc8:	9ec50513          	addi	a0,a0,-1556 # 77b0 <malloc+0x1dd6>
    3dcc:	710010ef          	jal	54dc <open>
  if (fd < 0) {
    3dd0:	04054863          	bltz	a0,3e20 <sharedfd+0x7c>
    3dd4:	e8ca                	sd	s2,80(sp)
    3dd6:	e4ce                	sd	s3,72(sp)
    3dd8:	e0d2                	sd	s4,64(sp)
    3dda:	fc56                	sd	s5,56(sp)
    3ddc:	89aa                	mv	s3,a0
  pid = fork();
    3dde:	6b6010ef          	jal	5494 <fork>
    3de2:	8aaa                	mv	s5,a0
  memset(buf, pid == 0 ? 'c' : 'p', sizeof(buf));
    3de4:	07000593          	li	a1,112
    3de8:	e119                	bnez	a0,3dee <sharedfd+0x4a>
    3dea:	06300593          	li	a1,99
    3dee:	4629                	li	a2,10
    3df0:	fa040513          	addi	a0,s0,-96
    3df4:	47e010ef          	jal	5272 <memset>
    3df8:	3e800493          	li	s1,1000
    if (write(fd, buf, sizeof(buf)) != sizeof(buf)) {
    3dfc:	fa040a13          	addi	s4,s0,-96
    3e00:	4929                	li	s2,10
    3e02:	864a                	mv	a2,s2
    3e04:	85d2                	mv	a1,s4
    3e06:	854e                	mv	a0,s3
    3e08:	6b4010ef          	jal	54bc <write>
    3e0c:	03251963          	bne	a0,s2,3e3e <sharedfd+0x9a>
  for (i = 0; i < N; i++) {
    3e10:	34fd                	addiw	s1,s1,-1
    3e12:	f8e5                	bnez	s1,3e02 <sharedfd+0x5e>
  if (pid == 0) {
    3e14:	040a9063          	bnez	s5,3e54 <sharedfd+0xb0>
    3e18:	f45e                	sd	s7,40(sp)
    exit(0);
    3e1a:	4501                	li	a0,0
    3e1c:	680010ef          	jal	549c <exit>
    3e20:	e8ca                	sd	s2,80(sp)
    3e22:	e4ce                	sd	s3,72(sp)
    3e24:	e0d2                	sd	s4,64(sp)
    3e26:	fc56                	sd	s5,56(sp)
    3e28:	f45e                	sd	s7,40(sp)
    printf("%s: cannot open sharedfd for writing", s);
    3e2a:	85a6                	mv	a1,s1
    3e2c:	00004517          	auipc	a0,0x4
    3e30:	99450513          	addi	a0,a0,-1644 # 77c0 <malloc+0x1de6>
    3e34:	2ef010ef          	jal	5922 <printf>
    exit(1);
    3e38:	4505                	li	a0,1
    3e3a:	662010ef          	jal	549c <exit>
    3e3e:	f45e                	sd	s7,40(sp)
      printf("%s: write sharedfd failed\n", s);
    3e40:	85da                	mv	a1,s6
    3e42:	00004517          	auipc	a0,0x4
    3e46:	9a650513          	addi	a0,a0,-1626 # 77e8 <malloc+0x1e0e>
    3e4a:	2d9010ef          	jal	5922 <printf>
      exit(1);
    3e4e:	4505                	li	a0,1
    3e50:	64c010ef          	jal	549c <exit>
    wait(&xstatus);
    3e54:	f9c40513          	addi	a0,s0,-100
    3e58:	64c010ef          	jal	54a4 <wait>
    if (xstatus != 0)
    3e5c:	f9c42a03          	lw	s4,-100(s0)
    3e60:	000a0663          	beqz	s4,3e6c <sharedfd+0xc8>
    3e64:	f45e                	sd	s7,40(sp)
      exit(xstatus);
    3e66:	8552                	mv	a0,s4
    3e68:	634010ef          	jal	549c <exit>
    3e6c:	f45e                	sd	s7,40(sp)
  close(fd);
    3e6e:	854e                	mv	a0,s3
    3e70:	654010ef          	jal	54c4 <close>
  fd = open("sharedfd", 0);
    3e74:	4581                	li	a1,0
    3e76:	00004517          	auipc	a0,0x4
    3e7a:	93a50513          	addi	a0,a0,-1734 # 77b0 <malloc+0x1dd6>
    3e7e:	65e010ef          	jal	54dc <open>
    3e82:	8baa                	mv	s7,a0
  nc = np = 0;
    3e84:	89d2                	mv	s3,s4
  if (fd < 0) {
    3e86:	02054363          	bltz	a0,3eac <sharedfd+0x108>
    3e8a:	faa40913          	addi	s2,s0,-86
      if (buf[i] == 'c')
    3e8e:	06300493          	li	s1,99
      if (buf[i] == 'p')
    3e92:	07000a93          	li	s5,112
  while ((n = read(fd, buf, sizeof(buf))) > 0) {
    3e96:	4629                	li	a2,10
    3e98:	fa040593          	addi	a1,s0,-96
    3e9c:	855e                	mv	a0,s7
    3e9e:	616010ef          	jal	54b4 <read>
    3ea2:	02a05b63          	blez	a0,3ed8 <sharedfd+0x134>
    3ea6:	fa040793          	addi	a5,s0,-96
    3eaa:	a839                	j	3ec8 <sharedfd+0x124>
    printf("%s: cannot open sharedfd for reading\n", s);
    3eac:	85da                	mv	a1,s6
    3eae:	00004517          	auipc	a0,0x4
    3eb2:	95a50513          	addi	a0,a0,-1702 # 7808 <malloc+0x1e2e>
    3eb6:	26d010ef          	jal	5922 <printf>
    exit(1);
    3eba:	4505                	li	a0,1
    3ebc:	5e0010ef          	jal	549c <exit>
        nc++;
    3ec0:	2a05                	addiw	s4,s4,1
    for (i = 0; i < sizeof(buf); i++) {
    3ec2:	0785                	addi	a5,a5,1
    3ec4:	fd2789e3          	beq	a5,s2,3e96 <sharedfd+0xf2>
      if (buf[i] == 'c')
    3ec8:	0007c703          	lbu	a4,0(a5)
    3ecc:	fe970ae3          	beq	a4,s1,3ec0 <sharedfd+0x11c>
      if (buf[i] == 'p')
    3ed0:	ff5719e3          	bne	a4,s5,3ec2 <sharedfd+0x11e>
        np++;
    3ed4:	2985                	addiw	s3,s3,1
    3ed6:	b7f5                	j	3ec2 <sharedfd+0x11e>
  close(fd);
    3ed8:	855e                	mv	a0,s7
    3eda:	5ea010ef          	jal	54c4 <close>
  unlink("sharedfd");
    3ede:	00004517          	auipc	a0,0x4
    3ee2:	8d250513          	addi	a0,a0,-1838 # 77b0 <malloc+0x1dd6>
    3ee6:	606010ef          	jal	54ec <unlink>
  if (nc == N * SZ && np == N * SZ) {
    3eea:	6789                	lui	a5,0x2
    3eec:	71078793          	addi	a5,a5,1808 # 2710 <fourteen+0xec>
    3ef0:	00fa1763          	bne	s4,a5,3efe <sharedfd+0x15a>
    3ef4:	01499563          	bne	s3,s4,3efe <sharedfd+0x15a>
    exit(0);
    3ef8:	4501                	li	a0,0
    3efa:	5a2010ef          	jal	549c <exit>
    printf("%s: nc/np test fails\n", s);
    3efe:	85da                	mv	a1,s6
    3f00:	00004517          	auipc	a0,0x4
    3f04:	93050513          	addi	a0,a0,-1744 # 7830 <malloc+0x1e56>
    3f08:	21b010ef          	jal	5922 <printf>
    exit(1);
    3f0c:	4505                	li	a0,1
    3f0e:	58e010ef          	jal	549c <exit>

0000000000003f12 <fourfiles>:
{
    3f12:	7135                	addi	sp,sp,-160
    3f14:	ed06                	sd	ra,152(sp)
    3f16:	e922                	sd	s0,144(sp)
    3f18:	e526                	sd	s1,136(sp)
    3f1a:	e14a                	sd	s2,128(sp)
    3f1c:	fcce                	sd	s3,120(sp)
    3f1e:	f8d2                	sd	s4,112(sp)
    3f20:	f4d6                	sd	s5,104(sp)
    3f22:	f0da                	sd	s6,96(sp)
    3f24:	ecde                	sd	s7,88(sp)
    3f26:	e8e2                	sd	s8,80(sp)
    3f28:	e4e6                	sd	s9,72(sp)
    3f2a:	e0ea                	sd	s10,64(sp)
    3f2c:	fc6e                	sd	s11,56(sp)
    3f2e:	1100                	addi	s0,sp,160
    3f30:	8caa                	mv	s9,a0
  char *names[] = {"f0", "f1", "f2", "f3"};
    3f32:	00004797          	auipc	a5,0x4
    3f36:	91678793          	addi	a5,a5,-1770 # 7848 <malloc+0x1e6e>
    3f3a:	f6f43823          	sd	a5,-144(s0)
    3f3e:	00004797          	auipc	a5,0x4
    3f42:	91278793          	addi	a5,a5,-1774 # 7850 <malloc+0x1e76>
    3f46:	f6f43c23          	sd	a5,-136(s0)
    3f4a:	00004797          	auipc	a5,0x4
    3f4e:	90e78793          	addi	a5,a5,-1778 # 7858 <malloc+0x1e7e>
    3f52:	f8f43023          	sd	a5,-128(s0)
    3f56:	00004797          	auipc	a5,0x4
    3f5a:	90a78793          	addi	a5,a5,-1782 # 7860 <malloc+0x1e86>
    3f5e:	f8f43423          	sd	a5,-120(s0)
  for (pi = 0; pi < NCHILD; pi++) {
    3f62:	f7040b93          	addi	s7,s0,-144
  char *names[] = {"f0", "f1", "f2", "f3"};
    3f66:	895e                	mv	s2,s7
  for (pi = 0; pi < NCHILD; pi++) {
    3f68:	4481                	li	s1,0
    3f6a:	4a11                	li	s4,4
    fname = names[pi];
    3f6c:	00093983          	ld	s3,0(s2)
    unlink(fname);
    3f70:	854e                	mv	a0,s3
    3f72:	57a010ef          	jal	54ec <unlink>
    pid = fork();
    3f76:	51e010ef          	jal	5494 <fork>
    if (pid < 0) {
    3f7a:	04054063          	bltz	a0,3fba <fourfiles+0xa8>
    if (pid == 0) {
    3f7e:	c921                	beqz	a0,3fce <fourfiles+0xbc>
  for (pi = 0; pi < NCHILD; pi++) {
    3f80:	2485                	addiw	s1,s1,1
    3f82:	0921                	addi	s2,s2,8
    3f84:	ff4494e3          	bne	s1,s4,3f6c <fourfiles+0x5a>
    3f88:	4491                	li	s1,4
    wait(&xstatus);
    3f8a:	f6c40913          	addi	s2,s0,-148
    3f8e:	854a                	mv	a0,s2
    3f90:	514010ef          	jal	54a4 <wait>
    if (xstatus != 0)
    3f94:	f6c42b03          	lw	s6,-148(s0)
    3f98:	0a0b1463          	bnez	s6,4040 <fourfiles+0x12e>
  for (pi = 0; pi < NCHILD; pi++) {
    3f9c:	34fd                	addiw	s1,s1,-1
    3f9e:	f8e5                	bnez	s1,3f8e <fourfiles+0x7c>
    3fa0:	03000493          	li	s1,48
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    3fa4:	6a8d                	lui	s5,0x3
    3fa6:	0000aa17          	auipc	s4,0xa
    3faa:	d42a0a13          	addi	s4,s4,-702 # dce8 <buf>
    if (total != N * SZ) {
    3fae:	6d05                	lui	s10,0x1
    3fb0:	770d0d13          	addi	s10,s10,1904 # 1770 <createdelete+0x20>
  for (i = 0; i < NCHILD; i++) {
    3fb4:	03400d93          	li	s11,52
    3fb8:	a86d                	j	4072 <fourfiles+0x160>
      printf("%s: fork failed\n", s);
    3fba:	85e6                	mv	a1,s9
    3fbc:	00002517          	auipc	a0,0x2
    3fc0:	3dc50513          	addi	a0,a0,988 # 6398 <malloc+0x9be>
    3fc4:	15f010ef          	jal	5922 <printf>
      exit(1);
    3fc8:	4505                	li	a0,1
    3fca:	4d2010ef          	jal	549c <exit>
      fd = open(fname, O_CREATE | O_RDWR);
    3fce:	20200593          	li	a1,514
    3fd2:	854e                	mv	a0,s3
    3fd4:	508010ef          	jal	54dc <open>
    3fd8:	892a                	mv	s2,a0
      if (fd < 0) {
    3fda:	04054063          	bltz	a0,401a <fourfiles+0x108>
      memset(buf, '0' + pi, SZ);
    3fde:	1f400613          	li	a2,500
    3fe2:	0304859b          	addiw	a1,s1,48
    3fe6:	0000a517          	auipc	a0,0xa
    3fea:	d0250513          	addi	a0,a0,-766 # dce8 <buf>
    3fee:	284010ef          	jal	5272 <memset>
    3ff2:	44b1                	li	s1,12
        if ((n = write(fd, buf, SZ)) != SZ) {
    3ff4:	1f400993          	li	s3,500
    3ff8:	0000aa17          	auipc	s4,0xa
    3ffc:	cf0a0a13          	addi	s4,s4,-784 # dce8 <buf>
    4000:	864e                	mv	a2,s3
    4002:	85d2                	mv	a1,s4
    4004:	854a                	mv	a0,s2
    4006:	4b6010ef          	jal	54bc <write>
    400a:	85aa                	mv	a1,a0
    400c:	03351163          	bne	a0,s3,402e <fourfiles+0x11c>
      for (i = 0; i < N; i++) {
    4010:	34fd                	addiw	s1,s1,-1
    4012:	f4fd                	bnez	s1,4000 <fourfiles+0xee>
      exit(0);
    4014:	4501                	li	a0,0
    4016:	486010ef          	jal	549c <exit>
        printf("%s: create failed\n", s);
    401a:	85e6                	mv	a1,s9
    401c:	00002517          	auipc	a0,0x2
    4020:	4ec50513          	addi	a0,a0,1260 # 6508 <malloc+0xb2e>
    4024:	0ff010ef          	jal	5922 <printf>
        exit(1);
    4028:	4505                	li	a0,1
    402a:	472010ef          	jal	549c <exit>
          printf("write failed %d\n", n);
    402e:	00004517          	auipc	a0,0x4
    4032:	83a50513          	addi	a0,a0,-1990 # 7868 <malloc+0x1e8e>
    4036:	0ed010ef          	jal	5922 <printf>
          exit(1);
    403a:	4505                	li	a0,1
    403c:	460010ef          	jal	549c <exit>
      exit(xstatus);
    4040:	855a                	mv	a0,s6
    4042:	45a010ef          	jal	549c <exit>
          printf("%s: wrong char\n", s);
    4046:	85e6                	mv	a1,s9
    4048:	00004517          	auipc	a0,0x4
    404c:	83850513          	addi	a0,a0,-1992 # 7880 <malloc+0x1ea6>
    4050:	0d3010ef          	jal	5922 <printf>
          exit(1);
    4054:	4505                	li	a0,1
    4056:	446010ef          	jal	549c <exit>
    close(fd);
    405a:	854e                	mv	a0,s3
    405c:	468010ef          	jal	54c4 <close>
    if (total != N * SZ) {
    4060:	05a91863          	bne	s2,s10,40b0 <fourfiles+0x19e>
    unlink(fname);
    4064:	8562                	mv	a0,s8
    4066:	486010ef          	jal	54ec <unlink>
  for (i = 0; i < NCHILD; i++) {
    406a:	0ba1                	addi	s7,s7,8
    406c:	2485                	addiw	s1,s1,1
    406e:	05b48b63          	beq	s1,s11,40c4 <fourfiles+0x1b2>
    fname = names[i];
    4072:	000bbc03          	ld	s8,0(s7)
    fd = open(fname, 0);
    4076:	4581                	li	a1,0
    4078:	8562                	mv	a0,s8
    407a:	462010ef          	jal	54dc <open>
    407e:	89aa                	mv	s3,a0
    total = 0;
    4080:	895a                	mv	s2,s6
    while ((n = read(fd, buf, sizeof(buf))) > 0) {
    4082:	8656                	mv	a2,s5
    4084:	85d2                	mv	a1,s4
    4086:	854e                	mv	a0,s3
    4088:	42c010ef          	jal	54b4 <read>
    408c:	fca057e3          	blez	a0,405a <fourfiles+0x148>
    4090:	0000a797          	auipc	a5,0xa
    4094:	c5878793          	addi	a5,a5,-936 # dce8 <buf>
    4098:	00f506b3          	add	a3,a0,a5
        if (buf[j] != '0' + i) {
    409c:	0007c703          	lbu	a4,0(a5)
    40a0:	fa9713e3          	bne	a4,s1,4046 <fourfiles+0x134>
      for (j = 0; j < n; j++) {
    40a4:	0785                	addi	a5,a5,1
    40a6:	fed79be3          	bne	a5,a3,409c <fourfiles+0x18a>
      total += n;
    40aa:	00a9093b          	addw	s2,s2,a0
    40ae:	bfd1                	j	4082 <fourfiles+0x170>
      printf("wrong length %d\n", total);
    40b0:	85ca                	mv	a1,s2
    40b2:	00003517          	auipc	a0,0x3
    40b6:	7de50513          	addi	a0,a0,2014 # 7890 <malloc+0x1eb6>
    40ba:	069010ef          	jal	5922 <printf>
      exit(1);
    40be:	4505                	li	a0,1
    40c0:	3dc010ef          	jal	549c <exit>
}
    40c4:	60ea                	ld	ra,152(sp)
    40c6:	644a                	ld	s0,144(sp)
    40c8:	64aa                	ld	s1,136(sp)
    40ca:	690a                	ld	s2,128(sp)
    40cc:	79e6                	ld	s3,120(sp)
    40ce:	7a46                	ld	s4,112(sp)
    40d0:	7aa6                	ld	s5,104(sp)
    40d2:	7b06                	ld	s6,96(sp)
    40d4:	6be6                	ld	s7,88(sp)
    40d6:	6c46                	ld	s8,80(sp)
    40d8:	6ca6                	ld	s9,72(sp)
    40da:	6d06                	ld	s10,64(sp)
    40dc:	7de2                	ld	s11,56(sp)
    40de:	610d                	addi	sp,sp,160
    40e0:	8082                	ret

00000000000040e2 <concreate>:
{
    40e2:	7171                	addi	sp,sp,-176
    40e4:	f506                	sd	ra,168(sp)
    40e6:	f122                	sd	s0,160(sp)
    40e8:	ed26                	sd	s1,152(sp)
    40ea:	e94a                	sd	s2,144(sp)
    40ec:	e54e                	sd	s3,136(sp)
    40ee:	e152                	sd	s4,128(sp)
    40f0:	fcd6                	sd	s5,120(sp)
    40f2:	f8da                	sd	s6,112(sp)
    40f4:	f4de                	sd	s7,104(sp)
    40f6:	f0e2                	sd	s8,96(sp)
    40f8:	ece6                	sd	s9,88(sp)
    40fa:	e8ea                	sd	s10,80(sp)
    40fc:	1900                	addi	s0,sp,176
    40fe:	8d2a                	mv	s10,a0
  file[0] = 'C';
    4100:	04300793          	li	a5,67
    4104:	f8f40c23          	sb	a5,-104(s0)
  file[2] = '\0';
    4108:	f8040d23          	sb	zero,-102(s0)
  for (i = 0; i < N; i++) {
    410c:	4901                	li	s2,0
    unlink(file);
    410e:	f9840993          	addi	s3,s0,-104
    if (pid && (i % 3) == 1) {
    4112:	55555b37          	lui	s6,0x55555
    4116:	556b0b13          	addi	s6,s6,1366 # 55555556 <base+0x5554486e>
    411a:	4b85                	li	s7,1
      fd = open(file, O_CREATE | O_RDWR);
    411c:	20200c13          	li	s8,514
      link("C0", file);
    4120:	00003c97          	auipc	s9,0x3
    4124:	788c8c93          	addi	s9,s9,1928 # 78a8 <malloc+0x1ece>
      wait(&xstatus);
    4128:	f5c40a93          	addi	s5,s0,-164
  for (i = 0; i < N; i++) {
    412c:	02800a13          	li	s4,40
    4130:	ac25                	j	4368 <concreate+0x286>
      link("C0", file);
    4132:	85ce                	mv	a1,s3
    4134:	8566                	mv	a0,s9
    4136:	3c6010ef          	jal	54fc <link>
    if (pid == 0) {
    413a:	ac29                	j	4354 <concreate+0x272>
    } else if (pid == 0 && (i % 5) == 1) {
    413c:	666667b7          	lui	a5,0x66666
    4140:	66778793          	addi	a5,a5,1639 # 66666667 <base+0x6665597f>
    4144:	02f907b3          	mul	a5,s2,a5
    4148:	9785                	srai	a5,a5,0x21
    414a:	41f9571b          	sraiw	a4,s2,0x1f
    414e:	9f99                	subw	a5,a5,a4
    4150:	0027971b          	slliw	a4,a5,0x2
    4154:	9fb9                	addw	a5,a5,a4
    4156:	40f9093b          	subw	s2,s2,a5
    415a:	4785                	li	a5,1
    415c:	02f90563          	beq	s2,a5,4186 <concreate+0xa4>
      fd = open(file, O_CREATE | O_RDWR);
    4160:	20200593          	li	a1,514
    4164:	f9840513          	addi	a0,s0,-104
    4168:	374010ef          	jal	54dc <open>
      if (fd < 0) {
    416c:	1c055f63          	bgez	a0,434a <concreate+0x268>
        printf("concreate create %s failed\n", file);
    4170:	f9840593          	addi	a1,s0,-104
    4174:	00003517          	auipc	a0,0x3
    4178:	73c50513          	addi	a0,a0,1852 # 78b0 <malloc+0x1ed6>
    417c:	7a6010ef          	jal	5922 <printf>
        exit(1);
    4180:	4505                	li	a0,1
    4182:	31a010ef          	jal	549c <exit>
      link("C0", file);
    4186:	f9840593          	addi	a1,s0,-104
    418a:	00003517          	auipc	a0,0x3
    418e:	71e50513          	addi	a0,a0,1822 # 78a8 <malloc+0x1ece>
    4192:	36a010ef          	jal	54fc <link>
      exit(0);
    4196:	4501                	li	a0,0
    4198:	304010ef          	jal	549c <exit>
        exit(1);
    419c:	4505                	li	a0,1
    419e:	2fe010ef          	jal	549c <exit>
  memset(fa, 0, sizeof(fa));
    41a2:	02800613          	li	a2,40
    41a6:	4581                	li	a1,0
    41a8:	f7040513          	addi	a0,s0,-144
    41ac:	0c6010ef          	jal	5272 <memset>
  fd = open(".", 0);
    41b0:	4581                	li	a1,0
    41b2:	00002517          	auipc	a0,0x2
    41b6:	03e50513          	addi	a0,a0,62 # 61f0 <malloc+0x816>
    41ba:	322010ef          	jal	54dc <open>
    41be:	892a                	mv	s2,a0
  n = 0;
    41c0:	8b26                	mv	s6,s1
  while (read(fd, &de, sizeof(de)) > 0) {
    41c2:	f6040a13          	addi	s4,s0,-160
    41c6:	49c1                	li	s3,16
    if (de.name[0] == 'C' && de.name[2] == '\0') {
    41c8:	04300a93          	li	s5,67
      if (i < 0 || i >= sizeof(fa)) {
    41cc:	02700b93          	li	s7,39
      fa[i] = 1;
    41d0:	4c05                	li	s8,1
  while (read(fd, &de, sizeof(de)) > 0) {
    41d2:	864e                	mv	a2,s3
    41d4:	85d2                	mv	a1,s4
    41d6:	854a                	mv	a0,s2
    41d8:	2dc010ef          	jal	54b4 <read>
    41dc:	06a05763          	blez	a0,424a <concreate+0x168>
    if (de.inum == 0)
    41e0:	f6045783          	lhu	a5,-160(s0)
    41e4:	d7fd                	beqz	a5,41d2 <concreate+0xf0>
    if (de.name[0] == 'C' && de.name[2] == '\0') {
    41e6:	f6244783          	lbu	a5,-158(s0)
    41ea:	ff5794e3          	bne	a5,s5,41d2 <concreate+0xf0>
    41ee:	f6444783          	lbu	a5,-156(s0)
    41f2:	f3e5                	bnez	a5,41d2 <concreate+0xf0>
      i = de.name[1] - '0';
    41f4:	f6344783          	lbu	a5,-157(s0)
    41f8:	fd07879b          	addiw	a5,a5,-48
      if (i < 0 || i >= sizeof(fa)) {
    41fc:	00fbef63          	bltu	s7,a5,421a <concreate+0x138>
      if (fa[i]) {
    4200:	fa078713          	addi	a4,a5,-96
    4204:	9722                	add	a4,a4,s0
    4206:	fd074703          	lbu	a4,-48(a4)
    420a:	e705                	bnez	a4,4232 <concreate+0x150>
      fa[i] = 1;
    420c:	fa078793          	addi	a5,a5,-96
    4210:	97a2                	add	a5,a5,s0
    4212:	fd878823          	sb	s8,-48(a5)
      n++;
    4216:	2b05                	addiw	s6,s6,1
    4218:	bf6d                	j	41d2 <concreate+0xf0>
        printf("%s: concreate weird file %s\n", s, de.name);
    421a:	f6240613          	addi	a2,s0,-158
    421e:	85ea                	mv	a1,s10
    4220:	00003517          	auipc	a0,0x3
    4224:	6b050513          	addi	a0,a0,1712 # 78d0 <malloc+0x1ef6>
    4228:	6fa010ef          	jal	5922 <printf>
        exit(1);
    422c:	4505                	li	a0,1
    422e:	26e010ef          	jal	549c <exit>
        printf("%s: concreate duplicate file %s\n", s, de.name);
    4232:	f6240613          	addi	a2,s0,-158
    4236:	85ea                	mv	a1,s10
    4238:	00003517          	auipc	a0,0x3
    423c:	6b850513          	addi	a0,a0,1720 # 78f0 <malloc+0x1f16>
    4240:	6e2010ef          	jal	5922 <printf>
        exit(1);
    4244:	4505                	li	a0,1
    4246:	256010ef          	jal	549c <exit>
  close(fd);
    424a:	854a                	mv	a0,s2
    424c:	278010ef          	jal	54c4 <close>
  if (n != N) {
    4250:	02800793          	li	a5,40
    4254:	00fb1a63          	bne	s6,a5,4268 <concreate+0x186>
    if (((i % 3) == 0 && pid == 0) || ((i % 3) == 1 && pid != 0)) {
    4258:	55555a37          	lui	s4,0x55555
    425c:	556a0a13          	addi	s4,s4,1366 # 55555556 <base+0x5554486e>
      close(open(file, 0));
    4260:	f9840993          	addi	s3,s0,-104
  for (i = 0; i < N; i++) {
    4264:	8ada                	mv	s5,s6
    4266:	a049                	j	42e8 <concreate+0x206>
    printf("%s: concreate not enough files in directory listing\n", s);
    4268:	85ea                	mv	a1,s10
    426a:	00003517          	auipc	a0,0x3
    426e:	6ae50513          	addi	a0,a0,1710 # 7918 <malloc+0x1f3e>
    4272:	6b0010ef          	jal	5922 <printf>
    exit(1);
    4276:	4505                	li	a0,1
    4278:	224010ef          	jal	549c <exit>
      printf("%s: fork failed\n", s);
    427c:	85ea                	mv	a1,s10
    427e:	00002517          	auipc	a0,0x2
    4282:	11a50513          	addi	a0,a0,282 # 6398 <malloc+0x9be>
    4286:	69c010ef          	jal	5922 <printf>
      exit(1);
    428a:	4505                	li	a0,1
    428c:	210010ef          	jal	549c <exit>
      close(open(file, 0));
    4290:	4581                	li	a1,0
    4292:	854e                	mv	a0,s3
    4294:	248010ef          	jal	54dc <open>
    4298:	22c010ef          	jal	54c4 <close>
      close(open(file, 0));
    429c:	4581                	li	a1,0
    429e:	854e                	mv	a0,s3
    42a0:	23c010ef          	jal	54dc <open>
    42a4:	220010ef          	jal	54c4 <close>
      close(open(file, 0));
    42a8:	4581                	li	a1,0
    42aa:	854e                	mv	a0,s3
    42ac:	230010ef          	jal	54dc <open>
    42b0:	214010ef          	jal	54c4 <close>
      close(open(file, 0));
    42b4:	4581                	li	a1,0
    42b6:	854e                	mv	a0,s3
    42b8:	224010ef          	jal	54dc <open>
    42bc:	208010ef          	jal	54c4 <close>
      close(open(file, 0));
    42c0:	4581                	li	a1,0
    42c2:	854e                	mv	a0,s3
    42c4:	218010ef          	jal	54dc <open>
    42c8:	1fc010ef          	jal	54c4 <close>
      close(open(file, 0));
    42cc:	4581                	li	a1,0
    42ce:	854e                	mv	a0,s3
    42d0:	20c010ef          	jal	54dc <open>
    42d4:	1f0010ef          	jal	54c4 <close>
    if (pid == 0)
    42d8:	06090663          	beqz	s2,4344 <concreate+0x262>
      wait(0);
    42dc:	4501                	li	a0,0
    42de:	1c6010ef          	jal	54a4 <wait>
  for (i = 0; i < N; i++) {
    42e2:	2485                	addiw	s1,s1,1
    42e4:	0d548163          	beq	s1,s5,43a6 <concreate+0x2c4>
    file[1] = '0' + i;
    42e8:	0304879b          	addiw	a5,s1,48
    42ec:	f8f40ca3          	sb	a5,-103(s0)
    pid = fork();
    42f0:	1a4010ef          	jal	5494 <fork>
    42f4:	892a                	mv	s2,a0
    if (pid < 0) {
    42f6:	f80543e3          	bltz	a0,427c <concreate+0x19a>
    if (((i % 3) == 0 && pid == 0) || ((i % 3) == 1 && pid != 0)) {
    42fa:	03448733          	mul	a4,s1,s4
    42fe:	9301                	srli	a4,a4,0x20
    4300:	41f4d79b          	sraiw	a5,s1,0x1f
    4304:	9f1d                	subw	a4,a4,a5
    4306:	0017179b          	slliw	a5,a4,0x1
    430a:	9fb9                	addw	a5,a5,a4
    430c:	40f487bb          	subw	a5,s1,a5
    4310:	00a7e733          	or	a4,a5,a0
    4314:	2701                	sext.w	a4,a4
    4316:	df2d                	beqz	a4,4290 <concreate+0x1ae>
    4318:	c119                	beqz	a0,431e <concreate+0x23c>
    431a:	17fd                	addi	a5,a5,-1
    431c:	dbb5                	beqz	a5,4290 <concreate+0x1ae>
      unlink(file);
    431e:	854e                	mv	a0,s3
    4320:	1cc010ef          	jal	54ec <unlink>
      unlink(file);
    4324:	854e                	mv	a0,s3
    4326:	1c6010ef          	jal	54ec <unlink>
      unlink(file);
    432a:	854e                	mv	a0,s3
    432c:	1c0010ef          	jal	54ec <unlink>
      unlink(file);
    4330:	854e                	mv	a0,s3
    4332:	1ba010ef          	jal	54ec <unlink>
      unlink(file);
    4336:	854e                	mv	a0,s3
    4338:	1b4010ef          	jal	54ec <unlink>
      unlink(file);
    433c:	854e                	mv	a0,s3
    433e:	1ae010ef          	jal	54ec <unlink>
    4342:	bf59                	j	42d8 <concreate+0x1f6>
      exit(0);
    4344:	4501                	li	a0,0
    4346:	156010ef          	jal	549c <exit>
      close(fd);
    434a:	17a010ef          	jal	54c4 <close>
    if (pid == 0) {
    434e:	b5a1                	j	4196 <concreate+0xb4>
      close(fd);
    4350:	174010ef          	jal	54c4 <close>
      wait(&xstatus);
    4354:	8556                	mv	a0,s5
    4356:	14e010ef          	jal	54a4 <wait>
      if (xstatus != 0)
    435a:	f5c42483          	lw	s1,-164(s0)
    435e:	e2049fe3          	bnez	s1,419c <concreate+0xba>
  for (i = 0; i < N; i++) {
    4362:	2905                	addiw	s2,s2,1
    4364:	e3490fe3          	beq	s2,s4,41a2 <concreate+0xc0>
    file[1] = '0' + i;
    4368:	0309079b          	addiw	a5,s2,48
    436c:	f8f40ca3          	sb	a5,-103(s0)
    unlink(file);
    4370:	854e                	mv	a0,s3
    4372:	17a010ef          	jal	54ec <unlink>
    pid = fork();
    4376:	11e010ef          	jal	5494 <fork>
    if (pid && (i % 3) == 1) {
    437a:	dc0501e3          	beqz	a0,413c <concreate+0x5a>
    437e:	036907b3          	mul	a5,s2,s6
    4382:	9381                	srli	a5,a5,0x20
    4384:	41f9571b          	sraiw	a4,s2,0x1f
    4388:	9f99                	subw	a5,a5,a4
    438a:	0017971b          	slliw	a4,a5,0x1
    438e:	9fb9                	addw	a5,a5,a4
    4390:	40f907bb          	subw	a5,s2,a5
    4394:	d9778fe3          	beq	a5,s7,4132 <concreate+0x50>
      fd = open(file, O_CREATE | O_RDWR);
    4398:	85e2                	mv	a1,s8
    439a:	854e                	mv	a0,s3
    439c:	140010ef          	jal	54dc <open>
      if (fd < 0) {
    43a0:	fa0558e3          	bgez	a0,4350 <concreate+0x26e>
    43a4:	b3f1                	j	4170 <concreate+0x8e>
}
    43a6:	70aa                	ld	ra,168(sp)
    43a8:	740a                	ld	s0,160(sp)
    43aa:	64ea                	ld	s1,152(sp)
    43ac:	694a                	ld	s2,144(sp)
    43ae:	69aa                	ld	s3,136(sp)
    43b0:	6a0a                	ld	s4,128(sp)
    43b2:	7ae6                	ld	s5,120(sp)
    43b4:	7b46                	ld	s6,112(sp)
    43b6:	7ba6                	ld	s7,104(sp)
    43b8:	7c06                	ld	s8,96(sp)
    43ba:	6ce6                	ld	s9,88(sp)
    43bc:	6d46                	ld	s10,80(sp)
    43be:	614d                	addi	sp,sp,176
    43c0:	8082                	ret

00000000000043c2 <bigfile>:
{
    43c2:	7139                	addi	sp,sp,-64
    43c4:	fc06                	sd	ra,56(sp)
    43c6:	f822                	sd	s0,48(sp)
    43c8:	f426                	sd	s1,40(sp)
    43ca:	f04a                	sd	s2,32(sp)
    43cc:	ec4e                	sd	s3,24(sp)
    43ce:	e852                	sd	s4,16(sp)
    43d0:	e456                	sd	s5,8(sp)
    43d2:	e05a                	sd	s6,0(sp)
    43d4:	0080                	addi	s0,sp,64
    43d6:	8b2a                	mv	s6,a0
  unlink("bigfile.dat");
    43d8:	00003517          	auipc	a0,0x3
    43dc:	57850513          	addi	a0,a0,1400 # 7950 <malloc+0x1f76>
    43e0:	10c010ef          	jal	54ec <unlink>
  fd = open("bigfile.dat", O_CREATE | O_RDWR);
    43e4:	20200593          	li	a1,514
    43e8:	00003517          	auipc	a0,0x3
    43ec:	56850513          	addi	a0,a0,1384 # 7950 <malloc+0x1f76>
    43f0:	0ec010ef          	jal	54dc <open>
  if (fd < 0) {
    43f4:	08054a63          	bltz	a0,4488 <bigfile+0xc6>
    43f8:	8a2a                	mv	s4,a0
    43fa:	4481                	li	s1,0
    memset(buf, i, SZ);
    43fc:	25800913          	li	s2,600
    4400:	0000a997          	auipc	s3,0xa
    4404:	8e898993          	addi	s3,s3,-1816 # dce8 <buf>
  for (i = 0; i < N; i++) {
    4408:	4ad1                	li	s5,20
    memset(buf, i, SZ);
    440a:	864a                	mv	a2,s2
    440c:	85a6                	mv	a1,s1
    440e:	854e                	mv	a0,s3
    4410:	663000ef          	jal	5272 <memset>
    if (write(fd, buf, SZ) != SZ) {
    4414:	864a                	mv	a2,s2
    4416:	85ce                	mv	a1,s3
    4418:	8552                	mv	a0,s4
    441a:	0a2010ef          	jal	54bc <write>
    441e:	07251f63          	bne	a0,s2,449c <bigfile+0xda>
  for (i = 0; i < N; i++) {
    4422:	2485                	addiw	s1,s1,1
    4424:	ff5493e3          	bne	s1,s5,440a <bigfile+0x48>
  close(fd);
    4428:	8552                	mv	a0,s4
    442a:	09a010ef          	jal	54c4 <close>
  fd = open("bigfile.dat", 0);
    442e:	4581                	li	a1,0
    4430:	00003517          	auipc	a0,0x3
    4434:	52050513          	addi	a0,a0,1312 # 7950 <malloc+0x1f76>
    4438:	0a4010ef          	jal	54dc <open>
    443c:	8aaa                	mv	s5,a0
  total = 0;
    443e:	4a01                	li	s4,0
  for (i = 0;; i++) {
    4440:	4481                	li	s1,0
    cc = read(fd, buf, SZ / 2);
    4442:	12c00993          	li	s3,300
    4446:	0000a917          	auipc	s2,0xa
    444a:	8a290913          	addi	s2,s2,-1886 # dce8 <buf>
  if (fd < 0) {
    444e:	06054163          	bltz	a0,44b0 <bigfile+0xee>
    cc = read(fd, buf, SZ / 2);
    4452:	864e                	mv	a2,s3
    4454:	85ca                	mv	a1,s2
    4456:	8556                	mv	a0,s5
    4458:	05c010ef          	jal	54b4 <read>
    if (cc < 0) {
    445c:	06054463          	bltz	a0,44c4 <bigfile+0x102>
    if (cc == 0)
    4460:	c145                	beqz	a0,4500 <bigfile+0x13e>
    if (cc != SZ / 2) {
    4462:	07351b63          	bne	a0,s3,44d8 <bigfile+0x116>
    if (buf[0] != i / 2 || buf[SZ / 2 - 1] != i / 2) {
    4466:	01f4d79b          	srliw	a5,s1,0x1f
    446a:	9fa5                	addw	a5,a5,s1
    446c:	4017d79b          	sraiw	a5,a5,0x1
    4470:	00094703          	lbu	a4,0(s2)
    4474:	06f71c63          	bne	a4,a5,44ec <bigfile+0x12a>
    4478:	12b94703          	lbu	a4,299(s2)
    447c:	06f71863          	bne	a4,a5,44ec <bigfile+0x12a>
    total += cc;
    4480:	12ca0a1b          	addiw	s4,s4,300
  for (i = 0;; i++) {
    4484:	2485                	addiw	s1,s1,1
    cc = read(fd, buf, SZ / 2);
    4486:	b7f1                	j	4452 <bigfile+0x90>
    printf("%s: cannot create bigfile", s);
    4488:	85da                	mv	a1,s6
    448a:	00003517          	auipc	a0,0x3
    448e:	4d650513          	addi	a0,a0,1238 # 7960 <malloc+0x1f86>
    4492:	490010ef          	jal	5922 <printf>
    exit(1);
    4496:	4505                	li	a0,1
    4498:	004010ef          	jal	549c <exit>
      printf("%s: write bigfile failed\n", s);
    449c:	85da                	mv	a1,s6
    449e:	00003517          	auipc	a0,0x3
    44a2:	4e250513          	addi	a0,a0,1250 # 7980 <malloc+0x1fa6>
    44a6:	47c010ef          	jal	5922 <printf>
      exit(1);
    44aa:	4505                	li	a0,1
    44ac:	7f1000ef          	jal	549c <exit>
    printf("%s: cannot open bigfile\n", s);
    44b0:	85da                	mv	a1,s6
    44b2:	00003517          	auipc	a0,0x3
    44b6:	4ee50513          	addi	a0,a0,1262 # 79a0 <malloc+0x1fc6>
    44ba:	468010ef          	jal	5922 <printf>
    exit(1);
    44be:	4505                	li	a0,1
    44c0:	7dd000ef          	jal	549c <exit>
      printf("%s: read bigfile failed\n", s);
    44c4:	85da                	mv	a1,s6
    44c6:	00003517          	auipc	a0,0x3
    44ca:	4fa50513          	addi	a0,a0,1274 # 79c0 <malloc+0x1fe6>
    44ce:	454010ef          	jal	5922 <printf>
      exit(1);
    44d2:	4505                	li	a0,1
    44d4:	7c9000ef          	jal	549c <exit>
      printf("%s: short read bigfile\n", s);
    44d8:	85da                	mv	a1,s6
    44da:	00003517          	auipc	a0,0x3
    44de:	50650513          	addi	a0,a0,1286 # 79e0 <malloc+0x2006>
    44e2:	440010ef          	jal	5922 <printf>
      exit(1);
    44e6:	4505                	li	a0,1
    44e8:	7b5000ef          	jal	549c <exit>
      printf("%s: read bigfile wrong data\n", s);
    44ec:	85da                	mv	a1,s6
    44ee:	00003517          	auipc	a0,0x3
    44f2:	50a50513          	addi	a0,a0,1290 # 79f8 <malloc+0x201e>
    44f6:	42c010ef          	jal	5922 <printf>
      exit(1);
    44fa:	4505                	li	a0,1
    44fc:	7a1000ef          	jal	549c <exit>
  close(fd);
    4500:	8556                	mv	a0,s5
    4502:	7c3000ef          	jal	54c4 <close>
  if (total != N * SZ) {
    4506:	678d                	lui	a5,0x3
    4508:	ee078793          	addi	a5,a5,-288 # 2ee0 <subdir+0x356>
    450c:	02fa1263          	bne	s4,a5,4530 <bigfile+0x16e>
  unlink("bigfile.dat");
    4510:	00003517          	auipc	a0,0x3
    4514:	44050513          	addi	a0,a0,1088 # 7950 <malloc+0x1f76>
    4518:	7d5000ef          	jal	54ec <unlink>
}
    451c:	70e2                	ld	ra,56(sp)
    451e:	7442                	ld	s0,48(sp)
    4520:	74a2                	ld	s1,40(sp)
    4522:	7902                	ld	s2,32(sp)
    4524:	69e2                	ld	s3,24(sp)
    4526:	6a42                	ld	s4,16(sp)
    4528:	6aa2                	ld	s5,8(sp)
    452a:	6b02                	ld	s6,0(sp)
    452c:	6121                	addi	sp,sp,64
    452e:	8082                	ret
    printf("%s: read bigfile wrong total\n", s);
    4530:	85da                	mv	a1,s6
    4532:	00003517          	auipc	a0,0x3
    4536:	4e650513          	addi	a0,a0,1254 # 7a18 <malloc+0x203e>
    453a:	3e8010ef          	jal	5922 <printf>
    exit(1);
    453e:	4505                	li	a0,1
    4540:	75d000ef          	jal	549c <exit>

0000000000004544 <bigargtest>:
{
    4544:	7121                	addi	sp,sp,-448
    4546:	ff06                	sd	ra,440(sp)
    4548:	fb22                	sd	s0,432(sp)
    454a:	f726                	sd	s1,424(sp)
    454c:	0380                	addi	s0,sp,448
    454e:	84aa                	mv	s1,a0
  unlink("bigarg-ok");
    4550:	00003517          	auipc	a0,0x3
    4554:	4e850513          	addi	a0,a0,1256 # 7a38 <malloc+0x205e>
    4558:	795000ef          	jal	54ec <unlink>
  pid = fork();
    455c:	739000ef          	jal	5494 <fork>
  if (pid == 0) {
    4560:	c915                	beqz	a0,4594 <bigargtest+0x50>
  } else if (pid < 0) {
    4562:	08054c63          	bltz	a0,45fa <bigargtest+0xb6>
  wait(&xstatus);
    4566:	fdc40513          	addi	a0,s0,-36
    456a:	73b000ef          	jal	54a4 <wait>
  if (xstatus != 0)
    456e:	fdc42503          	lw	a0,-36(s0)
    4572:	ed51                	bnez	a0,460e <bigargtest+0xca>
  fd = open("bigarg-ok", 0);
    4574:	4581                	li	a1,0
    4576:	00003517          	auipc	a0,0x3
    457a:	4c250513          	addi	a0,a0,1218 # 7a38 <malloc+0x205e>
    457e:	75f000ef          	jal	54dc <open>
  if (fd < 0) {
    4582:	08054863          	bltz	a0,4612 <bigargtest+0xce>
  close(fd);
    4586:	73f000ef          	jal	54c4 <close>
}
    458a:	70fa                	ld	ra,440(sp)
    458c:	745a                	ld	s0,432(sp)
    458e:	74ba                	ld	s1,424(sp)
    4590:	6139                	addi	sp,sp,448
    4592:	8082                	ret
    memset(big, ' ', sizeof(big));
    4594:	19000613          	li	a2,400
    4598:	02000593          	li	a1,32
    459c:	e4840513          	addi	a0,s0,-440
    45a0:	4d3000ef          	jal	5272 <memset>
    big[sizeof(big) - 1] = '\0';
    45a4:	fc040ba3          	sb	zero,-41(s0)
    for (i = 0; i < MAXARG - 1; i++)
    45a8:	00006797          	auipc	a5,0x6
    45ac:	f2878793          	addi	a5,a5,-216 # a4d0 <args.1>
    45b0:	00006697          	auipc	a3,0x6
    45b4:	01868693          	addi	a3,a3,24 # a5c8 <args.1+0xf8>
      args[i] = big;
    45b8:	e4840713          	addi	a4,s0,-440
    45bc:	e398                	sd	a4,0(a5)
    for (i = 0; i < MAXARG - 1; i++)
    45be:	07a1                	addi	a5,a5,8
    45c0:	fed79ee3          	bne	a5,a3,45bc <bigargtest+0x78>
    args[MAXARG - 1] = 0;
    45c4:	00006797          	auipc	a5,0x6
    45c8:	0007b223          	sd	zero,4(a5) # a5c8 <args.1+0xf8>
    exec("echo", args);
    45cc:	00006597          	auipc	a1,0x6
    45d0:	f0458593          	addi	a1,a1,-252 # a4d0 <args.1>
    45d4:	00001517          	auipc	a0,0x1
    45d8:	53450513          	addi	a0,a0,1332 # 5b08 <malloc+0x12e>
    45dc:	6f9000ef          	jal	54d4 <exec>
    fd = open("bigarg-ok", O_CREATE);
    45e0:	20000593          	li	a1,512
    45e4:	00003517          	auipc	a0,0x3
    45e8:	45450513          	addi	a0,a0,1108 # 7a38 <malloc+0x205e>
    45ec:	6f1000ef          	jal	54dc <open>
    close(fd);
    45f0:	6d5000ef          	jal	54c4 <close>
    exit(0);
    45f4:	4501                	li	a0,0
    45f6:	6a7000ef          	jal	549c <exit>
    printf("%s: bigargtest: fork failed\n", s);
    45fa:	85a6                	mv	a1,s1
    45fc:	00003517          	auipc	a0,0x3
    4600:	44c50513          	addi	a0,a0,1100 # 7a48 <malloc+0x206e>
    4604:	31e010ef          	jal	5922 <printf>
    exit(1);
    4608:	4505                	li	a0,1
    460a:	693000ef          	jal	549c <exit>
    exit(xstatus);
    460e:	68f000ef          	jal	549c <exit>
    printf("%s: bigarg test failed!\n", s);
    4612:	85a6                	mv	a1,s1
    4614:	00003517          	auipc	a0,0x3
    4618:	45450513          	addi	a0,a0,1108 # 7a68 <malloc+0x208e>
    461c:	306010ef          	jal	5922 <printf>
    exit(1);
    4620:	4505                	li	a0,1
    4622:	67b000ef          	jal	549c <exit>

0000000000004626 <partial_write>:
{
    4626:	bb010113          	addi	sp,sp,-1104
    462a:	44113423          	sd	ra,1096(sp)
    462e:	44813023          	sd	s0,1088(sp)
    4632:	42913c23          	sd	s1,1080(sp)
    4636:	43213823          	sd	s2,1072(sp)
    463a:	43313423          	sd	s3,1064(sp)
    463e:	43413023          	sd	s4,1056(sp)
    4642:	41513c23          	sd	s5,1048(sp)
    4646:	45010413          	addi	s0,sp,1104
    464a:	8aaa                	mv	s5,a0
  unlink("testfile");
    464c:	00003517          	auipc	a0,0x3
    4650:	43c50513          	addi	a0,a0,1084 # 7a88 <malloc+0x20ae>
    4654:	699000ef          	jal	54ec <unlink>
  int fd = open("testfile", O_CREATE | O_RDWR);
    4658:	20200593          	li	a1,514
    465c:	00003517          	auipc	a0,0x3
    4660:	42c50513          	addi	a0,a0,1068 # 7a88 <malloc+0x20ae>
    4664:	679000ef          	jal	54dc <open>
  if (fd < 0) {
    4668:	14054f63          	bltz	a0,47c6 <partial_write+0x1a0>
    466c:	84aa                	mv	s1,a0
  int cc = write(fd, "A", 1);
    466e:	4605                	li	a2,1
    4670:	00003597          	auipc	a1,0x3
    4674:	44858593          	addi	a1,a1,1096 # 7ab8 <malloc+0x20de>
    4678:	645000ef          	jal	54bc <write>
  if (cc != 1) {
    467c:	4785                	li	a5,1
    467e:	14f51e63          	bne	a0,a5,47da <partial_write+0x1b4>
  close(fd);
    4682:	8526                	mv	a0,s1
    4684:	641000ef          	jal	54c4 <close>
  fd = open("testfile", O_RDWR);
    4688:	4589                	li	a1,2
    468a:	00003517          	auipc	a0,0x3
    468e:	3fe50513          	addi	a0,a0,1022 # 7a88 <malloc+0x20ae>
    4692:	64b000ef          	jal	54dc <open>
    4696:	892a                	mv	s2,a0
  if (fd < 0) {
    4698:	14054b63          	bltz	a0,47ee <partial_write+0x1c8>
  char *p = sbrk(0);
    469c:	4501                	li	a0,0
    469e:	5cb000ef          	jal	5468 <sbrk>
  sbrk(PGSIZE - ((uint64)p % PGSIZE));
    46a2:	6485                	lui	s1,0x1
    46a4:	14fd                	addi	s1,s1,-1 # fff <bigdir+0x10b>
    46a6:	009577b3          	and	a5,a0,s1
    46aa:	6505                	lui	a0,0x1
    46ac:	9d1d                	subw	a0,a0,a5
    46ae:	5bb000ef          	jal	5468 <sbrk>
  p = sbrk(0);
    46b2:	4501                	li	a0,0
    46b4:	5b5000ef          	jal	5468 <sbrk>
  if ((uint64)p % PGSIZE != 0) {
    46b8:	8ce9                	and	s1,s1,a0
    46ba:	14049463          	bnez	s1,4802 <partial_write+0x1dc>
  p[-1] = 'X';
    46be:	05800793          	li	a5,88
    46c2:	fef50fa3          	sb	a5,-1(a0) # fff <bigdir+0x10b>
  cc = write(fd, p - 1, 2);
    46c6:	4609                	li	a2,2
    46c8:	fff50593          	addi	a1,a0,-1
    46cc:	854a                	mv	a0,s2
    46ce:	5ef000ef          	jal	54bc <write>
  if (cc != -1) {
    46d2:	57fd                	li	a5,-1
    46d4:	14f51163          	bne	a0,a5,4816 <partial_write+0x1f0>
  close(fd);
    46d8:	854a                	mv	a0,s2
    46da:	5eb000ef          	jal	54c4 <close>
  fd = open("testfile", O_RDONLY);
    46de:	4581                	li	a1,0
    46e0:	00003517          	auipc	a0,0x3
    46e4:	3a850513          	addi	a0,a0,936 # 7a88 <malloc+0x20ae>
    46e8:	5f5000ef          	jal	54dc <open>
    46ec:	84aa                	mv	s1,a0
  if (fd < 0) {
    46ee:	12054e63          	bltz	a0,482a <partial_write+0x204>
  cc = read(fd, &b, 1);
    46f2:	4605                	li	a2,1
    46f4:	fbf40593          	addi	a1,s0,-65
    46f8:	5bd000ef          	jal	54b4 <read>
  if (cc != 1) {
    46fc:	4785                	li	a5,1
    46fe:	14f51063          	bne	a0,a5,483e <partial_write+0x218>
  close(fd);
    4702:	8526                	mv	a0,s1
    4704:	5c1000ef          	jal	54c4 <close>
  if (b != 'X') {
    4708:	fbf44603          	lbu	a2,-65(s0)
    470c:	05800793          	li	a5,88
    4710:	14f61163          	bne	a2,a5,4852 <partial_write+0x22c>
  fd = open("bigfile", O_CREATE | O_RDWR);
    4714:	20200593          	li	a1,514
    4718:	00003517          	auipc	a0,0x3
    471c:	47050513          	addi	a0,a0,1136 # 7b88 <malloc+0x21ae>
    4720:	5bd000ef          	jal	54dc <open>
    4724:	8a2a                	mv	s4,a0
    4726:	04000913          	li	s2,64
    memset(buf, 0, sizeof(buf));
    472a:	bb840993          	addi	s3,s0,-1096
    472e:	40000493          	li	s1,1024
    4732:	8626                	mv	a2,s1
    4734:	4581                	li	a1,0
    4736:	854e                	mv	a0,s3
    4738:	33b000ef          	jal	5272 <memset>
    cc = write(fd, buf, sizeof(buf));
    473c:	8626                	mv	a2,s1
    473e:	85ce                	mv	a1,s3
    4740:	8552                	mv	a0,s4
    4742:	57b000ef          	jal	54bc <write>
    if (cc != sizeof(buf)) {
    4746:	12951063          	bne	a0,s1,4866 <partial_write+0x240>
  for (int i = 0; i < 64; i++) {
    474a:	397d                	addiw	s2,s2,-1
    474c:	fe0913e3          	bnez	s2,4732 <partial_write+0x10c>
  close(fd);
    4750:	8552                	mv	a0,s4
    4752:	573000ef          	jal	54c4 <close>
  unlink("bigfile");
    4756:	00003517          	auipc	a0,0x3
    475a:	43250513          	addi	a0,a0,1074 # 7b88 <malloc+0x21ae>
    475e:	58f000ef          	jal	54ec <unlink>
  fd = open("testfile", O_RDONLY);
    4762:	4581                	li	a1,0
    4764:	00003517          	auipc	a0,0x3
    4768:	32450513          	addi	a0,a0,804 # 7a88 <malloc+0x20ae>
    476c:	571000ef          	jal	54dc <open>
    4770:	84aa                	mv	s1,a0
  if (fd < 0) {
    4772:	10054463          	bltz	a0,487a <partial_write+0x254>
  cc = read(fd, &b, 1);
    4776:	4605                	li	a2,1
    4778:	fbf40593          	addi	a1,s0,-65
    477c:	539000ef          	jal	54b4 <read>
  if (cc != 1) {
    4780:	4785                	li	a5,1
    4782:	10f51663          	bne	a0,a5,488e <partial_write+0x268>
  close(fd);
    4786:	8526                	mv	a0,s1
    4788:	53d000ef          	jal	54c4 <close>
  if (b != 'X') {
    478c:	fbf44603          	lbu	a2,-65(s0)
    4790:	05800793          	li	a5,88
    4794:	10f61763          	bne	a2,a5,48a2 <partial_write+0x27c>
  unlink("testfile");
    4798:	00003517          	auipc	a0,0x3
    479c:	2f050513          	addi	a0,a0,752 # 7a88 <malloc+0x20ae>
    47a0:	54d000ef          	jal	54ec <unlink>
}
    47a4:	44813083          	ld	ra,1096(sp)
    47a8:	44013403          	ld	s0,1088(sp)
    47ac:	43813483          	ld	s1,1080(sp)
    47b0:	43013903          	ld	s2,1072(sp)
    47b4:	42813983          	ld	s3,1064(sp)
    47b8:	42013a03          	ld	s4,1056(sp)
    47bc:	41813a83          	ld	s5,1048(sp)
    47c0:	45010113          	addi	sp,sp,1104
    47c4:	8082                	ret
    printf("%s: cannot create testfile\n", s);
    47c6:	85d6                	mv	a1,s5
    47c8:	00003517          	auipc	a0,0x3
    47cc:	2d050513          	addi	a0,a0,720 # 7a98 <malloc+0x20be>
    47d0:	152010ef          	jal	5922 <printf>
    exit(1);
    47d4:	4505                	li	a0,1
    47d6:	4c7000ef          	jal	549c <exit>
    printf("%s: could not write A\n", s);
    47da:	85d6                	mv	a1,s5
    47dc:	00003517          	auipc	a0,0x3
    47e0:	2e450513          	addi	a0,a0,740 # 7ac0 <malloc+0x20e6>
    47e4:	13e010ef          	jal	5922 <printf>
    exit(1);
    47e8:	4505                	li	a0,1
    47ea:	4b3000ef          	jal	549c <exit>
    printf("%s: cannot re-open testfile\n", s);
    47ee:	85d6                	mv	a1,s5
    47f0:	00003517          	auipc	a0,0x3
    47f4:	2e850513          	addi	a0,a0,744 # 7ad8 <malloc+0x20fe>
    47f8:	12a010ef          	jal	5922 <printf>
    exit(1);
    47fc:	4505                	li	a0,1
    47fe:	49f000ef          	jal	549c <exit>
    printf("%s: sbrk did not align\n", s);
    4802:	85d6                	mv	a1,s5
    4804:	00003517          	auipc	a0,0x3
    4808:	2f450513          	addi	a0,a0,756 # 7af8 <malloc+0x211e>
    480c:	116010ef          	jal	5922 <printf>
    exit(1);
    4810:	4505                	li	a0,1
    4812:	48b000ef          	jal	549c <exit>
    printf("%s: write succeeded, should have failed\n", s);
    4816:	85d6                	mv	a1,s5
    4818:	00003517          	auipc	a0,0x3
    481c:	2f850513          	addi	a0,a0,760 # 7b10 <malloc+0x2136>
    4820:	102010ef          	jal	5922 <printf>
    exit(1);
    4824:	4505                	li	a0,1
    4826:	477000ef          	jal	549c <exit>
    printf("%s: cannot re-open testfile\n", s);
    482a:	85d6                	mv	a1,s5
    482c:	00003517          	auipc	a0,0x3
    4830:	2ac50513          	addi	a0,a0,684 # 7ad8 <malloc+0x20fe>
    4834:	0ee010ef          	jal	5922 <printf>
    exit(1);
    4838:	4505                	li	a0,1
    483a:	463000ef          	jal	549c <exit>
    printf("%s: cannot read testfile\n", s);
    483e:	85d6                	mv	a1,s5
    4840:	00003517          	auipc	a0,0x3
    4844:	30050513          	addi	a0,a0,768 # 7b40 <malloc+0x2166>
    4848:	0da010ef          	jal	5922 <printf>
    exit(1);
    484c:	4505                	li	a0,1
    484e:	44f000ef          	jal	549c <exit>
    printf("%s: read returned %c, expected X\n", s, b);
    4852:	85d6                	mv	a1,s5
    4854:	00003517          	auipc	a0,0x3
    4858:	30c50513          	addi	a0,a0,780 # 7b60 <malloc+0x2186>
    485c:	0c6010ef          	jal	5922 <printf>
    exit(1);
    4860:	4505                	li	a0,1
    4862:	43b000ef          	jal	549c <exit>
      printf("%s: could not write to bigfile\n", s);
    4866:	85d6                	mv	a1,s5
    4868:	00003517          	auipc	a0,0x3
    486c:	32850513          	addi	a0,a0,808 # 7b90 <malloc+0x21b6>
    4870:	0b2010ef          	jal	5922 <printf>
      exit(-1);
    4874:	557d                	li	a0,-1
    4876:	427000ef          	jal	549c <exit>
    printf("%s: cannot re-open testfile\n", s);
    487a:	85d6                	mv	a1,s5
    487c:	00003517          	auipc	a0,0x3
    4880:	25c50513          	addi	a0,a0,604 # 7ad8 <malloc+0x20fe>
    4884:	09e010ef          	jal	5922 <printf>
    exit(1);
    4888:	4505                	li	a0,1
    488a:	413000ef          	jal	549c <exit>
    printf("%s: cannot read testfile\n", s);
    488e:	85d6                	mv	a1,s5
    4890:	00003517          	auipc	a0,0x3
    4894:	2b050513          	addi	a0,a0,688 # 7b40 <malloc+0x2166>
    4898:	08a010ef          	jal	5922 <printf>
    exit(1);
    489c:	4505                	li	a0,1
    489e:	3ff000ef          	jal	549c <exit>
    printf("%s: read returned %c, expected X\n", s, b);
    48a2:	85d6                	mv	a1,s5
    48a4:	00003517          	auipc	a0,0x3
    48a8:	2bc50513          	addi	a0,a0,700 # 7b60 <malloc+0x2186>
    48ac:	076010ef          	jal	5922 <printf>
    exit(1);
    48b0:	4505                	li	a0,1
    48b2:	3eb000ef          	jal	549c <exit>

00000000000048b6 <lazy_alloc>:
{
    48b6:	1141                	addi	sp,sp,-16
    48b8:	e406                	sd	ra,8(sp)
    48ba:	e022                	sd	s0,0(sp)
    48bc:	0800                	addi	s0,sp,16
  prev_end = sbrklazy(REGION_SZ);
    48be:	40000537          	lui	a0,0x40000
    48c2:	3bd000ef          	jal	547e <sbrklazy>
  if (prev_end == (char *)SBRK_ERROR) {
    48c6:	57fd                	li	a5,-1
    48c8:	02f50a63          	beq	a0,a5,48fc <lazy_alloc+0x46>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    48cc:	6605                	lui	a2,0x1
    48ce:	962a                	add	a2,a2,a0
    48d0:	400017b7          	lui	a5,0x40001
    48d4:	00f50733          	add	a4,a0,a5
    48d8:	87b2                	mv	a5,a2
    48da:	000406b7          	lui	a3,0x40
    *(char **)i = i;
    48de:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    48e0:	97b6                	add	a5,a5,a3
    48e2:	fee79ee3          	bne	a5,a4,48de <lazy_alloc+0x28>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    48e6:	000406b7          	lui	a3,0x40
    if (*(char **)i != i) {
    48ea:	621c                	ld	a5,0(a2)
    48ec:	02c79163          	bne	a5,a2,490e <lazy_alloc+0x58>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    48f0:	9636                	add	a2,a2,a3
    48f2:	fee61ce3          	bne	a2,a4,48ea <lazy_alloc+0x34>
  exit(0);
    48f6:	4501                	li	a0,0
    48f8:	3a5000ef          	jal	549c <exit>
    printf("sbrklazy() failed\n");
    48fc:	00003517          	auipc	a0,0x3
    4900:	2b450513          	addi	a0,a0,692 # 7bb0 <malloc+0x21d6>
    4904:	01e010ef          	jal	5922 <printf>
    exit(1);
    4908:	4505                	li	a0,1
    490a:	393000ef          	jal	549c <exit>
      printf("failed to read value from memory\n");
    490e:	00003517          	auipc	a0,0x3
    4912:	2ba50513          	addi	a0,a0,698 # 7bc8 <malloc+0x21ee>
    4916:	00c010ef          	jal	5922 <printf>
      exit(1);
    491a:	4505                	li	a0,1
    491c:	381000ef          	jal	549c <exit>

0000000000004920 <lazy_unmap>:
{
    4920:	7139                	addi	sp,sp,-64
    4922:	fc06                	sd	ra,56(sp)
    4924:	f822                	sd	s0,48(sp)
    4926:	0080                	addi	s0,sp,64
  prev_end = sbrklazy(REGION_SZ);
    4928:	40000537          	lui	a0,0x40000
    492c:	353000ef          	jal	547e <sbrklazy>
  if (prev_end == (char *)SBRK_ERROR) {
    4930:	57fd                	li	a5,-1
    4932:	04f50863          	beq	a0,a5,4982 <lazy_unmap+0x62>
    4936:	f426                	sd	s1,40(sp)
    4938:	f04a                	sd	s2,32(sp)
    493a:	ec4e                	sd	s3,24(sp)
    493c:	e852                	sd	s4,16(sp)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    493e:	6905                	lui	s2,0x1
    4940:	992a                	add	s2,s2,a0
    4942:	400017b7          	lui	a5,0x40001
    4946:	00f504b3          	add	s1,a0,a5
    494a:	87ca                	mv	a5,s2
    494c:	01000737          	lui	a4,0x1000
    *(char **)i = i;
    4950:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    4952:	97ba                	add	a5,a5,a4
    4954:	fe979ee3          	bne	a5,s1,4950 <lazy_unmap+0x30>
      wait(&status);
    4958:	fcc40993          	addi	s3,s0,-52
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    495c:	01000a37          	lui	s4,0x1000
    pid = fork();
    4960:	335000ef          	jal	5494 <fork>
    if (pid < 0) {
    4964:	02054c63          	bltz	a0,499c <lazy_unmap+0x7c>
    } else if (pid == 0) {
    4968:	c139                	beqz	a0,49ae <lazy_unmap+0x8e>
      wait(&status);
    496a:	854e                	mv	a0,s3
    496c:	339000ef          	jal	54a4 <wait>
      if (status == 0) {
    4970:	fcc42783          	lw	a5,-52(s0)
    4974:	c7b1                	beqz	a5,49c0 <lazy_unmap+0xa0>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    4976:	9952                	add	s2,s2,s4
    4978:	fe9914e3          	bne	s2,s1,4960 <lazy_unmap+0x40>
  exit(0);
    497c:	4501                	li	a0,0
    497e:	31f000ef          	jal	549c <exit>
    4982:	f426                	sd	s1,40(sp)
    4984:	f04a                	sd	s2,32(sp)
    4986:	ec4e                	sd	s3,24(sp)
    4988:	e852                	sd	s4,16(sp)
    printf("sbrklazy() failed\n");
    498a:	00003517          	auipc	a0,0x3
    498e:	22650513          	addi	a0,a0,550 # 7bb0 <malloc+0x21d6>
    4992:	791000ef          	jal	5922 <printf>
    exit(1);
    4996:	4505                	li	a0,1
    4998:	305000ef          	jal	549c <exit>
      printf("error forking\n");
    499c:	00003517          	auipc	a0,0x3
    49a0:	25450513          	addi	a0,a0,596 # 7bf0 <malloc+0x2216>
    49a4:	77f000ef          	jal	5922 <printf>
      exit(1);
    49a8:	4505                	li	a0,1
    49aa:	2f3000ef          	jal	549c <exit>
      sbrklazy(-1L * REGION_SZ);
    49ae:	c0000537          	lui	a0,0xc0000
    49b2:	2cd000ef          	jal	547e <sbrklazy>
      *(char **)i = i;
    49b6:	01293023          	sd	s2,0(s2) # 1000 <bigdir+0x10c>
      exit(0);
    49ba:	4501                	li	a0,0
    49bc:	2e1000ef          	jal	549c <exit>
        printf("memory not unmapped\n");
    49c0:	00003517          	auipc	a0,0x3
    49c4:	24050513          	addi	a0,a0,576 # 7c00 <malloc+0x2226>
    49c8:	75b000ef          	jal	5922 <printf>
        exit(1);
    49cc:	4505                	li	a0,1
    49ce:	2cf000ef          	jal	549c <exit>

00000000000049d2 <lazy_copy>:
{
    49d2:	7119                	addi	sp,sp,-128
    49d4:	fc86                	sd	ra,120(sp)
    49d6:	f8a2                	sd	s0,112(sp)
    49d8:	f4a6                	sd	s1,104(sp)
    49da:	f0ca                	sd	s2,96(sp)
    49dc:	ecce                	sd	s3,88(sp)
    49de:	e8d2                	sd	s4,80(sp)
    49e0:	e4d6                	sd	s5,72(sp)
    49e2:	e0da                	sd	s6,64(sp)
    49e4:	fc5e                	sd	s7,56(sp)
    49e6:	0100                	addi	s0,sp,128
    char *p = sbrk(0);
    49e8:	4501                	li	a0,0
    49ea:	27f000ef          	jal	5468 <sbrk>
    49ee:	84aa                	mv	s1,a0
    sbrklazy(4 * PGSIZE);
    49f0:	6511                	lui	a0,0x4
    49f2:	28d000ef          	jal	547e <sbrklazy>
    open(p + 8192, 0);
    49f6:	4581                	li	a1,0
    49f8:	6509                	lui	a0,0x2
    49fa:	9526                	add	a0,a0,s1
    49fc:	2e1000ef          	jal	54dc <open>
    void *xx = sbrk(0);
    4a00:	4501                	li	a0,0
    4a02:	267000ef          	jal	5468 <sbrk>
    4a06:	84aa                	mv	s1,a0
    void *ret = sbrk(-(((uint64)xx) + 1));
    4a08:	fff54513          	not	a0,a0
    4a0c:	2501                	sext.w	a0,a0
    4a0e:	25b000ef          	jal	5468 <sbrk>
    if (ret != xx) {
    4a12:	00a48c63          	beq	s1,a0,4a2a <lazy_copy+0x58>
    4a16:	85aa                	mv	a1,a0
      printf("sbrk(sbrk(0)+1) returned %p, not old sz\n", ret);
    4a18:	00003517          	auipc	a0,0x3
    4a1c:	20050513          	addi	a0,a0,512 # 7c18 <malloc+0x223e>
    4a20:	703000ef          	jal	5922 <printf>
      exit(1);
    4a24:	4505                	li	a0,1
    4a26:	277000ef          	jal	549c <exit>
  unsigned long bad[] = {
    4a2a:	00004797          	auipc	a5,0x4
    4a2e:	8de78793          	addi	a5,a5,-1826 # 8308 <malloc+0x292e>
    4a32:	7fa8                	ld	a0,120(a5)
    4a34:	63cc                	ld	a1,128(a5)
    4a36:	67d0                	ld	a2,136(a5)
    4a38:	6bd4                	ld	a3,144(a5)
    4a3a:	6fd8                	ld	a4,152(a5)
    4a3c:	f8a43023          	sd	a0,-128(s0)
    4a40:	f8b43423          	sd	a1,-120(s0)
    4a44:	f8c43823          	sd	a2,-112(s0)
    4a48:	f8d43c23          	sd	a3,-104(s0)
    4a4c:	fae43023          	sd	a4,-96(s0)
    4a50:	73dc                	ld	a5,160(a5)
    4a52:	faf43423          	sd	a5,-88(s0)
  for (int i = 0; i < sizeof(bad) / sizeof(bad[0]); i++) {
    4a56:	f8040913          	addi	s2,s0,-128
    int fd = open("README", 0);
    4a5a:	00001a97          	auipc	s5,0x1
    4a5e:	286a8a93          	addi	s5,s5,646 # 5ce0 <malloc+0x306>
    if (read(fd, (char *)bad[i], 512) >= 0) {
    4a62:	20000a13          	li	s4,512
    fd = open("junk", O_CREATE | O_RDWR | O_TRUNC);
    4a66:	60200b93          	li	s7,1538
    4a6a:	00001b17          	auipc	s6,0x1
    4a6e:	186b0b13          	addi	s6,s6,390 # 5bf0 <malloc+0x216>
    int fd = open("README", 0);
    4a72:	4581                	li	a1,0
    4a74:	8556                	mv	a0,s5
    4a76:	267000ef          	jal	54dc <open>
    4a7a:	84aa                	mv	s1,a0
    if (fd < 0) {
    4a7c:	04054563          	bltz	a0,4ac6 <lazy_copy+0xf4>
    if (read(fd, (char *)bad[i], 512) >= 0) {
    4a80:	00093983          	ld	s3,0(s2)
    4a84:	8652                	mv	a2,s4
    4a86:	85ce                	mv	a1,s3
    4a88:	22d000ef          	jal	54b4 <read>
    4a8c:	04055663          	bgez	a0,4ad8 <lazy_copy+0x106>
    close(fd);
    4a90:	8526                	mv	a0,s1
    4a92:	233000ef          	jal	54c4 <close>
    fd = open("junk", O_CREATE | O_RDWR | O_TRUNC);
    4a96:	85de                	mv	a1,s7
    4a98:	855a                	mv	a0,s6
    4a9a:	243000ef          	jal	54dc <open>
    4a9e:	84aa                	mv	s1,a0
    if (fd < 0) {
    4aa0:	04054563          	bltz	a0,4aea <lazy_copy+0x118>
    if (write(fd, (char *)bad[i], 512) >= 0) {
    4aa4:	8652                	mv	a2,s4
    4aa6:	85ce                	mv	a1,s3
    4aa8:	215000ef          	jal	54bc <write>
    4aac:	04055863          	bgez	a0,4afc <lazy_copy+0x12a>
    close(fd);
    4ab0:	8526                	mv	a0,s1
    4ab2:	213000ef          	jal	54c4 <close>
  for (int i = 0; i < sizeof(bad) / sizeof(bad[0]); i++) {
    4ab6:	0921                	addi	s2,s2,8
    4ab8:	fb040793          	addi	a5,s0,-80
    4abc:	faf91be3          	bne	s2,a5,4a72 <lazy_copy+0xa0>
  exit(0);
    4ac0:	4501                	li	a0,0
    4ac2:	1db000ef          	jal	549c <exit>
      printf("cannot open README\n");
    4ac6:	00003517          	auipc	a0,0x3
    4aca:	18250513          	addi	a0,a0,386 # 7c48 <malloc+0x226e>
    4ace:	655000ef          	jal	5922 <printf>
      exit(1);
    4ad2:	4505                	li	a0,1
    4ad4:	1c9000ef          	jal	549c <exit>
      printf("read succeeded\n");
    4ad8:	00003517          	auipc	a0,0x3
    4adc:	18850513          	addi	a0,a0,392 # 7c60 <malloc+0x2286>
    4ae0:	643000ef          	jal	5922 <printf>
      exit(1);
    4ae4:	4505                	li	a0,1
    4ae6:	1b7000ef          	jal	549c <exit>
      printf("cannot open junk\n");
    4aea:	00003517          	auipc	a0,0x3
    4aee:	18650513          	addi	a0,a0,390 # 7c70 <malloc+0x2296>
    4af2:	631000ef          	jal	5922 <printf>
      exit(1);
    4af6:	4505                	li	a0,1
    4af8:	1a5000ef          	jal	549c <exit>
      printf("write succeeded\n");
    4afc:	00003517          	auipc	a0,0x3
    4b00:	18c50513          	addi	a0,a0,396 # 7c88 <malloc+0x22ae>
    4b04:	61f000ef          	jal	5922 <printf>
      exit(1);
    4b08:	4505                	li	a0,1
    4b0a:	193000ef          	jal	549c <exit>

0000000000004b0e <lazy_sbrk>:
{
    4b0e:	7179                	addi	sp,sp,-48
    4b10:	f406                	sd	ra,40(sp)
    4b12:	f022                	sd	s0,32(sp)
    4b14:	ec26                	sd	s1,24(sp)
    4b16:	e84a                	sd	s2,16(sp)
    4b18:	e44e                	sd	s3,8(sp)
    4b1a:	1800                	addi	s0,sp,48
  char *p = sbrk(0);
    4b1c:	4501                	li	a0,0
    4b1e:	14b000ef          	jal	5468 <sbrk>
    4b22:	84aa                	mv	s1,a0
  while ((uint64)p < MAXVA - (1 << 30)) {
    4b24:	0ff00793          	li	a5,255
    4b28:	07fa                	slli	a5,a5,0x1e
    4b2a:	00f57e63          	bgeu	a0,a5,4b46 <lazy_sbrk+0x38>
    p = sbrklazy(1 << 30);
    4b2e:	400009b7          	lui	s3,0x40000
  while ((uint64)p < MAXVA - (1 << 30)) {
    4b32:	893e                	mv	s2,a5
    p = sbrklazy(1 << 30);
    4b34:	854e                	mv	a0,s3
    4b36:	149000ef          	jal	547e <sbrklazy>
    p = sbrklazy(0);
    4b3a:	4501                	li	a0,0
    4b3c:	143000ef          	jal	547e <sbrklazy>
    4b40:	84aa                	mv	s1,a0
  while ((uint64)p < MAXVA - (1 << 30)) {
    4b42:	ff2569e3          	bltu	a0,s2,4b34 <lazy_sbrk+0x26>
  int n = TRAPFRAME - PGSIZE - (uint64)p;
    4b46:	7975                	lui	s2,0xffffd
    4b48:	4099093b          	subw	s2,s2,s1
  char *p1 = sbrklazy(n);
    4b4c:	854a                	mv	a0,s2
    4b4e:	131000ef          	jal	547e <sbrklazy>
    4b52:	862a                	mv	a2,a0
  if (p1 < 0 || p1 != p) {
    4b54:	00950d63          	beq	a0,s1,4b6e <lazy_sbrk+0x60>
    printf("sbrklazy(%d) returned %p, not expected %p\n", n, p1, p);
    4b58:	86a6                	mv	a3,s1
    4b5a:	85ca                	mv	a1,s2
    4b5c:	00003517          	auipc	a0,0x3
    4b60:	14450513          	addi	a0,a0,324 # 7ca0 <malloc+0x22c6>
    4b64:	5bf000ef          	jal	5922 <printf>
    exit(1);
    4b68:	4505                	li	a0,1
    4b6a:	133000ef          	jal	549c <exit>
  p = sbrk(PGSIZE);
    4b6e:	6505                	lui	a0,0x1
    4b70:	0f9000ef          	jal	5468 <sbrk>
    4b74:	862a                	mv	a2,a0
  if (p < 0 || (uint64)p != TRAPFRAME - PGSIZE) {
    4b76:	040007b7          	lui	a5,0x4000
    4b7a:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3fef315>
    4b7c:	07b2                	slli	a5,a5,0xc
    4b7e:	00f50c63          	beq	a0,a5,4b96 <lazy_sbrk+0x88>
    printf("sbrk(%d) returned %p, not expected TRAPFRAME-PGSIZE\n", PGSIZE, p);
    4b82:	6585                	lui	a1,0x1
    4b84:	00003517          	auipc	a0,0x3
    4b88:	14c50513          	addi	a0,a0,332 # 7cd0 <malloc+0x22f6>
    4b8c:	597000ef          	jal	5922 <printf>
    exit(1);
    4b90:	4505                	li	a0,1
    4b92:	10b000ef          	jal	549c <exit>
  p[0] = 1;
    4b96:	040007b7          	lui	a5,0x4000
    4b9a:	17f5                	addi	a5,a5,-3 # 3fffffd <base+0x3fef315>
    4b9c:	07b2                	slli	a5,a5,0xc
    4b9e:	4705                	li	a4,1
    4ba0:	00e78023          	sb	a4,0(a5)
  if (p[1] != 0) {
    4ba4:	0017c783          	lbu	a5,1(a5)
    4ba8:	cb91                	beqz	a5,4bbc <lazy_sbrk+0xae>
    printf("sbrk() returned non-zero-filled memory\n");
    4baa:	00003517          	auipc	a0,0x3
    4bae:	15e50513          	addi	a0,a0,350 # 7d08 <malloc+0x232e>
    4bb2:	571000ef          	jal	5922 <printf>
    exit(1);
    4bb6:	4505                	li	a0,1
    4bb8:	0e5000ef          	jal	549c <exit>
  p = sbrk(1);
    4bbc:	4505                	li	a0,1
    4bbe:	0ab000ef          	jal	5468 <sbrk>
    4bc2:	85aa                	mv	a1,a0
  if ((uint64)p != -1) {
    4bc4:	57fd                	li	a5,-1
    4bc6:	00f50b63          	beq	a0,a5,4bdc <lazy_sbrk+0xce>
    printf("sbrk(1) returned %p, expected error\n", p);
    4bca:	00003517          	auipc	a0,0x3
    4bce:	16650513          	addi	a0,a0,358 # 7d30 <malloc+0x2356>
    4bd2:	551000ef          	jal	5922 <printf>
    exit(1);
    4bd6:	4505                	li	a0,1
    4bd8:	0c5000ef          	jal	549c <exit>
  p = sbrklazy(1);
    4bdc:	4505                	li	a0,1
    4bde:	0a1000ef          	jal	547e <sbrklazy>
    4be2:	85aa                	mv	a1,a0
  if ((uint64)p != -1) {
    4be4:	57fd                	li	a5,-1
    4be6:	00f50b63          	beq	a0,a5,4bfc <lazy_sbrk+0xee>
    printf("sbrklazy(1) returned %p, expected error\n", p);
    4bea:	00003517          	auipc	a0,0x3
    4bee:	16e50513          	addi	a0,a0,366 # 7d58 <malloc+0x237e>
    4bf2:	531000ef          	jal	5922 <printf>
    exit(1);
    4bf6:	4505                	li	a0,1
    4bf8:	0a5000ef          	jal	549c <exit>
  exit(0);
    4bfc:	4501                	li	a0,0
    4bfe:	09f000ef          	jal	549c <exit>

0000000000004c02 <lazy_copyinstr>:
{
    4c02:	715d                	addi	sp,sp,-80
    4c04:	e486                	sd	ra,72(sp)
    4c06:	e0a2                	sd	s0,64(sp)
    4c08:	fc26                	sd	s1,56(sp)
    4c0a:	f84a                	sd	s2,48(sp)
    4c0c:	f44e                	sd	s3,40(sp)
    4c0e:	0880                	addi	s0,sp,80
    4c10:	89aa                	mv	s3,a0
  char *p = sbrk(0);
    4c12:	4501                	li	a0,0
    4c14:	055000ef          	jal	5468 <sbrk>
  sbrk(PGSIZE - ((uint64)p % PGSIZE));
    4c18:	6485                	lui	s1,0x1
    4c1a:	14fd                	addi	s1,s1,-1 # fff <bigdir+0x10b>
    4c1c:	009577b3          	and	a5,a0,s1
    4c20:	6505                	lui	a0,0x1
    4c22:	9d1d                	subw	a0,a0,a5
    4c24:	045000ef          	jal	5468 <sbrk>
  p = sbrk(0);
    4c28:	4501                	li	a0,0
    4c2a:	03f000ef          	jal	5468 <sbrk>
  if ((uint64)p % PGSIZE != 0) {
    4c2e:	8ce9                	and	s1,s1,a0
    4c30:	e8a9                	bnez	s1,4c82 <lazy_copyinstr+0x80>
    4c32:	892a                	mv	s2,a0
  sbrklazy(2 * PGSIZE);
    4c34:	6509                	lui	a0,0x2
    4c36:	049000ef          	jal	547e <sbrklazy>
  p[4095] = '/';
    4c3a:	6505                	lui	a0,0x1
    4c3c:	00a907b3          	add	a5,s2,a0
    4c40:	02f00713          	li	a4,47
    4c44:	fee78fa3          	sb	a4,-1(a5)
  int fd = open(&p[4095], O_RDONLY);
    4c48:	157d                	addi	a0,a0,-1 # fff <bigdir+0x10b>
    4c4a:	4581                	li	a1,0
    4c4c:	954a                	add	a0,a0,s2
    4c4e:	08f000ef          	jal	54dc <open>
    4c52:	84aa                	mv	s1,a0
  if (fd < 0) {
    4c54:	04054163          	bltz	a0,4c96 <lazy_copyinstr+0x94>
  int r = fstat(fd, &st);
    4c58:	fb840593          	addi	a1,s0,-72
    4c5c:	099000ef          	jal	54f4 <fstat>
  if (r < 0) {
    4c60:	04054463          	bltz	a0,4ca8 <lazy_copyinstr+0xa6>
  if (st.type != T_DIR) {
    4c64:	fc041703          	lh	a4,-64(s0)
    4c68:	4785                	li	a5,1
    4c6a:	04f71863          	bne	a4,a5,4cba <lazy_copyinstr+0xb8>
  close(fd);
    4c6e:	8526                	mv	a0,s1
    4c70:	055000ef          	jal	54c4 <close>
}
    4c74:	60a6                	ld	ra,72(sp)
    4c76:	6406                	ld	s0,64(sp)
    4c78:	74e2                	ld	s1,56(sp)
    4c7a:	7942                	ld	s2,48(sp)
    4c7c:	79a2                	ld	s3,40(sp)
    4c7e:	6161                	addi	sp,sp,80
    4c80:	8082                	ret
    printf("%s: sbrk did not align\n", s);
    4c82:	85ce                	mv	a1,s3
    4c84:	00003517          	auipc	a0,0x3
    4c88:	e7450513          	addi	a0,a0,-396 # 7af8 <malloc+0x211e>
    4c8c:	497000ef          	jal	5922 <printf>
    exit(1);
    4c90:	4505                	li	a0,1
    4c92:	00b000ef          	jal	549c <exit>
    printf("could not open /");
    4c96:	00003517          	auipc	a0,0x3
    4c9a:	0f250513          	addi	a0,a0,242 # 7d88 <malloc+0x23ae>
    4c9e:	485000ef          	jal	5922 <printf>
    exit(1);
    4ca2:	4505                	li	a0,1
    4ca4:	7f8000ef          	jal	549c <exit>
    printf("could not stat /");
    4ca8:	00003517          	auipc	a0,0x3
    4cac:	0f850513          	addi	a0,a0,248 # 7da0 <malloc+0x23c6>
    4cb0:	473000ef          	jal	5922 <printf>
    exit(1);
    4cb4:	4505                	li	a0,1
    4cb6:	7e6000ef          	jal	549c <exit>
    printf("/ is not T_DIR");
    4cba:	00003517          	auipc	a0,0x3
    4cbe:	0fe50513          	addi	a0,a0,254 # 7db8 <malloc+0x23de>
    4cc2:	461000ef          	jal	5922 <printf>
    exit(1);
    4cc6:	4505                	li	a0,1
    4cc8:	7d4000ef          	jal	549c <exit>

0000000000004ccc <fsfull>:
{
    4ccc:	7131                	addi	sp,sp,-192
    4cce:	fd06                	sd	ra,184(sp)
    4cd0:	f922                	sd	s0,176(sp)
    4cd2:	f526                	sd	s1,168(sp)
    4cd4:	f14a                	sd	s2,160(sp)
    4cd6:	ed4e                	sd	s3,152(sp)
    4cd8:	e952                	sd	s4,144(sp)
    4cda:	e556                	sd	s5,136(sp)
    4cdc:	e15a                	sd	s6,128(sp)
    4cde:	fcde                	sd	s7,120(sp)
    4ce0:	f8e2                	sd	s8,112(sp)
    4ce2:	f4e6                	sd	s9,104(sp)
    4ce4:	f0ea                	sd	s10,96(sp)
    4ce6:	ecee                	sd	s11,88(sp)
    4ce8:	0180                	addi	s0,sp,192
  printf("fsfull test\n");
    4cea:	00003517          	auipc	a0,0x3
    4cee:	0de50513          	addi	a0,a0,222 # 7dc8 <malloc+0x23ee>
    4cf2:	431000ef          	jal	5922 <printf>
  int fsblocks = 0;
    4cf6:	4981                	li	s3,0
  for (nfiles = 0;; nfiles++) {
    4cf8:	4481                	li	s1,0
    name[0] = 'f';
    4cfa:	06600d93          	li	s11,102
    name[1] = '0' + nfiles / 1000;
    4cfe:	106257b7          	lui	a5,0x10625
    4d02:	dd378793          	addi	a5,a5,-557 # 10624dd3 <base+0x106140eb>
    4d06:	f4f43423          	sd	a5,-184(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4d0a:	51eb8b37          	lui	s6,0x51eb8
    4d0e:	51fb0b13          	addi	s6,s6,1311 # 51eb851f <base+0x51ea7837>
    name[3] = '0' + (nfiles % 100) / 10;
    4d12:	66666ab7          	lui	s5,0x66666
    4d16:	667a8a93          	addi	s5,s5,1639 # 66666667 <base+0x6665597f>
    printf("writing %s\n", name);
    4d1a:	f5040d13          	addi	s10,s0,-176
    name[0] = 'f';
    4d1e:	f5b40823          	sb	s11,-176(s0)
    name[1] = '0' + nfiles / 1000;
    4d22:	f4843783          	ld	a5,-184(s0)
    4d26:	02f487b3          	mul	a5,s1,a5
    4d2a:	9799                	srai	a5,a5,0x26
    4d2c:	41f4d69b          	sraiw	a3,s1,0x1f
    4d30:	9f95                	subw	a5,a5,a3
    4d32:	0307871b          	addiw	a4,a5,48
    4d36:	f4e408a3          	sb	a4,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4d3a:	3e800713          	li	a4,1000
    4d3e:	02f707bb          	mulw	a5,a4,a5
    4d42:	40f487bb          	subw	a5,s1,a5
    4d46:	03678733          	mul	a4,a5,s6
    4d4a:	9715                	srai	a4,a4,0x25
    4d4c:	41f7d79b          	sraiw	a5,a5,0x1f
    4d50:	40f707bb          	subw	a5,a4,a5
    4d54:	0307879b          	addiw	a5,a5,48
    4d58:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    4d5c:	036487b3          	mul	a5,s1,s6
    4d60:	9795                	srai	a5,a5,0x25
    4d62:	9f95                	subw	a5,a5,a3
    4d64:	06400713          	li	a4,100
    4d68:	02f707bb          	mulw	a5,a4,a5
    4d6c:	40f487bb          	subw	a5,s1,a5
    4d70:	03578733          	mul	a4,a5,s5
    4d74:	9709                	srai	a4,a4,0x22
    4d76:	41f7d79b          	sraiw	a5,a5,0x1f
    4d7a:	40f707bb          	subw	a5,a4,a5
    4d7e:	0307879b          	addiw	a5,a5,48
    4d82:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    4d86:	03548733          	mul	a4,s1,s5
    4d8a:	9709                	srai	a4,a4,0x22
    4d8c:	9f15                	subw	a4,a4,a3
    4d8e:	0027179b          	slliw	a5,a4,0x2
    4d92:	9fb9                	addw	a5,a5,a4
    4d94:	0017979b          	slliw	a5,a5,0x1
    4d98:	40f487bb          	subw	a5,s1,a5
    4d9c:	0307879b          	addiw	a5,a5,48
    4da0:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4da4:	f4040aa3          	sb	zero,-171(s0)
    printf("writing %s\n", name);
    4da8:	85ea                	mv	a1,s10
    4daa:	00003517          	auipc	a0,0x3
    4dae:	02e50513          	addi	a0,a0,46 # 7dd8 <malloc+0x23fe>
    4db2:	371000ef          	jal	5922 <printf>
    int fd = open(name, O_CREATE | O_RDWR);
    4db6:	20200593          	li	a1,514
    4dba:	856a                	mv	a0,s10
    4dbc:	720000ef          	jal	54dc <open>
    4dc0:	892a                	mv	s2,a0
    if (fd < 0) {
    4dc2:	0e055c63          	bgez	a0,4eba <fsfull+0x1ee>
      printf("open %s failed\n", name);
    4dc6:	f5040593          	addi	a1,s0,-176
    4dca:	00003517          	auipc	a0,0x3
    4dce:	01e50513          	addi	a0,a0,30 # 7de8 <malloc+0x240e>
    4dd2:	351000ef          	jal	5922 <printf>
  while (nfiles >= 0) {
    4dd6:	0a04cc63          	bltz	s1,4e8e <fsfull+0x1c2>
    name[0] = 'f';
    4dda:	06600c93          	li	s9,102
    name[1] = '0' + nfiles / 1000;
    4dde:	10625ab7          	lui	s5,0x10625
    4de2:	dd3a8a93          	addi	s5,s5,-557 # 10624dd3 <base+0x106140eb>
    name[2] = '0' + (nfiles % 1000) / 100;
    4de6:	3e800c13          	li	s8,1000
    4dea:	51eb8a37          	lui	s4,0x51eb8
    4dee:	51fa0a13          	addi	s4,s4,1311 # 51eb851f <base+0x51ea7837>
    name[3] = '0' + (nfiles % 100) / 10;
    4df2:	06400b93          	li	s7,100
    4df6:	66666937          	lui	s2,0x66666
    4dfa:	66790913          	addi	s2,s2,1639 # 66666667 <base+0x6665597f>
    unlink(name);
    4dfe:	f5040b13          	addi	s6,s0,-176
    name[0] = 'f';
    4e02:	f5940823          	sb	s9,-176(s0)
    name[1] = '0' + nfiles / 1000;
    4e06:	035487b3          	mul	a5,s1,s5
    4e0a:	9799                	srai	a5,a5,0x26
    4e0c:	41f4d69b          	sraiw	a3,s1,0x1f
    4e10:	9f95                	subw	a5,a5,a3
    4e12:	0307871b          	addiw	a4,a5,48
    4e16:	f4e408a3          	sb	a4,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4e1a:	02fc07bb          	mulw	a5,s8,a5
    4e1e:	40f487bb          	subw	a5,s1,a5
    4e22:	03478733          	mul	a4,a5,s4
    4e26:	9715                	srai	a4,a4,0x25
    4e28:	41f7d79b          	sraiw	a5,a5,0x1f
    4e2c:	40f707bb          	subw	a5,a4,a5
    4e30:	0307879b          	addiw	a5,a5,48
    4e34:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    4e38:	034487b3          	mul	a5,s1,s4
    4e3c:	9795                	srai	a5,a5,0x25
    4e3e:	9f95                	subw	a5,a5,a3
    4e40:	02fb87bb          	mulw	a5,s7,a5
    4e44:	40f487bb          	subw	a5,s1,a5
    4e48:	03278733          	mul	a4,a5,s2
    4e4c:	9709                	srai	a4,a4,0x22
    4e4e:	41f7d79b          	sraiw	a5,a5,0x1f
    4e52:	40f707bb          	subw	a5,a4,a5
    4e56:	0307879b          	addiw	a5,a5,48
    4e5a:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    4e5e:	03248733          	mul	a4,s1,s2
    4e62:	9709                	srai	a4,a4,0x22
    4e64:	9f15                	subw	a4,a4,a3
    4e66:	0027179b          	slliw	a5,a4,0x2
    4e6a:	9fb9                	addw	a5,a5,a4
    4e6c:	0017979b          	slliw	a5,a5,0x1
    4e70:	40f487bb          	subw	a5,s1,a5
    4e74:	0307879b          	addiw	a5,a5,48
    4e78:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4e7c:	f4040aa3          	sb	zero,-171(s0)
    unlink(name);
    4e80:	855a                	mv	a0,s6
    4e82:	66a000ef          	jal	54ec <unlink>
    nfiles--;
    4e86:	34fd                	addiw	s1,s1,-1
  while (nfiles >= 0) {
    4e88:	57fd                	li	a5,-1
    4e8a:	f6f49ce3          	bne	s1,a5,4e02 <fsfull+0x136>
  printf("fsfull test finished, %d blocks\n", fsblocks);
    4e8e:	85ce                	mv	a1,s3
    4e90:	00003517          	auipc	a0,0x3
    4e94:	f7850513          	addi	a0,a0,-136 # 7e08 <malloc+0x242e>
    4e98:	28b000ef          	jal	5922 <printf>
}
    4e9c:	70ea                	ld	ra,184(sp)
    4e9e:	744a                	ld	s0,176(sp)
    4ea0:	74aa                	ld	s1,168(sp)
    4ea2:	790a                	ld	s2,160(sp)
    4ea4:	69ea                	ld	s3,152(sp)
    4ea6:	6a4a                	ld	s4,144(sp)
    4ea8:	6aaa                	ld	s5,136(sp)
    4eaa:	6b0a                	ld	s6,128(sp)
    4eac:	7be6                	ld	s7,120(sp)
    4eae:	7c46                	ld	s8,112(sp)
    4eb0:	7ca6                	ld	s9,104(sp)
    4eb2:	7d06                	ld	s10,96(sp)
    4eb4:	6de6                	ld	s11,88(sp)
    4eb6:	6129                	addi	sp,sp,192
    4eb8:	8082                	ret
    int total = 0;
    4eba:	4a01                	li	s4,0
      int cc = write(fd, buf, BSIZE);
    4ebc:	40000c93          	li	s9,1024
    4ec0:	00009c17          	auipc	s8,0x9
    4ec4:	e28c0c13          	addi	s8,s8,-472 # dce8 <buf>
      if (cc < BSIZE)
    4ec8:	3ff00b93          	li	s7,1023
      int cc = write(fd, buf, BSIZE);
    4ecc:	8666                	mv	a2,s9
    4ece:	85e2                	mv	a1,s8
    4ed0:	854a                	mv	a0,s2
    4ed2:	5ea000ef          	jal	54bc <write>
      if (cc < BSIZE)
    4ed6:	00abd663          	bge	s7,a0,4ee2 <fsfull+0x216>
      total += cc;
    4eda:	00aa0a3b          	addw	s4,s4,a0
      fsblocks++;
    4ede:	2985                	addiw	s3,s3,1 # 40000001 <base+0x3ffef319>
    while (1) {
    4ee0:	b7f5                	j	4ecc <fsfull+0x200>
    printf("wrote %d bytes\n", total);
    4ee2:	85d2                	mv	a1,s4
    4ee4:	00003517          	auipc	a0,0x3
    4ee8:	f1450513          	addi	a0,a0,-236 # 7df8 <malloc+0x241e>
    4eec:	237000ef          	jal	5922 <printf>
    close(fd);
    4ef0:	854a                	mv	a0,s2
    4ef2:	5d2000ef          	jal	54c4 <close>
    if (total == 0)
    4ef6:	ee0a00e3          	beqz	s4,4dd6 <fsfull+0x10a>
  for (nfiles = 0;; nfiles++) {
    4efa:	2485                	addiw	s1,s1,1
    4efc:	b50d                	j	4d1e <fsfull+0x52>

0000000000004efe <run>:

// run each test in its own process. run returns 1 if child's exit()
// indicates success.
int
run(void f(char *), char *s)
{
    4efe:	7179                	addi	sp,sp,-48
    4f00:	f406                	sd	ra,40(sp)
    4f02:	f022                	sd	s0,32(sp)
    4f04:	ec26                	sd	s1,24(sp)
    4f06:	e84a                	sd	s2,16(sp)
    4f08:	1800                	addi	s0,sp,48
    4f0a:	84aa                	mv	s1,a0
    4f0c:	892e                	mv	s2,a1
  int pid;
  int xstatus;

  printf("test %s: ", s);
    4f0e:	00003517          	auipc	a0,0x3
    4f12:	f2250513          	addi	a0,a0,-222 # 7e30 <malloc+0x2456>
    4f16:	20d000ef          	jal	5922 <printf>
  if ((pid = fork()) < 0) {
    4f1a:	57a000ef          	jal	5494 <fork>
    4f1e:	02054a63          	bltz	a0,4f52 <run+0x54>
    printf("runtest: fork error\n");
    exit(1);
  }
  if (pid == 0) {
    4f22:	c129                	beqz	a0,4f64 <run+0x66>
    f(s);
    exit(0);
  } else {
    wait(&xstatus);
    4f24:	fdc40513          	addi	a0,s0,-36
    4f28:	57c000ef          	jal	54a4 <wait>
    if (xstatus != 0)
    4f2c:	fdc42783          	lw	a5,-36(s0)
    4f30:	cf9d                	beqz	a5,4f6e <run+0x70>
      printf("FAILED\n");
    4f32:	00003517          	auipc	a0,0x3
    4f36:	f2650513          	addi	a0,a0,-218 # 7e58 <malloc+0x247e>
    4f3a:	1e9000ef          	jal	5922 <printf>
    else
      printf("OK\n");
    return xstatus == 0;
    4f3e:	fdc42503          	lw	a0,-36(s0)
  }
}
    4f42:	00153513          	seqz	a0,a0
    4f46:	70a2                	ld	ra,40(sp)
    4f48:	7402                	ld	s0,32(sp)
    4f4a:	64e2                	ld	s1,24(sp)
    4f4c:	6942                	ld	s2,16(sp)
    4f4e:	6145                	addi	sp,sp,48
    4f50:	8082                	ret
    printf("runtest: fork error\n");
    4f52:	00003517          	auipc	a0,0x3
    4f56:	eee50513          	addi	a0,a0,-274 # 7e40 <malloc+0x2466>
    4f5a:	1c9000ef          	jal	5922 <printf>
    exit(1);
    4f5e:	4505                	li	a0,1
    4f60:	53c000ef          	jal	549c <exit>
    f(s);
    4f64:	854a                	mv	a0,s2
    4f66:	9482                	jalr	s1
    exit(0);
    4f68:	4501                	li	a0,0
    4f6a:	532000ef          	jal	549c <exit>
      printf("OK\n");
    4f6e:	00003517          	auipc	a0,0x3
    4f72:	ef250513          	addi	a0,a0,-270 # 7e60 <malloc+0x2486>
    4f76:	1ad000ef          	jal	5922 <printf>
    4f7a:	b7d1                	j	4f3e <run+0x40>

0000000000004f7c <runtests>:

int
runtests(struct test *tests, char *justone, int continuous)
{
    4f7c:	7179                	addi	sp,sp,-48
    4f7e:	f406                	sd	ra,40(sp)
    4f80:	f022                	sd	s0,32(sp)
    4f82:	ec26                	sd	s1,24(sp)
    4f84:	e44e                	sd	s3,8(sp)
    4f86:	1800                	addi	s0,sp,48
    4f88:	84aa                	mv	s1,a0
  int ntests = 0;
  for (struct test *t = tests; t->s != 0; t++) {
    4f8a:	6508                	ld	a0,8(a0)
    4f8c:	cd29                	beqz	a0,4fe6 <runtests+0x6a>
    4f8e:	e84a                	sd	s2,16(sp)
    4f90:	e052                	sd	s4,0(sp)
    4f92:	892e                	mv	s2,a1
    if ((justone == 0) || strcmp(t->s, justone) == 0) {
      ntests++;
      if (!run(t->f, t->s)) {
        if (continuous != 2) {
    4f94:	1679                	addi	a2,a2,-2 # ffe <bigdir+0x10a>
    4f96:	00c03a33          	snez	s4,a2
  int ntests = 0;
    4f9a:	4981                	li	s3,0
    4f9c:	a029                	j	4fa6 <runtests+0x2a>
      ntests++;
    4f9e:	2985                	addiw	s3,s3,1
  for (struct test *t = tests; t->s != 0; t++) {
    4fa0:	04c1                	addi	s1,s1,16
    4fa2:	6488                	ld	a0,8(s1)
    4fa4:	c905                	beqz	a0,4fd4 <runtests+0x58>
    if ((justone == 0) || strcmp(t->s, justone) == 0) {
    4fa6:	00090663          	beqz	s2,4fb2 <runtests+0x36>
    4faa:	85ca                	mv	a1,s2
    4fac:	26a000ef          	jal	5216 <strcmp>
    4fb0:	f965                	bnez	a0,4fa0 <runtests+0x24>
      if (!run(t->f, t->s)) {
    4fb2:	648c                	ld	a1,8(s1)
    4fb4:	6088                	ld	a0,0(s1)
    4fb6:	f49ff0ef          	jal	4efe <run>
        if (continuous != 2) {
    4fba:	f175                	bnez	a0,4f9e <runtests+0x22>
    4fbc:	fe0a01e3          	beqz	s4,4f9e <runtests+0x22>
          printf("SOME TESTS FAILED\n");
    4fc0:	00003517          	auipc	a0,0x3
    4fc4:	ea850513          	addi	a0,a0,-344 # 7e68 <malloc+0x248e>
    4fc8:	15b000ef          	jal	5922 <printf>
          return -1;
    4fcc:	59fd                	li	s3,-1
    4fce:	6942                	ld	s2,16(sp)
    4fd0:	6a02                	ld	s4,0(sp)
    4fd2:	a019                	j	4fd8 <runtests+0x5c>
    4fd4:	6942                	ld	s2,16(sp)
    4fd6:	6a02                	ld	s4,0(sp)
        }
      }
    }
  }
  return ntests;
}
    4fd8:	854e                	mv	a0,s3
    4fda:	70a2                	ld	ra,40(sp)
    4fdc:	7402                	ld	s0,32(sp)
    4fde:	64e2                	ld	s1,24(sp)
    4fe0:	69a2                	ld	s3,8(sp)
    4fe2:	6145                	addi	sp,sp,48
    4fe4:	8082                	ret
  return ntests;
    4fe6:	4981                	li	s3,0
    4fe8:	bfc5                	j	4fd8 <runtests+0x5c>

0000000000004fea <countfree>:

// use sbrk() to count how many free physical memory pages there are.
int
countfree()
{
    4fea:	7179                	addi	sp,sp,-48
    4fec:	f406                	sd	ra,40(sp)
    4fee:	f022                	sd	s0,32(sp)
    4ff0:	ec26                	sd	s1,24(sp)
    4ff2:	e84a                	sd	s2,16(sp)
    4ff4:	e44e                	sd	s3,8(sp)
    4ff6:	e052                	sd	s4,0(sp)
    4ff8:	1800                	addi	s0,sp,48
  int n = 0;
  uint64 sz0 = (uint64)sbrk(0);
    4ffa:	4501                	li	a0,0
    4ffc:	46c000ef          	jal	5468 <sbrk>
    5000:	8a2a                	mv	s4,a0
  int n = 0;
    5002:	4481                	li	s1,0
  while (1) {
    char *a = sbrk(PGSIZE);
    5004:	6985                	lui	s3,0x1
    if (a == SBRK_ERROR) {
    5006:	597d                	li	s2,-1
    char *a = sbrk(PGSIZE);
    5008:	854e                	mv	a0,s3
    500a:	45e000ef          	jal	5468 <sbrk>
    if (a == SBRK_ERROR) {
    500e:	01250463          	beq	a0,s2,5016 <countfree+0x2c>
      break;
    }
    n += 1;
    5012:	2485                	addiw	s1,s1,1
  while (1) {
    5014:	bfd5                	j	5008 <countfree+0x1e>
  }
  sbrk(-((uint64)sbrk(0) - sz0));
    5016:	4501                	li	a0,0
    5018:	450000ef          	jal	5468 <sbrk>
    501c:	40aa053b          	subw	a0,s4,a0
    5020:	448000ef          	jal	5468 <sbrk>
  return n;
}
    5024:	8526                	mv	a0,s1
    5026:	70a2                	ld	ra,40(sp)
    5028:	7402                	ld	s0,32(sp)
    502a:	64e2                	ld	s1,24(sp)
    502c:	6942                	ld	s2,16(sp)
    502e:	69a2                	ld	s3,8(sp)
    5030:	6a02                	ld	s4,0(sp)
    5032:	6145                	addi	sp,sp,48
    5034:	8082                	ret

0000000000005036 <drivetests>:

int
drivetests(int quick, int continuous, char *justone)
{
    5036:	7159                	addi	sp,sp,-112
    5038:	f486                	sd	ra,104(sp)
    503a:	f0a2                	sd	s0,96(sp)
    503c:	eca6                	sd	s1,88(sp)
    503e:	e8ca                	sd	s2,80(sp)
    5040:	e4ce                	sd	s3,72(sp)
    5042:	e0d2                	sd	s4,64(sp)
    5044:	fc56                	sd	s5,56(sp)
    5046:	f85a                	sd	s6,48(sp)
    5048:	f45e                	sd	s7,40(sp)
    504a:	f062                	sd	s8,32(sp)
    504c:	ec66                	sd	s9,24(sp)
    504e:	e86a                	sd	s10,16(sp)
    5050:	e46e                	sd	s11,8(sp)
    5052:	1880                	addi	s0,sp,112
    5054:	8aaa                	mv	s5,a0
    5056:	89ae                	mv	s3,a1
    5058:	8a32                	mv	s4,a2
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
      if (continuous != 2) {
        return 1;
      }
    }
    if (justone != 0 && ntests == 0) {
    505a:	00c03d33          	snez	s10,a2
    printf("usertests starting\n");
    505e:	00003c17          	auipc	s8,0x3
    5062:	e22c0c13          	addi	s8,s8,-478 # 7e80 <malloc+0x24a6>
    n = runtests(quicktests, justone, continuous);
    5066:	00005b97          	auipc	s7,0x5
    506a:	faab8b93          	addi	s7,s7,-86 # a010 <quicktests>
      if (continuous != 2) {
    506e:	4b09                	li	s6,2
      n = runtests(slowtests, justone, continuous);
    5070:	00005c97          	auipc	s9,0x5
    5074:	3e0c8c93          	addi	s9,s9,992 # a450 <slowtests>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    5078:	00003d97          	auipc	s11,0x3
    507c:	e40d8d93          	addi	s11,s11,-448 # 7eb8 <malloc+0x24de>
    5080:	a82d                	j	50ba <drivetests+0x84>
      if (continuous != 2) {
    5082:	0b699363          	bne	s3,s6,5128 <drivetests+0xf2>
    int ntests = 0;
    5086:	4481                	li	s1,0
    5088:	a0b9                	j	50d6 <drivetests+0xa0>
        printf("usertests slow tests starting\n");
    508a:	00003517          	auipc	a0,0x3
    508e:	e0e50513          	addi	a0,a0,-498 # 7e98 <malloc+0x24be>
    5092:	091000ef          	jal	5922 <printf>
    5096:	a0a1                	j	50de <drivetests+0xa8>
        if (continuous != 2) {
    5098:	05698b63          	beq	s3,s6,50ee <drivetests+0xb8>
          return 1;
    509c:	4505                	li	a0,1
    509e:	a0b5                	j	510a <drivetests+0xd4>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    50a0:	864a                	mv	a2,s2
    50a2:	85aa                	mv	a1,a0
    50a4:	856e                	mv	a0,s11
    50a6:	07d000ef          	jal	5922 <printf>
      if (continuous != 2) {
    50aa:	09699163          	bne	s3,s6,512c <drivetests+0xf6>
    if (justone != 0 && ntests == 0) {
    50ae:	e491                	bnez	s1,50ba <drivetests+0x84>
    50b0:	000d0563          	beqz	s10,50ba <drivetests+0x84>
    50b4:	a0a1                	j	50fc <drivetests+0xc6>
      printf("NO TESTS EXECUTED\n");
      return 1;
    }
  } while (continuous);
    50b6:	06098d63          	beqz	s3,5130 <drivetests+0xfa>
    printf("usertests starting\n");
    50ba:	8562                	mv	a0,s8
    50bc:	067000ef          	jal	5922 <printf>
    int free0 = countfree();
    50c0:	f2bff0ef          	jal	4fea <countfree>
    50c4:	892a                	mv	s2,a0
    n = runtests(quicktests, justone, continuous);
    50c6:	864e                	mv	a2,s3
    50c8:	85d2                	mv	a1,s4
    50ca:	855e                	mv	a0,s7
    50cc:	eb1ff0ef          	jal	4f7c <runtests>
    50d0:	84aa                	mv	s1,a0
    if (n < 0) {
    50d2:	fa0548e3          	bltz	a0,5082 <drivetests+0x4c>
    if (!quick) {
    50d6:	000a9c63          	bnez	s5,50ee <drivetests+0xb8>
      if (justone == 0)
    50da:	fa0a08e3          	beqz	s4,508a <drivetests+0x54>
      n = runtests(slowtests, justone, continuous);
    50de:	864e                	mv	a2,s3
    50e0:	85d2                	mv	a1,s4
    50e2:	8566                	mv	a0,s9
    50e4:	e99ff0ef          	jal	4f7c <runtests>
      if (n < 0) {
    50e8:	fa0548e3          	bltz	a0,5098 <drivetests+0x62>
        ntests += n;
    50ec:	9ca9                	addw	s1,s1,a0
    if ((free1 = countfree()) < free0) {
    50ee:	efdff0ef          	jal	4fea <countfree>
    50f2:	fb2547e3          	blt	a0,s2,50a0 <drivetests+0x6a>
    if (justone != 0 && ntests == 0) {
    50f6:	f0e1                	bnez	s1,50b6 <drivetests+0x80>
    50f8:	fa0d0fe3          	beqz	s10,50b6 <drivetests+0x80>
      printf("NO TESTS EXECUTED\n");
    50fc:	00003517          	auipc	a0,0x3
    5100:	dec50513          	addi	a0,a0,-532 # 7ee8 <malloc+0x250e>
    5104:	01f000ef          	jal	5922 <printf>
      return 1;
    5108:	4505                	li	a0,1
  return 0;
}
    510a:	70a6                	ld	ra,104(sp)
    510c:	7406                	ld	s0,96(sp)
    510e:	64e6                	ld	s1,88(sp)
    5110:	6946                	ld	s2,80(sp)
    5112:	69a6                	ld	s3,72(sp)
    5114:	6a06                	ld	s4,64(sp)
    5116:	7ae2                	ld	s5,56(sp)
    5118:	7b42                	ld	s6,48(sp)
    511a:	7ba2                	ld	s7,40(sp)
    511c:	7c02                	ld	s8,32(sp)
    511e:	6ce2                	ld	s9,24(sp)
    5120:	6d42                	ld	s10,16(sp)
    5122:	6da2                	ld	s11,8(sp)
    5124:	6165                	addi	sp,sp,112
    5126:	8082                	ret
        return 1;
    5128:	4505                	li	a0,1
    512a:	b7c5                	j	510a <drivetests+0xd4>
        return 1;
    512c:	4505                	li	a0,1
    512e:	bff1                	j	510a <drivetests+0xd4>
  return 0;
    5130:	854e                	mv	a0,s3
    5132:	bfe1                	j	510a <drivetests+0xd4>

0000000000005134 <main>:

int
main(int argc, char *argv[])
{
    5134:	1101                	addi	sp,sp,-32
    5136:	ec06                	sd	ra,24(sp)
    5138:	e822                	sd	s0,16(sp)
    513a:	e426                	sd	s1,8(sp)
    513c:	e04a                	sd	s2,0(sp)
    513e:	1000                	addi	s0,sp,32
    5140:	84aa                	mv	s1,a0
  int continuous = 0;
  int quick = 0;
  char *justone = 0;

  if (argc == 2 && strcmp(argv[1], "-q") == 0) {
    5142:	4789                	li	a5,2
    5144:	00f50e63          	beq	a0,a5,5160 <main+0x2c>
    continuous = 1;
  } else if (argc == 2 && strcmp(argv[1], "-C") == 0) {
    continuous = 2;
  } else if (argc == 2 && argv[1][0] != '-') {
    justone = argv[1];
  } else if (argc > 1) {
    5148:	4785                	li	a5,1
    514a:	06a7c663          	blt	a5,a0,51b6 <main+0x82>
  char *justone = 0;
    514e:	4601                	li	a2,0
  int quick = 0;
    5150:	4501                	li	a0,0
  int continuous = 0;
    5152:	4581                	li	a1,0
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    exit(1);
  }
  if (drivetests(quick, continuous, justone)) {
    5154:	ee3ff0ef          	jal	5036 <drivetests>
    5158:	cd35                	beqz	a0,51d4 <main+0xa0>
    exit(1);
    515a:	4505                	li	a0,1
    515c:	340000ef          	jal	549c <exit>
    5160:	892e                	mv	s2,a1
  if (argc == 2 && strcmp(argv[1], "-q") == 0) {
    5162:	00003597          	auipc	a1,0x3
    5166:	d9e58593          	addi	a1,a1,-610 # 7f00 <malloc+0x2526>
    516a:	00893503          	ld	a0,8(s2)
    516e:	0a8000ef          	jal	5216 <strcmp>
    5172:	85aa                	mv	a1,a0
    5174:	e501                	bnez	a0,517c <main+0x48>
  char *justone = 0;
    5176:	4601                	li	a2,0
    quick = 1;
    5178:	4505                	li	a0,1
    517a:	bfe9                	j	5154 <main+0x20>
  } else if (argc == 2 && strcmp(argv[1], "-c") == 0) {
    517c:	00003597          	auipc	a1,0x3
    5180:	d8c58593          	addi	a1,a1,-628 # 7f08 <malloc+0x252e>
    5184:	00893503          	ld	a0,8(s2)
    5188:	08e000ef          	jal	5216 <strcmp>
    518c:	cd15                	beqz	a0,51c8 <main+0x94>
  } else if (argc == 2 && strcmp(argv[1], "-C") == 0) {
    518e:	00003597          	auipc	a1,0x3
    5192:	dca58593          	addi	a1,a1,-566 # 7f58 <malloc+0x257e>
    5196:	00893503          	ld	a0,8(s2)
    519a:	07c000ef          	jal	5216 <strcmp>
    519e:	c905                	beqz	a0,51ce <main+0x9a>
  } else if (argc == 2 && argv[1][0] != '-') {
    51a0:	00893603          	ld	a2,8(s2)
    51a4:	00064703          	lbu	a4,0(a2)
    51a8:	02d00793          	li	a5,45
    51ac:	00f70563          	beq	a4,a5,51b6 <main+0x82>
  int quick = 0;
    51b0:	4501                	li	a0,0
  int continuous = 0;
    51b2:	4581                	li	a1,0
    51b4:	b745                	j	5154 <main+0x20>
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    51b6:	00003517          	auipc	a0,0x3
    51ba:	d5a50513          	addi	a0,a0,-678 # 7f10 <malloc+0x2536>
    51be:	764000ef          	jal	5922 <printf>
    exit(1);
    51c2:	4505                	li	a0,1
    51c4:	2d8000ef          	jal	549c <exit>
  char *justone = 0;
    51c8:	4601                	li	a2,0
    continuous = 1;
    51ca:	4585                	li	a1,1
    51cc:	b761                	j	5154 <main+0x20>
    continuous = 2;
    51ce:	85a6                	mv	a1,s1
  char *justone = 0;
    51d0:	4601                	li	a2,0
    51d2:	b749                	j	5154 <main+0x20>
  }
  printf("ALL TESTS PASSED\n");
    51d4:	00003517          	auipc	a0,0x3
    51d8:	d6c50513          	addi	a0,a0,-660 # 7f40 <malloc+0x2566>
    51dc:	746000ef          	jal	5922 <printf>
  exit(0);
    51e0:	4501                	li	a0,0
    51e2:	2ba000ef          	jal	549c <exit>

00000000000051e6 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
    51e6:	1141                	addi	sp,sp,-16
    51e8:	e406                	sd	ra,8(sp)
    51ea:	e022                	sd	s0,0(sp)
    51ec:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
    51ee:	f47ff0ef          	jal	5134 <main>
  exit(r);
    51f2:	2aa000ef          	jal	549c <exit>

00000000000051f6 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
    51f6:	1141                	addi	sp,sp,-16
    51f8:	e406                	sd	ra,8(sp)
    51fa:	e022                	sd	s0,0(sp)
    51fc:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
    51fe:	87aa                	mv	a5,a0
    5200:	0585                	addi	a1,a1,1
    5202:	0785                	addi	a5,a5,1
    5204:	fff5c703          	lbu	a4,-1(a1)
    5208:	fee78fa3          	sb	a4,-1(a5)
    520c:	fb75                	bnez	a4,5200 <strcpy+0xa>
    ;
  return os;
}
    520e:	60a2                	ld	ra,8(sp)
    5210:	6402                	ld	s0,0(sp)
    5212:	0141                	addi	sp,sp,16
    5214:	8082                	ret

0000000000005216 <strcmp>:

int
strcmp(const char *p, const char *q)
{
    5216:	1141                	addi	sp,sp,-16
    5218:	e406                	sd	ra,8(sp)
    521a:	e022                	sd	s0,0(sp)
    521c:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
    521e:	00054783          	lbu	a5,0(a0)
    5222:	cb91                	beqz	a5,5236 <strcmp+0x20>
    5224:	0005c703          	lbu	a4,0(a1)
    5228:	00f71763          	bne	a4,a5,5236 <strcmp+0x20>
    p++, q++;
    522c:	0505                	addi	a0,a0,1
    522e:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
    5230:	00054783          	lbu	a5,0(a0)
    5234:	fbe5                	bnez	a5,5224 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
    5236:	0005c503          	lbu	a0,0(a1)
}
    523a:	40a7853b          	subw	a0,a5,a0
    523e:	60a2                	ld	ra,8(sp)
    5240:	6402                	ld	s0,0(sp)
    5242:	0141                	addi	sp,sp,16
    5244:	8082                	ret

0000000000005246 <strlen>:

uint
strlen(const char *s)
{
    5246:	1141                	addi	sp,sp,-16
    5248:	e406                	sd	ra,8(sp)
    524a:	e022                	sd	s0,0(sp)
    524c:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    524e:	00054783          	lbu	a5,0(a0)
    5252:	cf91                	beqz	a5,526e <strlen+0x28>
    5254:	00150793          	addi	a5,a0,1
    5258:	86be                	mv	a3,a5
    525a:	0785                	addi	a5,a5,1
    525c:	fff7c703          	lbu	a4,-1(a5)
    5260:	ff65                	bnez	a4,5258 <strlen+0x12>
    5262:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    5266:	60a2                	ld	ra,8(sp)
    5268:	6402                	ld	s0,0(sp)
    526a:	0141                	addi	sp,sp,16
    526c:	8082                	ret
  for (n = 0; s[n]; n++)
    526e:	4501                	li	a0,0
    5270:	bfdd                	j	5266 <strlen+0x20>

0000000000005272 <memset>:

void *
memset(void *dst, int c, uint n)
{
    5272:	1141                	addi	sp,sp,-16
    5274:	e406                	sd	ra,8(sp)
    5276:	e022                	sd	s0,0(sp)
    5278:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    527a:	ca19                	beqz	a2,5290 <memset+0x1e>
    527c:	87aa                	mv	a5,a0
    527e:	1602                	slli	a2,a2,0x20
    5280:	9201                	srli	a2,a2,0x20
    5282:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    5286:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    528a:	0785                	addi	a5,a5,1
    528c:	fee79de3          	bne	a5,a4,5286 <memset+0x14>
  }
  return dst;
}
    5290:	60a2                	ld	ra,8(sp)
    5292:	6402                	ld	s0,0(sp)
    5294:	0141                	addi	sp,sp,16
    5296:	8082                	ret

0000000000005298 <strchr>:

char *
strchr(const char *s, char c)
{
    5298:	1141                	addi	sp,sp,-16
    529a:	e406                	sd	ra,8(sp)
    529c:	e022                	sd	s0,0(sp)
    529e:	0800                	addi	s0,sp,16
  for (; *s; s++)
    52a0:	00054783          	lbu	a5,0(a0)
    52a4:	cf81                	beqz	a5,52bc <strchr+0x24>
    if (*s == c)
    52a6:	00f58763          	beq	a1,a5,52b4 <strchr+0x1c>
  for (; *s; s++)
    52aa:	0505                	addi	a0,a0,1
    52ac:	00054783          	lbu	a5,0(a0)
    52b0:	fbfd                	bnez	a5,52a6 <strchr+0xe>
      return (char *)s;
  return 0;
    52b2:	4501                	li	a0,0
}
    52b4:	60a2                	ld	ra,8(sp)
    52b6:	6402                	ld	s0,0(sp)
    52b8:	0141                	addi	sp,sp,16
    52ba:	8082                	ret
  return 0;
    52bc:	4501                	li	a0,0
    52be:	bfdd                	j	52b4 <strchr+0x1c>

00000000000052c0 <gets>:

char *
gets(char *buf, int max)
{
    52c0:	711d                	addi	sp,sp,-96
    52c2:	ec86                	sd	ra,88(sp)
    52c4:	e8a2                	sd	s0,80(sp)
    52c6:	e4a6                	sd	s1,72(sp)
    52c8:	e0ca                	sd	s2,64(sp)
    52ca:	fc4e                	sd	s3,56(sp)
    52cc:	f852                	sd	s4,48(sp)
    52ce:	f456                	sd	s5,40(sp)
    52d0:	f05a                	sd	s6,32(sp)
    52d2:	ec5e                	sd	s7,24(sp)
    52d4:	e862                	sd	s8,16(sp)
    52d6:	1080                	addi	s0,sp,96
    52d8:	8baa                	mv	s7,a0
    52da:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
    52dc:	892a                	mv	s2,a0
    52de:	4481                	li	s1,0
    cc = read(0, &c, 1);
    52e0:	faf40b13          	addi	s6,s0,-81
    52e4:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
    52e6:	8c26                	mv	s8,s1
    52e8:	0014899b          	addiw	s3,s1,1
    52ec:	84ce                	mv	s1,s3
    52ee:	0349d463          	bge	s3,s4,5316 <gets+0x56>
    cc = read(0, &c, 1);
    52f2:	8656                	mv	a2,s5
    52f4:	85da                	mv	a1,s6
    52f6:	4501                	li	a0,0
    52f8:	1bc000ef          	jal	54b4 <read>
    if (cc < 1)
    52fc:	00a05d63          	blez	a0,5316 <gets+0x56>
      break;
    buf[i++] = c;
    5300:	faf44783          	lbu	a5,-81(s0)
    5304:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
    5308:	0905                	addi	s2,s2,1
    530a:	ff678713          	addi	a4,a5,-10
    530e:	c319                	beqz	a4,5314 <gets+0x54>
    5310:	17cd                	addi	a5,a5,-13
    5312:	fbf1                	bnez	a5,52e6 <gets+0x26>
    buf[i++] = c;
    5314:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
    5316:	9c5e                	add	s8,s8,s7
    5318:	000c0023          	sb	zero,0(s8)
  return buf;
}
    531c:	855e                	mv	a0,s7
    531e:	60e6                	ld	ra,88(sp)
    5320:	6446                	ld	s0,80(sp)
    5322:	64a6                	ld	s1,72(sp)
    5324:	6906                	ld	s2,64(sp)
    5326:	79e2                	ld	s3,56(sp)
    5328:	7a42                	ld	s4,48(sp)
    532a:	7aa2                	ld	s5,40(sp)
    532c:	7b02                	ld	s6,32(sp)
    532e:	6be2                	ld	s7,24(sp)
    5330:	6c42                	ld	s8,16(sp)
    5332:	6125                	addi	sp,sp,96
    5334:	8082                	ret

0000000000005336 <stat>:

int
stat(const char *n, struct stat *st)
{
    5336:	1101                	addi	sp,sp,-32
    5338:	ec06                	sd	ra,24(sp)
    533a:	e822                	sd	s0,16(sp)
    533c:	e04a                	sd	s2,0(sp)
    533e:	1000                	addi	s0,sp,32
    5340:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    5342:	4581                	li	a1,0
    5344:	198000ef          	jal	54dc <open>
  if (fd < 0)
    5348:	02054263          	bltz	a0,536c <stat+0x36>
    534c:	e426                	sd	s1,8(sp)
    534e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
    5350:	85ca                	mv	a1,s2
    5352:	1a2000ef          	jal	54f4 <fstat>
    5356:	892a                	mv	s2,a0
  close(fd);
    5358:	8526                	mv	a0,s1
    535a:	16a000ef          	jal	54c4 <close>
  return r;
    535e:	64a2                	ld	s1,8(sp)
}
    5360:	854a                	mv	a0,s2
    5362:	60e2                	ld	ra,24(sp)
    5364:	6442                	ld	s0,16(sp)
    5366:	6902                	ld	s2,0(sp)
    5368:	6105                	addi	sp,sp,32
    536a:	8082                	ret
    return -1;
    536c:	57fd                	li	a5,-1
    536e:	893e                	mv	s2,a5
    5370:	bfc5                	j	5360 <stat+0x2a>

0000000000005372 <atoi>:

int
atoi(const char *s)
{
    5372:	1141                	addi	sp,sp,-16
    5374:	e406                	sd	ra,8(sp)
    5376:	e022                	sd	s0,0(sp)
    5378:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
    537a:	00054683          	lbu	a3,0(a0)
    537e:	fd06879b          	addiw	a5,a3,-48 # 3ffd0 <base+0x2f2e8>
    5382:	0ff7f793          	zext.b	a5,a5
    5386:	4625                	li	a2,9
    5388:	02f66963          	bltu	a2,a5,53ba <atoi+0x48>
    538c:	872a                	mv	a4,a0
  n = 0;
    538e:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
    5390:	0705                	addi	a4,a4,1 # 1000001 <base+0xfef319>
    5392:	0025179b          	slliw	a5,a0,0x2
    5396:	9fa9                	addw	a5,a5,a0
    5398:	0017979b          	slliw	a5,a5,0x1
    539c:	9fb5                	addw	a5,a5,a3
    539e:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
    53a2:	00074683          	lbu	a3,0(a4)
    53a6:	fd06879b          	addiw	a5,a3,-48
    53aa:	0ff7f793          	zext.b	a5,a5
    53ae:	fef671e3          	bgeu	a2,a5,5390 <atoi+0x1e>
  return n;
}
    53b2:	60a2                	ld	ra,8(sp)
    53b4:	6402                	ld	s0,0(sp)
    53b6:	0141                	addi	sp,sp,16
    53b8:	8082                	ret
  n = 0;
    53ba:	4501                	li	a0,0
    53bc:	bfdd                	j	53b2 <atoi+0x40>

00000000000053be <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
    53be:	1141                	addi	sp,sp,-16
    53c0:	e406                	sd	ra,8(sp)
    53c2:	e022                	sd	s0,0(sp)
    53c4:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    53c6:	02b57563          	bgeu	a0,a1,53f0 <memmove+0x32>
    while (n-- > 0)
    53ca:	00c05f63          	blez	a2,53e8 <memmove+0x2a>
    53ce:	1602                	slli	a2,a2,0x20
    53d0:	9201                	srli	a2,a2,0x20
    53d2:	00c507b3          	add	a5,a0,a2
  dst = vdst;
    53d6:	872a                	mv	a4,a0
      *dst++ = *src++;
    53d8:	0585                	addi	a1,a1,1
    53da:	0705                	addi	a4,a4,1
    53dc:	fff5c683          	lbu	a3,-1(a1)
    53e0:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    53e4:	fee79ae3          	bne	a5,a4,53d8 <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
    53e8:	60a2                	ld	ra,8(sp)
    53ea:	6402                	ld	s0,0(sp)
    53ec:	0141                	addi	sp,sp,16
    53ee:	8082                	ret
    while (n-- > 0)
    53f0:	fec05ce3          	blez	a2,53e8 <memmove+0x2a>
    dst += n;
    53f4:	00c50733          	add	a4,a0,a2
    src += n;
    53f8:	95b2                	add	a1,a1,a2
    53fa:	fff6079b          	addiw	a5,a2,-1
    53fe:	1782                	slli	a5,a5,0x20
    5400:	9381                	srli	a5,a5,0x20
    5402:	fff7c793          	not	a5,a5
    5406:	97ba                	add	a5,a5,a4
      *--dst = *--src;
    5408:	15fd                	addi	a1,a1,-1
    540a:	177d                	addi	a4,a4,-1
    540c:	0005c683          	lbu	a3,0(a1)
    5410:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
    5414:	fef71ae3          	bne	a4,a5,5408 <memmove+0x4a>
    5418:	bfc1                	j	53e8 <memmove+0x2a>

000000000000541a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
    541a:	1141                	addi	sp,sp,-16
    541c:	e406                	sd	ra,8(sp)
    541e:	e022                	sd	s0,0(sp)
    5420:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    5422:	c61d                	beqz	a2,5450 <memcmp+0x36>
    5424:	1602                	slli	a2,a2,0x20
    5426:	9201                	srli	a2,a2,0x20
    5428:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
    542c:	00054783          	lbu	a5,0(a0)
    5430:	0005c703          	lbu	a4,0(a1)
    5434:	00e79863          	bne	a5,a4,5444 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
    5438:	0505                	addi	a0,a0,1
    p2++;
    543a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    543c:	fed518e3          	bne	a0,a3,542c <memcmp+0x12>
  }
  return 0;
    5440:	4501                	li	a0,0
    5442:	a019                	j	5448 <memcmp+0x2e>
      return *p1 - *p2;
    5444:	40e7853b          	subw	a0,a5,a4
}
    5448:	60a2                	ld	ra,8(sp)
    544a:	6402                	ld	s0,0(sp)
    544c:	0141                	addi	sp,sp,16
    544e:	8082                	ret
  return 0;
    5450:	4501                	li	a0,0
    5452:	bfdd                	j	5448 <memcmp+0x2e>

0000000000005454 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
    5454:	1141                	addi	sp,sp,-16
    5456:	e406                	sd	ra,8(sp)
    5458:	e022                	sd	s0,0(sp)
    545a:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    545c:	f63ff0ef          	jal	53be <memmove>
}
    5460:	60a2                	ld	ra,8(sp)
    5462:	6402                	ld	s0,0(sp)
    5464:	0141                	addi	sp,sp,16
    5466:	8082                	ret

0000000000005468 <sbrk>:

char *
sbrk(int n)
{
    5468:	1141                	addi	sp,sp,-16
    546a:	e406                	sd	ra,8(sp)
    546c:	e022                	sd	s0,0(sp)
    546e:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
    5470:	4585                	li	a1,1
    5472:	0b2000ef          	jal	5524 <sys_sbrk>
}
    5476:	60a2                	ld	ra,8(sp)
    5478:	6402                	ld	s0,0(sp)
    547a:	0141                	addi	sp,sp,16
    547c:	8082                	ret

000000000000547e <sbrklazy>:

char *
sbrklazy(int n)
{
    547e:	1141                	addi	sp,sp,-16
    5480:	e406                	sd	ra,8(sp)
    5482:	e022                	sd	s0,0(sp)
    5484:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
    5486:	4589                	li	a1,2
    5488:	09c000ef          	jal	5524 <sys_sbrk>
}
    548c:	60a2                	ld	ra,8(sp)
    548e:	6402                	ld	s0,0(sp)
    5490:	0141                	addi	sp,sp,16
    5492:	8082                	ret

0000000000005494 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
    5494:	4885                	li	a7,1
 ecall
    5496:	00000073          	ecall
 ret
    549a:	8082                	ret

000000000000549c <exit>:
.global exit
exit:
 li a7, SYS_exit
    549c:	4889                	li	a7,2
 ecall
    549e:	00000073          	ecall
 ret
    54a2:	8082                	ret

00000000000054a4 <wait>:
.global wait
wait:
 li a7, SYS_wait
    54a4:	488d                	li	a7,3
 ecall
    54a6:	00000073          	ecall
 ret
    54aa:	8082                	ret

00000000000054ac <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
    54ac:	4891                	li	a7,4
 ecall
    54ae:	00000073          	ecall
 ret
    54b2:	8082                	ret

00000000000054b4 <read>:
.global read
read:
 li a7, SYS_read
    54b4:	4895                	li	a7,5
 ecall
    54b6:	00000073          	ecall
 ret
    54ba:	8082                	ret

00000000000054bc <write>:
.global write
write:
 li a7, SYS_write
    54bc:	48c1                	li	a7,16
 ecall
    54be:	00000073          	ecall
 ret
    54c2:	8082                	ret

00000000000054c4 <close>:
.global close
close:
 li a7, SYS_close
    54c4:	48d5                	li	a7,21
 ecall
    54c6:	00000073          	ecall
 ret
    54ca:	8082                	ret

00000000000054cc <kill>:
.global kill
kill:
 li a7, SYS_kill
    54cc:	4899                	li	a7,6
 ecall
    54ce:	00000073          	ecall
 ret
    54d2:	8082                	ret

00000000000054d4 <exec>:
.global exec
exec:
 li a7, SYS_exec
    54d4:	489d                	li	a7,7
 ecall
    54d6:	00000073          	ecall
 ret
    54da:	8082                	ret

00000000000054dc <open>:
.global open
open:
 li a7, SYS_open
    54dc:	48bd                	li	a7,15
 ecall
    54de:	00000073          	ecall
 ret
    54e2:	8082                	ret

00000000000054e4 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
    54e4:	48c5                	li	a7,17
 ecall
    54e6:	00000073          	ecall
 ret
    54ea:	8082                	ret

00000000000054ec <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
    54ec:	48c9                	li	a7,18
 ecall
    54ee:	00000073          	ecall
 ret
    54f2:	8082                	ret

00000000000054f4 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
    54f4:	48a1                	li	a7,8
 ecall
    54f6:	00000073          	ecall
 ret
    54fa:	8082                	ret

00000000000054fc <link>:
.global link
link:
 li a7, SYS_link
    54fc:	48cd                	li	a7,19
 ecall
    54fe:	00000073          	ecall
 ret
    5502:	8082                	ret

0000000000005504 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
    5504:	48d1                	li	a7,20
 ecall
    5506:	00000073          	ecall
 ret
    550a:	8082                	ret

000000000000550c <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
    550c:	48a5                	li	a7,9
 ecall
    550e:	00000073          	ecall
 ret
    5512:	8082                	ret

0000000000005514 <dup>:
.global dup
dup:
 li a7, SYS_dup
    5514:	48a9                	li	a7,10
 ecall
    5516:	00000073          	ecall
 ret
    551a:	8082                	ret

000000000000551c <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
    551c:	48ad                	li	a7,11
 ecall
    551e:	00000073          	ecall
 ret
    5522:	8082                	ret

0000000000005524 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
    5524:	48b1                	li	a7,12
 ecall
    5526:	00000073          	ecall
 ret
    552a:	8082                	ret

000000000000552c <pause>:
.global pause
pause:
 li a7, SYS_pause
    552c:	48b5                	li	a7,13
 ecall
    552e:	00000073          	ecall
 ret
    5532:	8082                	ret

0000000000005534 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
    5534:	48b9                	li	a7,14
 ecall
    5536:	00000073          	ecall
 ret
    553a:	8082                	ret

000000000000553c <sync>:
.global sync
sync:
 li a7, SYS_sync
    553c:	48d9                	li	a7,22
 ecall
    553e:	00000073          	ecall
 ret
    5542:	8082                	ret

0000000000005544 <clone>:
.global clone
clone:
 li a7, SYS_clone
    5544:	48dd                	li	a7,23
 ecall
    5546:	00000073          	ecall
 ret
    554a:	8082                	ret

000000000000554c <join>:
.global join
join:
 li a7, SYS_join
    554c:	48e1                	li	a7,24
 ecall
    554e:	00000073          	ecall
 ret
    5552:	8082                	ret

0000000000005554 <sem_init>:
.global sem_init
sem_init:
 li a7, SYS_sem_init
    5554:	48e5                	li	a7,25
 ecall
    5556:	00000073          	ecall
 ret
    555a:	8082                	ret

000000000000555c <sem_wait>:
.global sem_wait
sem_wait:
 li a7, SYS_sem_wait
    555c:	48e9                	li	a7,26
 ecall
    555e:	00000073          	ecall
 ret
    5562:	8082                	ret

0000000000005564 <sem_signal>:
.global sem_signal
sem_signal:
 li a7, SYS_sem_signal
    5564:	48ed                	li	a7,27
 ecall
    5566:	00000073          	ecall
 ret
    556a:	8082                	ret

000000000000556c <set_priority>:
.global set_priority
set_priority:
 li a7, SYS_set_priority
    556c:	48f1                	li	a7,28
 ecall
    556e:	00000073          	ecall
 ret
    5572:	8082                	ret

0000000000005574 <get_priority>:
.global get_priority
get_priority:
 li a7, SYS_get_priority
    5574:	48f5                	li	a7,29
 ecall
    5576:	00000073          	ecall
 ret
    557a:	8082                	ret

000000000000557c <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
    557c:	1101                	addi	sp,sp,-32
    557e:	ec06                	sd	ra,24(sp)
    5580:	e822                	sd	s0,16(sp)
    5582:	1000                	addi	s0,sp,32
    5584:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
    5588:	4605                	li	a2,1
    558a:	fef40593          	addi	a1,s0,-17
    558e:	f2fff0ef          	jal	54bc <write>
}
    5592:	60e2                	ld	ra,24(sp)
    5594:	6442                	ld	s0,16(sp)
    5596:	6105                	addi	sp,sp,32
    5598:	8082                	ret

000000000000559a <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
    559a:	715d                	addi	sp,sp,-80
    559c:	e486                	sd	ra,72(sp)
    559e:	e0a2                	sd	s0,64(sp)
    55a0:	f84a                	sd	s2,48(sp)
    55a2:	f44e                	sd	s3,40(sp)
    55a4:	0880                	addi	s0,sp,80
    55a6:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
    55a8:	c6d1                	beqz	a3,5634 <printint+0x9a>
    55aa:	0805d563          	bgez	a1,5634 <printint+0x9a>
    neg = 1;
    x = -xx;
    55ae:	40b005b3          	neg	a1,a1
    neg = 1;
    55b2:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
    55b4:	fb840993          	addi	s3,s0,-72
  neg = 0;
    55b8:	86ce                	mv	a3,s3
  i = 0;
    55ba:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    55bc:	00003817          	auipc	a6,0x3
    55c0:	df480813          	addi	a6,a6,-524 # 83b0 <digits>
    55c4:	88ba                	mv	a7,a4
    55c6:	0017051b          	addiw	a0,a4,1
    55ca:	872a                	mv	a4,a0
    55cc:	02c5f7b3          	remu	a5,a1,a2
    55d0:	97c2                	add	a5,a5,a6
    55d2:	0007c783          	lbu	a5,0(a5)
    55d6:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
    55da:	87ae                	mv	a5,a1
    55dc:	02c5d5b3          	divu	a1,a1,a2
    55e0:	0685                	addi	a3,a3,1
    55e2:	fec7f1e3          	bgeu	a5,a2,55c4 <printint+0x2a>
  if (neg)
    55e6:	00030c63          	beqz	t1,55fe <printint+0x64>
    buf[i++] = '-';
    55ea:	fd050793          	addi	a5,a0,-48
    55ee:	00878533          	add	a0,a5,s0
    55f2:	02d00793          	li	a5,45
    55f6:	fef50423          	sb	a5,-24(a0)
    55fa:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
    55fe:	02e05563          	blez	a4,5628 <printint+0x8e>
    5602:	fc26                	sd	s1,56(sp)
    5604:	377d                	addiw	a4,a4,-1
    5606:	00e984b3          	add	s1,s3,a4
    560a:	19fd                	addi	s3,s3,-1 # fff <bigdir+0x10b>
    560c:	99ba                	add	s3,s3,a4
    560e:	1702                	slli	a4,a4,0x20
    5610:	9301                	srli	a4,a4,0x20
    5612:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
    5616:	0004c583          	lbu	a1,0(s1)
    561a:	854a                	mv	a0,s2
    561c:	f61ff0ef          	jal	557c <putc>
  while (--i >= 0)
    5620:	14fd                	addi	s1,s1,-1
    5622:	ff349ae3          	bne	s1,s3,5616 <printint+0x7c>
    5626:	74e2                	ld	s1,56(sp)
}
    5628:	60a6                	ld	ra,72(sp)
    562a:	6406                	ld	s0,64(sp)
    562c:	7942                	ld	s2,48(sp)
    562e:	79a2                	ld	s3,40(sp)
    5630:	6161                	addi	sp,sp,80
    5632:	8082                	ret
  neg = 0;
    5634:	4301                	li	t1,0
    5636:	bfbd                	j	55b4 <printint+0x1a>

0000000000005638 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
    5638:	711d                	addi	sp,sp,-96
    563a:	ec86                	sd	ra,88(sp)
    563c:	e8a2                	sd	s0,80(sp)
    563e:	e4a6                	sd	s1,72(sp)
    5640:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
    5642:	0005c483          	lbu	s1,0(a1)
    5646:	22048363          	beqz	s1,586c <vprintf+0x234>
    564a:	e0ca                	sd	s2,64(sp)
    564c:	fc4e                	sd	s3,56(sp)
    564e:	f852                	sd	s4,48(sp)
    5650:	f456                	sd	s5,40(sp)
    5652:	f05a                	sd	s6,32(sp)
    5654:	ec5e                	sd	s7,24(sp)
    5656:	e862                	sd	s8,16(sp)
    5658:	8b2a                	mv	s6,a0
    565a:	8a2e                	mv	s4,a1
    565c:	8bb2                	mv	s7,a2
  state = 0;
    565e:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
    5660:	4901                	li	s2,0
    5662:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
    5664:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
    5668:	06400c13          	li	s8,100
    566c:	a00d                	j	568e <vprintf+0x56>
        putc(fd, c0);
    566e:	85a6                	mv	a1,s1
    5670:	855a                	mv	a0,s6
    5672:	f0bff0ef          	jal	557c <putc>
    5676:	a019                	j	567c <vprintf+0x44>
    } else if (state == '%') {
    5678:	03598363          	beq	s3,s5,569e <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
    567c:	0019079b          	addiw	a5,s2,1
    5680:	893e                	mv	s2,a5
    5682:	873e                	mv	a4,a5
    5684:	97d2                	add	a5,a5,s4
    5686:	0007c483          	lbu	s1,0(a5)
    568a:	1c048a63          	beqz	s1,585e <vprintf+0x226>
    c0 = fmt[i] & 0xff;
    568e:	0004879b          	sext.w	a5,s1
    if (state == 0) {
    5692:	fe0993e3          	bnez	s3,5678 <vprintf+0x40>
      if (c0 == '%') {
    5696:	fd579ce3          	bne	a5,s5,566e <vprintf+0x36>
        state = '%';
    569a:	89be                	mv	s3,a5
    569c:	b7c5                	j	567c <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
    569e:	00ea06b3          	add	a3,s4,a4
    56a2:	0016c603          	lbu	a2,1(a3)
      if (c1)
    56a6:	1c060863          	beqz	a2,5876 <vprintf+0x23e>
      if (c0 == 'd') {
    56aa:	03878763          	beq	a5,s8,56d8 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
    56ae:	f9478693          	addi	a3,a5,-108
    56b2:	0016b693          	seqz	a3,a3
    56b6:	f9c60593          	addi	a1,a2,-100
    56ba:	e99d                	bnez	a1,56f0 <vprintf+0xb8>
    56bc:	ca95                	beqz	a3,56f0 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
    56be:	008b8493          	addi	s1,s7,8
    56c2:	4685                	li	a3,1
    56c4:	4629                	li	a2,10
    56c6:	000bb583          	ld	a1,0(s7)
    56ca:	855a                	mv	a0,s6
    56cc:	ecfff0ef          	jal	559a <printint>
        i += 1;
    56d0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
    56d2:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
    56d4:	4981                	li	s3,0
    56d6:	b75d                	j	567c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
    56d8:	008b8493          	addi	s1,s7,8
    56dc:	4685                	li	a3,1
    56de:	4629                	li	a2,10
    56e0:	000ba583          	lw	a1,0(s7)
    56e4:	855a                	mv	a0,s6
    56e6:	eb5ff0ef          	jal	559a <printint>
    56ea:	8ba6                	mv	s7,s1
      state = 0;
    56ec:	4981                	li	s3,0
    56ee:	b779                	j	567c <vprintf+0x44>
        c2 = fmt[i + 2] & 0xff;
    56f0:	9752                	add	a4,a4,s4
    56f2:	00274583          	lbu	a1,2(a4)
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    56f6:	f9460713          	addi	a4,a2,-108
    56fa:	00173713          	seqz	a4,a4
    56fe:	8f75                	and	a4,a4,a3
    5700:	f9c58513          	addi	a0,a1,-100
    5704:	18051363          	bnez	a0,588a <vprintf+0x252>
    5708:	18070163          	beqz	a4,588a <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
    570c:	008b8493          	addi	s1,s7,8
    5710:	4685                	li	a3,1
    5712:	4629                	li	a2,10
    5714:	000bb583          	ld	a1,0(s7)
    5718:	855a                	mv	a0,s6
    571a:	e81ff0ef          	jal	559a <printint>
        i += 2;
    571e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
    5720:	8ba6                	mv	s7,s1
      state = 0;
    5722:	4981                	li	s3,0
        i += 2;
    5724:	bfa1                	j	567c <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
    5726:	008b8493          	addi	s1,s7,8
    572a:	4681                	li	a3,0
    572c:	4629                	li	a2,10
    572e:	000be583          	lwu	a1,0(s7)
    5732:	855a                	mv	a0,s6
    5734:	e67ff0ef          	jal	559a <printint>
    5738:	8ba6                	mv	s7,s1
      state = 0;
    573a:	4981                	li	s3,0
    573c:	b781                	j	567c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    573e:	008b8493          	addi	s1,s7,8
    5742:	4681                	li	a3,0
    5744:	4629                	li	a2,10
    5746:	000bb583          	ld	a1,0(s7)
    574a:	855a                	mv	a0,s6
    574c:	e4fff0ef          	jal	559a <printint>
        i += 1;
    5750:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
    5752:	8ba6                	mv	s7,s1
      state = 0;
    5754:	4981                	li	s3,0
    5756:	b71d                	j	567c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    5758:	008b8493          	addi	s1,s7,8
    575c:	4681                	li	a3,0
    575e:	4629                	li	a2,10
    5760:	000bb583          	ld	a1,0(s7)
    5764:	855a                	mv	a0,s6
    5766:	e35ff0ef          	jal	559a <printint>
        i += 2;
    576a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
    576c:	8ba6                	mv	s7,s1
      state = 0;
    576e:	4981                	li	s3,0
        i += 2;
    5770:	b731                	j	567c <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
    5772:	008b8493          	addi	s1,s7,8
    5776:	4681                	li	a3,0
    5778:	4641                	li	a2,16
    577a:	000be583          	lwu	a1,0(s7)
    577e:	855a                	mv	a0,s6
    5780:	e1bff0ef          	jal	559a <printint>
    5784:	8ba6                	mv	s7,s1
      state = 0;
    5786:	4981                	li	s3,0
    5788:	bdd5                	j	567c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    578a:	008b8493          	addi	s1,s7,8
    578e:	4681                	li	a3,0
    5790:	4641                	li	a2,16
    5792:	000bb583          	ld	a1,0(s7)
    5796:	855a                	mv	a0,s6
    5798:	e03ff0ef          	jal	559a <printint>
        i += 1;
    579c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
    579e:	8ba6                	mv	s7,s1
      state = 0;
    57a0:	4981                	li	s3,0
    57a2:	bde9                	j	567c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    57a4:	008b8493          	addi	s1,s7,8
    57a8:	4681                	li	a3,0
    57aa:	4641                	li	a2,16
    57ac:	000bb583          	ld	a1,0(s7)
    57b0:	855a                	mv	a0,s6
    57b2:	de9ff0ef          	jal	559a <printint>
        i += 2;
    57b6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
    57b8:	8ba6                	mv	s7,s1
      state = 0;
    57ba:	4981                	li	s3,0
        i += 2;
    57bc:	b5c1                	j	567c <vprintf+0x44>
    57be:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
    57c0:	008b8793          	addi	a5,s7,8
    57c4:	8cbe                	mv	s9,a5
    57c6:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
    57ca:	03000593          	li	a1,48
    57ce:	855a                	mv	a0,s6
    57d0:	dadff0ef          	jal	557c <putc>
  putc(fd, 'x');
    57d4:	07800593          	li	a1,120
    57d8:	855a                	mv	a0,s6
    57da:	da3ff0ef          	jal	557c <putc>
    57de:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    57e0:	00003b97          	auipc	s7,0x3
    57e4:	bd0b8b93          	addi	s7,s7,-1072 # 83b0 <digits>
    57e8:	03c9d793          	srli	a5,s3,0x3c
    57ec:	97de                	add	a5,a5,s7
    57ee:	0007c583          	lbu	a1,0(a5)
    57f2:	855a                	mv	a0,s6
    57f4:	d89ff0ef          	jal	557c <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    57f8:	0992                	slli	s3,s3,0x4
    57fa:	34fd                	addiw	s1,s1,-1
    57fc:	f4f5                	bnez	s1,57e8 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
    57fe:	8be6                	mv	s7,s9
      state = 0;
    5800:	4981                	li	s3,0
    5802:	6ca2                	ld	s9,8(sp)
    5804:	bda5                	j	567c <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
    5806:	008b8493          	addi	s1,s7,8
    580a:	000bc583          	lbu	a1,0(s7)
    580e:	855a                	mv	a0,s6
    5810:	d6dff0ef          	jal	557c <putc>
    5814:	8ba6                	mv	s7,s1
      state = 0;
    5816:	4981                	li	s3,0
    5818:	b595                	j	567c <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
    581a:	008b8993          	addi	s3,s7,8
    581e:	000bb483          	ld	s1,0(s7)
    5822:	cc91                	beqz	s1,583e <vprintf+0x206>
        for (; *s; s++)
    5824:	0004c583          	lbu	a1,0(s1)
    5828:	c985                	beqz	a1,5858 <vprintf+0x220>
          putc(fd, *s);
    582a:	855a                	mv	a0,s6
    582c:	d51ff0ef          	jal	557c <putc>
        for (; *s; s++)
    5830:	0485                	addi	s1,s1,1
    5832:	0004c583          	lbu	a1,0(s1)
    5836:	f9f5                	bnez	a1,582a <vprintf+0x1f2>
        if ((s = va_arg(ap, char *)) == 0)
    5838:	8bce                	mv	s7,s3
      state = 0;
    583a:	4981                	li	s3,0
    583c:	b581                	j	567c <vprintf+0x44>
          s = "(null)";
    583e:	00003497          	auipc	s1,0x3
    5842:	ac248493          	addi	s1,s1,-1342 # 8300 <malloc+0x2926>
        for (; *s; s++)
    5846:	02800593          	li	a1,40
    584a:	b7c5                	j	582a <vprintf+0x1f2>
        putc(fd, '%');
    584c:	85be                	mv	a1,a5
    584e:	855a                	mv	a0,s6
    5850:	d2dff0ef          	jal	557c <putc>
      state = 0;
    5854:	4981                	li	s3,0
    5856:	b51d                	j	567c <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
    5858:	8bce                	mv	s7,s3
      state = 0;
    585a:	4981                	li	s3,0
    585c:	b505                	j	567c <vprintf+0x44>
    585e:	6906                	ld	s2,64(sp)
    5860:	79e2                	ld	s3,56(sp)
    5862:	7a42                	ld	s4,48(sp)
    5864:	7aa2                	ld	s5,40(sp)
    5866:	7b02                	ld	s6,32(sp)
    5868:	6be2                	ld	s7,24(sp)
    586a:	6c42                	ld	s8,16(sp)
    }
  }
}
    586c:	60e6                	ld	ra,88(sp)
    586e:	6446                	ld	s0,80(sp)
    5870:	64a6                	ld	s1,72(sp)
    5872:	6125                	addi	sp,sp,96
    5874:	8082                	ret
      if (c0 == 'd') {
    5876:	06400713          	li	a4,100
    587a:	e4e78fe3          	beq	a5,a4,56d8 <vprintf+0xa0>
      } else if (c0 == 'l' && c1 == 'd') {
    587e:	f9478693          	addi	a3,a5,-108
    5882:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
    5886:	85b2                	mv	a1,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    5888:	4701                	li	a4,0
      } else if (c0 == 'u') {
    588a:	07500513          	li	a0,117
    588e:	e8a78ce3          	beq	a5,a0,5726 <vprintf+0xee>
      } else if (c0 == 'l' && c1 == 'u') {
    5892:	f8b60513          	addi	a0,a2,-117
    5896:	e119                	bnez	a0,589c <vprintf+0x264>
    5898:	ea0693e3          	bnez	a3,573e <vprintf+0x106>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    589c:	f8b58513          	addi	a0,a1,-117
    58a0:	e119                	bnez	a0,58a6 <vprintf+0x26e>
    58a2:	ea071be3          	bnez	a4,5758 <vprintf+0x120>
      } else if (c0 == 'x') {
    58a6:	07800513          	li	a0,120
    58aa:	eca784e3          	beq	a5,a0,5772 <vprintf+0x13a>
      } else if (c0 == 'l' && c1 == 'x') {
    58ae:	f8860613          	addi	a2,a2,-120
    58b2:	e219                	bnez	a2,58b8 <vprintf+0x280>
    58b4:	ec069be3          	bnez	a3,578a <vprintf+0x152>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    58b8:	f8858593          	addi	a1,a1,-120
    58bc:	e199                	bnez	a1,58c2 <vprintf+0x28a>
    58be:	ee0713e3          	bnez	a4,57a4 <vprintf+0x16c>
      } else if (c0 == 'p') {
    58c2:	07000713          	li	a4,112
    58c6:	eee78ce3          	beq	a5,a4,57be <vprintf+0x186>
      } else if (c0 == 'c') {
    58ca:	06300713          	li	a4,99
    58ce:	f2e78ce3          	beq	a5,a4,5806 <vprintf+0x1ce>
      } else if (c0 == 's') {
    58d2:	07300713          	li	a4,115
    58d6:	f4e782e3          	beq	a5,a4,581a <vprintf+0x1e2>
      } else if (c0 == '%') {
    58da:	02500713          	li	a4,37
    58de:	f6e787e3          	beq	a5,a4,584c <vprintf+0x214>
        putc(fd, '%');
    58e2:	02500593          	li	a1,37
    58e6:	855a                	mv	a0,s6
    58e8:	c95ff0ef          	jal	557c <putc>
        putc(fd, c0);
    58ec:	85a6                	mv	a1,s1
    58ee:	855a                	mv	a0,s6
    58f0:	c8dff0ef          	jal	557c <putc>
      state = 0;
    58f4:	4981                	li	s3,0
    58f6:	b359                	j	567c <vprintf+0x44>

00000000000058f8 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    58f8:	715d                	addi	sp,sp,-80
    58fa:	ec06                	sd	ra,24(sp)
    58fc:	e822                	sd	s0,16(sp)
    58fe:	1000                	addi	s0,sp,32
    5900:	e010                	sd	a2,0(s0)
    5902:	e414                	sd	a3,8(s0)
    5904:	e818                	sd	a4,16(s0)
    5906:	ec1c                	sd	a5,24(s0)
    5908:	03043023          	sd	a6,32(s0)
    590c:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    5910:	8622                	mv	a2,s0
    5912:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    5916:	d23ff0ef          	jal	5638 <vprintf>
}
    591a:	60e2                	ld	ra,24(sp)
    591c:	6442                	ld	s0,16(sp)
    591e:	6161                	addi	sp,sp,80
    5920:	8082                	ret

0000000000005922 <printf>:

void
printf(const char *fmt, ...)
{
    5922:	711d                	addi	sp,sp,-96
    5924:	ec06                	sd	ra,24(sp)
    5926:	e822                	sd	s0,16(sp)
    5928:	1000                	addi	s0,sp,32
    592a:	e40c                	sd	a1,8(s0)
    592c:	e810                	sd	a2,16(s0)
    592e:	ec14                	sd	a3,24(s0)
    5930:	f018                	sd	a4,32(s0)
    5932:	f41c                	sd	a5,40(s0)
    5934:	03043823          	sd	a6,48(s0)
    5938:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    593c:	00840613          	addi	a2,s0,8
    5940:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    5944:	85aa                	mv	a1,a0
    5946:	4505                	li	a0,1
    5948:	cf1ff0ef          	jal	5638 <vprintf>
}
    594c:	60e2                	ld	ra,24(sp)
    594e:	6442                	ld	s0,16(sp)
    5950:	6125                	addi	sp,sp,96
    5952:	8082                	ret

0000000000005954 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    5954:	1141                	addi	sp,sp,-16
    5956:	e406                	sd	ra,8(sp)
    5958:	e022                	sd	s0,0(sp)
    595a:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
    595c:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    5960:	00005797          	auipc	a5,0x5
    5964:	b607b783          	ld	a5,-1184(a5) # a4c0 <freep>
    5968:	a039                	j	5976 <free+0x22>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    596a:	6398                	ld	a4,0(a5)
    596c:	00e7e463          	bltu	a5,a4,5974 <free+0x20>
    5970:	00e6ea63          	bltu	a3,a4,5984 <free+0x30>
{
    5974:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    5976:	fed7fae3          	bgeu	a5,a3,596a <free+0x16>
    597a:	6398                	ld	a4,0(a5)
    597c:	00e6e463          	bltu	a3,a4,5984 <free+0x30>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    5980:	fee7eae3          	bltu	a5,a4,5974 <free+0x20>
      break;
  if (bp + bp->s.size == p->s.ptr) {
    5984:	ff852583          	lw	a1,-8(a0)
    5988:	6390                	ld	a2,0(a5)
    598a:	02059813          	slli	a6,a1,0x20
    598e:	01c85713          	srli	a4,a6,0x1c
    5992:	9736                	add	a4,a4,a3
    5994:	02e60563          	beq	a2,a4,59be <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    5998:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
    599c:	4790                	lw	a2,8(a5)
    599e:	02061593          	slli	a1,a2,0x20
    59a2:	01c5d713          	srli	a4,a1,0x1c
    59a6:	973e                	add	a4,a4,a5
    59a8:	02e68263          	beq	a3,a4,59cc <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    59ac:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    59ae:	00005717          	auipc	a4,0x5
    59b2:	b0f73923          	sd	a5,-1262(a4) # a4c0 <freep>
}
    59b6:	60a2                	ld	ra,8(sp)
    59b8:	6402                	ld	s0,0(sp)
    59ba:	0141                	addi	sp,sp,16
    59bc:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    59be:	4618                	lw	a4,8(a2)
    59c0:	9f2d                	addw	a4,a4,a1
    59c2:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    59c6:	6398                	ld	a4,0(a5)
    59c8:	6310                	ld	a2,0(a4)
    59ca:	b7f9                	j	5998 <free+0x44>
    p->s.size += bp->s.size;
    59cc:	ff852703          	lw	a4,-8(a0)
    59d0:	9f31                	addw	a4,a4,a2
    59d2:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    59d4:	ff053683          	ld	a3,-16(a0)
    59d8:	bfd1                	j	59ac <free+0x58>

00000000000059da <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
    59da:	7139                	addi	sp,sp,-64
    59dc:	fc06                	sd	ra,56(sp)
    59de:	f822                	sd	s0,48(sp)
    59e0:	f04a                	sd	s2,32(sp)
    59e2:	ec4e                	sd	s3,24(sp)
    59e4:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
    59e6:	02051993          	slli	s3,a0,0x20
    59ea:	0209d993          	srli	s3,s3,0x20
    59ee:	09bd                	addi	s3,s3,15
    59f0:	0049d993          	srli	s3,s3,0x4
    59f4:	2985                	addiw	s3,s3,1
    59f6:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
    59f8:	00005517          	auipc	a0,0x5
    59fc:	ac853503          	ld	a0,-1336(a0) # a4c0 <freep>
    5a00:	c905                	beqz	a0,5a30 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    5a02:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    5a04:	4798                	lw	a4,8(a5)
    5a06:	09377663          	bgeu	a4,s3,5a92 <malloc+0xb8>
    5a0a:	f426                	sd	s1,40(sp)
    5a0c:	e852                	sd	s4,16(sp)
    5a0e:	e456                	sd	s5,8(sp)
    5a10:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
    5a12:	8a4e                	mv	s4,s3
    5a14:	6705                	lui	a4,0x1
    5a16:	00e9f363          	bgeu	s3,a4,5a1c <malloc+0x42>
    5a1a:	6a05                	lui	s4,0x1
    5a1c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    5a20:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
    5a24:	00005497          	auipc	s1,0x5
    5a28:	a9c48493          	addi	s1,s1,-1380 # a4c0 <freep>
  if (p == SBRK_ERROR)
    5a2c:	5afd                	li	s5,-1
    5a2e:	a83d                	j	5a6c <malloc+0x92>
    5a30:	f426                	sd	s1,40(sp)
    5a32:	e852                	sd	s4,16(sp)
    5a34:	e456                	sd	s5,8(sp)
    5a36:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    5a38:	0000b797          	auipc	a5,0xb
    5a3c:	2b078793          	addi	a5,a5,688 # 10ce8 <base>
    5a40:	00005717          	auipc	a4,0x5
    5a44:	a8f73023          	sd	a5,-1408(a4) # a4c0 <freep>
    5a48:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    5a4a:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
    5a4e:	b7d1                	j	5a12 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    5a50:	6398                	ld	a4,0(a5)
    5a52:	e118                	sd	a4,0(a0)
    5a54:	a899                	j	5aaa <malloc+0xd0>
  hp->s.size = nu;
    5a56:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
    5a5a:	0541                	addi	a0,a0,16
    5a5c:	ef9ff0ef          	jal	5954 <free>
  return freep;
    5a60:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
    5a62:	c125                	beqz	a0,5ac2 <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
    5a64:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
    5a66:	4798                	lw	a4,8(a5)
    5a68:	03277163          	bgeu	a4,s2,5a8a <malloc+0xb0>
    if (p == freep)
    5a6c:	6098                	ld	a4,0(s1)
    5a6e:	853e                	mv	a0,a5
    5a70:	fef71ae3          	bne	a4,a5,5a64 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    5a74:	8552                	mv	a0,s4
    5a76:	9f3ff0ef          	jal	5468 <sbrk>
  if (p == SBRK_ERROR)
    5a7a:	fd551ee3          	bne	a0,s5,5a56 <malloc+0x7c>
        return 0;
    5a7e:	4501                	li	a0,0
    5a80:	74a2                	ld	s1,40(sp)
    5a82:	6a42                	ld	s4,16(sp)
    5a84:	6aa2                	ld	s5,8(sp)
    5a86:	6b02                	ld	s6,0(sp)
    5a88:	a03d                	j	5ab6 <malloc+0xdc>
    5a8a:	74a2                	ld	s1,40(sp)
    5a8c:	6a42                	ld	s4,16(sp)
    5a8e:	6aa2                	ld	s5,8(sp)
    5a90:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
    5a92:	fae90fe3          	beq	s2,a4,5a50 <malloc+0x76>
        p->s.size -= nunits;
    5a96:	4137073b          	subw	a4,a4,s3
    5a9a:	c798                	sw	a4,8(a5)
        p += p->s.size;
    5a9c:	02071693          	slli	a3,a4,0x20
    5aa0:	01c6d713          	srli	a4,a3,0x1c
    5aa4:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    5aa6:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    5aaa:	00005717          	auipc	a4,0x5
    5aae:	a0a73b23          	sd	a0,-1514(a4) # a4c0 <freep>
      return (void *)(p + 1);
    5ab2:	01078513          	addi	a0,a5,16
  }
}
    5ab6:	70e2                	ld	ra,56(sp)
    5ab8:	7442                	ld	s0,48(sp)
    5aba:	7902                	ld	s2,32(sp)
    5abc:	69e2                	ld	s3,24(sp)
    5abe:	6121                	addi	sp,sp,64
    5ac0:	8082                	ret
    5ac2:	74a2                	ld	s1,40(sp)
    5ac4:	6a42                	ld	s4,16(sp)
    5ac6:	6aa2                	ld	s5,8(sp)
    5ac8:	6b02                	ld	s6,0(sp)
    5aca:	b7f5                	j	5ab6 <malloc+0xdc>
