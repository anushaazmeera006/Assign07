kernel/semaphore.o: kernel/semaphore.c kernel/types.h kernel/riscv.h \
 kernel/spinlock.h kernel/param.h kernel/proc.h kernel/defs.h \
 kernel/semaphore.h
