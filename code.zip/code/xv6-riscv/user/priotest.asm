
user/_priotest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:

volatile int order = 0;

int
main(void)
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	1800                	addi	s0,sp,48
  int lowpid, highpid;
  int lowpriority = 20;
  int highpriority = 2;

  printf("Q4: Priority Scheduling and Aging Test\n");
   8:	00001517          	auipc	a0,0x1
   c:	a1850513          	addi	a0,a0,-1512 # a20 <malloc+0xf4>
  10:	065000ef          	jal	874 <printf>

  // Q4: Verify priority system calls.
  if (get_priority(getpid()) != 10 ||
  14:	45a000ef          	jal	46e <getpid>
  18:	4ae000ef          	jal	4c6 <get_priority>
  1c:	47a9                	li	a5,10
  1e:	00f50c63          	beq	a0,a5,36 <main+0x36>
  22:	ec26                	sd	s1,24(sp)
      set_priority(getpid(), 5) < 0 ||
      get_priority(getpid()) != 5) {
    printf("FAIL: priority system calls\n");
  24:	00001517          	auipc	a0,0x1
  28:	a2450513          	addi	a0,a0,-1500 # a48 <malloc+0x11c>
  2c:	049000ef          	jal	874 <printf>
    exit(1);
  30:	4505                	li	a0,1
  32:	3bc000ef          	jal	3ee <exit>
      set_priority(getpid(), 5) < 0 ||
  36:	438000ef          	jal	46e <getpid>
  3a:	4595                	li	a1,5
  3c:	482000ef          	jal	4be <set_priority>
  if (get_priority(getpid()) != 10 ||
  40:	fe0541e3          	bltz	a0,22 <main+0x22>
      get_priority(getpid()) != 5) {
  44:	42a000ef          	jal	46e <getpid>
  48:	47e000ef          	jal	4c6 <get_priority>
      set_priority(getpid(), 5) < 0 ||
  4c:	4795                	li	a5,5
  4e:	fcf51ae3          	bne	a0,a5,22 <main+0x22>
  52:	ec26                	sd	s1,24(sp)
  }
  printf("PASS: priority system calls\n");
  54:	00001517          	auipc	a0,0x1
  58:	a1c50513          	addi	a0,a0,-1508 # a70 <malloc+0x144>
  5c:	019000ef          	jal	874 <printf>

  // Q4: Create two workers with different priorities.
  lowpid = fork();
  60:	386000ef          	jal	3e6 <fork>
  64:	84aa                	mv	s1,a0
  if (lowpid == 0) {
  66:	e121                	bnez	a0,a6 <main+0xa6>
    set_priority(getpid(), lowpriority);
  68:	406000ef          	jal	46e <getpid>
  6c:	45d1                	li	a1,20
  6e:	450000ef          	jal	4be <set_priority>
    for (volatile int i = 0; i < 3000000; i++)
  72:	fc042e23          	sw	zero,-36(s0)
  76:	002dc737          	lui	a4,0x2dc
  7a:	6bf70713          	addi	a4,a4,1727 # 2dc6bf <base+0x2da6af>
  7e:	a031                	j	8a <main+0x8a>
  80:	fdc42783          	lw	a5,-36(s0)
  84:	2785                	addiw	a5,a5,1
  86:	fcf42e23          	sw	a5,-36(s0)
  8a:	fdc42783          	lw	a5,-36(s0)
  8e:	2781                	sext.w	a5,a5
  90:	fef758e3          	bge	a4,a5,80 <main+0x80>
      ;
    printf("Low-priority worker finished\n");
  94:	00001517          	auipc	a0,0x1
  98:	9fc50513          	addi	a0,a0,-1540 # a90 <malloc+0x164>
  9c:	7d8000ef          	jal	874 <printf>
    exit(0);
  a0:	4501                	li	a0,0
  a2:	34c000ef          	jal	3ee <exit>
  }

  highpid = fork();
  a6:	340000ef          	jal	3e6 <fork>
  if (highpid == 0) {
  aa:	c129                	beqz	a0,ec <main+0xec>
      ;
    printf("High-priority worker finished\n");
    exit(0);
  }

  if (lowpid > 0 && highpid > 0) {
  ac:	00905463          	blez	s1,b4 <main+0xb4>
  b0:	06a04d63          	bgtz	a0,12a <main+0x12a>
    wait(0);
    wait(0);
  }

  // Q4: Show aging changes in a low-priority process.
  printf("Aging test: waiting process starts at priority %d\n",
  b4:	45d1                	li	a1,20
  b6:	00001517          	auipc	a0,0x1
  ba:	a1a50513          	addi	a0,a0,-1510 # ad0 <malloc+0x1a4>
  be:	7b6000ef          	jal	874 <printf>
         lowpriority);
  printf("Aging policy: after 30 scheduler scans, priority improves by 1\n");
  c2:	00001517          	auipc	a0,0x1
  c6:	a4650513          	addi	a0,a0,-1466 # b08 <malloc+0x1dc>
  ca:	7aa000ef          	jal	874 <printf>
  printf("Inspect kernel/proc.c scheduler output to observe actual aging.\n");
  ce:	00001517          	auipc	a0,0x1
  d2:	a7a50513          	addi	a0,a0,-1414 # b48 <malloc+0x21c>
  d6:	79e000ef          	jal	874 <printf>

  printf("Q4 test completed.\n");
  da:	00001517          	auipc	a0,0x1
  de:	ab650513          	addi	a0,a0,-1354 # b90 <malloc+0x264>
  e2:	792000ef          	jal	874 <printf>
  exit(0);
  e6:	4501                	li	a0,0
  e8:	306000ef          	jal	3ee <exit>
    set_priority(getpid(), highpriority);
  ec:	382000ef          	jal	46e <getpid>
  f0:	4589                	li	a1,2
  f2:	3cc000ef          	jal	4be <set_priority>
    for (volatile int i = 0; i < 3000000; i++)
  f6:	fc042e23          	sw	zero,-36(s0)
  fa:	002dc737          	lui	a4,0x2dc
  fe:	6bf70713          	addi	a4,a4,1727 # 2dc6bf <base+0x2da6af>
 102:	a031                	j	10e <main+0x10e>
 104:	fdc42783          	lw	a5,-36(s0)
 108:	2785                	addiw	a5,a5,1
 10a:	fcf42e23          	sw	a5,-36(s0)
 10e:	fdc42783          	lw	a5,-36(s0)
 112:	2781                	sext.w	a5,a5
 114:	fef758e3          	bge	a4,a5,104 <main+0x104>
    printf("High-priority worker finished\n");
 118:	00001517          	auipc	a0,0x1
 11c:	99850513          	addi	a0,a0,-1640 # ab0 <malloc+0x184>
 120:	754000ef          	jal	874 <printf>
    exit(0);
 124:	4501                	li	a0,0
 126:	2c8000ef          	jal	3ee <exit>
    wait(0);
 12a:	4501                	li	a0,0
 12c:	2ca000ef          	jal	3f6 <wait>
    wait(0);
 130:	4501                	li	a0,0
 132:	2c4000ef          	jal	3f6 <wait>
 136:	bfbd                	j	b4 <main+0xb4>

0000000000000138 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 138:	1141                	addi	sp,sp,-16
 13a:	e406                	sd	ra,8(sp)
 13c:	e022                	sd	s0,0(sp)
 13e:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 140:	ec1ff0ef          	jal	0 <main>
  exit(r);
 144:	2aa000ef          	jal	3ee <exit>

0000000000000148 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
 148:	1141                	addi	sp,sp,-16
 14a:	e406                	sd	ra,8(sp)
 14c:	e022                	sd	s0,0(sp)
 14e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
 150:	87aa                	mv	a5,a0
 152:	0585                	addi	a1,a1,1
 154:	0785                	addi	a5,a5,1
 156:	fff5c703          	lbu	a4,-1(a1)
 15a:	fee78fa3          	sb	a4,-1(a5)
 15e:	fb75                	bnez	a4,152 <strcpy+0xa>
    ;
  return os;
}
 160:	60a2                	ld	ra,8(sp)
 162:	6402                	ld	s0,0(sp)
 164:	0141                	addi	sp,sp,16
 166:	8082                	ret

0000000000000168 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 168:	1141                	addi	sp,sp,-16
 16a:	e406                	sd	ra,8(sp)
 16c:	e022                	sd	s0,0(sp)
 16e:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
 170:	00054783          	lbu	a5,0(a0)
 174:	cb91                	beqz	a5,188 <strcmp+0x20>
 176:	0005c703          	lbu	a4,0(a1)
 17a:	00f71763          	bne	a4,a5,188 <strcmp+0x20>
    p++, q++;
 17e:	0505                	addi	a0,a0,1
 180:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
 182:	00054783          	lbu	a5,0(a0)
 186:	fbe5                	bnez	a5,176 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 188:	0005c503          	lbu	a0,0(a1)
}
 18c:	40a7853b          	subw	a0,a5,a0
 190:	60a2                	ld	ra,8(sp)
 192:	6402                	ld	s0,0(sp)
 194:	0141                	addi	sp,sp,16
 196:	8082                	ret

0000000000000198 <strlen>:

uint
strlen(const char *s)
{
 198:	1141                	addi	sp,sp,-16
 19a:	e406                	sd	ra,8(sp)
 19c:	e022                	sd	s0,0(sp)
 19e:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
 1a0:	00054783          	lbu	a5,0(a0)
 1a4:	cf91                	beqz	a5,1c0 <strlen+0x28>
 1a6:	00150793          	addi	a5,a0,1
 1aa:	86be                	mv	a3,a5
 1ac:	0785                	addi	a5,a5,1
 1ae:	fff7c703          	lbu	a4,-1(a5)
 1b2:	ff65                	bnez	a4,1aa <strlen+0x12>
 1b4:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 1b8:	60a2                	ld	ra,8(sp)
 1ba:	6402                	ld	s0,0(sp)
 1bc:	0141                	addi	sp,sp,16
 1be:	8082                	ret
  for (n = 0; s[n]; n++)
 1c0:	4501                	li	a0,0
 1c2:	bfdd                	j	1b8 <strlen+0x20>

00000000000001c4 <memset>:

void *
memset(void *dst, int c, uint n)
{
 1c4:	1141                	addi	sp,sp,-16
 1c6:	e406                	sd	ra,8(sp)
 1c8:	e022                	sd	s0,0(sp)
 1ca:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 1cc:	ca19                	beqz	a2,1e2 <memset+0x1e>
 1ce:	87aa                	mv	a5,a0
 1d0:	1602                	slli	a2,a2,0x20
 1d2:	9201                	srli	a2,a2,0x20
 1d4:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 1d8:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 1dc:	0785                	addi	a5,a5,1
 1de:	fee79de3          	bne	a5,a4,1d8 <memset+0x14>
  }
  return dst;
}
 1e2:	60a2                	ld	ra,8(sp)
 1e4:	6402                	ld	s0,0(sp)
 1e6:	0141                	addi	sp,sp,16
 1e8:	8082                	ret

00000000000001ea <strchr>:

char *
strchr(const char *s, char c)
{
 1ea:	1141                	addi	sp,sp,-16
 1ec:	e406                	sd	ra,8(sp)
 1ee:	e022                	sd	s0,0(sp)
 1f0:	0800                	addi	s0,sp,16
  for (; *s; s++)
 1f2:	00054783          	lbu	a5,0(a0)
 1f6:	cf81                	beqz	a5,20e <strchr+0x24>
    if (*s == c)
 1f8:	00f58763          	beq	a1,a5,206 <strchr+0x1c>
  for (; *s; s++)
 1fc:	0505                	addi	a0,a0,1
 1fe:	00054783          	lbu	a5,0(a0)
 202:	fbfd                	bnez	a5,1f8 <strchr+0xe>
      return (char *)s;
  return 0;
 204:	4501                	li	a0,0
}
 206:	60a2                	ld	ra,8(sp)
 208:	6402                	ld	s0,0(sp)
 20a:	0141                	addi	sp,sp,16
 20c:	8082                	ret
  return 0;
 20e:	4501                	li	a0,0
 210:	bfdd                	j	206 <strchr+0x1c>

0000000000000212 <gets>:

char *
gets(char *buf, int max)
{
 212:	711d                	addi	sp,sp,-96
 214:	ec86                	sd	ra,88(sp)
 216:	e8a2                	sd	s0,80(sp)
 218:	e4a6                	sd	s1,72(sp)
 21a:	e0ca                	sd	s2,64(sp)
 21c:	fc4e                	sd	s3,56(sp)
 21e:	f852                	sd	s4,48(sp)
 220:	f456                	sd	s5,40(sp)
 222:	f05a                	sd	s6,32(sp)
 224:	ec5e                	sd	s7,24(sp)
 226:	e862                	sd	s8,16(sp)
 228:	1080                	addi	s0,sp,96
 22a:	8baa                	mv	s7,a0
 22c:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 22e:	892a                	mv	s2,a0
 230:	4481                	li	s1,0
    cc = read(0, &c, 1);
 232:	faf40b13          	addi	s6,s0,-81
 236:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
 238:	8c26                	mv	s8,s1
 23a:	0014899b          	addiw	s3,s1,1
 23e:	84ce                	mv	s1,s3
 240:	0349d463          	bge	s3,s4,268 <gets+0x56>
    cc = read(0, &c, 1);
 244:	8656                	mv	a2,s5
 246:	85da                	mv	a1,s6
 248:	4501                	li	a0,0
 24a:	1bc000ef          	jal	406 <read>
    if (cc < 1)
 24e:	00a05d63          	blez	a0,268 <gets+0x56>
      break;
    buf[i++] = c;
 252:	faf44783          	lbu	a5,-81(s0)
 256:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 25a:	0905                	addi	s2,s2,1
 25c:	ff678713          	addi	a4,a5,-10
 260:	c319                	beqz	a4,266 <gets+0x54>
 262:	17cd                	addi	a5,a5,-13
 264:	fbf1                	bnez	a5,238 <gets+0x26>
    buf[i++] = c;
 266:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 268:	9c5e                	add	s8,s8,s7
 26a:	000c0023          	sb	zero,0(s8)
  return buf;
}
 26e:	855e                	mv	a0,s7
 270:	60e6                	ld	ra,88(sp)
 272:	6446                	ld	s0,80(sp)
 274:	64a6                	ld	s1,72(sp)
 276:	6906                	ld	s2,64(sp)
 278:	79e2                	ld	s3,56(sp)
 27a:	7a42                	ld	s4,48(sp)
 27c:	7aa2                	ld	s5,40(sp)
 27e:	7b02                	ld	s6,32(sp)
 280:	6be2                	ld	s7,24(sp)
 282:	6c42                	ld	s8,16(sp)
 284:	6125                	addi	sp,sp,96
 286:	8082                	ret

0000000000000288 <stat>:

int
stat(const char *n, struct stat *st)
{
 288:	1101                	addi	sp,sp,-32
 28a:	ec06                	sd	ra,24(sp)
 28c:	e822                	sd	s0,16(sp)
 28e:	e04a                	sd	s2,0(sp)
 290:	1000                	addi	s0,sp,32
 292:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 294:	4581                	li	a1,0
 296:	198000ef          	jal	42e <open>
  if (fd < 0)
 29a:	02054263          	bltz	a0,2be <stat+0x36>
 29e:	e426                	sd	s1,8(sp)
 2a0:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 2a2:	85ca                	mv	a1,s2
 2a4:	1a2000ef          	jal	446 <fstat>
 2a8:	892a                	mv	s2,a0
  close(fd);
 2aa:	8526                	mv	a0,s1
 2ac:	16a000ef          	jal	416 <close>
  return r;
 2b0:	64a2                	ld	s1,8(sp)
}
 2b2:	854a                	mv	a0,s2
 2b4:	60e2                	ld	ra,24(sp)
 2b6:	6442                	ld	s0,16(sp)
 2b8:	6902                	ld	s2,0(sp)
 2ba:	6105                	addi	sp,sp,32
 2bc:	8082                	ret
    return -1;
 2be:	57fd                	li	a5,-1
 2c0:	893e                	mv	s2,a5
 2c2:	bfc5                	j	2b2 <stat+0x2a>

00000000000002c4 <atoi>:

int
atoi(const char *s)
{
 2c4:	1141                	addi	sp,sp,-16
 2c6:	e406                	sd	ra,8(sp)
 2c8:	e022                	sd	s0,0(sp)
 2ca:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 2cc:	00054683          	lbu	a3,0(a0)
 2d0:	fd06879b          	addiw	a5,a3,-48
 2d4:	0ff7f793          	zext.b	a5,a5
 2d8:	4625                	li	a2,9
 2da:	02f66963          	bltu	a2,a5,30c <atoi+0x48>
 2de:	872a                	mv	a4,a0
  n = 0;
 2e0:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 2e2:	0705                	addi	a4,a4,1
 2e4:	0025179b          	slliw	a5,a0,0x2
 2e8:	9fa9                	addw	a5,a5,a0
 2ea:	0017979b          	slliw	a5,a5,0x1
 2ee:	9fb5                	addw	a5,a5,a3
 2f0:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 2f4:	00074683          	lbu	a3,0(a4)
 2f8:	fd06879b          	addiw	a5,a3,-48
 2fc:	0ff7f793          	zext.b	a5,a5
 300:	fef671e3          	bgeu	a2,a5,2e2 <atoi+0x1e>
  return n;
}
 304:	60a2                	ld	ra,8(sp)
 306:	6402                	ld	s0,0(sp)
 308:	0141                	addi	sp,sp,16
 30a:	8082                	ret
  n = 0;
 30c:	4501                	li	a0,0
 30e:	bfdd                	j	304 <atoi+0x40>

0000000000000310 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 310:	1141                	addi	sp,sp,-16
 312:	e406                	sd	ra,8(sp)
 314:	e022                	sd	s0,0(sp)
 316:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 318:	02b57563          	bgeu	a0,a1,342 <memmove+0x32>
    while (n-- > 0)
 31c:	00c05f63          	blez	a2,33a <memmove+0x2a>
 320:	1602                	slli	a2,a2,0x20
 322:	9201                	srli	a2,a2,0x20
 324:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 328:	872a                	mv	a4,a0
      *dst++ = *src++;
 32a:	0585                	addi	a1,a1,1
 32c:	0705                	addi	a4,a4,1
 32e:	fff5c683          	lbu	a3,-1(a1)
 332:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 336:	fee79ae3          	bne	a5,a4,32a <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 33a:	60a2                	ld	ra,8(sp)
 33c:	6402                	ld	s0,0(sp)
 33e:	0141                	addi	sp,sp,16
 340:	8082                	ret
    while (n-- > 0)
 342:	fec05ce3          	blez	a2,33a <memmove+0x2a>
    dst += n;
 346:	00c50733          	add	a4,a0,a2
    src += n;
 34a:	95b2                	add	a1,a1,a2
 34c:	fff6079b          	addiw	a5,a2,-1
 350:	1782                	slli	a5,a5,0x20
 352:	9381                	srli	a5,a5,0x20
 354:	fff7c793          	not	a5,a5
 358:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 35a:	15fd                	addi	a1,a1,-1
 35c:	177d                	addi	a4,a4,-1
 35e:	0005c683          	lbu	a3,0(a1)
 362:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 366:	fef71ae3          	bne	a4,a5,35a <memmove+0x4a>
 36a:	bfc1                	j	33a <memmove+0x2a>

000000000000036c <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 36c:	1141                	addi	sp,sp,-16
 36e:	e406                	sd	ra,8(sp)
 370:	e022                	sd	s0,0(sp)
 372:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 374:	c61d                	beqz	a2,3a2 <memcmp+0x36>
 376:	1602                	slli	a2,a2,0x20
 378:	9201                	srli	a2,a2,0x20
 37a:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 37e:	00054783          	lbu	a5,0(a0)
 382:	0005c703          	lbu	a4,0(a1)
 386:	00e79863          	bne	a5,a4,396 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 38a:	0505                	addi	a0,a0,1
    p2++;
 38c:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 38e:	fed518e3          	bne	a0,a3,37e <memcmp+0x12>
  }
  return 0;
 392:	4501                	li	a0,0
 394:	a019                	j	39a <memcmp+0x2e>
      return *p1 - *p2;
 396:	40e7853b          	subw	a0,a5,a4
}
 39a:	60a2                	ld	ra,8(sp)
 39c:	6402                	ld	s0,0(sp)
 39e:	0141                	addi	sp,sp,16
 3a0:	8082                	ret
  return 0;
 3a2:	4501                	li	a0,0
 3a4:	bfdd                	j	39a <memcmp+0x2e>

00000000000003a6 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3a6:	1141                	addi	sp,sp,-16
 3a8:	e406                	sd	ra,8(sp)
 3aa:	e022                	sd	s0,0(sp)
 3ac:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3ae:	f63ff0ef          	jal	310 <memmove>
}
 3b2:	60a2                	ld	ra,8(sp)
 3b4:	6402                	ld	s0,0(sp)
 3b6:	0141                	addi	sp,sp,16
 3b8:	8082                	ret

00000000000003ba <sbrk>:

char *
sbrk(int n)
{
 3ba:	1141                	addi	sp,sp,-16
 3bc:	e406                	sd	ra,8(sp)
 3be:	e022                	sd	s0,0(sp)
 3c0:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 3c2:	4585                	li	a1,1
 3c4:	0b2000ef          	jal	476 <sys_sbrk>
}
 3c8:	60a2                	ld	ra,8(sp)
 3ca:	6402                	ld	s0,0(sp)
 3cc:	0141                	addi	sp,sp,16
 3ce:	8082                	ret

00000000000003d0 <sbrklazy>:

char *
sbrklazy(int n)
{
 3d0:	1141                	addi	sp,sp,-16
 3d2:	e406                	sd	ra,8(sp)
 3d4:	e022                	sd	s0,0(sp)
 3d6:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 3d8:	4589                	li	a1,2
 3da:	09c000ef          	jal	476 <sys_sbrk>
}
 3de:	60a2                	ld	ra,8(sp)
 3e0:	6402                	ld	s0,0(sp)
 3e2:	0141                	addi	sp,sp,16
 3e4:	8082                	ret

00000000000003e6 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3e6:	4885                	li	a7,1
 ecall
 3e8:	00000073          	ecall
 ret
 3ec:	8082                	ret

00000000000003ee <exit>:
.global exit
exit:
 li a7, SYS_exit
 3ee:	4889                	li	a7,2
 ecall
 3f0:	00000073          	ecall
 ret
 3f4:	8082                	ret

00000000000003f6 <wait>:
.global wait
wait:
 li a7, SYS_wait
 3f6:	488d                	li	a7,3
 ecall
 3f8:	00000073          	ecall
 ret
 3fc:	8082                	ret

00000000000003fe <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3fe:	4891                	li	a7,4
 ecall
 400:	00000073          	ecall
 ret
 404:	8082                	ret

0000000000000406 <read>:
.global read
read:
 li a7, SYS_read
 406:	4895                	li	a7,5
 ecall
 408:	00000073          	ecall
 ret
 40c:	8082                	ret

000000000000040e <write>:
.global write
write:
 li a7, SYS_write
 40e:	48c1                	li	a7,16
 ecall
 410:	00000073          	ecall
 ret
 414:	8082                	ret

0000000000000416 <close>:
.global close
close:
 li a7, SYS_close
 416:	48d5                	li	a7,21
 ecall
 418:	00000073          	ecall
 ret
 41c:	8082                	ret

000000000000041e <kill>:
.global kill
kill:
 li a7, SYS_kill
 41e:	4899                	li	a7,6
 ecall
 420:	00000073          	ecall
 ret
 424:	8082                	ret

0000000000000426 <exec>:
.global exec
exec:
 li a7, SYS_exec
 426:	489d                	li	a7,7
 ecall
 428:	00000073          	ecall
 ret
 42c:	8082                	ret

000000000000042e <open>:
.global open
open:
 li a7, SYS_open
 42e:	48bd                	li	a7,15
 ecall
 430:	00000073          	ecall
 ret
 434:	8082                	ret

0000000000000436 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 436:	48c5                	li	a7,17
 ecall
 438:	00000073          	ecall
 ret
 43c:	8082                	ret

000000000000043e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 43e:	48c9                	li	a7,18
 ecall
 440:	00000073          	ecall
 ret
 444:	8082                	ret

0000000000000446 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 446:	48a1                	li	a7,8
 ecall
 448:	00000073          	ecall
 ret
 44c:	8082                	ret

000000000000044e <link>:
.global link
link:
 li a7, SYS_link
 44e:	48cd                	li	a7,19
 ecall
 450:	00000073          	ecall
 ret
 454:	8082                	ret

0000000000000456 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 456:	48d1                	li	a7,20
 ecall
 458:	00000073          	ecall
 ret
 45c:	8082                	ret

000000000000045e <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 45e:	48a5                	li	a7,9
 ecall
 460:	00000073          	ecall
 ret
 464:	8082                	ret

0000000000000466 <dup>:
.global dup
dup:
 li a7, SYS_dup
 466:	48a9                	li	a7,10
 ecall
 468:	00000073          	ecall
 ret
 46c:	8082                	ret

000000000000046e <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 46e:	48ad                	li	a7,11
 ecall
 470:	00000073          	ecall
 ret
 474:	8082                	ret

0000000000000476 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 476:	48b1                	li	a7,12
 ecall
 478:	00000073          	ecall
 ret
 47c:	8082                	ret

000000000000047e <pause>:
.global pause
pause:
 li a7, SYS_pause
 47e:	48b5                	li	a7,13
 ecall
 480:	00000073          	ecall
 ret
 484:	8082                	ret

0000000000000486 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 486:	48b9                	li	a7,14
 ecall
 488:	00000073          	ecall
 ret
 48c:	8082                	ret

000000000000048e <sync>:
.global sync
sync:
 li a7, SYS_sync
 48e:	48d9                	li	a7,22
 ecall
 490:	00000073          	ecall
 ret
 494:	8082                	ret

0000000000000496 <clone>:
.global clone
clone:
 li a7, SYS_clone
 496:	48dd                	li	a7,23
 ecall
 498:	00000073          	ecall
 ret
 49c:	8082                	ret

000000000000049e <join>:
.global join
join:
 li a7, SYS_join
 49e:	48e1                	li	a7,24
 ecall
 4a0:	00000073          	ecall
 ret
 4a4:	8082                	ret

00000000000004a6 <sem_init>:
.global sem_init
sem_init:
 li a7, SYS_sem_init
 4a6:	48e5                	li	a7,25
 ecall
 4a8:	00000073          	ecall
 ret
 4ac:	8082                	ret

00000000000004ae <sem_wait>:
.global sem_wait
sem_wait:
 li a7, SYS_sem_wait
 4ae:	48e9                	li	a7,26
 ecall
 4b0:	00000073          	ecall
 ret
 4b4:	8082                	ret

00000000000004b6 <sem_signal>:
.global sem_signal
sem_signal:
 li a7, SYS_sem_signal
 4b6:	48ed                	li	a7,27
 ecall
 4b8:	00000073          	ecall
 ret
 4bc:	8082                	ret

00000000000004be <set_priority>:
.global set_priority
set_priority:
 li a7, SYS_set_priority
 4be:	48f1                	li	a7,28
 ecall
 4c0:	00000073          	ecall
 ret
 4c4:	8082                	ret

00000000000004c6 <get_priority>:
.global get_priority
get_priority:
 li a7, SYS_get_priority
 4c6:	48f5                	li	a7,29
 ecall
 4c8:	00000073          	ecall
 ret
 4cc:	8082                	ret

00000000000004ce <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4ce:	1101                	addi	sp,sp,-32
 4d0:	ec06                	sd	ra,24(sp)
 4d2:	e822                	sd	s0,16(sp)
 4d4:	1000                	addi	s0,sp,32
 4d6:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 4da:	4605                	li	a2,1
 4dc:	fef40593          	addi	a1,s0,-17
 4e0:	f2fff0ef          	jal	40e <write>
}
 4e4:	60e2                	ld	ra,24(sp)
 4e6:	6442                	ld	s0,16(sp)
 4e8:	6105                	addi	sp,sp,32
 4ea:	8082                	ret

00000000000004ec <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 4ec:	715d                	addi	sp,sp,-80
 4ee:	e486                	sd	ra,72(sp)
 4f0:	e0a2                	sd	s0,64(sp)
 4f2:	f84a                	sd	s2,48(sp)
 4f4:	f44e                	sd	s3,40(sp)
 4f6:	0880                	addi	s0,sp,80
 4f8:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 4fa:	c6d1                	beqz	a3,586 <printint+0x9a>
 4fc:	0805d563          	bgez	a1,586 <printint+0x9a>
    neg = 1;
    x = -xx;
 500:	40b005b3          	neg	a1,a1
    neg = 1;
 504:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 506:	fb840993          	addi	s3,s0,-72
  neg = 0;
 50a:	86ce                	mv	a3,s3
  i = 0;
 50c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
 50e:	00000817          	auipc	a6,0x0
 512:	6a280813          	addi	a6,a6,1698 # bb0 <digits>
 516:	88ba                	mv	a7,a4
 518:	0017051b          	addiw	a0,a4,1
 51c:	872a                	mv	a4,a0
 51e:	02c5f7b3          	remu	a5,a1,a2
 522:	97c2                	add	a5,a5,a6
 524:	0007c783          	lbu	a5,0(a5)
 528:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
 52c:	87ae                	mv	a5,a1
 52e:	02c5d5b3          	divu	a1,a1,a2
 532:	0685                	addi	a3,a3,1
 534:	fec7f1e3          	bgeu	a5,a2,516 <printint+0x2a>
  if (neg)
 538:	00030c63          	beqz	t1,550 <printint+0x64>
    buf[i++] = '-';
 53c:	fd050793          	addi	a5,a0,-48
 540:	00878533          	add	a0,a5,s0
 544:	02d00793          	li	a5,45
 548:	fef50423          	sb	a5,-24(a0)
 54c:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
 550:	02e05563          	blez	a4,57a <printint+0x8e>
 554:	fc26                	sd	s1,56(sp)
 556:	377d                	addiw	a4,a4,-1
 558:	00e984b3          	add	s1,s3,a4
 55c:	19fd                	addi	s3,s3,-1
 55e:	99ba                	add	s3,s3,a4
 560:	1702                	slli	a4,a4,0x20
 562:	9301                	srli	a4,a4,0x20
 564:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 568:	0004c583          	lbu	a1,0(s1)
 56c:	854a                	mv	a0,s2
 56e:	f61ff0ef          	jal	4ce <putc>
  while (--i >= 0)
 572:	14fd                	addi	s1,s1,-1
 574:	ff349ae3          	bne	s1,s3,568 <printint+0x7c>
 578:	74e2                	ld	s1,56(sp)
}
 57a:	60a6                	ld	ra,72(sp)
 57c:	6406                	ld	s0,64(sp)
 57e:	7942                	ld	s2,48(sp)
 580:	79a2                	ld	s3,40(sp)
 582:	6161                	addi	sp,sp,80
 584:	8082                	ret
  neg = 0;
 586:	4301                	li	t1,0
 588:	bfbd                	j	506 <printint+0x1a>

000000000000058a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 58a:	711d                	addi	sp,sp,-96
 58c:	ec86                	sd	ra,88(sp)
 58e:	e8a2                	sd	s0,80(sp)
 590:	e4a6                	sd	s1,72(sp)
 592:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 594:	0005c483          	lbu	s1,0(a1)
 598:	22048363          	beqz	s1,7be <vprintf+0x234>
 59c:	e0ca                	sd	s2,64(sp)
 59e:	fc4e                	sd	s3,56(sp)
 5a0:	f852                	sd	s4,48(sp)
 5a2:	f456                	sd	s5,40(sp)
 5a4:	f05a                	sd	s6,32(sp)
 5a6:	ec5e                	sd	s7,24(sp)
 5a8:	e862                	sd	s8,16(sp)
 5aa:	8b2a                	mv	s6,a0
 5ac:	8a2e                	mv	s4,a1
 5ae:	8bb2                	mv	s7,a2
  state = 0;
 5b0:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 5b2:	4901                	li	s2,0
 5b4:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 5b6:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 5ba:	06400c13          	li	s8,100
 5be:	a00d                	j	5e0 <vprintf+0x56>
        putc(fd, c0);
 5c0:	85a6                	mv	a1,s1
 5c2:	855a                	mv	a0,s6
 5c4:	f0bff0ef          	jal	4ce <putc>
 5c8:	a019                	j	5ce <vprintf+0x44>
    } else if (state == '%') {
 5ca:	03598363          	beq	s3,s5,5f0 <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
 5ce:	0019079b          	addiw	a5,s2,1
 5d2:	893e                	mv	s2,a5
 5d4:	873e                	mv	a4,a5
 5d6:	97d2                	add	a5,a5,s4
 5d8:	0007c483          	lbu	s1,0(a5)
 5dc:	1c048a63          	beqz	s1,7b0 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 5e0:	0004879b          	sext.w	a5,s1
    if (state == 0) {
 5e4:	fe0993e3          	bnez	s3,5ca <vprintf+0x40>
      if (c0 == '%') {
 5e8:	fd579ce3          	bne	a5,s5,5c0 <vprintf+0x36>
        state = '%';
 5ec:	89be                	mv	s3,a5
 5ee:	b7c5                	j	5ce <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
 5f0:	00ea06b3          	add	a3,s4,a4
 5f4:	0016c603          	lbu	a2,1(a3)
      if (c1)
 5f8:	1c060863          	beqz	a2,7c8 <vprintf+0x23e>
      if (c0 == 'd') {
 5fc:	03878763          	beq	a5,s8,62a <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 600:	f9478693          	addi	a3,a5,-108
 604:	0016b693          	seqz	a3,a3
 608:	f9c60593          	addi	a1,a2,-100
 60c:	e99d                	bnez	a1,642 <vprintf+0xb8>
 60e:	ca95                	beqz	a3,642 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 610:	008b8493          	addi	s1,s7,8
 614:	4685                	li	a3,1
 616:	4629                	li	a2,10
 618:	000bb583          	ld	a1,0(s7)
 61c:	855a                	mv	a0,s6
 61e:	ecfff0ef          	jal	4ec <printint>
        i += 1;
 622:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 624:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 626:	4981                	li	s3,0
 628:	b75d                	j	5ce <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 62a:	008b8493          	addi	s1,s7,8
 62e:	4685                	li	a3,1
 630:	4629                	li	a2,10
 632:	000ba583          	lw	a1,0(s7)
 636:	855a                	mv	a0,s6
 638:	eb5ff0ef          	jal	4ec <printint>
 63c:	8ba6                	mv	s7,s1
      state = 0;
 63e:	4981                	li	s3,0
 640:	b779                	j	5ce <vprintf+0x44>
        c2 = fmt[i + 2] & 0xff;
 642:	9752                	add	a4,a4,s4
 644:	00274583          	lbu	a1,2(a4)
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 648:	f9460713          	addi	a4,a2,-108
 64c:	00173713          	seqz	a4,a4
 650:	8f75                	and	a4,a4,a3
 652:	f9c58513          	addi	a0,a1,-100
 656:	18051363          	bnez	a0,7dc <vprintf+0x252>
 65a:	18070163          	beqz	a4,7dc <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 65e:	008b8493          	addi	s1,s7,8
 662:	4685                	li	a3,1
 664:	4629                	li	a2,10
 666:	000bb583          	ld	a1,0(s7)
 66a:	855a                	mv	a0,s6
 66c:	e81ff0ef          	jal	4ec <printint>
        i += 2;
 670:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 672:	8ba6                	mv	s7,s1
      state = 0;
 674:	4981                	li	s3,0
        i += 2;
 676:	bfa1                	j	5ce <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 678:	008b8493          	addi	s1,s7,8
 67c:	4681                	li	a3,0
 67e:	4629                	li	a2,10
 680:	000be583          	lwu	a1,0(s7)
 684:	855a                	mv	a0,s6
 686:	e67ff0ef          	jal	4ec <printint>
 68a:	8ba6                	mv	s7,s1
      state = 0;
 68c:	4981                	li	s3,0
 68e:	b781                	j	5ce <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 690:	008b8493          	addi	s1,s7,8
 694:	4681                	li	a3,0
 696:	4629                	li	a2,10
 698:	000bb583          	ld	a1,0(s7)
 69c:	855a                	mv	a0,s6
 69e:	e4fff0ef          	jal	4ec <printint>
        i += 1;
 6a2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 6a4:	8ba6                	mv	s7,s1
      state = 0;
 6a6:	4981                	li	s3,0
 6a8:	b71d                	j	5ce <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6aa:	008b8493          	addi	s1,s7,8
 6ae:	4681                	li	a3,0
 6b0:	4629                	li	a2,10
 6b2:	000bb583          	ld	a1,0(s7)
 6b6:	855a                	mv	a0,s6
 6b8:	e35ff0ef          	jal	4ec <printint>
        i += 2;
 6bc:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 6be:	8ba6                	mv	s7,s1
      state = 0;
 6c0:	4981                	li	s3,0
        i += 2;
 6c2:	b731                	j	5ce <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 6c4:	008b8493          	addi	s1,s7,8
 6c8:	4681                	li	a3,0
 6ca:	4641                	li	a2,16
 6cc:	000be583          	lwu	a1,0(s7)
 6d0:	855a                	mv	a0,s6
 6d2:	e1bff0ef          	jal	4ec <printint>
 6d6:	8ba6                	mv	s7,s1
      state = 0;
 6d8:	4981                	li	s3,0
 6da:	bdd5                	j	5ce <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6dc:	008b8493          	addi	s1,s7,8
 6e0:	4681                	li	a3,0
 6e2:	4641                	li	a2,16
 6e4:	000bb583          	ld	a1,0(s7)
 6e8:	855a                	mv	a0,s6
 6ea:	e03ff0ef          	jal	4ec <printint>
        i += 1;
 6ee:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6f0:	8ba6                	mv	s7,s1
      state = 0;
 6f2:	4981                	li	s3,0
 6f4:	bde9                	j	5ce <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6f6:	008b8493          	addi	s1,s7,8
 6fa:	4681                	li	a3,0
 6fc:	4641                	li	a2,16
 6fe:	000bb583          	ld	a1,0(s7)
 702:	855a                	mv	a0,s6
 704:	de9ff0ef          	jal	4ec <printint>
        i += 2;
 708:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 70a:	8ba6                	mv	s7,s1
      state = 0;
 70c:	4981                	li	s3,0
        i += 2;
 70e:	b5c1                	j	5ce <vprintf+0x44>
 710:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 712:	008b8793          	addi	a5,s7,8
 716:	8cbe                	mv	s9,a5
 718:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 71c:	03000593          	li	a1,48
 720:	855a                	mv	a0,s6
 722:	dadff0ef          	jal	4ce <putc>
  putc(fd, 'x');
 726:	07800593          	li	a1,120
 72a:	855a                	mv	a0,s6
 72c:	da3ff0ef          	jal	4ce <putc>
 730:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 732:	00000b97          	auipc	s7,0x0
 736:	47eb8b93          	addi	s7,s7,1150 # bb0 <digits>
 73a:	03c9d793          	srli	a5,s3,0x3c
 73e:	97de                	add	a5,a5,s7
 740:	0007c583          	lbu	a1,0(a5)
 744:	855a                	mv	a0,s6
 746:	d89ff0ef          	jal	4ce <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 74a:	0992                	slli	s3,s3,0x4
 74c:	34fd                	addiw	s1,s1,-1
 74e:	f4f5                	bnez	s1,73a <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 750:	8be6                	mv	s7,s9
      state = 0;
 752:	4981                	li	s3,0
 754:	6ca2                	ld	s9,8(sp)
 756:	bda5                	j	5ce <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 758:	008b8493          	addi	s1,s7,8
 75c:	000bc583          	lbu	a1,0(s7)
 760:	855a                	mv	a0,s6
 762:	d6dff0ef          	jal	4ce <putc>
 766:	8ba6                	mv	s7,s1
      state = 0;
 768:	4981                	li	s3,0
 76a:	b595                	j	5ce <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 76c:	008b8993          	addi	s3,s7,8
 770:	000bb483          	ld	s1,0(s7)
 774:	cc91                	beqz	s1,790 <vprintf+0x206>
        for (; *s; s++)
 776:	0004c583          	lbu	a1,0(s1)
 77a:	c985                	beqz	a1,7aa <vprintf+0x220>
          putc(fd, *s);
 77c:	855a                	mv	a0,s6
 77e:	d51ff0ef          	jal	4ce <putc>
        for (; *s; s++)
 782:	0485                	addi	s1,s1,1
 784:	0004c583          	lbu	a1,0(s1)
 788:	f9f5                	bnez	a1,77c <vprintf+0x1f2>
        if ((s = va_arg(ap, char *)) == 0)
 78a:	8bce                	mv	s7,s3
      state = 0;
 78c:	4981                	li	s3,0
 78e:	b581                	j	5ce <vprintf+0x44>
          s = "(null)";
 790:	00000497          	auipc	s1,0x0
 794:	41848493          	addi	s1,s1,1048 # ba8 <malloc+0x27c>
        for (; *s; s++)
 798:	02800593          	li	a1,40
 79c:	b7c5                	j	77c <vprintf+0x1f2>
        putc(fd, '%');
 79e:	85be                	mv	a1,a5
 7a0:	855a                	mv	a0,s6
 7a2:	d2dff0ef          	jal	4ce <putc>
      state = 0;
 7a6:	4981                	li	s3,0
 7a8:	b51d                	j	5ce <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 7aa:	8bce                	mv	s7,s3
      state = 0;
 7ac:	4981                	li	s3,0
 7ae:	b505                	j	5ce <vprintf+0x44>
 7b0:	6906                	ld	s2,64(sp)
 7b2:	79e2                	ld	s3,56(sp)
 7b4:	7a42                	ld	s4,48(sp)
 7b6:	7aa2                	ld	s5,40(sp)
 7b8:	7b02                	ld	s6,32(sp)
 7ba:	6be2                	ld	s7,24(sp)
 7bc:	6c42                	ld	s8,16(sp)
    }
  }
}
 7be:	60e6                	ld	ra,88(sp)
 7c0:	6446                	ld	s0,80(sp)
 7c2:	64a6                	ld	s1,72(sp)
 7c4:	6125                	addi	sp,sp,96
 7c6:	8082                	ret
      if (c0 == 'd') {
 7c8:	06400713          	li	a4,100
 7cc:	e4e78fe3          	beq	a5,a4,62a <vprintf+0xa0>
      } else if (c0 == 'l' && c1 == 'd') {
 7d0:	f9478693          	addi	a3,a5,-108
 7d4:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 7d8:	85b2                	mv	a1,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 7da:	4701                	li	a4,0
      } else if (c0 == 'u') {
 7dc:	07500513          	li	a0,117
 7e0:	e8a78ce3          	beq	a5,a0,678 <vprintf+0xee>
      } else if (c0 == 'l' && c1 == 'u') {
 7e4:	f8b60513          	addi	a0,a2,-117
 7e8:	e119                	bnez	a0,7ee <vprintf+0x264>
 7ea:	ea0693e3          	bnez	a3,690 <vprintf+0x106>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 7ee:	f8b58513          	addi	a0,a1,-117
 7f2:	e119                	bnez	a0,7f8 <vprintf+0x26e>
 7f4:	ea071be3          	bnez	a4,6aa <vprintf+0x120>
      } else if (c0 == 'x') {
 7f8:	07800513          	li	a0,120
 7fc:	eca784e3          	beq	a5,a0,6c4 <vprintf+0x13a>
      } else if (c0 == 'l' && c1 == 'x') {
 800:	f8860613          	addi	a2,a2,-120
 804:	e219                	bnez	a2,80a <vprintf+0x280>
 806:	ec069be3          	bnez	a3,6dc <vprintf+0x152>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 80a:	f8858593          	addi	a1,a1,-120
 80e:	e199                	bnez	a1,814 <vprintf+0x28a>
 810:	ee0713e3          	bnez	a4,6f6 <vprintf+0x16c>
      } else if (c0 == 'p') {
 814:	07000713          	li	a4,112
 818:	eee78ce3          	beq	a5,a4,710 <vprintf+0x186>
      } else if (c0 == 'c') {
 81c:	06300713          	li	a4,99
 820:	f2e78ce3          	beq	a5,a4,758 <vprintf+0x1ce>
      } else if (c0 == 's') {
 824:	07300713          	li	a4,115
 828:	f4e782e3          	beq	a5,a4,76c <vprintf+0x1e2>
      } else if (c0 == '%') {
 82c:	02500713          	li	a4,37
 830:	f6e787e3          	beq	a5,a4,79e <vprintf+0x214>
        putc(fd, '%');
 834:	02500593          	li	a1,37
 838:	855a                	mv	a0,s6
 83a:	c95ff0ef          	jal	4ce <putc>
        putc(fd, c0);
 83e:	85a6                	mv	a1,s1
 840:	855a                	mv	a0,s6
 842:	c8dff0ef          	jal	4ce <putc>
      state = 0;
 846:	4981                	li	s3,0
 848:	b359                	j	5ce <vprintf+0x44>

000000000000084a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 84a:	715d                	addi	sp,sp,-80
 84c:	ec06                	sd	ra,24(sp)
 84e:	e822                	sd	s0,16(sp)
 850:	1000                	addi	s0,sp,32
 852:	e010                	sd	a2,0(s0)
 854:	e414                	sd	a3,8(s0)
 856:	e818                	sd	a4,16(s0)
 858:	ec1c                	sd	a5,24(s0)
 85a:	03043023          	sd	a6,32(s0)
 85e:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 862:	8622                	mv	a2,s0
 864:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 868:	d23ff0ef          	jal	58a <vprintf>
}
 86c:	60e2                	ld	ra,24(sp)
 86e:	6442                	ld	s0,16(sp)
 870:	6161                	addi	sp,sp,80
 872:	8082                	ret

0000000000000874 <printf>:

void
printf(const char *fmt, ...)
{
 874:	711d                	addi	sp,sp,-96
 876:	ec06                	sd	ra,24(sp)
 878:	e822                	sd	s0,16(sp)
 87a:	1000                	addi	s0,sp,32
 87c:	e40c                	sd	a1,8(s0)
 87e:	e810                	sd	a2,16(s0)
 880:	ec14                	sd	a3,24(s0)
 882:	f018                	sd	a4,32(s0)
 884:	f41c                	sd	a5,40(s0)
 886:	03043823          	sd	a6,48(s0)
 88a:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 88e:	00840613          	addi	a2,s0,8
 892:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 896:	85aa                	mv	a1,a0
 898:	4505                	li	a0,1
 89a:	cf1ff0ef          	jal	58a <vprintf>
}
 89e:	60e2                	ld	ra,24(sp)
 8a0:	6442                	ld	s0,16(sp)
 8a2:	6125                	addi	sp,sp,96
 8a4:	8082                	ret

00000000000008a6 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8a6:	1141                	addi	sp,sp,-16
 8a8:	e406                	sd	ra,8(sp)
 8aa:	e022                	sd	s0,0(sp)
 8ac:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 8ae:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8b2:	00001797          	auipc	a5,0x1
 8b6:	7567b783          	ld	a5,1878(a5) # 2008 <freep>
 8ba:	a039                	j	8c8 <free+0x22>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8bc:	6398                	ld	a4,0(a5)
 8be:	00e7e463          	bltu	a5,a4,8c6 <free+0x20>
 8c2:	00e6ea63          	bltu	a3,a4,8d6 <free+0x30>
{
 8c6:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8c8:	fed7fae3          	bgeu	a5,a3,8bc <free+0x16>
 8cc:	6398                	ld	a4,0(a5)
 8ce:	00e6e463          	bltu	a3,a4,8d6 <free+0x30>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8d2:	fee7eae3          	bltu	a5,a4,8c6 <free+0x20>
      break;
  if (bp + bp->s.size == p->s.ptr) {
 8d6:	ff852583          	lw	a1,-8(a0)
 8da:	6390                	ld	a2,0(a5)
 8dc:	02059813          	slli	a6,a1,0x20
 8e0:	01c85713          	srli	a4,a6,0x1c
 8e4:	9736                	add	a4,a4,a3
 8e6:	02e60563          	beq	a2,a4,910 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 8ea:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
 8ee:	4790                	lw	a2,8(a5)
 8f0:	02061593          	slli	a1,a2,0x20
 8f4:	01c5d713          	srli	a4,a1,0x1c
 8f8:	973e                	add	a4,a4,a5
 8fa:	02e68263          	beq	a3,a4,91e <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 8fe:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 900:	00001717          	auipc	a4,0x1
 904:	70f73423          	sd	a5,1800(a4) # 2008 <freep>
}
 908:	60a2                	ld	ra,8(sp)
 90a:	6402                	ld	s0,0(sp)
 90c:	0141                	addi	sp,sp,16
 90e:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 910:	4618                	lw	a4,8(a2)
 912:	9f2d                	addw	a4,a4,a1
 914:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 918:	6398                	ld	a4,0(a5)
 91a:	6310                	ld	a2,0(a4)
 91c:	b7f9                	j	8ea <free+0x44>
    p->s.size += bp->s.size;
 91e:	ff852703          	lw	a4,-8(a0)
 922:	9f31                	addw	a4,a4,a2
 924:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 926:	ff053683          	ld	a3,-16(a0)
 92a:	bfd1                	j	8fe <free+0x58>

000000000000092c <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 92c:	7139                	addi	sp,sp,-64
 92e:	fc06                	sd	ra,56(sp)
 930:	f822                	sd	s0,48(sp)
 932:	f04a                	sd	s2,32(sp)
 934:	ec4e                	sd	s3,24(sp)
 936:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 938:	02051993          	slli	s3,a0,0x20
 93c:	0209d993          	srli	s3,s3,0x20
 940:	09bd                	addi	s3,s3,15
 942:	0049d993          	srli	s3,s3,0x4
 946:	2985                	addiw	s3,s3,1
 948:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
 94a:	00001517          	auipc	a0,0x1
 94e:	6be53503          	ld	a0,1726(a0) # 2008 <freep>
 952:	c905                	beqz	a0,982 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 954:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 956:	4798                	lw	a4,8(a5)
 958:	09377663          	bgeu	a4,s3,9e4 <malloc+0xb8>
 95c:	f426                	sd	s1,40(sp)
 95e:	e852                	sd	s4,16(sp)
 960:	e456                	sd	s5,8(sp)
 962:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 964:	8a4e                	mv	s4,s3
 966:	6705                	lui	a4,0x1
 968:	00e9f363          	bgeu	s3,a4,96e <malloc+0x42>
 96c:	6a05                	lui	s4,0x1
 96e:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 972:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 976:	00001497          	auipc	s1,0x1
 97a:	69248493          	addi	s1,s1,1682 # 2008 <freep>
  if (p == SBRK_ERROR)
 97e:	5afd                	li	s5,-1
 980:	a83d                	j	9be <malloc+0x92>
 982:	f426                	sd	s1,40(sp)
 984:	e852                	sd	s4,16(sp)
 986:	e456                	sd	s5,8(sp)
 988:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 98a:	00001797          	auipc	a5,0x1
 98e:	68678793          	addi	a5,a5,1670 # 2010 <base>
 992:	00001717          	auipc	a4,0x1
 996:	66f73b23          	sd	a5,1654(a4) # 2008 <freep>
 99a:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 99c:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 9a0:	b7d1                	j	964 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 9a2:	6398                	ld	a4,0(a5)
 9a4:	e118                	sd	a4,0(a0)
 9a6:	a899                	j	9fc <malloc+0xd0>
  hp->s.size = nu;
 9a8:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 9ac:	0541                	addi	a0,a0,16
 9ae:	ef9ff0ef          	jal	8a6 <free>
  return freep;
 9b2:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
 9b4:	c125                	beqz	a0,a14 <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 9b6:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 9b8:	4798                	lw	a4,8(a5)
 9ba:	03277163          	bgeu	a4,s2,9dc <malloc+0xb0>
    if (p == freep)
 9be:	6098                	ld	a4,0(s1)
 9c0:	853e                	mv	a0,a5
 9c2:	fef71ae3          	bne	a4,a5,9b6 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 9c6:	8552                	mv	a0,s4
 9c8:	9f3ff0ef          	jal	3ba <sbrk>
  if (p == SBRK_ERROR)
 9cc:	fd551ee3          	bne	a0,s5,9a8 <malloc+0x7c>
        return 0;
 9d0:	4501                	li	a0,0
 9d2:	74a2                	ld	s1,40(sp)
 9d4:	6a42                	ld	s4,16(sp)
 9d6:	6aa2                	ld	s5,8(sp)
 9d8:	6b02                	ld	s6,0(sp)
 9da:	a03d                	j	a08 <malloc+0xdc>
 9dc:	74a2                	ld	s1,40(sp)
 9de:	6a42                	ld	s4,16(sp)
 9e0:	6aa2                	ld	s5,8(sp)
 9e2:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 9e4:	fae90fe3          	beq	s2,a4,9a2 <malloc+0x76>
        p->s.size -= nunits;
 9e8:	4137073b          	subw	a4,a4,s3
 9ec:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9ee:	02071693          	slli	a3,a4,0x20
 9f2:	01c6d713          	srli	a4,a3,0x1c
 9f6:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9f8:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9fc:	00001717          	auipc	a4,0x1
 a00:	60a73623          	sd	a0,1548(a4) # 2008 <freep>
      return (void *)(p + 1);
 a04:	01078513          	addi	a0,a5,16
  }
}
 a08:	70e2                	ld	ra,56(sp)
 a0a:	7442                	ld	s0,48(sp)
 a0c:	7902                	ld	s2,32(sp)
 a0e:	69e2                	ld	s3,24(sp)
 a10:	6121                	addi	sp,sp,64
 a12:	8082                	ret
 a14:	74a2                	ld	s1,40(sp)
 a16:	6a42                	ld	s4,16(sp)
 a18:	6aa2                	ld	s5,8(sp)
 a1a:	6b02                	ld	s6,0(sp)
 a1c:	b7f5                	j	a08 <malloc+0xdc>
