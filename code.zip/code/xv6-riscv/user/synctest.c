#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#define PGSIZE 4096

#define NTHREADS 3
#define ITERATIONS 100000
#define BUFSIZE 5
#define ITEMS 10
#define STACKSIZE 4096

#define SEM_COUNTER 0
#define SEM_EMPTY   1
#define SEM_FULL    2
#define SEM_MUTEX   3

volatile int counter = 0;

int buffer[BUFSIZE];
int in = 0;
int out = 0;
int produced = 0;
int consumed = 0;

char counter_stacks[NTHREADS][PGSIZE] __attribute__((aligned(PGSIZE)));
char pc_stacks[2][PGSIZE] __attribute__((aligned(PGSIZE)));

void
counter_worker(void *arg)
{
  int i;
  (void)arg;

  for(i = 0; i < ITERATIONS; i++){
    sem_wait(SEM_COUNTER);
    counter++;
    sem_signal(SEM_COUNTER);
  }

  exit(0);
}

void
producer(void *arg)
{
  int i;
  (void)arg;

  for(i = 1; i <= ITEMS; i++){
    sem_wait(SEM_EMPTY);
    sem_wait(SEM_MUTEX);

    buffer[in] = i;
    in = (in + 1) % BUFSIZE;
    produced++;
    printf("Produced: %d\n", i);

    sem_signal(SEM_MUTEX);
    sem_signal(SEM_FULL);
  }

  exit(0);
}

void
consumer(void *arg)
{
  int item;
  (void)arg;

  for(int i = 0; i < ITEMS; i++){
    sem_wait(SEM_FULL);
    sem_wait(SEM_MUTEX);

    item = buffer[out];
    out = (out + 1) % BUFSIZE;
    consumed++;
    printf("Consumed: %d\n", item);

    sem_signal(SEM_MUTEX);
    sem_signal(SEM_EMPTY);
  }

  exit(0);
}

int
main(void)
{
  int i;
  int failed = 0;

  printf("\n=== Synchronized Counter Test ===\n");

  counter = 0;
  if(sem_init(SEM_COUNTER, 1) < 0){
    printf("FAIL: counter semaphore initialization\n");
    exit(1);
  }

  for(i = 0; i < NTHREADS; i++){
    if(clone(counter_worker, 0, counter_stacks[i]) < 0){
       printf("FAIL: clone counter thread\n");
       exit(1);
     }
  }

  for(i = 0; i < NTHREADS; i++){
    if(join() < 0){
      printf("FAIL: join counter thread\n");
      failed = 1;
    }
    
  }

  printf("Final counter: %d (expected 300000)\n", counter);

  if(counter != 300000)
    failed = 1;

  if(!failed)
    printf("Counter test: PASS\n");
  else
    printf("Counter test: FAIL\n");

  printf("\n=== Producer-Consumer Test ===\n");

  in = 0;
  out = 0;
  produced = 0;
  consumed = 0;

  if(sem_init(SEM_EMPTY, BUFSIZE) < 0 ||
     sem_init(SEM_FULL, 0) < 0 ||
     sem_init(SEM_MUTEX, 1) < 0){
    printf("FAIL: producer-consumer semaphore initialization\n");
    exit(1);
  }

  if(clone(producer, 0, pc_stacks[0]) < 0){
    printf("FAIL: clone producer\n");
    exit(1);
  }
  if(clone(consumer, 0, pc_stacks[1]) < 0){
   printf("FAIL: clone consumer\n");
   exit(1);
  }

  if(join() < 0 || join() < 0){
    printf("FAIL: join producer-consumer threads\n");
    failed = 1;
  }

  

  printf("Produced total: %d\n", produced);
  printf("Consumed total: %d\n", consumed);

  if(produced != ITEMS || consumed != ITEMS)
    failed = 1;

  if(!failed)
    printf("Producer-Consumer test: PASS\n");
  else
    printf("Q2 synchronization test: FAIL\n");

  exit(failed);
}
