
user/_semtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  printf("semtest: starting\n");
   8:	00001517          	auipc	a0,0x1
   c:	96850513          	addi	a0,a0,-1688 # 970 <malloc+0xf4>
  10:	7b4000ef          	jal	7c4 <printf>

  if (sem_init(0, 1) < 0) {
  14:	4585                	li	a1,1
  16:	4501                	li	a0,0
  18:	3de000ef          	jal	3f6 <sem_init>
  1c:	02054b63          	bltz	a0,52 <main+0x52>
    printf("semtest: init failed\n");
    exit(1);
  }

  if (sem_wait(0) < 0) {
  20:	4501                	li	a0,0
  22:	3dc000ef          	jal	3fe <sem_wait>
  26:	02054f63          	bltz	a0,64 <main+0x64>
    printf("semtest: wait failed\n");
    exit(1);
  }

  printf("semtest: wait passed\n");
  2a:	00001517          	auipc	a0,0x1
  2e:	98e50513          	addi	a0,a0,-1650 # 9b8 <malloc+0x13c>
  32:	792000ef          	jal	7c4 <printf>

  if (sem_signal(0) < 0) {
  36:	4501                	li	a0,0
  38:	3ce000ef          	jal	406 <sem_signal>
  3c:	02054d63          	bltz	a0,76 <main+0x76>
    printf("semtest: signal failed\n");
    exit(1);
  }

  printf("semtest: PASS\n");
  40:	00001517          	auipc	a0,0x1
  44:	9a850513          	addi	a0,a0,-1624 # 9e8 <malloc+0x16c>
  48:	77c000ef          	jal	7c4 <printf>
  exit(0);
  4c:	4501                	li	a0,0
  4e:	2f0000ef          	jal	33e <exit>
    printf("semtest: init failed\n");
  52:	00001517          	auipc	a0,0x1
  56:	93650513          	addi	a0,a0,-1738 # 988 <malloc+0x10c>
  5a:	76a000ef          	jal	7c4 <printf>
    exit(1);
  5e:	4505                	li	a0,1
  60:	2de000ef          	jal	33e <exit>
    printf("semtest: wait failed\n");
  64:	00001517          	auipc	a0,0x1
  68:	93c50513          	addi	a0,a0,-1732 # 9a0 <malloc+0x124>
  6c:	758000ef          	jal	7c4 <printf>
    exit(1);
  70:	4505                	li	a0,1
  72:	2cc000ef          	jal	33e <exit>
    printf("semtest: signal failed\n");
  76:	00001517          	auipc	a0,0x1
  7a:	95a50513          	addi	a0,a0,-1702 # 9d0 <malloc+0x154>
  7e:	746000ef          	jal	7c4 <printf>
    exit(1);
  82:	4505                	li	a0,1
  84:	2ba000ef          	jal	33e <exit>

0000000000000088 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
  88:	1141                	addi	sp,sp,-16
  8a:	e406                	sd	ra,8(sp)
  8c:	e022                	sd	s0,0(sp)
  8e:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
  90:	f71ff0ef          	jal	0 <main>
  exit(r);
  94:	2aa000ef          	jal	33e <exit>

0000000000000098 <strcpy>:
}

char *
strcpy(char *s, const char *t)
{
  98:	1141                	addi	sp,sp,-16
  9a:	e406                	sd	ra,8(sp)
  9c:	e022                	sd	s0,0(sp)
  9e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while ((*s++ = *t++) != 0)
  a0:	87aa                	mv	a5,a0
  a2:	0585                	addi	a1,a1,1
  a4:	0785                	addi	a5,a5,1
  a6:	fff5c703          	lbu	a4,-1(a1)
  aa:	fee78fa3          	sb	a4,-1(a5)
  ae:	fb75                	bnez	a4,a2 <strcpy+0xa>
    ;
  return os;
}
  b0:	60a2                	ld	ra,8(sp)
  b2:	6402                	ld	s0,0(sp)
  b4:	0141                	addi	sp,sp,16
  b6:	8082                	ret

00000000000000b8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  b8:	1141                	addi	sp,sp,-16
  ba:	e406                	sd	ra,8(sp)
  bc:	e022                	sd	s0,0(sp)
  be:	0800                	addi	s0,sp,16
  while (*p && *p == *q)
  c0:	00054783          	lbu	a5,0(a0)
  c4:	cb91                	beqz	a5,d8 <strcmp+0x20>
  c6:	0005c703          	lbu	a4,0(a1)
  ca:	00f71763          	bne	a4,a5,d8 <strcmp+0x20>
    p++, q++;
  ce:	0505                	addi	a0,a0,1
  d0:	0585                	addi	a1,a1,1
  while (*p && *p == *q)
  d2:	00054783          	lbu	a5,0(a0)
  d6:	fbe5                	bnez	a5,c6 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  d8:	0005c503          	lbu	a0,0(a1)
}
  dc:	40a7853b          	subw	a0,a5,a0
  e0:	60a2                	ld	ra,8(sp)
  e2:	6402                	ld	s0,0(sp)
  e4:	0141                	addi	sp,sp,16
  e6:	8082                	ret

00000000000000e8 <strlen>:

uint
strlen(const char *s)
{
  e8:	1141                	addi	sp,sp,-16
  ea:	e406                	sd	ra,8(sp)
  ec:	e022                	sd	s0,0(sp)
  ee:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
  f0:	00054783          	lbu	a5,0(a0)
  f4:	cf91                	beqz	a5,110 <strlen+0x28>
  f6:	00150793          	addi	a5,a0,1
  fa:	86be                	mv	a3,a5
  fc:	0785                	addi	a5,a5,1
  fe:	fff7c703          	lbu	a4,-1(a5)
 102:	ff65                	bnez	a4,fa <strlen+0x12>
 104:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 108:	60a2                	ld	ra,8(sp)
 10a:	6402                	ld	s0,0(sp)
 10c:	0141                	addi	sp,sp,16
 10e:	8082                	ret
  for (n = 0; s[n]; n++)
 110:	4501                	li	a0,0
 112:	bfdd                	j	108 <strlen+0x20>

0000000000000114 <memset>:

void *
memset(void *dst, int c, uint n)
{
 114:	1141                	addi	sp,sp,-16
 116:	e406                	sd	ra,8(sp)
 118:	e022                	sd	s0,0(sp)
 11a:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
 11c:	ca19                	beqz	a2,132 <memset+0x1e>
 11e:	87aa                	mv	a5,a0
 120:	1602                	slli	a2,a2,0x20
 122:	9201                	srli	a2,a2,0x20
 124:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 128:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
 12c:	0785                	addi	a5,a5,1
 12e:	fee79de3          	bne	a5,a4,128 <memset+0x14>
  }
  return dst;
}
 132:	60a2                	ld	ra,8(sp)
 134:	6402                	ld	s0,0(sp)
 136:	0141                	addi	sp,sp,16
 138:	8082                	ret

000000000000013a <strchr>:

char *
strchr(const char *s, char c)
{
 13a:	1141                	addi	sp,sp,-16
 13c:	e406                	sd	ra,8(sp)
 13e:	e022                	sd	s0,0(sp)
 140:	0800                	addi	s0,sp,16
  for (; *s; s++)
 142:	00054783          	lbu	a5,0(a0)
 146:	cf81                	beqz	a5,15e <strchr+0x24>
    if (*s == c)
 148:	00f58763          	beq	a1,a5,156 <strchr+0x1c>
  for (; *s; s++)
 14c:	0505                	addi	a0,a0,1
 14e:	00054783          	lbu	a5,0(a0)
 152:	fbfd                	bnez	a5,148 <strchr+0xe>
      return (char *)s;
  return 0;
 154:	4501                	li	a0,0
}
 156:	60a2                	ld	ra,8(sp)
 158:	6402                	ld	s0,0(sp)
 15a:	0141                	addi	sp,sp,16
 15c:	8082                	ret
  return 0;
 15e:	4501                	li	a0,0
 160:	bfdd                	j	156 <strchr+0x1c>

0000000000000162 <gets>:

char *
gets(char *buf, int max)
{
 162:	711d                	addi	sp,sp,-96
 164:	ec86                	sd	ra,88(sp)
 166:	e8a2                	sd	s0,80(sp)
 168:	e4a6                	sd	s1,72(sp)
 16a:	e0ca                	sd	s2,64(sp)
 16c:	fc4e                	sd	s3,56(sp)
 16e:	f852                	sd	s4,48(sp)
 170:	f456                	sd	s5,40(sp)
 172:	f05a                	sd	s6,32(sp)
 174:	ec5e                	sd	s7,24(sp)
 176:	e862                	sd	s8,16(sp)
 178:	1080                	addi	s0,sp,96
 17a:	8baa                	mv	s7,a0
 17c:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for (i = 0; i + 1 < max;) {
 17e:	892a                	mv	s2,a0
 180:	4481                	li	s1,0
    cc = read(0, &c, 1);
 182:	faf40b13          	addi	s6,s0,-81
 186:	4a85                	li	s5,1
  for (i = 0; i + 1 < max;) {
 188:	8c26                	mv	s8,s1
 18a:	0014899b          	addiw	s3,s1,1
 18e:	84ce                	mv	s1,s3
 190:	0349d463          	bge	s3,s4,1b8 <gets+0x56>
    cc = read(0, &c, 1);
 194:	8656                	mv	a2,s5
 196:	85da                	mv	a1,s6
 198:	4501                	li	a0,0
 19a:	1bc000ef          	jal	356 <read>
    if (cc < 1)
 19e:	00a05d63          	blez	a0,1b8 <gets+0x56>
      break;
    buf[i++] = c;
 1a2:	faf44783          	lbu	a5,-81(s0)
 1a6:	00f90023          	sb	a5,0(s2)
    if (c == '\n' || c == '\r')
 1aa:	0905                	addi	s2,s2,1
 1ac:	ff678713          	addi	a4,a5,-10
 1b0:	c319                	beqz	a4,1b6 <gets+0x54>
 1b2:	17cd                	addi	a5,a5,-13
 1b4:	fbf1                	bnez	a5,188 <gets+0x26>
    buf[i++] = c;
 1b6:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1b8:	9c5e                	add	s8,s8,s7
 1ba:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1be:	855e                	mv	a0,s7
 1c0:	60e6                	ld	ra,88(sp)
 1c2:	6446                	ld	s0,80(sp)
 1c4:	64a6                	ld	s1,72(sp)
 1c6:	6906                	ld	s2,64(sp)
 1c8:	79e2                	ld	s3,56(sp)
 1ca:	7a42                	ld	s4,48(sp)
 1cc:	7aa2                	ld	s5,40(sp)
 1ce:	7b02                	ld	s6,32(sp)
 1d0:	6be2                	ld	s7,24(sp)
 1d2:	6c42                	ld	s8,16(sp)
 1d4:	6125                	addi	sp,sp,96
 1d6:	8082                	ret

00000000000001d8 <stat>:

int
stat(const char *n, struct stat *st)
{
 1d8:	1101                	addi	sp,sp,-32
 1da:	ec06                	sd	ra,24(sp)
 1dc:	e822                	sd	s0,16(sp)
 1de:	e04a                	sd	s2,0(sp)
 1e0:	1000                	addi	s0,sp,32
 1e2:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1e4:	4581                	li	a1,0
 1e6:	198000ef          	jal	37e <open>
  if (fd < 0)
 1ea:	02054263          	bltz	a0,20e <stat+0x36>
 1ee:	e426                	sd	s1,8(sp)
 1f0:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 1f2:	85ca                	mv	a1,s2
 1f4:	1a2000ef          	jal	396 <fstat>
 1f8:	892a                	mv	s2,a0
  close(fd);
 1fa:	8526                	mv	a0,s1
 1fc:	16a000ef          	jal	366 <close>
  return r;
 200:	64a2                	ld	s1,8(sp)
}
 202:	854a                	mv	a0,s2
 204:	60e2                	ld	ra,24(sp)
 206:	6442                	ld	s0,16(sp)
 208:	6902                	ld	s2,0(sp)
 20a:	6105                	addi	sp,sp,32
 20c:	8082                	ret
    return -1;
 20e:	57fd                	li	a5,-1
 210:	893e                	mv	s2,a5
 212:	bfc5                	j	202 <stat+0x2a>

0000000000000214 <atoi>:

int
atoi(const char *s)
{
 214:	1141                	addi	sp,sp,-16
 216:	e406                	sd	ra,8(sp)
 218:	e022                	sd	s0,0(sp)
 21a:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while ('0' <= *s && *s <= '9')
 21c:	00054683          	lbu	a3,0(a0)
 220:	fd06879b          	addiw	a5,a3,-48
 224:	0ff7f793          	zext.b	a5,a5
 228:	4625                	li	a2,9
 22a:	02f66963          	bltu	a2,a5,25c <atoi+0x48>
 22e:	872a                	mv	a4,a0
  n = 0;
 230:	4501                	li	a0,0
    n = n * 10 + *s++ - '0';
 232:	0705                	addi	a4,a4,1
 234:	0025179b          	slliw	a5,a0,0x2
 238:	9fa9                	addw	a5,a5,a0
 23a:	0017979b          	slliw	a5,a5,0x1
 23e:	9fb5                	addw	a5,a5,a3
 240:	fd07851b          	addiw	a0,a5,-48
  while ('0' <= *s && *s <= '9')
 244:	00074683          	lbu	a3,0(a4)
 248:	fd06879b          	addiw	a5,a3,-48
 24c:	0ff7f793          	zext.b	a5,a5
 250:	fef671e3          	bgeu	a2,a5,232 <atoi+0x1e>
  return n;
}
 254:	60a2                	ld	ra,8(sp)
 256:	6402                	ld	s0,0(sp)
 258:	0141                	addi	sp,sp,16
 25a:	8082                	ret
  n = 0;
 25c:	4501                	li	a0,0
 25e:	bfdd                	j	254 <atoi+0x40>

0000000000000260 <memmove>:

void *
memmove(void *vdst, const void *vsrc, int n)
{
 260:	1141                	addi	sp,sp,-16
 262:	e406                	sd	ra,8(sp)
 264:	e022                	sd	s0,0(sp)
 266:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 268:	02b57563          	bgeu	a0,a1,292 <memmove+0x32>
    while (n-- > 0)
 26c:	00c05f63          	blez	a2,28a <memmove+0x2a>
 270:	1602                	slli	a2,a2,0x20
 272:	9201                	srli	a2,a2,0x20
 274:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 278:	872a                	mv	a4,a0
      *dst++ = *src++;
 27a:	0585                	addi	a1,a1,1
 27c:	0705                	addi	a4,a4,1
 27e:	fff5c683          	lbu	a3,-1(a1)
 282:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
 286:	fee79ae3          	bne	a5,a4,27a <memmove+0x1a>
    src += n;
    while (n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 28a:	60a2                	ld	ra,8(sp)
 28c:	6402                	ld	s0,0(sp)
 28e:	0141                	addi	sp,sp,16
 290:	8082                	ret
    while (n-- > 0)
 292:	fec05ce3          	blez	a2,28a <memmove+0x2a>
    dst += n;
 296:	00c50733          	add	a4,a0,a2
    src += n;
 29a:	95b2                	add	a1,a1,a2
 29c:	fff6079b          	addiw	a5,a2,-1
 2a0:	1782                	slli	a5,a5,0x20
 2a2:	9381                	srli	a5,a5,0x20
 2a4:	fff7c793          	not	a5,a5
 2a8:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2aa:	15fd                	addi	a1,a1,-1
 2ac:	177d                	addi	a4,a4,-1
 2ae:	0005c683          	lbu	a3,0(a1)
 2b2:	00d70023          	sb	a3,0(a4)
    while (n-- > 0)
 2b6:	fef71ae3          	bne	a4,a5,2aa <memmove+0x4a>
 2ba:	bfc1                	j	28a <memmove+0x2a>

00000000000002bc <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2bc:	1141                	addi	sp,sp,-16
 2be:	e406                	sd	ra,8(sp)
 2c0:	e022                	sd	s0,0(sp)
 2c2:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 2c4:	c61d                	beqz	a2,2f2 <memcmp+0x36>
 2c6:	1602                	slli	a2,a2,0x20
 2c8:	9201                	srli	a2,a2,0x20
 2ca:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 2ce:	00054783          	lbu	a5,0(a0)
 2d2:	0005c703          	lbu	a4,0(a1)
 2d6:	00e79863          	bne	a5,a4,2e6 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 2da:	0505                	addi	a0,a0,1
    p2++;
 2dc:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 2de:	fed518e3          	bne	a0,a3,2ce <memcmp+0x12>
  }
  return 0;
 2e2:	4501                	li	a0,0
 2e4:	a019                	j	2ea <memcmp+0x2e>
      return *p1 - *p2;
 2e6:	40e7853b          	subw	a0,a5,a4
}
 2ea:	60a2                	ld	ra,8(sp)
 2ec:	6402                	ld	s0,0(sp)
 2ee:	0141                	addi	sp,sp,16
 2f0:	8082                	ret
  return 0;
 2f2:	4501                	li	a0,0
 2f4:	bfdd                	j	2ea <memcmp+0x2e>

00000000000002f6 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 2f6:	1141                	addi	sp,sp,-16
 2f8:	e406                	sd	ra,8(sp)
 2fa:	e022                	sd	s0,0(sp)
 2fc:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 2fe:	f63ff0ef          	jal	260 <memmove>
}
 302:	60a2                	ld	ra,8(sp)
 304:	6402                	ld	s0,0(sp)
 306:	0141                	addi	sp,sp,16
 308:	8082                	ret

000000000000030a <sbrk>:

char *
sbrk(int n)
{
 30a:	1141                	addi	sp,sp,-16
 30c:	e406                	sd	ra,8(sp)
 30e:	e022                	sd	s0,0(sp)
 310:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 312:	4585                	li	a1,1
 314:	0b2000ef          	jal	3c6 <sys_sbrk>
}
 318:	60a2                	ld	ra,8(sp)
 31a:	6402                	ld	s0,0(sp)
 31c:	0141                	addi	sp,sp,16
 31e:	8082                	ret

0000000000000320 <sbrklazy>:

char *
sbrklazy(int n)
{
 320:	1141                	addi	sp,sp,-16
 322:	e406                	sd	ra,8(sp)
 324:	e022                	sd	s0,0(sp)
 326:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 328:	4589                	li	a1,2
 32a:	09c000ef          	jal	3c6 <sys_sbrk>
}
 32e:	60a2                	ld	ra,8(sp)
 330:	6402                	ld	s0,0(sp)
 332:	0141                	addi	sp,sp,16
 334:	8082                	ret

0000000000000336 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 336:	4885                	li	a7,1
 ecall
 338:	00000073          	ecall
 ret
 33c:	8082                	ret

000000000000033e <exit>:
.global exit
exit:
 li a7, SYS_exit
 33e:	4889                	li	a7,2
 ecall
 340:	00000073          	ecall
 ret
 344:	8082                	ret

0000000000000346 <wait>:
.global wait
wait:
 li a7, SYS_wait
 346:	488d                	li	a7,3
 ecall
 348:	00000073          	ecall
 ret
 34c:	8082                	ret

000000000000034e <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 34e:	4891                	li	a7,4
 ecall
 350:	00000073          	ecall
 ret
 354:	8082                	ret

0000000000000356 <read>:
.global read
read:
 li a7, SYS_read
 356:	4895                	li	a7,5
 ecall
 358:	00000073          	ecall
 ret
 35c:	8082                	ret

000000000000035e <write>:
.global write
write:
 li a7, SYS_write
 35e:	48c1                	li	a7,16
 ecall
 360:	00000073          	ecall
 ret
 364:	8082                	ret

0000000000000366 <close>:
.global close
close:
 li a7, SYS_close
 366:	48d5                	li	a7,21
 ecall
 368:	00000073          	ecall
 ret
 36c:	8082                	ret

000000000000036e <kill>:
.global kill
kill:
 li a7, SYS_kill
 36e:	4899                	li	a7,6
 ecall
 370:	00000073          	ecall
 ret
 374:	8082                	ret

0000000000000376 <exec>:
.global exec
exec:
 li a7, SYS_exec
 376:	489d                	li	a7,7
 ecall
 378:	00000073          	ecall
 ret
 37c:	8082                	ret

000000000000037e <open>:
.global open
open:
 li a7, SYS_open
 37e:	48bd                	li	a7,15
 ecall
 380:	00000073          	ecall
 ret
 384:	8082                	ret

0000000000000386 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 386:	48c5                	li	a7,17
 ecall
 388:	00000073          	ecall
 ret
 38c:	8082                	ret

000000000000038e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 38e:	48c9                	li	a7,18
 ecall
 390:	00000073          	ecall
 ret
 394:	8082                	ret

0000000000000396 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 396:	48a1                	li	a7,8
 ecall
 398:	00000073          	ecall
 ret
 39c:	8082                	ret

000000000000039e <link>:
.global link
link:
 li a7, SYS_link
 39e:	48cd                	li	a7,19
 ecall
 3a0:	00000073          	ecall
 ret
 3a4:	8082                	ret

00000000000003a6 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3a6:	48d1                	li	a7,20
 ecall
 3a8:	00000073          	ecall
 ret
 3ac:	8082                	ret

00000000000003ae <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3ae:	48a5                	li	a7,9
 ecall
 3b0:	00000073          	ecall
 ret
 3b4:	8082                	ret

00000000000003b6 <dup>:
.global dup
dup:
 li a7, SYS_dup
 3b6:	48a9                	li	a7,10
 ecall
 3b8:	00000073          	ecall
 ret
 3bc:	8082                	ret

00000000000003be <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3be:	48ad                	li	a7,11
 ecall
 3c0:	00000073          	ecall
 ret
 3c4:	8082                	ret

00000000000003c6 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 3c6:	48b1                	li	a7,12
 ecall
 3c8:	00000073          	ecall
 ret
 3cc:	8082                	ret

00000000000003ce <pause>:
.global pause
pause:
 li a7, SYS_pause
 3ce:	48b5                	li	a7,13
 ecall
 3d0:	00000073          	ecall
 ret
 3d4:	8082                	ret

00000000000003d6 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 3d6:	48b9                	li	a7,14
 ecall
 3d8:	00000073          	ecall
 ret
 3dc:	8082                	ret

00000000000003de <sync>:
.global sync
sync:
 li a7, SYS_sync
 3de:	48d9                	li	a7,22
 ecall
 3e0:	00000073          	ecall
 ret
 3e4:	8082                	ret

00000000000003e6 <clone>:
.global clone
clone:
 li a7, SYS_clone
 3e6:	48dd                	li	a7,23
 ecall
 3e8:	00000073          	ecall
 ret
 3ec:	8082                	ret

00000000000003ee <join>:
.global join
join:
 li a7, SYS_join
 3ee:	48e1                	li	a7,24
 ecall
 3f0:	00000073          	ecall
 ret
 3f4:	8082                	ret

00000000000003f6 <sem_init>:
.global sem_init
sem_init:
 li a7, SYS_sem_init
 3f6:	48e5                	li	a7,25
 ecall
 3f8:	00000073          	ecall
 ret
 3fc:	8082                	ret

00000000000003fe <sem_wait>:
.global sem_wait
sem_wait:
 li a7, SYS_sem_wait
 3fe:	48e9                	li	a7,26
 ecall
 400:	00000073          	ecall
 ret
 404:	8082                	ret

0000000000000406 <sem_signal>:
.global sem_signal
sem_signal:
 li a7, SYS_sem_signal
 406:	48ed                	li	a7,27
 ecall
 408:	00000073          	ecall
 ret
 40c:	8082                	ret

000000000000040e <set_priority>:
.global set_priority
set_priority:
 li a7, SYS_set_priority
 40e:	48f1                	li	a7,28
 ecall
 410:	00000073          	ecall
 ret
 414:	8082                	ret

0000000000000416 <get_priority>:
.global get_priority
get_priority:
 li a7, SYS_get_priority
 416:	48f5                	li	a7,29
 ecall
 418:	00000073          	ecall
 ret
 41c:	8082                	ret

000000000000041e <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 41e:	1101                	addi	sp,sp,-32
 420:	ec06                	sd	ra,24(sp)
 422:	e822                	sd	s0,16(sp)
 424:	1000                	addi	s0,sp,32
 426:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 42a:	4605                	li	a2,1
 42c:	fef40593          	addi	a1,s0,-17
 430:	f2fff0ef          	jal	35e <write>
}
 434:	60e2                	ld	ra,24(sp)
 436:	6442                	ld	s0,16(sp)
 438:	6105                	addi	sp,sp,32
 43a:	8082                	ret

000000000000043c <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 43c:	715d                	addi	sp,sp,-80
 43e:	e486                	sd	ra,72(sp)
 440:	e0a2                	sd	s0,64(sp)
 442:	f84a                	sd	s2,48(sp)
 444:	f44e                	sd	s3,40(sp)
 446:	0880                	addi	s0,sp,80
 448:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if (sgn && xx < 0) {
 44a:	c6d1                	beqz	a3,4d6 <printint+0x9a>
 44c:	0805d563          	bgez	a1,4d6 <printint+0x9a>
    neg = 1;
    x = -xx;
 450:	40b005b3          	neg	a1,a1
    neg = 1;
 454:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 456:	fb840993          	addi	s3,s0,-72
  neg = 0;
 45a:	86ce                	mv	a3,s3
  i = 0;
 45c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
 45e:	00000817          	auipc	a6,0x0
 462:	5a280813          	addi	a6,a6,1442 # a00 <digits>
 466:	88ba                	mv	a7,a4
 468:	0017051b          	addiw	a0,a4,1
 46c:	872a                	mv	a4,a0
 46e:	02c5f7b3          	remu	a5,a1,a2
 472:	97c2                	add	a5,a5,a6
 474:	0007c783          	lbu	a5,0(a5)
 478:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
 47c:	87ae                	mv	a5,a1
 47e:	02c5d5b3          	divu	a1,a1,a2
 482:	0685                	addi	a3,a3,1
 484:	fec7f1e3          	bgeu	a5,a2,466 <printint+0x2a>
  if (neg)
 488:	00030c63          	beqz	t1,4a0 <printint+0x64>
    buf[i++] = '-';
 48c:	fd050793          	addi	a5,a0,-48
 490:	00878533          	add	a0,a5,s0
 494:	02d00793          	li	a5,45
 498:	fef50423          	sb	a5,-24(a0)
 49c:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
 4a0:	02e05563          	blez	a4,4ca <printint+0x8e>
 4a4:	fc26                	sd	s1,56(sp)
 4a6:	377d                	addiw	a4,a4,-1
 4a8:	00e984b3          	add	s1,s3,a4
 4ac:	19fd                	addi	s3,s3,-1
 4ae:	99ba                	add	s3,s3,a4
 4b0:	1702                	slli	a4,a4,0x20
 4b2:	9301                	srli	a4,a4,0x20
 4b4:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 4b8:	0004c583          	lbu	a1,0(s1)
 4bc:	854a                	mv	a0,s2
 4be:	f61ff0ef          	jal	41e <putc>
  while (--i >= 0)
 4c2:	14fd                	addi	s1,s1,-1
 4c4:	ff349ae3          	bne	s1,s3,4b8 <printint+0x7c>
 4c8:	74e2                	ld	s1,56(sp)
}
 4ca:	60a6                	ld	ra,72(sp)
 4cc:	6406                	ld	s0,64(sp)
 4ce:	7942                	ld	s2,48(sp)
 4d0:	79a2                	ld	s3,40(sp)
 4d2:	6161                	addi	sp,sp,80
 4d4:	8082                	ret
  neg = 0;
 4d6:	4301                	li	t1,0
 4d8:	bfbd                	j	456 <printint+0x1a>

00000000000004da <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4da:	711d                	addi	sp,sp,-96
 4dc:	ec86                	sd	ra,88(sp)
 4de:	e8a2                	sd	s0,80(sp)
 4e0:	e4a6                	sd	s1,72(sp)
 4e2:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for (i = 0; fmt[i]; i++) {
 4e4:	0005c483          	lbu	s1,0(a1)
 4e8:	22048363          	beqz	s1,70e <vprintf+0x234>
 4ec:	e0ca                	sd	s2,64(sp)
 4ee:	fc4e                	sd	s3,56(sp)
 4f0:	f852                	sd	s4,48(sp)
 4f2:	f456                	sd	s5,40(sp)
 4f4:	f05a                	sd	s6,32(sp)
 4f6:	ec5e                	sd	s7,24(sp)
 4f8:	e862                	sd	s8,16(sp)
 4fa:	8b2a                	mv	s6,a0
 4fc:	8a2e                	mv	s4,a1
 4fe:	8bb2                	mv	s7,a2
  state = 0;
 500:	4981                	li	s3,0
  for (i = 0; fmt[i]; i++) {
 502:	4901                	li	s2,0
 504:	4701                	li	a4,0
      if (c0 == '%') {
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if (state == '%') {
 506:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if (c0)
        c1 = fmt[i + 1] & 0xff;
      if (c1)
        c2 = fmt[i + 2] & 0xff;
      if (c0 == 'd') {
 50a:	06400c13          	li	s8,100
 50e:	a00d                	j	530 <vprintf+0x56>
        putc(fd, c0);
 510:	85a6                	mv	a1,s1
 512:	855a                	mv	a0,s6
 514:	f0bff0ef          	jal	41e <putc>
 518:	a019                	j	51e <vprintf+0x44>
    } else if (state == '%') {
 51a:	03598363          	beq	s3,s5,540 <vprintf+0x66>
  for (i = 0; fmt[i]; i++) {
 51e:	0019079b          	addiw	a5,s2,1
 522:	893e                	mv	s2,a5
 524:	873e                	mv	a4,a5
 526:	97d2                	add	a5,a5,s4
 528:	0007c483          	lbu	s1,0(a5)
 52c:	1c048a63          	beqz	s1,700 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 530:	0004879b          	sext.w	a5,s1
    if (state == 0) {
 534:	fe0993e3          	bnez	s3,51a <vprintf+0x40>
      if (c0 == '%') {
 538:	fd579ce3          	bne	a5,s5,510 <vprintf+0x36>
        state = '%';
 53c:	89be                	mv	s3,a5
 53e:	b7c5                	j	51e <vprintf+0x44>
        c1 = fmt[i + 1] & 0xff;
 540:	00ea06b3          	add	a3,s4,a4
 544:	0016c603          	lbu	a2,1(a3)
      if (c1)
 548:	1c060863          	beqz	a2,718 <vprintf+0x23e>
      if (c0 == 'd') {
 54c:	03878763          	beq	a5,s8,57a <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if (c0 == 'l' && c1 == 'd') {
 550:	f9478693          	addi	a3,a5,-108
 554:	0016b693          	seqz	a3,a3
 558:	f9c60593          	addi	a1,a2,-100
 55c:	e99d                	bnez	a1,592 <vprintf+0xb8>
 55e:	ca95                	beqz	a3,592 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 560:	008b8493          	addi	s1,s7,8
 564:	4685                	li	a3,1
 566:	4629                	li	a2,10
 568:	000bb583          	ld	a1,0(s7)
 56c:	855a                	mv	a0,s6
 56e:	ecfff0ef          	jal	43c <printint>
        i += 1;
 572:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 574:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 576:	4981                	li	s3,0
 578:	b75d                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 57a:	008b8493          	addi	s1,s7,8
 57e:	4685                	li	a3,1
 580:	4629                	li	a2,10
 582:	000ba583          	lw	a1,0(s7)
 586:	855a                	mv	a0,s6
 588:	eb5ff0ef          	jal	43c <printint>
 58c:	8ba6                	mv	s7,s1
      state = 0;
 58e:	4981                	li	s3,0
 590:	b779                	j	51e <vprintf+0x44>
        c2 = fmt[i + 2] & 0xff;
 592:	9752                	add	a4,a4,s4
 594:	00274583          	lbu	a1,2(a4)
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 598:	f9460713          	addi	a4,a2,-108
 59c:	00173713          	seqz	a4,a4
 5a0:	8f75                	and	a4,a4,a3
 5a2:	f9c58513          	addi	a0,a1,-100
 5a6:	18051363          	bnez	a0,72c <vprintf+0x252>
 5aa:	18070163          	beqz	a4,72c <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5ae:	008b8493          	addi	s1,s7,8
 5b2:	4685                	li	a3,1
 5b4:	4629                	li	a2,10
 5b6:	000bb583          	ld	a1,0(s7)
 5ba:	855a                	mv	a0,s6
 5bc:	e81ff0ef          	jal	43c <printint>
        i += 2;
 5c0:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 5c2:	8ba6                	mv	s7,s1
      state = 0;
 5c4:	4981                	li	s3,0
        i += 2;
 5c6:	bfa1                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 5c8:	008b8493          	addi	s1,s7,8
 5cc:	4681                	li	a3,0
 5ce:	4629                	li	a2,10
 5d0:	000be583          	lwu	a1,0(s7)
 5d4:	855a                	mv	a0,s6
 5d6:	e67ff0ef          	jal	43c <printint>
 5da:	8ba6                	mv	s7,s1
      state = 0;
 5dc:	4981                	li	s3,0
 5de:	b781                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5e0:	008b8493          	addi	s1,s7,8
 5e4:	4681                	li	a3,0
 5e6:	4629                	li	a2,10
 5e8:	000bb583          	ld	a1,0(s7)
 5ec:	855a                	mv	a0,s6
 5ee:	e4fff0ef          	jal	43c <printint>
        i += 1;
 5f2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5f4:	8ba6                	mv	s7,s1
      state = 0;
 5f6:	4981                	li	s3,0
 5f8:	b71d                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5fa:	008b8493          	addi	s1,s7,8
 5fe:	4681                	li	a3,0
 600:	4629                	li	a2,10
 602:	000bb583          	ld	a1,0(s7)
 606:	855a                	mv	a0,s6
 608:	e35ff0ef          	jal	43c <printint>
        i += 2;
 60c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 60e:	8ba6                	mv	s7,s1
      state = 0;
 610:	4981                	li	s3,0
        i += 2;
 612:	b731                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 614:	008b8493          	addi	s1,s7,8
 618:	4681                	li	a3,0
 61a:	4641                	li	a2,16
 61c:	000be583          	lwu	a1,0(s7)
 620:	855a                	mv	a0,s6
 622:	e1bff0ef          	jal	43c <printint>
 626:	8ba6                	mv	s7,s1
      state = 0;
 628:	4981                	li	s3,0
 62a:	bdd5                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 62c:	008b8493          	addi	s1,s7,8
 630:	4681                	li	a3,0
 632:	4641                	li	a2,16
 634:	000bb583          	ld	a1,0(s7)
 638:	855a                	mv	a0,s6
 63a:	e03ff0ef          	jal	43c <printint>
        i += 1;
 63e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 640:	8ba6                	mv	s7,s1
      state = 0;
 642:	4981                	li	s3,0
 644:	bde9                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 646:	008b8493          	addi	s1,s7,8
 64a:	4681                	li	a3,0
 64c:	4641                	li	a2,16
 64e:	000bb583          	ld	a1,0(s7)
 652:	855a                	mv	a0,s6
 654:	de9ff0ef          	jal	43c <printint>
        i += 2;
 658:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 65a:	8ba6                	mv	s7,s1
      state = 0;
 65c:	4981                	li	s3,0
        i += 2;
 65e:	b5c1                	j	51e <vprintf+0x44>
 660:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 662:	008b8793          	addi	a5,s7,8
 666:	8cbe                	mv	s9,a5
 668:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 66c:	03000593          	li	a1,48
 670:	855a                	mv	a0,s6
 672:	dadff0ef          	jal	41e <putc>
  putc(fd, 'x');
 676:	07800593          	li	a1,120
 67a:	855a                	mv	a0,s6
 67c:	da3ff0ef          	jal	41e <putc>
 680:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 682:	00000b97          	auipc	s7,0x0
 686:	37eb8b93          	addi	s7,s7,894 # a00 <digits>
 68a:	03c9d793          	srli	a5,s3,0x3c
 68e:	97de                	add	a5,a5,s7
 690:	0007c583          	lbu	a1,0(a5)
 694:	855a                	mv	a0,s6
 696:	d89ff0ef          	jal	41e <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 69a:	0992                	slli	s3,s3,0x4
 69c:	34fd                	addiw	s1,s1,-1
 69e:	f4f5                	bnez	s1,68a <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 6a0:	8be6                	mv	s7,s9
      state = 0;
 6a2:	4981                	li	s3,0
 6a4:	6ca2                	ld	s9,8(sp)
 6a6:	bda5                	j	51e <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 6a8:	008b8493          	addi	s1,s7,8
 6ac:	000bc583          	lbu	a1,0(s7)
 6b0:	855a                	mv	a0,s6
 6b2:	d6dff0ef          	jal	41e <putc>
 6b6:	8ba6                	mv	s7,s1
      state = 0;
 6b8:	4981                	li	s3,0
 6ba:	b595                	j	51e <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 6bc:	008b8993          	addi	s3,s7,8
 6c0:	000bb483          	ld	s1,0(s7)
 6c4:	cc91                	beqz	s1,6e0 <vprintf+0x206>
        for (; *s; s++)
 6c6:	0004c583          	lbu	a1,0(s1)
 6ca:	c985                	beqz	a1,6fa <vprintf+0x220>
          putc(fd, *s);
 6cc:	855a                	mv	a0,s6
 6ce:	d51ff0ef          	jal	41e <putc>
        for (; *s; s++)
 6d2:	0485                	addi	s1,s1,1
 6d4:	0004c583          	lbu	a1,0(s1)
 6d8:	f9f5                	bnez	a1,6cc <vprintf+0x1f2>
        if ((s = va_arg(ap, char *)) == 0)
 6da:	8bce                	mv	s7,s3
      state = 0;
 6dc:	4981                	li	s3,0
 6de:	b581                	j	51e <vprintf+0x44>
          s = "(null)";
 6e0:	00000497          	auipc	s1,0x0
 6e4:	31848493          	addi	s1,s1,792 # 9f8 <malloc+0x17c>
        for (; *s; s++)
 6e8:	02800593          	li	a1,40
 6ec:	b7c5                	j	6cc <vprintf+0x1f2>
        putc(fd, '%');
 6ee:	85be                	mv	a1,a5
 6f0:	855a                	mv	a0,s6
 6f2:	d2dff0ef          	jal	41e <putc>
      state = 0;
 6f6:	4981                	li	s3,0
 6f8:	b51d                	j	51e <vprintf+0x44>
        if ((s = va_arg(ap, char *)) == 0)
 6fa:	8bce                	mv	s7,s3
      state = 0;
 6fc:	4981                	li	s3,0
 6fe:	b505                	j	51e <vprintf+0x44>
 700:	6906                	ld	s2,64(sp)
 702:	79e2                	ld	s3,56(sp)
 704:	7a42                	ld	s4,48(sp)
 706:	7aa2                	ld	s5,40(sp)
 708:	7b02                	ld	s6,32(sp)
 70a:	6be2                	ld	s7,24(sp)
 70c:	6c42                	ld	s8,16(sp)
    }
  }
}
 70e:	60e6                	ld	ra,88(sp)
 710:	6446                	ld	s0,80(sp)
 712:	64a6                	ld	s1,72(sp)
 714:	6125                	addi	sp,sp,96
 716:	8082                	ret
      if (c0 == 'd') {
 718:	06400713          	li	a4,100
 71c:	e4e78fe3          	beq	a5,a4,57a <vprintf+0xa0>
      } else if (c0 == 'l' && c1 == 'd') {
 720:	f9478693          	addi	a3,a5,-108
 724:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 728:	85b2                	mv	a1,a2
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
 72a:	4701                	li	a4,0
      } else if (c0 == 'u') {
 72c:	07500513          	li	a0,117
 730:	e8a78ce3          	beq	a5,a0,5c8 <vprintf+0xee>
      } else if (c0 == 'l' && c1 == 'u') {
 734:	f8b60513          	addi	a0,a2,-117
 738:	e119                	bnez	a0,73e <vprintf+0x264>
 73a:	ea0693e3          	bnez	a3,5e0 <vprintf+0x106>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
 73e:	f8b58513          	addi	a0,a1,-117
 742:	e119                	bnez	a0,748 <vprintf+0x26e>
 744:	ea071be3          	bnez	a4,5fa <vprintf+0x120>
      } else if (c0 == 'x') {
 748:	07800513          	li	a0,120
 74c:	eca784e3          	beq	a5,a0,614 <vprintf+0x13a>
      } else if (c0 == 'l' && c1 == 'x') {
 750:	f8860613          	addi	a2,a2,-120
 754:	e219                	bnez	a2,75a <vprintf+0x280>
 756:	ec069be3          	bnez	a3,62c <vprintf+0x152>
      } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
 75a:	f8858593          	addi	a1,a1,-120
 75e:	e199                	bnez	a1,764 <vprintf+0x28a>
 760:	ee0713e3          	bnez	a4,646 <vprintf+0x16c>
      } else if (c0 == 'p') {
 764:	07000713          	li	a4,112
 768:	eee78ce3          	beq	a5,a4,660 <vprintf+0x186>
      } else if (c0 == 'c') {
 76c:	06300713          	li	a4,99
 770:	f2e78ce3          	beq	a5,a4,6a8 <vprintf+0x1ce>
      } else if (c0 == 's') {
 774:	07300713          	li	a4,115
 778:	f4e782e3          	beq	a5,a4,6bc <vprintf+0x1e2>
      } else if (c0 == '%') {
 77c:	02500713          	li	a4,37
 780:	f6e787e3          	beq	a5,a4,6ee <vprintf+0x214>
        putc(fd, '%');
 784:	02500593          	li	a1,37
 788:	855a                	mv	a0,s6
 78a:	c95ff0ef          	jal	41e <putc>
        putc(fd, c0);
 78e:	85a6                	mv	a1,s1
 790:	855a                	mv	a0,s6
 792:	c8dff0ef          	jal	41e <putc>
      state = 0;
 796:	4981                	li	s3,0
 798:	b359                	j	51e <vprintf+0x44>

000000000000079a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 79a:	715d                	addi	sp,sp,-80
 79c:	ec06                	sd	ra,24(sp)
 79e:	e822                	sd	s0,16(sp)
 7a0:	1000                	addi	s0,sp,32
 7a2:	e010                	sd	a2,0(s0)
 7a4:	e414                	sd	a3,8(s0)
 7a6:	e818                	sd	a4,16(s0)
 7a8:	ec1c                	sd	a5,24(s0)
 7aa:	03043023          	sd	a6,32(s0)
 7ae:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7b2:	8622                	mv	a2,s0
 7b4:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7b8:	d23ff0ef          	jal	4da <vprintf>
}
 7bc:	60e2                	ld	ra,24(sp)
 7be:	6442                	ld	s0,16(sp)
 7c0:	6161                	addi	sp,sp,80
 7c2:	8082                	ret

00000000000007c4 <printf>:

void
printf(const char *fmt, ...)
{
 7c4:	711d                	addi	sp,sp,-96
 7c6:	ec06                	sd	ra,24(sp)
 7c8:	e822                	sd	s0,16(sp)
 7ca:	1000                	addi	s0,sp,32
 7cc:	e40c                	sd	a1,8(s0)
 7ce:	e810                	sd	a2,16(s0)
 7d0:	ec14                	sd	a3,24(s0)
 7d2:	f018                	sd	a4,32(s0)
 7d4:	f41c                	sd	a5,40(s0)
 7d6:	03043823          	sd	a6,48(s0)
 7da:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7de:	00840613          	addi	a2,s0,8
 7e2:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7e6:	85aa                	mv	a1,a0
 7e8:	4505                	li	a0,1
 7ea:	cf1ff0ef          	jal	4da <vprintf>
}
 7ee:	60e2                	ld	ra,24(sp)
 7f0:	6442                	ld	s0,16(sp)
 7f2:	6125                	addi	sp,sp,96
 7f4:	8082                	ret

00000000000007f6 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7f6:	1141                	addi	sp,sp,-16
 7f8:	e406                	sd	ra,8(sp)
 7fa:	e022                	sd	s0,0(sp)
 7fc:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header *)ap - 1;
 7fe:	ff050693          	addi	a3,a0,-16
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 802:	00000797          	auipc	a5,0x0
 806:	7fe7b783          	ld	a5,2046(a5) # 1000 <freep>
 80a:	a039                	j	818 <free+0x22>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 80c:	6398                	ld	a4,0(a5)
 80e:	00e7e463          	bltu	a5,a4,816 <free+0x20>
 812:	00e6ea63          	bltu	a3,a4,826 <free+0x30>
{
 816:	87ba                	mv	a5,a4
  for (p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 818:	fed7fae3          	bgeu	a5,a3,80c <free+0x16>
 81c:	6398                	ld	a4,0(a5)
 81e:	00e6e463          	bltu	a3,a4,826 <free+0x30>
    if (p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 822:	fee7eae3          	bltu	a5,a4,816 <free+0x20>
      break;
  if (bp + bp->s.size == p->s.ptr) {
 826:	ff852583          	lw	a1,-8(a0)
 82a:	6390                	ld	a2,0(a5)
 82c:	02059813          	slli	a6,a1,0x20
 830:	01c85713          	srli	a4,a6,0x1c
 834:	9736                	add	a4,a4,a3
 836:	02e60563          	beq	a2,a4,860 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 83a:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if (p + p->s.size == bp) {
 83e:	4790                	lw	a2,8(a5)
 840:	02061593          	slli	a1,a2,0x20
 844:	01c5d713          	srli	a4,a1,0x1c
 848:	973e                	add	a4,a4,a5
 84a:	02e68263          	beq	a3,a4,86e <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 84e:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 850:	00000717          	auipc	a4,0x0
 854:	7af73823          	sd	a5,1968(a4) # 1000 <freep>
}
 858:	60a2                	ld	ra,8(sp)
 85a:	6402                	ld	s0,0(sp)
 85c:	0141                	addi	sp,sp,16
 85e:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 860:	4618                	lw	a4,8(a2)
 862:	9f2d                	addw	a4,a4,a1
 864:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 868:	6398                	ld	a4,0(a5)
 86a:	6310                	ld	a2,0(a4)
 86c:	b7f9                	j	83a <free+0x44>
    p->s.size += bp->s.size;
 86e:	ff852703          	lw	a4,-8(a0)
 872:	9f31                	addw	a4,a4,a2
 874:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 876:	ff053683          	ld	a3,-16(a0)
 87a:	bfd1                	j	84e <free+0x58>

000000000000087c <malloc>:
  return freep;
}

void *
malloc(uint nbytes)
{
 87c:	7139                	addi	sp,sp,-64
 87e:	fc06                	sd	ra,56(sp)
 880:	f822                	sd	s0,48(sp)
 882:	f04a                	sd	s2,32(sp)
 884:	ec4e                	sd	s3,24(sp)
 886:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1) / sizeof(Header) + 1;
 888:	02051993          	slli	s3,a0,0x20
 88c:	0209d993          	srli	s3,s3,0x20
 890:	09bd                	addi	s3,s3,15
 892:	0049d993          	srli	s3,s3,0x4
 896:	2985                	addiw	s3,s3,1
 898:	894e                	mv	s2,s3
  if ((prevp = freep) == 0) {
 89a:	00000517          	auipc	a0,0x0
 89e:	76653503          	ld	a0,1894(a0) # 1000 <freep>
 8a2:	c905                	beqz	a0,8d2 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 8a4:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 8a6:	4798                	lw	a4,8(a5)
 8a8:	09377663          	bgeu	a4,s3,934 <malloc+0xb8>
 8ac:	f426                	sd	s1,40(sp)
 8ae:	e852                	sd	s4,16(sp)
 8b0:	e456                	sd	s5,8(sp)
 8b2:	e05a                	sd	s6,0(sp)
  if (nu < 4096)
 8b4:	8a4e                	mv	s4,s3
 8b6:	6705                	lui	a4,0x1
 8b8:	00e9f363          	bgeu	s3,a4,8be <malloc+0x42>
 8bc:	6a05                	lui	s4,0x1
 8be:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8c2:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void *)(p + 1);
    }
    if (p == freep)
 8c6:	00000497          	auipc	s1,0x0
 8ca:	73a48493          	addi	s1,s1,1850 # 1000 <freep>
  if (p == SBRK_ERROR)
 8ce:	5afd                	li	s5,-1
 8d0:	a83d                	j	90e <malloc+0x92>
 8d2:	f426                	sd	s1,40(sp)
 8d4:	e852                	sd	s4,16(sp)
 8d6:	e456                	sd	s5,8(sp)
 8d8:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 8da:	00000797          	auipc	a5,0x0
 8de:	73678793          	addi	a5,a5,1846 # 1010 <base>
 8e2:	00000717          	auipc	a4,0x0
 8e6:	70f73f23          	sd	a5,1822(a4) # 1000 <freep>
 8ea:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8ec:	0007a423          	sw	zero,8(a5)
    if (p->s.size >= nunits) {
 8f0:	b7d1                	j	8b4 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 8f2:	6398                	ld	a4,0(a5)
 8f4:	e118                	sd	a4,0(a0)
 8f6:	a899                	j	94c <malloc+0xd0>
  hp->s.size = nu;
 8f8:	01652423          	sw	s6,8(a0)
  free((void *)(hp + 1));
 8fc:	0541                	addi	a0,a0,16
 8fe:	ef9ff0ef          	jal	7f6 <free>
  return freep;
 902:	6088                	ld	a0,0(s1)
      if ((p = morecore(nunits)) == 0)
 904:	c125                	beqz	a0,964 <malloc+0xe8>
  for (p = prevp->s.ptr;; prevp = p, p = p->s.ptr) {
 906:	611c                	ld	a5,0(a0)
    if (p->s.size >= nunits) {
 908:	4798                	lw	a4,8(a5)
 90a:	03277163          	bgeu	a4,s2,92c <malloc+0xb0>
    if (p == freep)
 90e:	6098                	ld	a4,0(s1)
 910:	853e                	mv	a0,a5
 912:	fef71ae3          	bne	a4,a5,906 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 916:	8552                	mv	a0,s4
 918:	9f3ff0ef          	jal	30a <sbrk>
  if (p == SBRK_ERROR)
 91c:	fd551ee3          	bne	a0,s5,8f8 <malloc+0x7c>
        return 0;
 920:	4501                	li	a0,0
 922:	74a2                	ld	s1,40(sp)
 924:	6a42                	ld	s4,16(sp)
 926:	6aa2                	ld	s5,8(sp)
 928:	6b02                	ld	s6,0(sp)
 92a:	a03d                	j	958 <malloc+0xdc>
 92c:	74a2                	ld	s1,40(sp)
 92e:	6a42                	ld	s4,16(sp)
 930:	6aa2                	ld	s5,8(sp)
 932:	6b02                	ld	s6,0(sp)
      if (p->s.size == nunits)
 934:	fae90fe3          	beq	s2,a4,8f2 <malloc+0x76>
        p->s.size -= nunits;
 938:	4137073b          	subw	a4,a4,s3
 93c:	c798                	sw	a4,8(a5)
        p += p->s.size;
 93e:	02071693          	slli	a3,a4,0x20
 942:	01c6d713          	srli	a4,a3,0x1c
 946:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 948:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 94c:	00000717          	auipc	a4,0x0
 950:	6aa73a23          	sd	a0,1716(a4) # 1000 <freep>
      return (void *)(p + 1);
 954:	01078513          	addi	a0,a5,16
  }
}
 958:	70e2                	ld	ra,56(sp)
 95a:	7442                	ld	s0,48(sp)
 95c:	7902                	ld	s2,32(sp)
 95e:	69e2                	ld	s3,24(sp)
 960:	6121                	addi	sp,sp,64
 962:	8082                	ret
 964:	74a2                	ld	s1,40(sp)
 966:	6a42                	ld	s4,16(sp)
 968:	6aa2                	ld	s5,8(sp)
 96a:	6b02                	ld	s6,0(sp)
 96c:	b7f5                	j	958 <malloc+0xdc>
