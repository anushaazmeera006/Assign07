#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  kexit(n);
  return 0; // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return kfork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return kwait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
  argint(1, &t);
  addr = myproc()->sz;

  if (t == SBRK_EAGER || n < 0) {
    if (growproc(n) < 0) {
      return -1;
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
      return -1;
    if (addr + n > TRAPFRAME)
      return -1;
    myproc()->sz += n;
  }
  return addr;
}

uint64
sys_pause(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if (n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  while (ticks - ticks0 < n) {
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    release(&tickslock);
    sleep();
    acquire(&tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kkill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
// Q1: read the user arguments and create a thread in the caller's address space.
uint64
sys_clone(void)
{
  uint64 fcn;
  uint64 arg;
  uint64 stack;

  argaddr(0, &fcn);
  argaddr(1, &arg);
  argaddr(2, &stack);
  return kclone(fcn, arg, stack);
}

// Q1: wait for one child thread to exit and reclaim its kernel resources.
uint64
sys_join(void)
{
  return kjoin();
}
// Q2: initialize a semaphore identified by sem_id.
uint64
sys_sem_init(void)
{
  int sem_id;
  int value;

  argint(0, &sem_id);
  argint(1, &value);
  return ksem_init(sem_id, value);
}

// Q2: wait until one semaphore permit is available.
uint64
sys_sem_wait(void)
{
  int sem_id;

  argint(0, &sem_id);
  return ksem_wait(sem_id);
}

// Q2: release one semaphore permit.
uint64
sys_sem_signal(void)
{
  int sem_id;

  argint(0, &sem_id);
  return ksem_signal(sem_id);
}
// Q4: Set process priority system call.
uint64
sys_set_priority(void)
{
  int pid, priority;

  argint(0, &pid);
  argint(1, &priority);

  return set_priority_by_pid(pid, priority);
}
// Q4: Get process priority system call.
uint64
sys_get_priority(void)
{
  int pid;

  argint(0, &pid);

  return get_priority_by_pid(pid);
}
