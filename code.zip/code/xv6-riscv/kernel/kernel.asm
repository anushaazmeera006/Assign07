
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	0000b117          	auipc	sp,0xb
    80000004:	6a813103          	ld	sp,1704(sp) # 8000b6a8 <_GLOBAL_OFFSET_TABLE_+0x8>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	042000ef          	jal	80000058 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    80000024:	30a027f3          	csrr	a5,0x30a
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | MENVCFG_STCE);
    80000028:	577d                	li	a4,-1
    8000002a:	177e                	slli	a4,a4,0x3f
    8000002c:	8fd9                	or	a5,a5,a4

static inline void
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    8000002e:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r"(x));
    80000032:	306027f3          	csrr	a5,mcounteren

  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000036:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r"(x));
    8000003a:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r"(x));
    8000003e:	c01027f3          	rdtime	a5

  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    80000042:	000f4737          	lui	a4,0xf4
    80000046:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    8000004a:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    8000004c:	14d79073          	csrw	stimecmp,a5
}
    80000050:	60a2                	ld	ra,8(sp)
    80000052:	6402                	ld	s0,0(sp)
    80000054:	0141                	addi	sp,sp,16
    80000056:	8082                	ret

0000000080000058 <start>:
{
    80000058:	1141                	addi	sp,sp,-16
    8000005a:	e406                	sd	ra,8(sp)
    8000005c:	e022                	sd	s0,0(sp)
    8000005e:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r"(x));
    80000060:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000064:	7779                	lui	a4,0xffffe
    80000066:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffd9697>
    8000006a:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    8000006c:	6705                	lui	a4,0x1
    8000006e:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    80000072:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r"(x));
    80000074:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r"(x));
    80000078:	00001797          	auipc	a5,0x1
    8000007c:	de678793          	addi	a5,a5,-538 # 80000e5e <main>
    80000080:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r"(x));
    80000084:	4781                	li	a5,0
    80000086:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r"(x));
    8000008a:	67c1                	lui	a5,0x10
    8000008c:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000008e:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r"(x));
    80000092:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r"(x));
    80000096:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    8000009a:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r"(x));
    8000009e:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r"(x));
    800000a2:	57fd                	li	a5,-1
    800000a4:	83a9                	srli	a5,a5,0xa
    800000a6:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r"(x));
    800000aa:	47bd                	li	a5,15
    800000ac:	3a079073          	csrw	pmpcfg0,a5
  asm volatile("csrr %0, 0x30a" : "=r"(x));
    800000b0:	30a027f3          	csrr	a5,0x30a
  w_menvcfg(r_menvcfg() | MENVCFG_ADUE);
    800000b4:	4705                	li	a4,1
    800000b6:	1776                	slli	a4,a4,0x3d
    800000b8:	8fd9                	or	a5,a5,a4
  asm volatile("csrw 0x30a, %0" : : "r"(x));
    800000ba:	30a79073          	csrw	0x30a,a5
  timerinit();
    800000be:	f5fff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r"(x));
    800000c2:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c6:	2781                	sext.w	a5,a5
}

static inline void
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r"(x));
    800000c8:	823e                	mv	tp,a5
  asm volatile("mret");
    800000ca:	30200073          	mret
}
    800000ce:	60a2                	ld	ra,8(sp)
    800000d0:	6402                	ld	s0,0(sp)
    800000d2:	0141                	addi	sp,sp,16
    800000d4:	8082                	ret

00000000800000d6 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d6:	7119                	addi	sp,sp,-128
    800000d8:	fc86                	sd	ra,120(sp)
    800000da:	f8a2                	sd	s0,112(sp)
    800000dc:	f4a6                	sd	s1,104(sp)
    800000de:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while (i < n) {
    800000e0:	06c05b63          	blez	a2,80000156 <consolewrite+0x80>
    800000e4:	f0ca                	sd	s2,96(sp)
    800000e6:	ecce                	sd	s3,88(sp)
    800000e8:	e8d2                	sd	s4,80(sp)
    800000ea:	e4d6                	sd	s5,72(sp)
    800000ec:	e0da                	sd	s6,64(sp)
    800000ee:	fc5e                	sd	s7,56(sp)
    800000f0:	f862                	sd	s8,48(sp)
    800000f2:	f466                	sd	s9,40(sp)
    800000f4:	f06a                	sd	s10,32(sp)
    800000f6:	8b2a                	mv	s6,a0
    800000f8:	8bae                	mv	s7,a1
    800000fa:	8a32                	mv	s4,a2
  int i = 0;
    800000fc:	4481                	li	s1,0
    int nn = sizeof(buf);
    if (nn > n - i)
    800000fe:	02000c93          	li	s9,32
    80000102:	02000d13          	li	s10,32
      nn = n - i;
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000106:	f8040a93          	addi	s5,s0,-128
    8000010a:	5c7d                	li	s8,-1
    8000010c:	a025                	j	80000134 <consolewrite+0x5e>
    if (nn > n - i)
    8000010e:	0009099b          	sext.w	s3,s2
    if (either_copyin(buf, user_src, src + i, nn) == -1)
    80000112:	86ce                	mv	a3,s3
    80000114:	01748633          	add	a2,s1,s7
    80000118:	85da                	mv	a1,s6
    8000011a:	8556                	mv	a0,s5
    8000011c:	638020ef          	jal	80002754 <either_copyin>
    80000120:	03850d63          	beq	a0,s8,8000015a <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000124:	85ce                	mv	a1,s3
    80000126:	8556                	mv	a0,s5
    80000128:	7c2000ef          	jal	800008ea <uartwrite>
    i += nn;
    8000012c:	009904bb          	addw	s1,s2,s1
  while (i < n) {
    80000130:	0144d963          	bge	s1,s4,80000142 <consolewrite+0x6c>
    if (nn > n - i)
    80000134:	409a07bb          	subw	a5,s4,s1
    80000138:	893e                	mv	s2,a5
    8000013a:	fcfcdae3          	bge	s9,a5,8000010e <consolewrite+0x38>
    8000013e:	896a                	mv	s2,s10
    80000140:	b7f9                	j	8000010e <consolewrite+0x38>
    80000142:	7906                	ld	s2,96(sp)
    80000144:	69e6                	ld	s3,88(sp)
    80000146:	6a46                	ld	s4,80(sp)
    80000148:	6aa6                	ld	s5,72(sp)
    8000014a:	6b06                	ld	s6,64(sp)
    8000014c:	7be2                	ld	s7,56(sp)
    8000014e:	7c42                	ld	s8,48(sp)
    80000150:	7ca2                	ld	s9,40(sp)
    80000152:	7d02                	ld	s10,32(sp)
    80000154:	a821                	j	8000016c <consolewrite+0x96>
  int i = 0;
    80000156:	4481                	li	s1,0
    80000158:	a811                	j	8000016c <consolewrite+0x96>
    8000015a:	7906                	ld	s2,96(sp)
    8000015c:	69e6                	ld	s3,88(sp)
    8000015e:	6a46                	ld	s4,80(sp)
    80000160:	6aa6                	ld	s5,72(sp)
    80000162:	6b06                	ld	s6,64(sp)
    80000164:	7be2                	ld	s7,56(sp)
    80000166:	7c42                	ld	s8,48(sp)
    80000168:	7ca2                	ld	s9,40(sp)
    8000016a:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016c:	8526                	mv	a0,s1
    8000016e:	70e6                	ld	ra,120(sp)
    80000170:	7446                	ld	s0,112(sp)
    80000172:	74a6                	ld	s1,104(sp)
    80000174:	6109                	addi	sp,sp,128
    80000176:	8082                	ret

0000000080000178 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000178:	711d                	addi	sp,sp,-96
    8000017a:	ec86                	sd	ra,88(sp)
    8000017c:	e8a2                	sd	s0,80(sp)
    8000017e:	e4a6                	sd	s1,72(sp)
    80000180:	e0ca                	sd	s2,64(sp)
    80000182:	fc4e                	sd	s3,56(sp)
    80000184:	f852                	sd	s4,48(sp)
    80000186:	f05a                	sd	s6,32(sp)
    80000188:	ec5e                	sd	s7,24(sp)
    8000018a:	1080                	addi	s0,sp,96
    8000018c:	8b2a                	mv	s6,a0
    8000018e:	8a2e                	mv	s4,a1
    80000190:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000192:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000194:	00013517          	auipc	a0,0x13
    80000198:	55c50513          	addi	a0,a0,1372 # 800136f0 <cons>
    8000019c:	24d000ef          	jal	80000be8 <acquire>
  while (n > 0) {
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while (cons.r == cons.w) {
    800001a0:	00013497          	auipc	s1,0x13
    800001a4:	55048493          	addi	s1,s1,1360 # 800136f0 <cons>
      if (killed(myproc())) {
        release(&cons.lock);
        return -1;
      }
      sleep_prepare(&cons.r);
    800001a8:	00013917          	auipc	s2,0x13
    800001ac:	5e090913          	addi	s2,s2,1504 # 80013788 <cons+0x98>
  while (n > 0) {
    800001b0:	0d305263          	blez	s3,80000274 <consoleread+0xfc>
    while (cons.r == cons.w) {
    800001b4:	0984a783          	lw	a5,152(s1)
    800001b8:	09c4a703          	lw	a4,156(s1)
    800001bc:	0af71763          	bne	a4,a5,8000026a <consoleread+0xf2>
      if (killed(myproc())) {
    800001c0:	734010ef          	jal	800018f4 <myproc>
    800001c4:	266020ef          	jal	8000242a <killed>
    800001c8:	e925                	bnez	a0,80000238 <consoleread+0xc0>
      sleep_prepare(&cons.r);
    800001ca:	854a                	mv	a0,s2
    800001cc:	0ac020ef          	jal	80002278 <sleep_prepare>
      release(&cons.lock);
    800001d0:	8526                	mv	a0,s1
    800001d2:	29f000ef          	jal	80000c70 <release>
      sleep();
    800001d6:	0de020ef          	jal	800022b4 <sleep>
      acquire(&cons.lock);
    800001da:	8526                	mv	a0,s1
    800001dc:	20d000ef          	jal	80000be8 <acquire>
    while (cons.r == cons.w) {
    800001e0:	0984a783          	lw	a5,152(s1)
    800001e4:	09c4a703          	lw	a4,156(s1)
    800001e8:	fcf70ce3          	beq	a4,a5,800001c0 <consoleread+0x48>
    800001ec:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001ee:	00013717          	auipc	a4,0x13
    800001f2:	50270713          	addi	a4,a4,1282 # 800136f0 <cons>
    800001f6:	0017869b          	addiw	a3,a5,1
    800001fa:	08d72c23          	sw	a3,152(a4)
    800001fe:	07f7f693          	andi	a3,a5,127
    80000202:	9736                	add	a4,a4,a3
    80000204:	01874703          	lbu	a4,24(a4)
    80000208:	00070a9b          	sext.w	s5,a4

    if (c == C('D')) { // end-of-file
    8000020c:	4691                	li	a3,4
    8000020e:	04da8663          	beq	s5,a3,8000025a <consoleread+0xe2>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000212:	fae407a3          	sb	a4,-81(s0)
    if (either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000216:	4685                	li	a3,1
    80000218:	faf40613          	addi	a2,s0,-81
    8000021c:	85d2                	mv	a1,s4
    8000021e:	855a                	mv	a0,s6
    80000220:	4e8020ef          	jal	80002708 <either_copyout>
    80000224:	57fd                	li	a5,-1
    80000226:	04f50663          	beq	a0,a5,80000272 <consoleread+0xfa>
      break;

    dst++;
    8000022a:	0a05                	addi	s4,s4,1
    --n;
    8000022c:	39fd                	addiw	s3,s3,-1

    if (c == '\n') {
    8000022e:	47a9                	li	a5,10
    80000230:	04fa8b63          	beq	s5,a5,80000286 <consoleread+0x10e>
    80000234:	7aa2                	ld	s5,40(sp)
    80000236:	bfad                	j	800001b0 <consoleread+0x38>
        release(&cons.lock);
    80000238:	00013517          	auipc	a0,0x13
    8000023c:	4b850513          	addi	a0,a0,1208 # 800136f0 <cons>
    80000240:	231000ef          	jal	80000c70 <release>
        return -1;
    80000244:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000246:	60e6                	ld	ra,88(sp)
    80000248:	6446                	ld	s0,80(sp)
    8000024a:	64a6                	ld	s1,72(sp)
    8000024c:	6906                	ld	s2,64(sp)
    8000024e:	79e2                	ld	s3,56(sp)
    80000250:	7a42                	ld	s4,48(sp)
    80000252:	7b02                	ld	s6,32(sp)
    80000254:	6be2                	ld	s7,24(sp)
    80000256:	6125                	addi	sp,sp,96
    80000258:	8082                	ret
      if (n < target) {
    8000025a:	0179fa63          	bgeu	s3,s7,8000026e <consoleread+0xf6>
        cons.r--;
    8000025e:	00013717          	auipc	a4,0x13
    80000262:	52f72523          	sw	a5,1322(a4) # 80013788 <cons+0x98>
    80000266:	7aa2                	ld	s5,40(sp)
    80000268:	a031                	j	80000274 <consoleread+0xfc>
    8000026a:	f456                	sd	s5,40(sp)
    8000026c:	b749                	j	800001ee <consoleread+0x76>
    8000026e:	7aa2                	ld	s5,40(sp)
    80000270:	a011                	j	80000274 <consoleread+0xfc>
    80000272:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000274:	00013517          	auipc	a0,0x13
    80000278:	47c50513          	addi	a0,a0,1148 # 800136f0 <cons>
    8000027c:	1f5000ef          	jal	80000c70 <release>
  return target - n;
    80000280:	413b853b          	subw	a0,s7,s3
    80000284:	b7c9                	j	80000246 <consoleread+0xce>
    80000286:	7aa2                	ld	s5,40(sp)
    80000288:	b7f5                	j	80000274 <consoleread+0xfc>

000000008000028a <consputc>:
{
    8000028a:	1141                	addi	sp,sp,-16
    8000028c:	e406                	sd	ra,8(sp)
    8000028e:	e022                	sd	s0,0(sp)
    80000290:	0800                	addi	s0,sp,16
  if (c == BACKSPACE) {
    80000292:	10000793          	li	a5,256
    80000296:	00f50863          	beq	a0,a5,800002a6 <consputc+0x1c>
    uartputc_sync(c);
    8000029a:	6d6000ef          	jal	80000970 <uartputc_sync>
}
    8000029e:	60a2                	ld	ra,8(sp)
    800002a0:	6402                	ld	s0,0(sp)
    800002a2:	0141                	addi	sp,sp,16
    800002a4:	8082                	ret
    uartputc_sync('\b');
    800002a6:	4521                	li	a0,8
    800002a8:	6c8000ef          	jal	80000970 <uartputc_sync>
    uartputc_sync(' ');
    800002ac:	02000513          	li	a0,32
    800002b0:	6c0000ef          	jal	80000970 <uartputc_sync>
    uartputc_sync('\b');
    800002b4:	4521                	li	a0,8
    800002b6:	6ba000ef          	jal	80000970 <uartputc_sync>
    800002ba:	b7d5                	j	8000029e <consputc+0x14>

00000000800002bc <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002bc:	1101                	addi	sp,sp,-32
    800002be:	ec06                	sd	ra,24(sp)
    800002c0:	e822                	sd	s0,16(sp)
    800002c2:	e426                	sd	s1,8(sp)
    800002c4:	1000                	addi	s0,sp,32
    800002c6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002c8:	00013517          	auipc	a0,0x13
    800002cc:	42850513          	addi	a0,a0,1064 # 800136f0 <cons>
    800002d0:	119000ef          	jal	80000be8 <acquire>

  switch (c) {
    800002d4:	47d5                	li	a5,21
    800002d6:	08f48d63          	beq	s1,a5,80000370 <consoleintr+0xb4>
    800002da:	0297c563          	blt	a5,s1,80000304 <consoleintr+0x48>
    800002de:	47a1                	li	a5,8
    800002e0:	0ef48263          	beq	s1,a5,800003c4 <consoleintr+0x108>
    800002e4:	47c1                	li	a5,16
    800002e6:	10f49363          	bne	s1,a5,800003ec <consoleintr+0x130>
  case C('P'): // Print process list.
    procdump();
    800002ea:	4b6020ef          	jal	800027a0 <procdump>
      }
    }
    break;
  }

  release(&cons.lock);
    800002ee:	00013517          	auipc	a0,0x13
    800002f2:	40250513          	addi	a0,a0,1026 # 800136f0 <cons>
    800002f6:	17b000ef          	jal	80000c70 <release>
}
    800002fa:	60e2                	ld	ra,24(sp)
    800002fc:	6442                	ld	s0,16(sp)
    800002fe:	64a2                	ld	s1,8(sp)
    80000300:	6105                	addi	sp,sp,32
    80000302:	8082                	ret
  switch (c) {
    80000304:	07f00793          	li	a5,127
    80000308:	0af48e63          	beq	s1,a5,800003c4 <consoleintr+0x108>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    8000030c:	00013717          	auipc	a4,0x13
    80000310:	3e470713          	addi	a4,a4,996 # 800136f0 <cons>
    80000314:	0a072783          	lw	a5,160(a4)
    80000318:	09872703          	lw	a4,152(a4)
    8000031c:	9f99                	subw	a5,a5,a4
    8000031e:	07f00713          	li	a4,127
    80000322:	fcf766e3          	bltu	a4,a5,800002ee <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000326:	47b5                	li	a5,13
    80000328:	0cf48563          	beq	s1,a5,800003f2 <consoleintr+0x136>
      consputc(c);
    8000032c:	8526                	mv	a0,s1
    8000032e:	f5dff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000332:	00013717          	auipc	a4,0x13
    80000336:	3be70713          	addi	a4,a4,958 # 800136f0 <cons>
    8000033a:	0a072683          	lw	a3,160(a4)
    8000033e:	0016879b          	addiw	a5,a3,1
    80000342:	863e                	mv	a2,a5
    80000344:	0af72023          	sw	a5,160(a4)
    80000348:	07f6f693          	andi	a3,a3,127
    8000034c:	9736                	add	a4,a4,a3
    8000034e:	00970c23          	sb	s1,24(a4)
      if (c == '\n' || c == C('D') || cons.e - cons.r == INPUT_BUF_SIZE) {
    80000352:	ff648713          	addi	a4,s1,-10
    80000356:	c371                	beqz	a4,8000041a <consoleintr+0x15e>
    80000358:	14f1                	addi	s1,s1,-4
    8000035a:	c0e1                	beqz	s1,8000041a <consoleintr+0x15e>
    8000035c:	00013717          	auipc	a4,0x13
    80000360:	42c72703          	lw	a4,1068(a4) # 80013788 <cons+0x98>
    80000364:	9f99                	subw	a5,a5,a4
    80000366:	08000713          	li	a4,128
    8000036a:	f8e792e3          	bne	a5,a4,800002ee <consoleintr+0x32>
    8000036e:	a075                	j	8000041a <consoleintr+0x15e>
    80000370:	e04a                	sd	s2,0(sp)
    while (cons.e != cons.w &&
    80000372:	00013717          	auipc	a4,0x13
    80000376:	37e70713          	addi	a4,a4,894 # 800136f0 <cons>
    8000037a:	0a072783          	lw	a5,160(a4)
    8000037e:	09c72703          	lw	a4,156(a4)
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000382:	00013497          	auipc	s1,0x13
    80000386:	36e48493          	addi	s1,s1,878 # 800136f0 <cons>
    while (cons.e != cons.w &&
    8000038a:	4929                	li	s2,10
    8000038c:	02f70863          	beq	a4,a5,800003bc <consoleintr+0x100>
           cons.buf[(cons.e - 1) % INPUT_BUF_SIZE] != '\n') {
    80000390:	37fd                	addiw	a5,a5,-1
    80000392:	07f7f713          	andi	a4,a5,127
    80000396:	9726                	add	a4,a4,s1
    while (cons.e != cons.w &&
    80000398:	01874703          	lbu	a4,24(a4)
    8000039c:	03270263          	beq	a4,s2,800003c0 <consoleintr+0x104>
      cons.e--;
    800003a0:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    800003a4:	10000513          	li	a0,256
    800003a8:	ee3ff0ef          	jal	8000028a <consputc>
    while (cons.e != cons.w &&
    800003ac:	0a04a783          	lw	a5,160(s1)
    800003b0:	09c4a703          	lw	a4,156(s1)
    800003b4:	fcf71ee3          	bne	a4,a5,80000390 <consoleintr+0xd4>
    800003b8:	6902                	ld	s2,0(sp)
    800003ba:	bf15                	j	800002ee <consoleintr+0x32>
    800003bc:	6902                	ld	s2,0(sp)
    800003be:	bf05                	j	800002ee <consoleintr+0x32>
    800003c0:	6902                	ld	s2,0(sp)
    800003c2:	b735                	j	800002ee <consoleintr+0x32>
    if (cons.e != cons.w) {
    800003c4:	00013717          	auipc	a4,0x13
    800003c8:	32c70713          	addi	a4,a4,812 # 800136f0 <cons>
    800003cc:	0a072783          	lw	a5,160(a4)
    800003d0:	09c72703          	lw	a4,156(a4)
    800003d4:	f0f70de3          	beq	a4,a5,800002ee <consoleintr+0x32>
      cons.e--;
    800003d8:	37fd                	addiw	a5,a5,-1
    800003da:	00013717          	auipc	a4,0x13
    800003de:	3af72b23          	sw	a5,950(a4) # 80013790 <cons+0xa0>
      consputc(BACKSPACE);
    800003e2:	10000513          	li	a0,256
    800003e6:	ea5ff0ef          	jal	8000028a <consputc>
    800003ea:	b711                	j	800002ee <consoleintr+0x32>
    if (c != 0 && cons.e - cons.r < INPUT_BUF_SIZE) {
    800003ec:	f00481e3          	beqz	s1,800002ee <consoleintr+0x32>
    800003f0:	bf31                	j	8000030c <consoleintr+0x50>
      consputc(c);
    800003f2:	4529                	li	a0,10
    800003f4:	e97ff0ef          	jal	8000028a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003f8:	00013797          	auipc	a5,0x13
    800003fc:	2f878793          	addi	a5,a5,760 # 800136f0 <cons>
    80000400:	0a07a703          	lw	a4,160(a5)
    80000404:	0017069b          	addiw	a3,a4,1
    80000408:	8636                	mv	a2,a3
    8000040a:	0ad7a023          	sw	a3,160(a5)
    8000040e:	07f77713          	andi	a4,a4,127
    80000412:	97ba                	add	a5,a5,a4
    80000414:	4729                	li	a4,10
    80000416:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000041a:	00013797          	auipc	a5,0x13
    8000041e:	36c7a923          	sw	a2,882(a5) # 8001378c <cons+0x9c>
        wakeup(&cons.r);
    80000422:	00013517          	auipc	a0,0x13
    80000426:	36650513          	addi	a0,a0,870 # 80013788 <cons+0x98>
    8000042a:	6bb010ef          	jal	800022e4 <wakeup>
    8000042e:	b5c1                	j	800002ee <consoleintr+0x32>

0000000080000430 <consoleinit>:

void
consoleinit(void)
{
    80000430:	1141                	addi	sp,sp,-16
    80000432:	e406                	sd	ra,8(sp)
    80000434:	e022                	sd	s0,0(sp)
    80000436:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000438:	00008597          	auipc	a1,0x8
    8000043c:	bc858593          	addi	a1,a1,-1080 # 80008000 <etext>
    80000440:	00013517          	auipc	a0,0x13
    80000444:	2b050513          	addi	a0,a0,688 # 800136f0 <cons>
    80000448:	720000ef          	jal	80000b68 <initlock>

  uartinit();
    8000044c:	448000ef          	jal	80000894 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000450:	00024797          	auipc	a5,0x24
    80000454:	b8078793          	addi	a5,a5,-1152 # 80023fd0 <devsw>
    80000458:	00000717          	auipc	a4,0x0
    8000045c:	d2070713          	addi	a4,a4,-736 # 80000178 <consoleread>
    80000460:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000462:	00000717          	auipc	a4,0x0
    80000466:	c7470713          	addi	a4,a4,-908 # 800000d6 <consolewrite>
    8000046a:	ef98                	sd	a4,24(a5)
}
    8000046c:	60a2                	ld	ra,8(sp)
    8000046e:	6402                	ld	s0,0(sp)
    80000470:	0141                	addi	sp,sp,16
    80000472:	8082                	ret

0000000080000474 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000474:	7139                	addi	sp,sp,-64
    80000476:	fc06                	sd	ra,56(sp)
    80000478:	f822                	sd	s0,48(sp)
    8000047a:	f04a                	sd	s2,32(sp)
    8000047c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if (sign && (sign = (xx < 0)))
    8000047e:	c219                	beqz	a2,80000484 <printint+0x10>
    80000480:	08054163          	bltz	a0,80000502 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80000484:	4301                	li	t1,0

  i = 0;
    80000486:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000048a:	86ca                	mv	a3,s2
  i = 0;
    8000048c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    8000048e:	00008817          	auipc	a6,0x8
    80000492:	2f280813          	addi	a6,a6,754 # 80008780 <digits>
    80000496:	88ba                	mv	a7,a4
    80000498:	0017061b          	addiw	a2,a4,1
    8000049c:	8732                	mv	a4,a2
    8000049e:	02b577b3          	remu	a5,a0,a1
    800004a2:	97c2                	add	a5,a5,a6
    800004a4:	0007c783          	lbu	a5,0(a5)
    800004a8:	00f68023          	sb	a5,0(a3)
  } while ((x /= base) != 0);
    800004ac:	87aa                	mv	a5,a0
    800004ae:	02b55533          	divu	a0,a0,a1
    800004b2:	0685                	addi	a3,a3,1
    800004b4:	feb7f1e3          	bgeu	a5,a1,80000496 <printint+0x22>

  if (sign)
    800004b8:	00030c63          	beqz	t1,800004d0 <printint+0x5c>
    buf[i++] = '-';
    800004bc:	fe060793          	addi	a5,a2,-32
    800004c0:	00878633          	add	a2,a5,s0
    800004c4:	02d00793          	li	a5,45
    800004c8:	fef60423          	sb	a5,-24(a2)
    800004cc:	0028871b          	addiw	a4,a7,2

  while (--i >= 0)
    800004d0:	02e05463          	blez	a4,800004f8 <printint+0x84>
    800004d4:	f426                	sd	s1,40(sp)
    800004d6:	377d                	addiw	a4,a4,-1
    800004d8:	00e904b3          	add	s1,s2,a4
    800004dc:	197d                	addi	s2,s2,-1
    800004de:	993a                	add	s2,s2,a4
    800004e0:	1702                	slli	a4,a4,0x20
    800004e2:	9301                	srli	a4,a4,0x20
    800004e4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004e8:	0004c503          	lbu	a0,0(s1)
    800004ec:	d9fff0ef          	jal	8000028a <consputc>
  while (--i >= 0)
    800004f0:	14fd                	addi	s1,s1,-1
    800004f2:	ff249be3          	bne	s1,s2,800004e8 <printint+0x74>
    800004f6:	74a2                	ld	s1,40(sp)
}
    800004f8:	70e2                	ld	ra,56(sp)
    800004fa:	7442                	ld	s0,48(sp)
    800004fc:	7902                	ld	s2,32(sp)
    800004fe:	6121                	addi	sp,sp,64
    80000500:	8082                	ret
    x = -xx;
    80000502:	40a00533          	neg	a0,a0
  if (sign && (sign = (xx < 0)))
    80000506:	4305                	li	t1,1
    x = -xx;
    80000508:	bfbd                	j	80000486 <printint+0x12>

000000008000050a <printk>:
}

// Print to the console.
int
printk(char *fmt, ...)
{
    8000050a:	7131                	addi	sp,sp,-192
    8000050c:	fc86                	sd	ra,120(sp)
    8000050e:	f8a2                	sd	s0,112(sp)
    80000510:	f0ca                	sd	s2,96(sp)
    80000512:	0100                	addi	s0,sp,128
    80000514:	892a                	mv	s2,a0
    80000516:	e40c                	sd	a1,8(s0)
    80000518:	e810                	sd	a2,16(s0)
    8000051a:	ec14                	sd	a3,24(s0)
    8000051c:	f018                	sd	a4,32(s0)
    8000051e:	f41c                	sd	a5,40(s0)
    80000520:	03043823          	sd	a6,48(s0)
    80000524:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if (panicking == 0)
    80000528:	0000b797          	auipc	a5,0xb
    8000052c:	19c7a783          	lw	a5,412(a5) # 8000b6c4 <panicking>
    80000530:	cf9d                	beqz	a5,8000056e <printk+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000532:	00840793          	addi	a5,s0,8
    80000536:	f8f43423          	sd	a5,-120(s0)
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    8000053a:	00094503          	lbu	a0,0(s2)
    8000053e:	22050663          	beqz	a0,8000076a <printk+0x260>
    80000542:	f4a6                	sd	s1,104(sp)
    80000544:	ecce                	sd	s3,88(sp)
    80000546:	e8d2                	sd	s4,80(sp)
    80000548:	e4d6                	sd	s5,72(sp)
    8000054a:	e0da                	sd	s6,64(sp)
    8000054c:	fc5e                	sd	s7,56(sp)
    8000054e:	f862                	sd	s8,48(sp)
    80000550:	f06a                	sd	s10,32(sp)
    80000552:	ec6e                	sd	s11,24(sp)
    80000554:	4a01                	li	s4,0
    if (cx != '%') {
    80000556:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if (c0 == 'u') {
    8000055a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if (c0 == 'x') {
    8000055e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if (c0 == 'p') {
    80000562:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000566:	4b29                	li	s6,10
    if (c0 == 'd') {
    80000568:	06400b93          	li	s7,100
    8000056c:	a015                	j	80000590 <printk+0x86>
    acquire(&pr.lock);
    8000056e:	00013517          	auipc	a0,0x13
    80000572:	22a50513          	addi	a0,a0,554 # 80013798 <pr>
    80000576:	672000ef          	jal	80000be8 <acquire>
    8000057a:	bf65                	j	80000532 <printk+0x28>
      consputc(cx);
    8000057c:	d0fff0ef          	jal	8000028a <consputc>
      continue;
    80000580:	84d2                	mv	s1,s4
  for (i = 0; (cx = fmt[i] & 0xff) != 0; i++) {
    80000582:	2485                	addiw	s1,s1,1
    80000584:	8a26                	mv	s4,s1
    80000586:	94ca                	add	s1,s1,s2
    80000588:	0004c503          	lbu	a0,0(s1)
    8000058c:	1c050663          	beqz	a0,80000758 <printk+0x24e>
    if (cx != '%') {
    80000590:	ff3516e3          	bne	a0,s3,8000057c <printk+0x72>
    i++;
    80000594:	001a079b          	addiw	a5,s4,1
    80000598:	84be                	mv	s1,a5
    c0 = fmt[i + 0] & 0xff;
    8000059a:	00f90733          	add	a4,s2,a5
    8000059e:	00074a83          	lbu	s5,0(a4)
    if (c0)
    800005a2:	200a8963          	beqz	s5,800007b4 <printk+0x2aa>
      c1 = fmt[i + 1] & 0xff;
    800005a6:	00174683          	lbu	a3,1(a4)
    if (c1)
    800005aa:	1e068c63          	beqz	a3,800007a2 <printk+0x298>
    if (c0 == 'd') {
    800005ae:	037a8863          	beq	s5,s7,800005de <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800005b2:	f94a8713          	addi	a4,s5,-108
    800005b6:	00173713          	seqz	a4,a4
    800005ba:	f9c68613          	addi	a2,a3,-100
    800005be:	ee05                	bnez	a2,800005f6 <printk+0xec>
    800005c0:	cb1d                	beqz	a4,800005f6 <printk+0xec>
      printint(va_arg(ap, uint64), 10, 1);
    800005c2:	f8843783          	ld	a5,-120(s0)
    800005c6:	00878713          	addi	a4,a5,8
    800005ca:	f8e43423          	sd	a4,-120(s0)
    800005ce:	4605                	li	a2,1
    800005d0:	85da                	mv	a1,s6
    800005d2:	6388                	ld	a0,0(a5)
    800005d4:	ea1ff0ef          	jal	80000474 <printint>
      i += 1;
    800005d8:	002a049b          	addiw	s1,s4,2
    800005dc:	b75d                	j	80000582 <printk+0x78>
      printint(va_arg(ap, int), 10, 1);
    800005de:	f8843783          	ld	a5,-120(s0)
    800005e2:	00878713          	addi	a4,a5,8
    800005e6:	f8e43423          	sd	a4,-120(s0)
    800005ea:	4605                	li	a2,1
    800005ec:	85da                	mv	a1,s6
    800005ee:	4388                	lw	a0,0(a5)
    800005f0:	e85ff0ef          	jal	80000474 <printint>
    800005f4:	b779                	j	80000582 <printk+0x78>
      c2 = fmt[i + 2] & 0xff;
    800005f6:	97ca                	add	a5,a5,s2
    800005f8:	8636                	mv	a2,a3
    800005fa:	0027c683          	lbu	a3,2(a5)
    800005fe:	a2c9                	j	800007c0 <printk+0x2b6>
      printint(va_arg(ap, uint64), 10, 1);
    80000600:	f8843783          	ld	a5,-120(s0)
    80000604:	00878713          	addi	a4,a5,8
    80000608:	f8e43423          	sd	a4,-120(s0)
    8000060c:	4605                	li	a2,1
    8000060e:	45a9                	li	a1,10
    80000610:	6388                	ld	a0,0(a5)
    80000612:	e63ff0ef          	jal	80000474 <printint>
      i += 2;
    80000616:	003a049b          	addiw	s1,s4,3
    8000061a:	b7a5                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint32), 10, 0);
    8000061c:	f8843783          	ld	a5,-120(s0)
    80000620:	00878713          	addi	a4,a5,8
    80000624:	f8e43423          	sd	a4,-120(s0)
    80000628:	4601                	li	a2,0
    8000062a:	85da                	mv	a1,s6
    8000062c:	0007e503          	lwu	a0,0(a5)
    80000630:	e45ff0ef          	jal	80000474 <printint>
    80000634:	b7b9                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000636:	f8843783          	ld	a5,-120(s0)
    8000063a:	00878713          	addi	a4,a5,8
    8000063e:	f8e43423          	sd	a4,-120(s0)
    80000642:	4601                	li	a2,0
    80000644:	85da                	mv	a1,s6
    80000646:	6388                	ld	a0,0(a5)
    80000648:	e2dff0ef          	jal	80000474 <printint>
      i += 1;
    8000064c:	002a049b          	addiw	s1,s4,2
    80000650:	bf0d                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000652:	f8843783          	ld	a5,-120(s0)
    80000656:	00878713          	addi	a4,a5,8
    8000065a:	f8e43423          	sd	a4,-120(s0)
    8000065e:	4601                	li	a2,0
    80000660:	45a9                	li	a1,10
    80000662:	6388                	ld	a0,0(a5)
    80000664:	e11ff0ef          	jal	80000474 <printint>
      i += 2;
    80000668:	003a049b          	addiw	s1,s4,3
    8000066c:	bf19                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint32), 16, 0);
    8000066e:	f8843783          	ld	a5,-120(s0)
    80000672:	00878713          	addi	a4,a5,8
    80000676:	f8e43423          	sd	a4,-120(s0)
    8000067a:	4601                	li	a2,0
    8000067c:	45c1                	li	a1,16
    8000067e:	0007e503          	lwu	a0,0(a5)
    80000682:	df3ff0ef          	jal	80000474 <printint>
    80000686:	bdf5                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000688:	f8843783          	ld	a5,-120(s0)
    8000068c:	00878713          	addi	a4,a5,8
    80000690:	f8e43423          	sd	a4,-120(s0)
    80000694:	45c1                	li	a1,16
    80000696:	6388                	ld	a0,0(a5)
    80000698:	dddff0ef          	jal	80000474 <printint>
      i += 1;
    8000069c:	002a049b          	addiw	s1,s4,2
    800006a0:	b5cd                	j	80000582 <printk+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    800006a2:	f8843783          	ld	a5,-120(s0)
    800006a6:	00878713          	addi	a4,a5,8
    800006aa:	f8e43423          	sd	a4,-120(s0)
    800006ae:	4601                	li	a2,0
    800006b0:	45c1                	li	a1,16
    800006b2:	6388                	ld	a0,0(a5)
    800006b4:	dc1ff0ef          	jal	80000474 <printint>
      i += 2;
    800006b8:	003a049b          	addiw	s1,s4,3
    800006bc:	b5d9                	j	80000582 <printk+0x78>
    800006be:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006c0:	f8843783          	ld	a5,-120(s0)
    800006c4:	00878713          	addi	a4,a5,8
    800006c8:	f8e43423          	sd	a4,-120(s0)
    800006cc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006d0:	03000513          	li	a0,48
    800006d4:	bb7ff0ef          	jal	8000028a <consputc>
  consputc('x');
    800006d8:	07800513          	li	a0,120
    800006dc:	bafff0ef          	jal	8000028a <consputc>
    800006e0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006e2:	00008c97          	auipc	s9,0x8
    800006e6:	09ec8c93          	addi	s9,s9,158 # 80008780 <digits>
    800006ea:	03cad793          	srli	a5,s5,0x3c
    800006ee:	97e6                	add	a5,a5,s9
    800006f0:	0007c503          	lbu	a0,0(a5)
    800006f4:	b97ff0ef          	jal	8000028a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006f8:	0a92                	slli	s5,s5,0x4
    800006fa:	3a7d                	addiw	s4,s4,-1
    800006fc:	fe0a17e3          	bnez	s4,800006ea <printk+0x1e0>
    80000700:	7ca2                	ld	s9,40(sp)
    80000702:	b541                	j	80000582 <printk+0x78>
    } else if (c0 == 'c') {
      consputc(va_arg(ap, uint));
    80000704:	f8843783          	ld	a5,-120(s0)
    80000708:	00878713          	addi	a4,a5,8
    8000070c:	f8e43423          	sd	a4,-120(s0)
    80000710:	4388                	lw	a0,0(a5)
    80000712:	b79ff0ef          	jal	8000028a <consputc>
    80000716:	b5b5                	j	80000582 <printk+0x78>
    } else if (c0 == 's') {
      if ((s = va_arg(ap, char *)) == 0)
    80000718:	f8843783          	ld	a5,-120(s0)
    8000071c:	00878713          	addi	a4,a5,8
    80000720:	f8e43423          	sd	a4,-120(s0)
    80000724:	0007ba03          	ld	s4,0(a5)
    80000728:	000a0d63          	beqz	s4,80000742 <printk+0x238>
        s = "(null)";
      for (; *s; s++)
    8000072c:	000a4503          	lbu	a0,0(s4)
    80000730:	e40509e3          	beqz	a0,80000582 <printk+0x78>
        consputc(*s);
    80000734:	b57ff0ef          	jal	8000028a <consputc>
      for (; *s; s++)
    80000738:	0a05                	addi	s4,s4,1
    8000073a:	000a4503          	lbu	a0,0(s4)
    8000073e:	f97d                	bnez	a0,80000734 <printk+0x22a>
    80000740:	b589                	j	80000582 <printk+0x78>
        s = "(null)";
    80000742:	00008a17          	auipc	s4,0x8
    80000746:	8c6a0a13          	addi	s4,s4,-1850 # 80008008 <etext+0x8>
      for (; *s; s++)
    8000074a:	02800513          	li	a0,40
    8000074e:	b7dd                	j	80000734 <printk+0x22a>
    } else if (c0 == '%') {
      consputc('%');
    80000750:	8556                	mv	a0,s5
    80000752:	b39ff0ef          	jal	8000028a <consputc>
    80000756:	b535                	j	80000582 <printk+0x78>
    80000758:	74a6                	ld	s1,104(sp)
    8000075a:	69e6                	ld	s3,88(sp)
    8000075c:	6a46                	ld	s4,80(sp)
    8000075e:	6aa6                	ld	s5,72(sp)
    80000760:	6b06                	ld	s6,64(sp)
    80000762:	7be2                	ld	s7,56(sp)
    80000764:	7c42                	ld	s8,48(sp)
    80000766:	7d02                	ld	s10,32(sp)
    80000768:	6de2                	ld	s11,24(sp)
      consputc(c0);
    }
  }
  va_end(ap);

  if (panicking == 0)
    8000076a:	0000b797          	auipc	a5,0xb
    8000076e:	f5a7a783          	lw	a5,-166(a5) # 8000b6c4 <panicking>
    80000772:	c38d                	beqz	a5,80000794 <printk+0x28a>
    release(&pr.lock);

  return 0;
}
    80000774:	4501                	li	a0,0
    80000776:	70e6                	ld	ra,120(sp)
    80000778:	7446                	ld	s0,112(sp)
    8000077a:	7906                	ld	s2,96(sp)
    8000077c:	6129                	addi	sp,sp,192
    8000077e:	8082                	ret
    80000780:	74a6                	ld	s1,104(sp)
    80000782:	69e6                	ld	s3,88(sp)
    80000784:	6a46                	ld	s4,80(sp)
    80000786:	6aa6                	ld	s5,72(sp)
    80000788:	6b06                	ld	s6,64(sp)
    8000078a:	7be2                	ld	s7,56(sp)
    8000078c:	7c42                	ld	s8,48(sp)
    8000078e:	7d02                	ld	s10,32(sp)
    80000790:	6de2                	ld	s11,24(sp)
    80000792:	bfe1                	j	8000076a <printk+0x260>
    release(&pr.lock);
    80000794:	00013517          	auipc	a0,0x13
    80000798:	00450513          	addi	a0,a0,4 # 80013798 <pr>
    8000079c:	4d4000ef          	jal	80000c70 <release>
  return 0;
    800007a0:	bfd1                	j	80000774 <printk+0x26a>
    if (c0 == 'd') {
    800007a2:	e37a8ee3          	beq	s5,s7,800005de <printk+0xd4>
    } else if (c0 == 'l' && c1 == 'd') {
    800007a6:	f94a8713          	addi	a4,s5,-108
    800007aa:	00173713          	seqz	a4,a4
    800007ae:	8636                	mv	a2,a3
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007b0:	4781                	li	a5,0
    800007b2:	a00d                	j	800007d4 <printk+0x2ca>
    } else if (c0 == 'l' && c1 == 'd') {
    800007b4:	f94a8713          	addi	a4,s5,-108
    800007b8:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    800007bc:	8656                	mv	a2,s5
    800007be:	86d6                	mv	a3,s5
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'd') {
    800007c0:	f9460793          	addi	a5,a2,-108
    800007c4:	0017b793          	seqz	a5,a5
    800007c8:	8ff9                	and	a5,a5,a4
    800007ca:	f9c68593          	addi	a1,a3,-100
    800007ce:	e199                	bnez	a1,800007d4 <printk+0x2ca>
    800007d0:	e20798e3          	bnez	a5,80000600 <printk+0xf6>
    } else if (c0 == 'u') {
    800007d4:	e58a84e3          	beq	s5,s8,8000061c <printk+0x112>
    } else if (c0 == 'l' && c1 == 'u') {
    800007d8:	f8b60593          	addi	a1,a2,-117
    800007dc:	e199                	bnez	a1,800007e2 <printk+0x2d8>
    800007de:	e4071ce3          	bnez	a4,80000636 <printk+0x12c>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'u') {
    800007e2:	f8b68593          	addi	a1,a3,-117
    800007e6:	e199                	bnez	a1,800007ec <printk+0x2e2>
    800007e8:	e60795e3          	bnez	a5,80000652 <printk+0x148>
    } else if (c0 == 'x') {
    800007ec:	e9aa81e3          	beq	s5,s10,8000066e <printk+0x164>
    } else if (c0 == 'l' && c1 == 'x') {
    800007f0:	f8860613          	addi	a2,a2,-120
    800007f4:	e219                	bnez	a2,800007fa <printk+0x2f0>
    800007f6:	e80719e3          	bnez	a4,80000688 <printk+0x17e>
    } else if (c0 == 'l' && c1 == 'l' && c2 == 'x') {
    800007fa:	f8868693          	addi	a3,a3,-120
    800007fe:	e299                	bnez	a3,80000804 <printk+0x2fa>
    80000800:	ea0791e3          	bnez	a5,800006a2 <printk+0x198>
    } else if (c0 == 'p') {
    80000804:	ebba8de3          	beq	s5,s11,800006be <printk+0x1b4>
    } else if (c0 == 'c') {
    80000808:	06300793          	li	a5,99
    8000080c:	eefa8ce3          	beq	s5,a5,80000704 <printk+0x1fa>
    } else if (c0 == 's') {
    80000810:	07300793          	li	a5,115
    80000814:	f0fa82e3          	beq	s5,a5,80000718 <printk+0x20e>
    } else if (c0 == '%') {
    80000818:	02500793          	li	a5,37
    8000081c:	f2fa8ae3          	beq	s5,a5,80000750 <printk+0x246>
    } else if (c0 == 0) {
    80000820:	f60a80e3          	beqz	s5,80000780 <printk+0x276>
      consputc('%');
    80000824:	02500513          	li	a0,37
    80000828:	a63ff0ef          	jal	8000028a <consputc>
      consputc(c0);
    8000082c:	8556                	mv	a0,s5
    8000082e:	a5dff0ef          	jal	8000028a <consputc>
    80000832:	bb81                	j	80000582 <printk+0x78>

0000000080000834 <panic>:

void
panic(char *s)
{
    80000834:	1101                	addi	sp,sp,-32
    80000836:	ec06                	sd	ra,24(sp)
    80000838:	e822                	sd	s0,16(sp)
    8000083a:	e426                	sd	s1,8(sp)
    8000083c:	e04a                	sd	s2,0(sp)
    8000083e:	1000                	addi	s0,sp,32
    80000840:	892a                	mv	s2,a0
  panicking = 1;
    80000842:	4485                	li	s1,1
    80000844:	0000b797          	auipc	a5,0xb
    80000848:	e897a023          	sw	s1,-384(a5) # 8000b6c4 <panicking>
  printk("panic: ");
    8000084c:	00007517          	auipc	a0,0x7
    80000850:	7cc50513          	addi	a0,a0,1996 # 80008018 <etext+0x18>
    80000854:	cb7ff0ef          	jal	8000050a <printk>
  printk("%s\n", s);
    80000858:	85ca                	mv	a1,s2
    8000085a:	00007517          	auipc	a0,0x7
    8000085e:	7c650513          	addi	a0,a0,1990 # 80008020 <etext+0x20>
    80000862:	ca9ff0ef          	jal	8000050a <printk>
  panicked = 1; // freeze uart output from other CPUs
    80000866:	0000b797          	auipc	a5,0xb
    8000086a:	e497ad23          	sw	s1,-422(a5) # 8000b6c0 <panicked>
  for (;;)
    8000086e:	a001                	j	8000086e <panic+0x3a>

0000000080000870 <printkinit>:
    ;
}

void
printkinit(void)
{
    80000870:	1141                	addi	sp,sp,-16
    80000872:	e406                	sd	ra,8(sp)
    80000874:	e022                	sd	s0,0(sp)
    80000876:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000878:	00007597          	auipc	a1,0x7
    8000087c:	7b058593          	addi	a1,a1,1968 # 80008028 <etext+0x28>
    80000880:	00013517          	auipc	a0,0x13
    80000884:	f1850513          	addi	a0,a0,-232 # 80013798 <pr>
    80000888:	2e0000ef          	jal	80000b68 <initlock>
}
    8000088c:	60a2                	ld	ra,8(sp)
    8000088e:	6402                	ld	s0,0(sp)
    80000890:	0141                	addi	sp,sp,16
    80000892:	8082                	ret

0000000080000894 <uartinit>:
extern volatile int panicking; // from printk.c
extern volatile int panicked;  // from printk.c

void
uartinit(void)
{
    80000894:	1141                	addi	sp,sp,-16
    80000896:	e406                	sd	ra,8(sp)
    80000898:	e022                	sd	s0,0(sp)
    8000089a:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000089c:	100007b7          	lui	a5,0x10000
    800008a0:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    800008a4:	10000737          	lui	a4,0x10000
    800008a8:	f8000693          	li	a3,-128
    800008ac:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008b0:	468d                	li	a3,3
    800008b2:	10000637          	lui	a2,0x10000
    800008b6:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008ba:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008be:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008c2:	8732                	mv	a4,a2
    800008c4:	461d                	li	a2,7
    800008c6:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008ca:	00d780a3          	sb	a3,1(a5)

  initsleeplock(&tx_lock, "uart");
    800008ce:	00007597          	auipc	a1,0x7
    800008d2:	76258593          	addi	a1,a1,1890 # 80008030 <etext+0x30>
    800008d6:	00013517          	auipc	a0,0x13
    800008da:	eda50513          	addi	a0,a0,-294 # 800137b0 <tx_lock>
    800008de:	6f5030ef          	jal	800047d2 <initsleeplock>
}
    800008e2:	60a2                	ld	ra,8(sp)
    800008e4:	6402                	ld	s0,0(sp)
    800008e6:	0141                	addi	sp,sp,16
    800008e8:	8082                	ret

00000000800008ea <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008ea:	7139                	addi	sp,sp,-64
    800008ec:	fc06                	sd	ra,56(sp)
    800008ee:	f822                	sd	s0,48(sp)
    800008f0:	f04a                	sd	s2,32(sp)
    800008f2:	e456                	sd	s5,8(sp)
    800008f4:	0080                	addi	s0,sp,64
    800008f6:	8aaa                	mv	s5,a0
    800008f8:	892e                	mv	s2,a1
  acquiresleep(&tx_lock);
    800008fa:	00013517          	auipc	a0,0x13
    800008fe:	eb650513          	addi	a0,a0,-330 # 800137b0 <tx_lock>
    80000902:	707030ef          	jal	80004808 <acquiresleep>

  int i = 0;
  while (i < n) {
    80000906:	05205963          	blez	s2,80000958 <uartwrite+0x6e>
    8000090a:	f426                	sd	s1,40(sp)
    8000090c:	ec4e                	sd	s3,24(sp)
    8000090e:	e852                	sd	s4,16(sp)
    80000910:	e05a                	sd	s6,0(sp)
  int i = 0;
    80000912:	4481                	li	s1,0
    sleep_prepare(&tx_chan);
    80000914:	0000ba17          	auipc	s4,0xb
    80000918:	db4a0a13          	addi	s4,s4,-588 # 8000b6c8 <tx_chan>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    8000091c:	100009b7          	lui	s3,0x10000
    80000920:	0995                	addi	s3,s3,5 # 10000005 <_entry-0x6ffffffb>
      WriteReg(THR, buf[i]);
    80000922:	10000b37          	lui	s6,0x10000
    80000926:	a029                	j	80000930 <uartwrite+0x46>
      i += 1;
    } else {
      sleep();
    80000928:	18d010ef          	jal	800022b4 <sleep>
  while (i < n) {
    8000092c:	0324d263          	bge	s1,s2,80000950 <uartwrite+0x66>
    sleep_prepare(&tx_chan);
    80000930:	8552                	mv	a0,s4
    80000932:	147010ef          	jal	80002278 <sleep_prepare>
    if (ReadReg(LSR) & LSR_TX_IDLE) {
    80000936:	0009c783          	lbu	a5,0(s3)
    8000093a:	0207f793          	andi	a5,a5,32
    8000093e:	d7ed                	beqz	a5,80000928 <uartwrite+0x3e>
      WriteReg(THR, buf[i]);
    80000940:	009a87b3          	add	a5,s5,s1
    80000944:	0007c783          	lbu	a5,0(a5)
    80000948:	00fb0023          	sb	a5,0(s6) # 10000000 <_entry-0x70000000>
      i += 1;
    8000094c:	2485                	addiw	s1,s1,1
    8000094e:	bff9                	j	8000092c <uartwrite+0x42>
    80000950:	74a2                	ld	s1,40(sp)
    80000952:	69e2                	ld	s3,24(sp)
    80000954:	6a42                	ld	s4,16(sp)
    80000956:	6b02                	ld	s6,0(sp)
    }
  }

  releasesleep(&tx_lock);
    80000958:	00013517          	auipc	a0,0x13
    8000095c:	e5850513          	addi	a0,a0,-424 # 800137b0 <tx_lock>
    80000960:	6fd030ef          	jal	8000485c <releasesleep>
}
    80000964:	70e2                	ld	ra,56(sp)
    80000966:	7442                	ld	s0,48(sp)
    80000968:	7902                	ld	s2,32(sp)
    8000096a:	6aa2                	ld	s5,8(sp)
    8000096c:	6121                	addi	sp,sp,64
    8000096e:	8082                	ret

0000000080000970 <uartputc_sync>:
// interrupts, for use by kernel printk() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    80000970:	1101                	addi	sp,sp,-32
    80000972:	ec06                	sd	ra,24(sp)
    80000974:	e822                	sd	s0,16(sp)
    80000976:	e426                	sd	s1,8(sp)
    80000978:	1000                	addi	s0,sp,32
    8000097a:	84aa                	mv	s1,a0
  if (panicking == 0)
    8000097c:	0000b797          	auipc	a5,0xb
    80000980:	d487a783          	lw	a5,-696(a5) # 8000b6c4 <panicking>
    80000984:	cf95                	beqz	a5,800009c0 <uartputc_sync+0x50>
    push_off();

  if (panicked) {
    80000986:	0000b797          	auipc	a5,0xb
    8000098a:	d3a7a783          	lw	a5,-710(a5) # 8000b6c0 <panicked>
    8000098e:	ef85                	bnez	a5,800009c6 <uartputc_sync+0x56>
    for (;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while ((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    80000990:	10000737          	lui	a4,0x10000
    80000994:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000996:	00074783          	lbu	a5,0(a4)
    8000099a:	0207f793          	andi	a5,a5,32
    8000099e:	dfe5                	beqz	a5,80000996 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    800009a0:	0ff4f513          	zext.b	a0,s1
    800009a4:	100007b7          	lui	a5,0x10000
    800009a8:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if (panicking == 0)
    800009ac:	0000b797          	auipc	a5,0xb
    800009b0:	d187a783          	lw	a5,-744(a5) # 8000b6c4 <panicking>
    800009b4:	cb91                	beqz	a5,800009c8 <uartputc_sync+0x58>
    pop_off();
}
    800009b6:	60e2                	ld	ra,24(sp)
    800009b8:	6442                	ld	s0,16(sp)
    800009ba:	64a2                	ld	s1,8(sp)
    800009bc:	6105                	addi	sp,sp,32
    800009be:	8082                	ret
    push_off();
    800009c0:	1ee000ef          	jal	80000bae <push_off>
    800009c4:	b7c9                	j	80000986 <uartputc_sync+0x16>
    for (;;)
    800009c6:	a001                	j	800009c6 <uartputc_sync+0x56>
    pop_off();
    800009c8:	260000ef          	jal	80000c28 <pop_off>
}
    800009cc:	b7ed                	j	800009b6 <uartputc_sync+0x46>

00000000800009ce <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009ce:	1101                	addi	sp,sp,-32
    800009d0:	ec06                	sd	ra,24(sp)
    800009d2:	e822                	sd	s0,16(sp)
    800009d4:	e426                	sd	s1,8(sp)
    800009d6:	e04a                	sd	s2,0(sp)
    800009d8:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009da:	100007b7          	lui	a5,0x10000
    800009de:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  if (ReadReg(LSR) & LSR_TX_IDLE) {
    800009e2:	100007b7          	lui	a5,0x10000
    800009e6:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009ea:	0207f793          	andi	a5,a5,32
    800009ee:	ef99                	bnez	a5,80000a0c <uartintr+0x3e>
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009f0:	100004b7          	lui	s1,0x10000
    800009f4:	0495                	addi	s1,s1,5 # 10000005 <_entry-0x6ffffffb>
    return ReadReg(RHR);
    800009f6:	10000937          	lui	s2,0x10000
  if (ReadReg(LSR) & LSR_RX_READY) {
    800009fa:	0004c783          	lbu	a5,0(s1)
    800009fe:	8b85                	andi	a5,a5,1
    80000a00:	cf89                	beqz	a5,80000a1a <uartintr+0x4c>
    return ReadReg(RHR);
    80000a02:	00094503          	lbu	a0,0(s2) # 10000000 <_entry-0x70000000>
  // read and process incoming characters, if any.
  while (1) {
    int c = uartgetc();
    if (c == -1)
      break;
    consoleintr(c);
    80000a06:	8b7ff0ef          	jal	800002bc <consoleintr>
  while (1) {
    80000a0a:	bfc5                	j	800009fa <uartintr+0x2c>
    wakeup(&tx_chan);
    80000a0c:	0000b517          	auipc	a0,0xb
    80000a10:	cbc50513          	addi	a0,a0,-836 # 8000b6c8 <tx_chan>
    80000a14:	0d1010ef          	jal	800022e4 <wakeup>
    80000a18:	bfe1                	j	800009f0 <uartintr+0x22>
  }
}
    80000a1a:	60e2                	ld	ra,24(sp)
    80000a1c:	6442                	ld	s0,16(sp)
    80000a1e:	64a2                	ld	s1,8(sp)
    80000a20:	6902                	ld	s2,0(sp)
    80000a22:	6105                	addi	sp,sp,32
    80000a24:	8082                	ret

0000000080000a26 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a26:	1101                	addi	sp,sp,-32
    80000a28:	ec06                	sd	ra,24(sp)
    80000a2a:	e822                	sd	s0,16(sp)
    80000a2c:	e426                	sd	s1,8(sp)
    80000a2e:	e04a                	sd	s2,0(sp)
    80000a30:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (char *)pa < end || (uint64)pa >= PHYSTOP)
    80000a32:	00024797          	auipc	a5,0x24
    80000a36:	73678793          	addi	a5,a5,1846 # 80025168 <end>
    80000a3a:	00f53733          	sltu	a4,a0,a5
    80000a3e:	47c5                	li	a5,17
    80000a40:	07ee                	slli	a5,a5,0x1b
    80000a42:	17fd                	addi	a5,a5,-1
    80000a44:	00a7b7b3          	sltu	a5,a5,a0
    80000a48:	8fd9                	or	a5,a5,a4
    80000a4a:	ef95                	bnez	a5,80000a86 <kfree+0x60>
    80000a4c:	84aa                	mv	s1,a0
    80000a4e:	03451793          	slli	a5,a0,0x34
    80000a52:	eb95                	bnez	a5,80000a86 <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a54:	6605                	lui	a2,0x1
    80000a56:	4585                	li	a1,1
    80000a58:	250000ef          	jal	80000ca8 <memset>

  r = (struct run *)pa;

  acquire(&kmem.lock);
    80000a5c:	00013917          	auipc	s2,0x13
    80000a60:	d8490913          	addi	s2,s2,-636 # 800137e0 <kmem>
    80000a64:	854a                	mv	a0,s2
    80000a66:	182000ef          	jal	80000be8 <acquire>
  r->next = kmem.freelist;
    80000a6a:	01893783          	ld	a5,24(s2)
    80000a6e:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000a70:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000a74:	854a                	mv	a0,s2
    80000a76:	1fa000ef          	jal	80000c70 <release>
}
    80000a7a:	60e2                	ld	ra,24(sp)
    80000a7c:	6442                	ld	s0,16(sp)
    80000a7e:	64a2                	ld	s1,8(sp)
    80000a80:	6902                	ld	s2,0(sp)
    80000a82:	6105                	addi	sp,sp,32
    80000a84:	8082                	ret
    panic("kfree");
    80000a86:	00007517          	auipc	a0,0x7
    80000a8a:	5b250513          	addi	a0,a0,1458 # 80008038 <etext+0x38>
    80000a8e:	da7ff0ef          	jal	80000834 <panic>

0000000080000a92 <freerange>:
{
    80000a92:	7179                	addi	sp,sp,-48
    80000a94:	f406                	sd	ra,40(sp)
    80000a96:	f022                	sd	s0,32(sp)
    80000a98:	ec26                	sd	s1,24(sp)
    80000a9a:	1800                	addi	s0,sp,48
  p = (char *)PGROUNDUP((uint64)pa_start);
    80000a9c:	6785                	lui	a5,0x1
    80000a9e:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000aa2:	00e504b3          	add	s1,a0,a4
    80000aa6:	777d                	lui	a4,0xfffff
    80000aa8:	8cf9                	and	s1,s1,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000aaa:	94be                	add	s1,s1,a5
    80000aac:	0295e263          	bltu	a1,s1,80000ad0 <freerange+0x3e>
    80000ab0:	e84a                	sd	s2,16(sp)
    80000ab2:	e44e                	sd	s3,8(sp)
    80000ab4:	e052                	sd	s4,0(sp)
    80000ab6:	892e                	mv	s2,a1
    kfree(p);
    80000ab8:	8a3a                	mv	s4,a4
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000aba:	89be                	mv	s3,a5
    kfree(p);
    80000abc:	01448533          	add	a0,s1,s4
    80000ac0:	f67ff0ef          	jal	80000a26 <kfree>
  for (; p + PGSIZE <= (char *)pa_end; p += PGSIZE)
    80000ac4:	94ce                	add	s1,s1,s3
    80000ac6:	fe997be3          	bgeu	s2,s1,80000abc <freerange+0x2a>
    80000aca:	6942                	ld	s2,16(sp)
    80000acc:	69a2                	ld	s3,8(sp)
    80000ace:	6a02                	ld	s4,0(sp)
}
    80000ad0:	70a2                	ld	ra,40(sp)
    80000ad2:	7402                	ld	s0,32(sp)
    80000ad4:	64e2                	ld	s1,24(sp)
    80000ad6:	6145                	addi	sp,sp,48
    80000ad8:	8082                	ret

0000000080000ada <kinit>:
{
    80000ada:	1141                	addi	sp,sp,-16
    80000adc:	e406                	sd	ra,8(sp)
    80000ade:	e022                	sd	s0,0(sp)
    80000ae0:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ae2:	00007597          	auipc	a1,0x7
    80000ae6:	55e58593          	addi	a1,a1,1374 # 80008040 <etext+0x40>
    80000aea:	00013517          	auipc	a0,0x13
    80000aee:	cf650513          	addi	a0,a0,-778 # 800137e0 <kmem>
    80000af2:	076000ef          	jal	80000b68 <initlock>
  freerange(end, (void *)PHYSTOP);
    80000af6:	45c5                	li	a1,17
    80000af8:	05ee                	slli	a1,a1,0x1b
    80000afa:	00024517          	auipc	a0,0x24
    80000afe:	66e50513          	addi	a0,a0,1646 # 80025168 <end>
    80000b02:	f91ff0ef          	jal	80000a92 <freerange>
}
    80000b06:	60a2                	ld	ra,8(sp)
    80000b08:	6402                	ld	s0,0(sp)
    80000b0a:	0141                	addi	sp,sp,16
    80000b0c:	8082                	ret

0000000080000b0e <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b0e:	1101                	addi	sp,sp,-32
    80000b10:	ec06                	sd	ra,24(sp)
    80000b12:	e822                	sd	s0,16(sp)
    80000b14:	e426                	sd	s1,8(sp)
    80000b16:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b18:	00013517          	auipc	a0,0x13
    80000b1c:	cc850513          	addi	a0,a0,-824 # 800137e0 <kmem>
    80000b20:	0c8000ef          	jal	80000be8 <acquire>
  r = kmem.freelist;
    80000b24:	00013497          	auipc	s1,0x13
    80000b28:	cd44b483          	ld	s1,-812(s1) # 800137f8 <kmem+0x18>
  if (r)
    80000b2c:	c49d                	beqz	s1,80000b5a <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b2e:	609c                	ld	a5,0(s1)
    80000b30:	00013717          	auipc	a4,0x13
    80000b34:	ccf73423          	sd	a5,-824(a4) # 800137f8 <kmem+0x18>
  release(&kmem.lock);
    80000b38:	00013517          	auipc	a0,0x13
    80000b3c:	ca850513          	addi	a0,a0,-856 # 800137e0 <kmem>
    80000b40:	130000ef          	jal	80000c70 <release>

  if (r)
    memset((char *)r, 5, PGSIZE); // fill with junk
    80000b44:	6605                	lui	a2,0x1
    80000b46:	4595                	li	a1,5
    80000b48:	8526                	mv	a0,s1
    80000b4a:	15e000ef          	jal	80000ca8 <memset>
  return (void *)r;
}
    80000b4e:	8526                	mv	a0,s1
    80000b50:	60e2                	ld	ra,24(sp)
    80000b52:	6442                	ld	s0,16(sp)
    80000b54:	64a2                	ld	s1,8(sp)
    80000b56:	6105                	addi	sp,sp,32
    80000b58:	8082                	ret
  release(&kmem.lock);
    80000b5a:	00013517          	auipc	a0,0x13
    80000b5e:	c8650513          	addi	a0,a0,-890 # 800137e0 <kmem>
    80000b62:	10e000ef          	jal	80000c70 <release>
  if (r)
    80000b66:	b7e5                	j	80000b4e <kalloc+0x40>

0000000080000b68 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000b68:	1141                	addi	sp,sp,-16
    80000b6a:	e406                	sd	ra,8(sp)
    80000b6c:	e022                	sd	s0,0(sp)
    80000b6e:	0800                	addi	s0,sp,16
  lk->name = name;
    80000b70:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000b72:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000b76:	00053823          	sd	zero,16(a0)
}
    80000b7a:	60a2                	ld	ra,8(sp)
    80000b7c:	6402                	ld	s0,0(sp)
    80000b7e:	0141                	addi	sp,sp,16
    80000b80:	8082                	ret

0000000080000b82 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000b82:	411c                	lw	a5,0(a0)
    80000b84:	e399                	bnez	a5,80000b8a <holding+0x8>
    80000b86:	4501                	li	a0,0
  return r;
}
    80000b88:	8082                	ret
{
    80000b8a:	1101                	addi	sp,sp,-32
    80000b8c:	ec06                	sd	ra,24(sp)
    80000b8e:	e822                	sd	s0,16(sp)
    80000b90:	e426                	sd	s1,8(sp)
    80000b92:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000b94:	691c                	ld	a5,16(a0)
    80000b96:	84be                	mv	s1,a5
    80000b98:	53d000ef          	jal	800018d4 <mycpu>
    80000b9c:	40a48533          	sub	a0,s1,a0
    80000ba0:	00153513          	seqz	a0,a0
}
    80000ba4:	60e2                	ld	ra,24(sp)
    80000ba6:	6442                	ld	s0,16(sp)
    80000ba8:	64a2                	ld	s1,8(sp)
    80000baa:	6105                	addi	sp,sp,32
    80000bac:	8082                	ret

0000000080000bae <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000bae:	1101                	addi	sp,sp,-32
    80000bb0:	ec06                	sd	ra,24(sp)
    80000bb2:	e822                	sd	s0,16(sp)
    80000bb4:	e426                	sd	s1,8(sp)
    80000bb6:	1000                	addi	s0,sp,32
  __asm__ __volatile__("csrrc %0, sstatus, %1" : "=r"(x) : "rK"(x) : "memory");
    80000bb8:	100177f3          	csrrci	a5,sstatus,2
    80000bbc:	84be                	mv	s1,a5
  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  uint64 flags = rc_sstatus(SSTATUS_SIE);
  int old = !!(flags & SSTATUS_SIE);

  if (mycpu()->noff == 0)
    80000bbe:	517000ef          	jal	800018d4 <mycpu>
    80000bc2:	5d3c                	lw	a5,120(a0)
    80000bc4:	cb99                	beqz	a5,80000bda <push_off+0x2c>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000bc6:	50f000ef          	jal	800018d4 <mycpu>
    80000bca:	5d3c                	lw	a5,120(a0)
    80000bcc:	2785                	addiw	a5,a5,1
    80000bce:	dd3c                	sw	a5,120(a0)
}
    80000bd0:	60e2                	ld	ra,24(sp)
    80000bd2:	6442                	ld	s0,16(sp)
    80000bd4:	64a2                	ld	s1,8(sp)
    80000bd6:	6105                	addi	sp,sp,32
    80000bd8:	8082                	ret
    mycpu()->intena = old;
    80000bda:	4fb000ef          	jal	800018d4 <mycpu>
  int old = !!(flags & SSTATUS_SIE);
    80000bde:	0014d793          	srli	a5,s1,0x1
    80000be2:	8b85                	andi	a5,a5,1
    mycpu()->intena = old;
    80000be4:	dd7c                	sw	a5,124(a0)
    80000be6:	b7c5                	j	80000bc6 <push_off+0x18>

0000000080000be8 <acquire>:
{
    80000be8:	1101                	addi	sp,sp,-32
    80000bea:	ec06                	sd	ra,24(sp)
    80000bec:	e822                	sd	s0,16(sp)
    80000bee:	e426                	sd	s1,8(sp)
    80000bf0:	1000                	addi	s0,sp,32
    80000bf2:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000bf4:	fbbff0ef          	jal	80000bae <push_off>
  if (holding(lk))
    80000bf8:	8526                	mv	a0,s1
    80000bfa:	f89ff0ef          	jal	80000b82 <holding>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000bfe:	4705                	li	a4,1
  if (holding(lk))
    80000c00:	ed11                	bnez	a0,80000c1c <acquire+0x34>
  while (__atomic_exchange_n(&lk->locked, 1, __ATOMIC_ACQUIRE) != 0)
    80000c02:	87ba                	mv	a5,a4
    80000c04:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c08:	2781                	sext.w	a5,a5
    80000c0a:	ffe5                	bnez	a5,80000c02 <acquire+0x1a>
  lk->cpu = mycpu();
    80000c0c:	4c9000ef          	jal	800018d4 <mycpu>
    80000c10:	e888                	sd	a0,16(s1)
}
    80000c12:	60e2                	ld	ra,24(sp)
    80000c14:	6442                	ld	s0,16(sp)
    80000c16:	64a2                	ld	s1,8(sp)
    80000c18:	6105                	addi	sp,sp,32
    80000c1a:	8082                	ret
    panic("acquire");
    80000c1c:	00007517          	auipc	a0,0x7
    80000c20:	42c50513          	addi	a0,a0,1068 # 80008048 <etext+0x48>
    80000c24:	c11ff0ef          	jal	80000834 <panic>

0000000080000c28 <pop_off>:

void
pop_off(void)
{
    80000c28:	1141                	addi	sp,sp,-16
    80000c2a:	e406                	sd	ra,8(sp)
    80000c2c:	e022                	sd	s0,0(sp)
    80000c2e:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c30:	4a5000ef          	jal	800018d4 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80000c34:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000c38:	8b89                	andi	a5,a5,2
  if (intr_get())
    80000c3a:	ef99                	bnez	a5,80000c58 <pop_off+0x30>
    panic("pop_off - interruptible");
  if (c->noff < 1)
    80000c3c:	5d3c                	lw	a5,120(a0)
    80000c3e:	02f05363          	blez	a5,80000c64 <pop_off+0x3c>
    panic("pop_off");
  c->noff -= 1;
    80000c42:	37fd                	addiw	a5,a5,-1
    80000c44:	dd3c                	sw	a5,120(a0)
  if (c->noff == 0 && c->intena)
    80000c46:	e789                	bnez	a5,80000c50 <pop_off+0x28>
    80000c48:	5d7c                	lw	a5,124(a0)
    80000c4a:	c399                	beqz	a5,80000c50 <pop_off+0x28>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80000c4c:	10016073          	csrsi	sstatus,2
    intr_on();
}
    80000c50:	60a2                	ld	ra,8(sp)
    80000c52:	6402                	ld	s0,0(sp)
    80000c54:	0141                	addi	sp,sp,16
    80000c56:	8082                	ret
    panic("pop_off - interruptible");
    80000c58:	00007517          	auipc	a0,0x7
    80000c5c:	3f850513          	addi	a0,a0,1016 # 80008050 <etext+0x50>
    80000c60:	bd5ff0ef          	jal	80000834 <panic>
    panic("pop_off");
    80000c64:	00007517          	auipc	a0,0x7
    80000c68:	40450513          	addi	a0,a0,1028 # 80008068 <etext+0x68>
    80000c6c:	bc9ff0ef          	jal	80000834 <panic>

0000000080000c70 <release>:
{
    80000c70:	1101                	addi	sp,sp,-32
    80000c72:	ec06                	sd	ra,24(sp)
    80000c74:	e822                	sd	s0,16(sp)
    80000c76:	e426                	sd	s1,8(sp)
    80000c78:	1000                	addi	s0,sp,32
    80000c7a:	84aa                	mv	s1,a0
  if (!holding(lk))
    80000c7c:	f07ff0ef          	jal	80000b82 <holding>
    80000c80:	cd11                	beqz	a0,80000c9c <release+0x2c>
  lk->cpu = 0;
    80000c82:	0004b823          	sd	zero,16(s1)
  __atomic_store_n(&lk->locked, 0, __ATOMIC_RELEASE);
    80000c86:	0310000f          	fence	rw,w
    80000c8a:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000c8e:	f9bff0ef          	jal	80000c28 <pop_off>
}
    80000c92:	60e2                	ld	ra,24(sp)
    80000c94:	6442                	ld	s0,16(sp)
    80000c96:	64a2                	ld	s1,8(sp)
    80000c98:	6105                	addi	sp,sp,32
    80000c9a:	8082                	ret
    panic("release");
    80000c9c:	00007517          	auipc	a0,0x7
    80000ca0:	3d450513          	addi	a0,a0,980 # 80008070 <etext+0x70>
    80000ca4:	b91ff0ef          	jal	80000834 <panic>

0000000080000ca8 <memset>:
#include "types.h"

void *
memset(void *dst, int c, uint n)
{
    80000ca8:	1141                	addi	sp,sp,-16
    80000caa:	e406                	sd	ra,8(sp)
    80000cac:	e022                	sd	s0,0(sp)
    80000cae:	0800                	addi	s0,sp,16
  char *cdst = (char *)dst;
  int i;
  for (i = 0; i < n; i++) {
    80000cb0:	ca19                	beqz	a2,80000cc6 <memset+0x1e>
    80000cb2:	87aa                	mv	a5,a0
    80000cb4:	1602                	slli	a2,a2,0x20
    80000cb6:	9201                	srli	a2,a2,0x20
    80000cb8:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000cbc:	00b78023          	sb	a1,0(a5)
  for (i = 0; i < n; i++) {
    80000cc0:	0785                	addi	a5,a5,1
    80000cc2:	fee79de3          	bne	a5,a4,80000cbc <memset+0x14>
  }
  return dst;
}
    80000cc6:	60a2                	ld	ra,8(sp)
    80000cc8:	6402                	ld	s0,0(sp)
    80000cca:	0141                	addi	sp,sp,16
    80000ccc:	8082                	ret

0000000080000cce <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000cce:	1141                	addi	sp,sp,-16
    80000cd0:	e406                	sd	ra,8(sp)
    80000cd2:	e022                	sd	s0,0(sp)
    80000cd4:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while (n-- > 0) {
    80000cd6:	c61d                	beqz	a2,80000d04 <memcmp+0x36>
    80000cd8:	1602                	slli	a2,a2,0x20
    80000cda:	9201                	srli	a2,a2,0x20
    80000cdc:	00c506b3          	add	a3,a0,a2
    if (*s1 != *s2)
    80000ce0:	00054783          	lbu	a5,0(a0)
    80000ce4:	0005c703          	lbu	a4,0(a1)
    80000ce8:	00e79863          	bne	a5,a4,80000cf8 <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000cec:	0505                	addi	a0,a0,1
    80000cee:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    80000cf0:	fed518e3          	bne	a0,a3,80000ce0 <memcmp+0x12>
  }

  return 0;
    80000cf4:	4501                	li	a0,0
    80000cf6:	a019                	j	80000cfc <memcmp+0x2e>
      return *s1 - *s2;
    80000cf8:	40e7853b          	subw	a0,a5,a4
}
    80000cfc:	60a2                	ld	ra,8(sp)
    80000cfe:	6402                	ld	s0,0(sp)
    80000d00:	0141                	addi	sp,sp,16
    80000d02:	8082                	ret
  return 0;
    80000d04:	4501                	li	a0,0
    80000d06:	bfdd                	j	80000cfc <memcmp+0x2e>

0000000080000d08 <memmove>:

void *
memmove(void *dst, const void *src, uint n)
{
    80000d08:	1141                	addi	sp,sp,-16
    80000d0a:	e406                	sd	ra,8(sp)
    80000d0c:	e022                	sd	s0,0(sp)
    80000d0e:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if (n == 0)
    80000d10:	c205                	beqz	a2,80000d30 <memmove+0x28>
    return dst;

  s = src;
  d = dst;
  if (s < d && s + n > d) {
    80000d12:	02a5e363          	bltu	a1,a0,80000d38 <memmove+0x30>
    s += n;
    d += n;
    while (n-- > 0)
      *--d = *--s;
  } else
    while (n-- > 0)
    80000d16:	1602                	slli	a2,a2,0x20
    80000d18:	9201                	srli	a2,a2,0x20
    80000d1a:	00c587b3          	add	a5,a1,a2
{
    80000d1e:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d20:	0585                	addi	a1,a1,1
    80000d22:	0705                	addi	a4,a4,1
    80000d24:	fff5c683          	lbu	a3,-1(a1)
    80000d28:	fed70fa3          	sb	a3,-1(a4)
    while (n-- > 0)
    80000d2c:	feb79ae3          	bne	a5,a1,80000d20 <memmove+0x18>

  return dst;
}
    80000d30:	60a2                	ld	ra,8(sp)
    80000d32:	6402                	ld	s0,0(sp)
    80000d34:	0141                	addi	sp,sp,16
    80000d36:	8082                	ret
  if (s < d && s + n > d) {
    80000d38:	02061693          	slli	a3,a2,0x20
    80000d3c:	9281                	srli	a3,a3,0x20
    80000d3e:	00d58733          	add	a4,a1,a3
    80000d42:	fce57ae3          	bgeu	a0,a4,80000d16 <memmove+0xe>
    d += n;
    80000d46:	96aa                	add	a3,a3,a0
    while (n-- > 0)
    80000d48:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000d4c:	1782                	slli	a5,a5,0x20
    80000d4e:	9381                	srli	a5,a5,0x20
    80000d50:	fff7c793          	not	a5,a5
    80000d54:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000d56:	177d                	addi	a4,a4,-1
    80000d58:	16fd                	addi	a3,a3,-1
    80000d5a:	00074603          	lbu	a2,0(a4)
    80000d5e:	00c68023          	sb	a2,0(a3)
    while (n-- > 0)
    80000d62:	fee79ae3          	bne	a5,a4,80000d56 <memmove+0x4e>
    80000d66:	b7e9                	j	80000d30 <memmove+0x28>

0000000080000d68 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void *
memcpy(void *dst, const void *src, uint n)
{
    80000d68:	1141                	addi	sp,sp,-16
    80000d6a:	e406                	sd	ra,8(sp)
    80000d6c:	e022                	sd	s0,0(sp)
    80000d6e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000d70:	f99ff0ef          	jal	80000d08 <memmove>
}
    80000d74:	60a2                	ld	ra,8(sp)
    80000d76:	6402                	ld	s0,0(sp)
    80000d78:	0141                	addi	sp,sp,16
    80000d7a:	8082                	ret

0000000080000d7c <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000d7c:	1141                	addi	sp,sp,-16
    80000d7e:	e406                	sd	ra,8(sp)
    80000d80:	e022                	sd	s0,0(sp)
    80000d82:	0800                	addi	s0,sp,16
  while (n > 0 && *p && *p == *q)
    80000d84:	ce11                	beqz	a2,80000da0 <strncmp+0x24>
    80000d86:	00054783          	lbu	a5,0(a0)
    80000d8a:	cf89                	beqz	a5,80000da4 <strncmp+0x28>
    80000d8c:	0005c703          	lbu	a4,0(a1)
    80000d90:	00f71a63          	bne	a4,a5,80000da4 <strncmp+0x28>
    n--, p++, q++;
    80000d94:	367d                	addiw	a2,a2,-1
    80000d96:	0505                	addi	a0,a0,1
    80000d98:	0585                	addi	a1,a1,1
  while (n > 0 && *p && *p == *q)
    80000d9a:	f675                	bnez	a2,80000d86 <strncmp+0xa>
  if (n == 0)
    return 0;
    80000d9c:	4501                	li	a0,0
    80000d9e:	a801                	j	80000dae <strncmp+0x32>
    80000da0:	4501                	li	a0,0
    80000da2:	a031                	j	80000dae <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000da4:	00054503          	lbu	a0,0(a0)
    80000da8:	0005c783          	lbu	a5,0(a1)
    80000dac:	9d1d                	subw	a0,a0,a5
}
    80000dae:	60a2                	ld	ra,8(sp)
    80000db0:	6402                	ld	s0,0(sp)
    80000db2:	0141                	addi	sp,sp,16
    80000db4:	8082                	ret

0000000080000db6 <strncpy>:

char *
strncpy(char *s, const char *t, int n)
{
    80000db6:	1141                	addi	sp,sp,-16
    80000db8:	e406                	sd	ra,8(sp)
    80000dba:	e022                	sd	s0,0(sp)
    80000dbc:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while (n-- > 0 && (*s++ = *t++) != 0)
    80000dbe:	87aa                	mv	a5,a0
    80000dc0:	a011                	j	80000dc4 <strncpy+0xe>
    80000dc2:	8636                	mv	a2,a3
    80000dc4:	02c05863          	blez	a2,80000df4 <strncpy+0x3e>
    80000dc8:	fff6069b          	addiw	a3,a2,-1
    80000dcc:	8836                	mv	a6,a3
    80000dce:	0785                	addi	a5,a5,1
    80000dd0:	0005c703          	lbu	a4,0(a1)
    80000dd4:	fee78fa3          	sb	a4,-1(a5)
    80000dd8:	0585                	addi	a1,a1,1
    80000dda:	f765                	bnez	a4,80000dc2 <strncpy+0xc>
    ;
  while (n-- > 0)
    80000ddc:	873e                	mv	a4,a5
    80000dde:	01005b63          	blez	a6,80000df4 <strncpy+0x3e>
    80000de2:	9fb1                	addw	a5,a5,a2
    80000de4:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000de6:	0705                	addi	a4,a4,1
    80000de8:	fe070fa3          	sb	zero,-1(a4)
  while (n-- > 0)
    80000dec:	40e786bb          	subw	a3,a5,a4
    80000df0:	fed04be3          	bgtz	a3,80000de6 <strncpy+0x30>
  return os;
}
    80000df4:	60a2                	ld	ra,8(sp)
    80000df6:	6402                	ld	s0,0(sp)
    80000df8:	0141                	addi	sp,sp,16
    80000dfa:	8082                	ret

0000000080000dfc <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char *
safestrcpy(char *s, const char *t, int n)
{
    80000dfc:	1141                	addi	sp,sp,-16
    80000dfe:	e406                	sd	ra,8(sp)
    80000e00:	e022                	sd	s0,0(sp)
    80000e02:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if (n <= 0)
    80000e04:	02c05363          	blez	a2,80000e2a <safestrcpy+0x2e>
    80000e08:	fff6069b          	addiw	a3,a2,-1
    80000e0c:	1682                	slli	a3,a3,0x20
    80000e0e:	9281                	srli	a3,a3,0x20
    80000e10:	96ae                	add	a3,a3,a1
    80000e12:	87aa                	mv	a5,a0
    return os;
  while (--n > 0 && (*s++ = *t++) != 0)
    80000e14:	00d58963          	beq	a1,a3,80000e26 <safestrcpy+0x2a>
    80000e18:	0585                	addi	a1,a1,1
    80000e1a:	0785                	addi	a5,a5,1
    80000e1c:	fff5c703          	lbu	a4,-1(a1)
    80000e20:	fee78fa3          	sb	a4,-1(a5)
    80000e24:	fb65                	bnez	a4,80000e14 <safestrcpy+0x18>
    ;
  *s = 0;
    80000e26:	00078023          	sb	zero,0(a5)
  return os;
}
    80000e2a:	60a2                	ld	ra,8(sp)
    80000e2c:	6402                	ld	s0,0(sp)
    80000e2e:	0141                	addi	sp,sp,16
    80000e30:	8082                	ret

0000000080000e32 <strlen>:

int
strlen(const char *s)
{
    80000e32:	1141                	addi	sp,sp,-16
    80000e34:	e406                	sd	ra,8(sp)
    80000e36:	e022                	sd	s0,0(sp)
    80000e38:	0800                	addi	s0,sp,16
  int n;

  for (n = 0; s[n]; n++)
    80000e3a:	00054783          	lbu	a5,0(a0)
    80000e3e:	cf91                	beqz	a5,80000e5a <strlen+0x28>
    80000e40:	00150793          	addi	a5,a0,1
    80000e44:	86be                	mv	a3,a5
    80000e46:	0785                	addi	a5,a5,1
    80000e48:	fff7c703          	lbu	a4,-1(a5)
    80000e4c:	ff65                	bnez	a4,80000e44 <strlen+0x12>
    80000e4e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000e52:	60a2                	ld	ra,8(sp)
    80000e54:	6402                	ld	s0,0(sp)
    80000e56:	0141                	addi	sp,sp,16
    80000e58:	8082                	ret
  for (n = 0; s[n]; n++)
    80000e5a:	4501                	li	a0,0
    80000e5c:	bfdd                	j	80000e52 <strlen+0x20>

0000000080000e5e <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000e5e:	1141                	addi	sp,sp,-16
    80000e60:	e406                	sd	ra,8(sp)
    80000e62:	e022                	sd	s0,0(sp)
    80000e64:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80000e66:	25b000ef          	jal	800018c0 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();         // first user process

    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
  } else {
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e6a:	0000b717          	auipc	a4,0xb
    80000e6e:	86270713          	addi	a4,a4,-1950 # 8000b6cc <started>
  if (cpuid() == 0) {
    80000e72:	c51d                	beqz	a0,80000ea0 <main+0x42>
    while (__atomic_load_n(&started, __ATOMIC_ACQUIRE) == 0)
    80000e74:	431c                	lw	a5,0(a4)
    80000e76:	0230000f          	fence	r,rw
    80000e7a:	2781                	sext.w	a5,a5
    80000e7c:	dfe5                	beqz	a5,80000e74 <main+0x16>
      ;

    printk("hart %d starting\n", cpuid());
    80000e7e:	243000ef          	jal	800018c0 <cpuid>
    80000e82:	85aa                	mv	a1,a0
    80000e84:	00007517          	auipc	a0,0x7
    80000e88:	20c50513          	addi	a0,a0,524 # 80008090 <etext+0x90>
    80000e8c:	e7eff0ef          	jal	8000050a <printk>
    kvminithart();  // turn on paging
    80000e90:	086000ef          	jal	80000f16 <kvminithart>
    trapinithart(); // install kernel trap vector
    80000e94:	563010ef          	jal	80002bf6 <trapinithart>
    plicinithart(); // ask PLIC for device interrupts
    80000e98:	7a1040ef          	jal	80005e38 <plicinithart>
  }

  scheduler();
    80000e9c:	14a010ef          	jal	80001fe6 <scheduler>
    consoleinit();
    80000ea0:	d90ff0ef          	jal	80000430 <consoleinit>
    printkinit();
    80000ea4:	9cdff0ef          	jal	80000870 <printkinit>
    printk("\n");
    80000ea8:	00007517          	auipc	a0,0x7
    80000eac:	31850513          	addi	a0,a0,792 # 800081c0 <etext+0x1c0>
    80000eb0:	e5aff0ef          	jal	8000050a <printk>
    printk("xv6 kernel is booting\n");
    80000eb4:	00007517          	auipc	a0,0x7
    80000eb8:	1c450513          	addi	a0,a0,452 # 80008078 <etext+0x78>
    80000ebc:	e4eff0ef          	jal	8000050a <printk>
    printk("\n");
    80000ec0:	00007517          	auipc	a0,0x7
    80000ec4:	30050513          	addi	a0,a0,768 # 800081c0 <etext+0x1c0>
    80000ec8:	e42ff0ef          	jal	8000050a <printk>
    kinit();            // physical page allocator
    80000ecc:	c0fff0ef          	jal	80000ada <kinit>
    kvminit();          // create kernel page table
    80000ed0:	2d2000ef          	jal	800011a2 <kvminit>
    kvminithart();      // turn on paging
    80000ed4:	042000ef          	jal	80000f16 <kvminithart>
    procinit();         // process table
    80000ed8:	13f000ef          	jal	80001816 <procinit>
    seminit();
    80000edc:	241010ef          	jal	8000291c <seminit>
    trapinit();         // trap vectors
    80000ee0:	4f3010ef          	jal	80002bd2 <trapinit>
    trapinithart();     // install kernel trap vector
    80000ee4:	513010ef          	jal	80002bf6 <trapinithart>
    plicinit();         // set up interrupt controller
    80000ee8:	737040ef          	jal	80005e1e <plicinit>
    plicinithart();     // ask PLIC for device interrupts
    80000eec:	74d040ef          	jal	80005e38 <plicinithart>
    binit();            // buffer cache
    80000ef0:	4bc020ef          	jal	800033ac <binit>
    iinit();            // inode table
    80000ef4:	20f020ef          	jal	80003902 <iinit>
    fileinit();         // file table
    80000ef8:	1e7030ef          	jal	800048de <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000efc:	02c050ef          	jal	80005f28 <virtio_disk_init>
    userinit();         // first user process
    80000f00:	56b000ef          	jal	80001c6a <userinit>
    __atomic_store_n(&started, 1, __ATOMIC_RELEASE);
    80000f04:	0000a797          	auipc	a5,0xa
    80000f08:	7c878793          	addi	a5,a5,1992 # 8000b6cc <started>
    80000f0c:	4705                	li	a4,1
    80000f0e:	0310000f          	fence	rw,w
    80000f12:	c398                	sw	a4,0(a5)
    80000f14:	b761                	j	80000e9c <main+0x3e>

0000000080000f16 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f16:	1141                	addi	sp,sp,-16
    80000f18:	e406                	sd	ra,8(sp)
    80000f1a:	e022                	sd	s0,0(sp)
    80000f1c:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f1e:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f22:	0000a797          	auipc	a5,0xa
    80000f26:	7ae7b783          	ld	a5,1966(a5) # 8000b6d0 <kernel_pagetable>
    80000f2a:	83b1                	srli	a5,a5,0xc
    80000f2c:	577d                	li	a4,-1
    80000f2e:	177e                	slli	a4,a4,0x3f
    80000f30:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r"(x));
    80000f32:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero" ::: "memory");
    80000f36:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000f3a:	60a2                	ld	ra,8(sp)
    80000f3c:	6402                	ld	s0,0(sp)
    80000f3e:	0141                	addi	sp,sp,16
    80000f40:	8082                	ret

0000000080000f42 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000f42:	7139                	addi	sp,sp,-64
    80000f44:	fc06                	sd	ra,56(sp)
    80000f46:	f822                	sd	s0,48(sp)
    80000f48:	f426                	sd	s1,40(sp)
    80000f4a:	f04a                	sd	s2,32(sp)
    80000f4c:	ec4e                	sd	s3,24(sp)
    80000f4e:	e852                	sd	s4,16(sp)
    80000f50:	e456                	sd	s5,8(sp)
    80000f52:	e05a                	sd	s6,0(sp)
    80000f54:	0080                	addi	s0,sp,64
    80000f56:	84aa                	mv	s1,a0
    80000f58:	89ae                	mv	s3,a1
    80000f5a:	8b32                	mv	s6,a2
  if (va >= MAXVA)
    80000f5c:	57fd                	li	a5,-1
    80000f5e:	83e9                	srli	a5,a5,0x1a
    80000f60:	4a79                	li	s4,30
    panic("walk");

  for (int level = 2; level > 0; level--) {
    80000f62:	4ab1                	li	s5,12
  if (va >= MAXVA)
    80000f64:	04b7e263          	bltu	a5,a1,80000fa8 <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000f68:	0149d933          	srl	s2,s3,s4
    80000f6c:	1ff97913          	andi	s2,s2,511
    80000f70:	090e                	slli	s2,s2,0x3
    80000f72:	9926                	add	s2,s2,s1
    if (*pte & PTE_V) {
    80000f74:	00093483          	ld	s1,0(s2)
    80000f78:	0014f793          	andi	a5,s1,1
    80000f7c:	cf85                	beqz	a5,80000fb4 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000f7e:	80a9                	srli	s1,s1,0xa
    80000f80:	04b2                	slli	s1,s1,0xc
  for (int level = 2; level > 0; level--) {
    80000f82:	3a5d                	addiw	s4,s4,-9
    80000f84:	ff5a12e3          	bne	s4,s5,80000f68 <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000f88:	00c9d513          	srli	a0,s3,0xc
    80000f8c:	1ff57513          	andi	a0,a0,511
    80000f90:	050e                	slli	a0,a0,0x3
    80000f92:	9526                	add	a0,a0,s1
}
    80000f94:	70e2                	ld	ra,56(sp)
    80000f96:	7442                	ld	s0,48(sp)
    80000f98:	74a2                	ld	s1,40(sp)
    80000f9a:	7902                	ld	s2,32(sp)
    80000f9c:	69e2                	ld	s3,24(sp)
    80000f9e:	6a42                	ld	s4,16(sp)
    80000fa0:	6aa2                	ld	s5,8(sp)
    80000fa2:	6b02                	ld	s6,0(sp)
    80000fa4:	6121                	addi	sp,sp,64
    80000fa6:	8082                	ret
    panic("walk");
    80000fa8:	00007517          	auipc	a0,0x7
    80000fac:	10050513          	addi	a0,a0,256 # 800080a8 <etext+0xa8>
    80000fb0:	885ff0ef          	jal	80000834 <panic>
      if (!alloc || (pagetable = (pde_t *)kalloc()) == 0)
    80000fb4:	020b0263          	beqz	s6,80000fd8 <walk+0x96>
    80000fb8:	b57ff0ef          	jal	80000b0e <kalloc>
    80000fbc:	84aa                	mv	s1,a0
    80000fbe:	d979                	beqz	a0,80000f94 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80000fc0:	6605                	lui	a2,0x1
    80000fc2:	4581                	li	a1,0
    80000fc4:	ce5ff0ef          	jal	80000ca8 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80000fc8:	00c4d793          	srli	a5,s1,0xc
    80000fcc:	07aa                	slli	a5,a5,0xa
    80000fce:	0017e793          	ori	a5,a5,1
    80000fd2:	00f93023          	sd	a5,0(s2)
    80000fd6:	b775                	j	80000f82 <walk+0x40>
        return 0;
    80000fd8:	4501                	li	a0,0
    80000fda:	bf6d                	j	80000f94 <walk+0x52>

0000000080000fdc <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if (va >= MAXVA)
    80000fdc:	57fd                	li	a5,-1
    80000fde:	83e9                	srli	a5,a5,0x1a
    80000fe0:	00b7f463          	bgeu	a5,a1,80000fe8 <walkaddr+0xc>
    return 0;
    80000fe4:	4501                	li	a0,0
    return 0;
  if ((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80000fe6:	8082                	ret
{
    80000fe8:	1141                	addi	sp,sp,-16
    80000fea:	e406                	sd	ra,8(sp)
    80000fec:	e022                	sd	s0,0(sp)
    80000fee:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80000ff0:	4601                	li	a2,0
    80000ff2:	f51ff0ef          	jal	80000f42 <walk>
  if (pte == 0)
    80000ff6:	c901                	beqz	a0,80001006 <walkaddr+0x2a>
  if ((*pte & PTE_V) == 0)
    80000ff8:	611c                	ld	a5,0(a0)
  if ((*pte & PTE_U) == 0)
    80000ffa:	0117f693          	andi	a3,a5,17
    80000ffe:	4745                	li	a4,17
    return 0;
    80001000:	4501                	li	a0,0
  if ((*pte & PTE_U) == 0)
    80001002:	00e68663          	beq	a3,a4,8000100e <walkaddr+0x32>
}
    80001006:	60a2                	ld	ra,8(sp)
    80001008:	6402                	ld	s0,0(sp)
    8000100a:	0141                	addi	sp,sp,16
    8000100c:	8082                	ret
  pa = PTE2PA(*pte);
    8000100e:	83a9                	srli	a5,a5,0xa
    80001010:	00c79513          	slli	a0,a5,0xc
  return pa;
    80001014:	bfcd                	j	80001006 <walkaddr+0x2a>

0000000080001016 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001016:	715d                	addi	sp,sp,-80
    80001018:	e486                	sd	ra,72(sp)
    8000101a:	e0a2                	sd	s0,64(sp)
    8000101c:	fc26                	sd	s1,56(sp)
    8000101e:	f84a                	sd	s2,48(sp)
    80001020:	f44e                	sd	s3,40(sp)
    80001022:	f052                	sd	s4,32(sp)
    80001024:	ec56                	sd	s5,24(sp)
    80001026:	e85a                	sd	s6,16(sp)
    80001028:	e45e                	sd	s7,8(sp)
    8000102a:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    8000102c:	03459793          	slli	a5,a1,0x34
    80001030:	eba1                	bnez	a5,80001080 <mappages+0x6a>
    80001032:	8a2a                	mv	s4,a0
    80001034:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if ((size % PGSIZE) != 0)
    80001036:	03461793          	slli	a5,a2,0x34
    8000103a:	eba9                	bnez	a5,8000108c <mappages+0x76>
    panic("mappages: size not aligned");

  if (size == 0)
    8000103c:	ce31                	beqz	a2,80001098 <mappages+0x82>
    panic("mappages: size");

  a = va;
  last = va + size - PGSIZE;
    8000103e:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    80001042:	80060613          	addi	a2,a2,-2048
    80001046:	00b60933          	add	s2,a2,a1
  a = va;
    8000104a:	84ae                	mv	s1,a1
  for (;;) {
    if ((pte = walk(pagetable, a, 1)) == 0)
    8000104c:	4b05                	li	s6,1
    8000104e:	40b689b3          	sub	s3,a3,a1
    if (*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if (a == last)
      break;
    a += PGSIZE;
    80001052:	6b85                	lui	s7,0x1
    if ((pte = walk(pagetable, a, 1)) == 0)
    80001054:	865a                	mv	a2,s6
    80001056:	85a6                	mv	a1,s1
    80001058:	8552                	mv	a0,s4
    8000105a:	ee9ff0ef          	jal	80000f42 <walk>
    8000105e:	c929                	beqz	a0,800010b0 <mappages+0x9a>
    if (*pte & PTE_V)
    80001060:	611c                	ld	a5,0(a0)
    80001062:	8b85                	andi	a5,a5,1
    80001064:	e3a1                	bnez	a5,800010a4 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    80001066:	013487b3          	add	a5,s1,s3
    8000106a:	83b1                	srli	a5,a5,0xc
    8000106c:	07aa                	slli	a5,a5,0xa
    8000106e:	0157e7b3          	or	a5,a5,s5
    80001072:	0017e793          	ori	a5,a5,1
    80001076:	e11c                	sd	a5,0(a0)
    if (a == last)
    80001078:	05248863          	beq	s1,s2,800010c8 <mappages+0xb2>
    a += PGSIZE;
    8000107c:	94de                	add	s1,s1,s7
    if ((pte = walk(pagetable, a, 1)) == 0)
    8000107e:	bfd9                	j	80001054 <mappages+0x3e>
    panic("mappages: va not aligned");
    80001080:	00007517          	auipc	a0,0x7
    80001084:	03050513          	addi	a0,a0,48 # 800080b0 <etext+0xb0>
    80001088:	facff0ef          	jal	80000834 <panic>
    panic("mappages: size not aligned");
    8000108c:	00007517          	auipc	a0,0x7
    80001090:	04450513          	addi	a0,a0,68 # 800080d0 <etext+0xd0>
    80001094:	fa0ff0ef          	jal	80000834 <panic>
    panic("mappages: size");
    80001098:	00007517          	auipc	a0,0x7
    8000109c:	05850513          	addi	a0,a0,88 # 800080f0 <etext+0xf0>
    800010a0:	f94ff0ef          	jal	80000834 <panic>
      panic("mappages: remap");
    800010a4:	00007517          	auipc	a0,0x7
    800010a8:	05c50513          	addi	a0,a0,92 # 80008100 <etext+0x100>
    800010ac:	f88ff0ef          	jal	80000834 <panic>
      return -1;
    800010b0:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800010b2:	60a6                	ld	ra,72(sp)
    800010b4:	6406                	ld	s0,64(sp)
    800010b6:	74e2                	ld	s1,56(sp)
    800010b8:	7942                	ld	s2,48(sp)
    800010ba:	79a2                	ld	s3,40(sp)
    800010bc:	7a02                	ld	s4,32(sp)
    800010be:	6ae2                	ld	s5,24(sp)
    800010c0:	6b42                	ld	s6,16(sp)
    800010c2:	6ba2                	ld	s7,8(sp)
    800010c4:	6161                	addi	sp,sp,80
    800010c6:	8082                	ret
  return 0;
    800010c8:	4501                	li	a0,0
    800010ca:	b7e5                	j	800010b2 <mappages+0x9c>

00000000800010cc <kvmmap>:
{
    800010cc:	1141                	addi	sp,sp,-16
    800010ce:	e406                	sd	ra,8(sp)
    800010d0:	e022                	sd	s0,0(sp)
    800010d2:	0800                	addi	s0,sp,16
    800010d4:	87b6                	mv	a5,a3
  if (mappages(kpgtbl, va, sz, pa, perm) != 0)
    800010d6:	86b2                	mv	a3,a2
    800010d8:	863e                	mv	a2,a5
    800010da:	f3dff0ef          	jal	80001016 <mappages>
    800010de:	e509                	bnez	a0,800010e8 <kvmmap+0x1c>
}
    800010e0:	60a2                	ld	ra,8(sp)
    800010e2:	6402                	ld	s0,0(sp)
    800010e4:	0141                	addi	sp,sp,16
    800010e6:	8082                	ret
    panic("kvmmap");
    800010e8:	00007517          	auipc	a0,0x7
    800010ec:	02850513          	addi	a0,a0,40 # 80008110 <etext+0x110>
    800010f0:	f44ff0ef          	jal	80000834 <panic>

00000000800010f4 <kvmmake>:
{
    800010f4:	1101                	addi	sp,sp,-32
    800010f6:	ec06                	sd	ra,24(sp)
    800010f8:	e822                	sd	s0,16(sp)
    800010fa:	e426                	sd	s1,8(sp)
    800010fc:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t)kalloc();
    800010fe:	a11ff0ef          	jal	80000b0e <kalloc>
    80001102:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001104:	6605                	lui	a2,0x1
    80001106:	4581                	li	a1,0
    80001108:	ba1ff0ef          	jal	80000ca8 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000110c:	4719                	li	a4,6
    8000110e:	6685                	lui	a3,0x1
    80001110:	10000637          	lui	a2,0x10000
    80001114:	85b2                	mv	a1,a2
    80001116:	8526                	mv	a0,s1
    80001118:	fb5ff0ef          	jal	800010cc <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000111c:	4719                	li	a4,6
    8000111e:	6685                	lui	a3,0x1
    80001120:	10001637          	lui	a2,0x10001
    80001124:	85b2                	mv	a1,a2
    80001126:	8526                	mv	a0,s1
    80001128:	fa5ff0ef          	jal	800010cc <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000112c:	4719                	li	a4,6
    8000112e:	040006b7          	lui	a3,0x4000
    80001132:	0c000637          	lui	a2,0xc000
    80001136:	85b2                	mv	a1,a2
    80001138:	8526                	mv	a0,s1
    8000113a:	f93ff0ef          	jal	800010cc <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext - KERNBASE, PTE_R | PTE_X);
    8000113e:	4729                	li	a4,10
    80001140:	80007697          	auipc	a3,0x80007
    80001144:	ec068693          	addi	a3,a3,-320 # 8000 <_entry-0x7fff8000>
    80001148:	4605                	li	a2,1
    8000114a:	067e                	slli	a2,a2,0x1f
    8000114c:	85b2                	mv	a1,a2
    8000114e:	8526                	mv	a0,s1
    80001150:	f7dff0ef          	jal	800010cc <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP - (uint64)etext,
    80001154:	4719                	li	a4,6
    80001156:	00007697          	auipc	a3,0x7
    8000115a:	eaa68693          	addi	a3,a3,-342 # 80008000 <etext>
    8000115e:	47c5                	li	a5,17
    80001160:	07ee                	slli	a5,a5,0x1b
    80001162:	40d786b3          	sub	a3,a5,a3
    80001166:	00007617          	auipc	a2,0x7
    8000116a:	e9a60613          	addi	a2,a2,-358 # 80008000 <etext>
    8000116e:	85b2                	mv	a1,a2
    80001170:	8526                	mv	a0,s1
    80001172:	f5bff0ef          	jal	800010cc <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    80001176:	4729                	li	a4,10
    80001178:	6685                	lui	a3,0x1
    8000117a:	00006617          	auipc	a2,0x6
    8000117e:	e8660613          	addi	a2,a2,-378 # 80007000 <_trampoline>
    80001182:	040005b7          	lui	a1,0x4000
    80001186:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001188:	05b2                	slli	a1,a1,0xc
    8000118a:	8526                	mv	a0,s1
    8000118c:	f41ff0ef          	jal	800010cc <kvmmap>
  proc_mapstacks(kpgtbl);
    80001190:	8526                	mv	a0,s1
    80001192:	5ec000ef          	jal	8000177e <proc_mapstacks>
}
    80001196:	8526                	mv	a0,s1
    80001198:	60e2                	ld	ra,24(sp)
    8000119a:	6442                	ld	s0,16(sp)
    8000119c:	64a2                	ld	s1,8(sp)
    8000119e:	6105                	addi	sp,sp,32
    800011a0:	8082                	ret

00000000800011a2 <kvminit>:
{
    800011a2:	1141                	addi	sp,sp,-16
    800011a4:	e406                	sd	ra,8(sp)
    800011a6:	e022                	sd	s0,0(sp)
    800011a8:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800011aa:	f4bff0ef          	jal	800010f4 <kvmmake>
    800011ae:	0000a797          	auipc	a5,0xa
    800011b2:	52a7b123          	sd	a0,1314(a5) # 8000b6d0 <kernel_pagetable>
}
    800011b6:	60a2                	ld	ra,8(sp)
    800011b8:	6402                	ld	s0,0(sp)
    800011ba:	0141                	addi	sp,sp,16
    800011bc:	8082                	ret

00000000800011be <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800011be:	1101                	addi	sp,sp,-32
    800011c0:	ec06                	sd	ra,24(sp)
    800011c2:	e822                	sd	s0,16(sp)
    800011c4:	e426                	sd	s1,8(sp)
    800011c6:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t)kalloc();
    800011c8:	947ff0ef          	jal	80000b0e <kalloc>
    800011cc:	84aa                	mv	s1,a0
  if (pagetable == 0)
    800011ce:	c509                	beqz	a0,800011d8 <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800011d0:	6605                	lui	a2,0x1
    800011d2:	4581                	li	a1,0
    800011d4:	ad5ff0ef          	jal	80000ca8 <memset>
  return pagetable;
}
    800011d8:	8526                	mv	a0,s1
    800011da:	60e2                	ld	ra,24(sp)
    800011dc:	6442                	ld	s0,16(sp)
    800011de:	64a2                	ld	s1,8(sp)
    800011e0:	6105                	addi	sp,sp,32
    800011e2:	8082                	ret

00000000800011e4 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    800011e4:	7139                	addi	sp,sp,-64
    800011e6:	fc06                	sd	ra,56(sp)
    800011e8:	f822                	sd	s0,48(sp)
    800011ea:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if ((va % PGSIZE) != 0)
    800011ec:	03459793          	slli	a5,a1,0x34
    800011f0:	e38d                	bnez	a5,80001212 <uvmunmap+0x2e>
    800011f2:	f04a                	sd	s2,32(sp)
    800011f4:	ec4e                	sd	s3,24(sp)
    800011f6:	e852                	sd	s4,16(sp)
    800011f8:	e456                	sd	s5,8(sp)
    800011fa:	e05a                	sd	s6,0(sp)
    800011fc:	8a2a                	mv	s4,a0
    800011fe:	892e                	mv	s2,a1
    80001200:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    80001202:	0632                	slli	a2,a2,0xc
    80001204:	00b609b3          	add	s3,a2,a1
    80001208:	6b05                	lui	s6,0x1
    8000120a:	0535f963          	bgeu	a1,s3,8000125c <uvmunmap+0x78>
    8000120e:	f426                	sd	s1,40(sp)
    80001210:	a015                	j	80001234 <uvmunmap+0x50>
    80001212:	f426                	sd	s1,40(sp)
    80001214:	f04a                	sd	s2,32(sp)
    80001216:	ec4e                	sd	s3,24(sp)
    80001218:	e852                	sd	s4,16(sp)
    8000121a:	e456                	sd	s5,8(sp)
    8000121c:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    8000121e:	00007517          	auipc	a0,0x7
    80001222:	efa50513          	addi	a0,a0,-262 # 80008118 <etext+0x118>
    80001226:	e0eff0ef          	jal	80000834 <panic>
      continue;
    if (do_free) {
      uint64 pa = PTE2PA(*pte);
      kfree((void *)pa);
    }
    *pte = 0;
    8000122a:	0004b023          	sd	zero,0(s1)
  for (a = va; a < va + npages * PGSIZE; a += PGSIZE) {
    8000122e:	995a                	add	s2,s2,s6
    80001230:	03397563          	bgeu	s2,s3,8000125a <uvmunmap+0x76>
    if ((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    80001234:	4601                	li	a2,0
    80001236:	85ca                	mv	a1,s2
    80001238:	8552                	mv	a0,s4
    8000123a:	d09ff0ef          	jal	80000f42 <walk>
    8000123e:	84aa                	mv	s1,a0
    80001240:	d57d                	beqz	a0,8000122e <uvmunmap+0x4a>
    if ((*pte & PTE_V) == 0) // has physical page been allocated?
    80001242:	611c                	ld	a5,0(a0)
    80001244:	0017f713          	andi	a4,a5,1
    80001248:	d37d                	beqz	a4,8000122e <uvmunmap+0x4a>
    if (do_free) {
    8000124a:	fe0a80e3          	beqz	s5,8000122a <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    8000124e:	83a9                	srli	a5,a5,0xa
      kfree((void *)pa);
    80001250:	00c79513          	slli	a0,a5,0xc
    80001254:	fd2ff0ef          	jal	80000a26 <kfree>
    80001258:	bfc9                	j	8000122a <uvmunmap+0x46>
    8000125a:	74a2                	ld	s1,40(sp)
    8000125c:	7902                	ld	s2,32(sp)
    8000125e:	69e2                	ld	s3,24(sp)
    80001260:	6a42                	ld	s4,16(sp)
    80001262:	6aa2                	ld	s5,8(sp)
    80001264:	6b02                	ld	s6,0(sp)
  }
}
    80001266:	70e2                	ld	ra,56(sp)
    80001268:	7442                	ld	s0,48(sp)
    8000126a:	6121                	addi	sp,sp,64
    8000126c:	8082                	ret

000000008000126e <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    8000126e:	1101                	addi	sp,sp,-32
    80001270:	ec06                	sd	ra,24(sp)
    80001272:	e822                	sd	s0,16(sp)
    80001274:	e426                	sd	s1,8(sp)
    80001276:	1000                	addi	s0,sp,32
  if (newsz >= oldsz)
    return oldsz;
    80001278:	84ae                	mv	s1,a1
  if (newsz >= oldsz)
    8000127a:	00b67d63          	bgeu	a2,a1,80001294 <uvmdealloc+0x26>
    8000127e:	84b2                	mv	s1,a2

  if (PGROUNDUP(newsz) < PGROUNDUP(oldsz)) {
    80001280:	6785                	lui	a5,0x1
    80001282:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001284:	00f60733          	add	a4,a2,a5
    80001288:	76fd                	lui	a3,0xfffff
    8000128a:	8f75                	and	a4,a4,a3
    8000128c:	97ae                	add	a5,a5,a1
    8000128e:	8ff5                	and	a5,a5,a3
    80001290:	00f76863          	bltu	a4,a5,800012a0 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001294:	8526                	mv	a0,s1
    80001296:	60e2                	ld	ra,24(sp)
    80001298:	6442                	ld	s0,16(sp)
    8000129a:	64a2                	ld	s1,8(sp)
    8000129c:	6105                	addi	sp,sp,32
    8000129e:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800012a0:	8f99                	sub	a5,a5,a4
    800012a2:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800012a4:	4685                	li	a3,1
    800012a6:	0007861b          	sext.w	a2,a5
    800012aa:	85ba                	mv	a1,a4
    800012ac:	f39ff0ef          	jal	800011e4 <uvmunmap>
    800012b0:	b7d5                	j	80001294 <uvmdealloc+0x26>

00000000800012b2 <uvmalloc>:
  if (newsz < oldsz)
    800012b2:	0ab66163          	bltu	a2,a1,80001354 <uvmalloc+0xa2>
{
    800012b6:	715d                	addi	sp,sp,-80
    800012b8:	e486                	sd	ra,72(sp)
    800012ba:	e0a2                	sd	s0,64(sp)
    800012bc:	f84a                	sd	s2,48(sp)
    800012be:	f052                	sd	s4,32(sp)
    800012c0:	ec56                	sd	s5,24(sp)
    800012c2:	e45e                	sd	s7,8(sp)
    800012c4:	0880                	addi	s0,sp,80
    800012c6:	8aaa                	mv	s5,a0
    800012c8:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800012ca:	6785                	lui	a5,0x1
    800012cc:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012ce:	95be                	add	a1,a1,a5
    800012d0:	77fd                	lui	a5,0xfffff
    800012d2:	00f5f933          	and	s2,a1,a5
    800012d6:	8bca                	mv	s7,s2
  for (a = oldsz; a < newsz; a += PGSIZE) {
    800012d8:	08c97063          	bgeu	s2,a2,80001358 <uvmalloc+0xa6>
    800012dc:	fc26                	sd	s1,56(sp)
    800012de:	f44e                	sd	s3,40(sp)
    800012e0:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    800012e2:	6985                	lui	s3,0x1
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    800012e4:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800012e8:	827ff0ef          	jal	80000b0e <kalloc>
    800012ec:	84aa                	mv	s1,a0
    if (mem == 0) {
    800012ee:	c50d                	beqz	a0,80001318 <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    800012f0:	864e                	mv	a2,s3
    800012f2:	4581                	li	a1,0
    800012f4:	9b5ff0ef          	jal	80000ca8 <memset>
    if (mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R | PTE_U | xperm) !=
    800012f8:	875a                	mv	a4,s6
    800012fa:	86a6                	mv	a3,s1
    800012fc:	864e                	mv	a2,s3
    800012fe:	85ca                	mv	a1,s2
    80001300:	8556                	mv	a0,s5
    80001302:	d15ff0ef          	jal	80001016 <mappages>
    80001306:	e915                	bnez	a0,8000133a <uvmalloc+0x88>
  for (a = oldsz; a < newsz; a += PGSIZE) {
    80001308:	994e                	add	s2,s2,s3
    8000130a:	fd496fe3          	bltu	s2,s4,800012e8 <uvmalloc+0x36>
  return newsz;
    8000130e:	8552                	mv	a0,s4
    80001310:	74e2                	ld	s1,56(sp)
    80001312:	79a2                	ld	s3,40(sp)
    80001314:	6b42                	ld	s6,16(sp)
    80001316:	a811                	j	8000132a <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    80001318:	865e                	mv	a2,s7
    8000131a:	85ca                	mv	a1,s2
    8000131c:	8556                	mv	a0,s5
    8000131e:	f51ff0ef          	jal	8000126e <uvmdealloc>
      return 0;
    80001322:	4501                	li	a0,0
    80001324:	74e2                	ld	s1,56(sp)
    80001326:	79a2                	ld	s3,40(sp)
    80001328:	6b42                	ld	s6,16(sp)
}
    8000132a:	60a6                	ld	ra,72(sp)
    8000132c:	6406                	ld	s0,64(sp)
    8000132e:	7942                	ld	s2,48(sp)
    80001330:	7a02                	ld	s4,32(sp)
    80001332:	6ae2                	ld	s5,24(sp)
    80001334:	6ba2                	ld	s7,8(sp)
    80001336:	6161                	addi	sp,sp,80
    80001338:	8082                	ret
      kfree(mem);
    8000133a:	8526                	mv	a0,s1
    8000133c:	eeaff0ef          	jal	80000a26 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001340:	865e                	mv	a2,s7
    80001342:	85ca                	mv	a1,s2
    80001344:	8556                	mv	a0,s5
    80001346:	f29ff0ef          	jal	8000126e <uvmdealloc>
      return 0;
    8000134a:	4501                	li	a0,0
    8000134c:	74e2                	ld	s1,56(sp)
    8000134e:	79a2                	ld	s3,40(sp)
    80001350:	6b42                	ld	s6,16(sp)
    80001352:	bfe1                	j	8000132a <uvmalloc+0x78>
    return oldsz;
    80001354:	852e                	mv	a0,a1
}
    80001356:	8082                	ret
  return newsz;
    80001358:	8532                	mv	a0,a2
    8000135a:	bfc1                	j	8000132a <uvmalloc+0x78>

000000008000135c <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000135c:	7179                	addi	sp,sp,-48
    8000135e:	f406                	sd	ra,40(sp)
    80001360:	f022                	sd	s0,32(sp)
    80001362:	ec26                	sd	s1,24(sp)
    80001364:	e84a                	sd	s2,16(sp)
    80001366:	e44e                	sd	s3,8(sp)
    80001368:	1800                	addi	s0,sp,48
    8000136a:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for (int i = 0; i < 512; i++) {
    8000136c:	84aa                	mv	s1,a0
    8000136e:	6905                	lui	s2,0x1
    80001370:	992a                	add	s2,s2,a0
    80001372:	a811                	j	80001386 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if (pte & PTE_V) {
      panic("freewalk: leaf");
    80001374:	00007517          	auipc	a0,0x7
    80001378:	dbc50513          	addi	a0,a0,-580 # 80008130 <etext+0x130>
    8000137c:	cb8ff0ef          	jal	80000834 <panic>
  for (int i = 0; i < 512; i++) {
    80001380:	04a1                	addi	s1,s1,8
    80001382:	03248163          	beq	s1,s2,800013a4 <freewalk+0x48>
    pte_t pte = pagetable[i];
    80001386:	609c                	ld	a5,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    80001388:	0017f713          	andi	a4,a5,1
    8000138c:	db75                	beqz	a4,80001380 <freewalk+0x24>
    8000138e:	00e7f713          	andi	a4,a5,14
    80001392:	f36d                	bnez	a4,80001374 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80001394:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001396:	00c79513          	slli	a0,a5,0xc
    8000139a:	fc3ff0ef          	jal	8000135c <freewalk>
      pagetable[i] = 0;
    8000139e:	0004b023          	sd	zero,0(s1)
    if ((pte & PTE_V) && (pte & (PTE_R | PTE_W | PTE_X)) == 0) {
    800013a2:	bff9                	j	80001380 <freewalk+0x24>
    }
  }
  kfree((void *)pagetable);
    800013a4:	854e                	mv	a0,s3
    800013a6:	e80ff0ef          	jal	80000a26 <kfree>
}
    800013aa:	70a2                	ld	ra,40(sp)
    800013ac:	7402                	ld	s0,32(sp)
    800013ae:	64e2                	ld	s1,24(sp)
    800013b0:	6942                	ld	s2,16(sp)
    800013b2:	69a2                	ld	s3,8(sp)
    800013b4:	6145                	addi	sp,sp,48
    800013b6:	8082                	ret

00000000800013b8 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800013b8:	1101                	addi	sp,sp,-32
    800013ba:	ec06                	sd	ra,24(sp)
    800013bc:	e822                	sd	s0,16(sp)
    800013be:	e426                	sd	s1,8(sp)
    800013c0:	1000                	addi	s0,sp,32
    800013c2:	84aa                	mv	s1,a0
  if (sz > 0)
    800013c4:	e989                	bnez	a1,800013d6 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
  freewalk(pagetable);
    800013c6:	8526                	mv	a0,s1
    800013c8:	f95ff0ef          	jal	8000135c <freewalk>
}
    800013cc:	60e2                	ld	ra,24(sp)
    800013ce:	6442                	ld	s0,16(sp)
    800013d0:	64a2                	ld	s1,8(sp)
    800013d2:	6105                	addi	sp,sp,32
    800013d4:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz) / PGSIZE, 1);
    800013d6:	6785                	lui	a5,0x1
    800013d8:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013da:	95be                	add	a1,a1,a5
    800013dc:	4685                	li	a3,1
    800013de:	00c5d613          	srli	a2,a1,0xc
    800013e2:	4581                	li	a1,0
    800013e4:	e01ff0ef          	jal	800011e4 <uvmunmap>
    800013e8:	bff9                	j	800013c6 <uvmfree+0xe>

00000000800013ea <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for (i = 0; i < sz; i += PGSIZE) {
    800013ea:	ca59                	beqz	a2,80001480 <uvmcopy+0x96>
{
    800013ec:	715d                	addi	sp,sp,-80
    800013ee:	e486                	sd	ra,72(sp)
    800013f0:	e0a2                	sd	s0,64(sp)
    800013f2:	fc26                	sd	s1,56(sp)
    800013f4:	f84a                	sd	s2,48(sp)
    800013f6:	f44e                	sd	s3,40(sp)
    800013f8:	f052                	sd	s4,32(sp)
    800013fa:	ec56                	sd	s5,24(sp)
    800013fc:	e85a                	sd	s6,16(sp)
    800013fe:	e45e                	sd	s7,8(sp)
    80001400:	0880                	addi	s0,sp,80
    80001402:	8b2a                	mv	s6,a0
    80001404:	8bae                	mv	s7,a1
    80001406:	8ab2                	mv	s5,a2
  for (i = 0; i < sz; i += PGSIZE) {
    80001408:	4481                	li	s1,0
      continue; // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if ((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char *)pa, PGSIZE);
    8000140a:	6a05                	lui	s4,0x1
    8000140c:	a021                	j	80001414 <uvmcopy+0x2a>
  for (i = 0; i < sz; i += PGSIZE) {
    8000140e:	94d2                	add	s1,s1,s4
    80001410:	0554fc63          	bgeu	s1,s5,80001468 <uvmcopy+0x7e>
    if ((pte = walk(old, i, 0)) == 0)
    80001414:	4601                	li	a2,0
    80001416:	85a6                	mv	a1,s1
    80001418:	855a                	mv	a0,s6
    8000141a:	b29ff0ef          	jal	80000f42 <walk>
    8000141e:	d965                	beqz	a0,8000140e <uvmcopy+0x24>
    if ((*pte & PTE_V) == 0)
    80001420:	00053983          	ld	s3,0(a0)
    80001424:	0019f793          	andi	a5,s3,1
    80001428:	d3fd                	beqz	a5,8000140e <uvmcopy+0x24>
    if ((mem = kalloc()) == 0)
    8000142a:	ee4ff0ef          	jal	80000b0e <kalloc>
    8000142e:	892a                	mv	s2,a0
    80001430:	c11d                	beqz	a0,80001456 <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    80001432:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char *)pa, PGSIZE);
    80001436:	8652                	mv	a2,s4
    80001438:	05b2                	slli	a1,a1,0xc
    8000143a:	8cfff0ef          	jal	80000d08 <memmove>
    if (mappages(new, i, PGSIZE, (uint64)mem, flags) != 0) {
    8000143e:	3ff9f713          	andi	a4,s3,1023
    80001442:	86ca                	mv	a3,s2
    80001444:	8652                	mv	a2,s4
    80001446:	85a6                	mv	a1,s1
    80001448:	855e                	mv	a0,s7
    8000144a:	bcdff0ef          	jal	80001016 <mappages>
    8000144e:	d161                	beqz	a0,8000140e <uvmcopy+0x24>
      kfree(mem);
    80001450:	854a                	mv	a0,s2
    80001452:	dd4ff0ef          	jal	80000a26 <kfree>
    }
  }
  return 0;

err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001456:	4685                	li	a3,1
    80001458:	00c4d613          	srli	a2,s1,0xc
    8000145c:	4581                	li	a1,0
    8000145e:	855e                	mv	a0,s7
    80001460:	d85ff0ef          	jal	800011e4 <uvmunmap>
  return -1;
    80001464:	557d                	li	a0,-1
    80001466:	a011                	j	8000146a <uvmcopy+0x80>
  return 0;
    80001468:	4501                	li	a0,0
}
    8000146a:	60a6                	ld	ra,72(sp)
    8000146c:	6406                	ld	s0,64(sp)
    8000146e:	74e2                	ld	s1,56(sp)
    80001470:	7942                	ld	s2,48(sp)
    80001472:	79a2                	ld	s3,40(sp)
    80001474:	7a02                	ld	s4,32(sp)
    80001476:	6ae2                	ld	s5,24(sp)
    80001478:	6b42                	ld	s6,16(sp)
    8000147a:	6ba2                	ld	s7,8(sp)
    8000147c:	6161                	addi	sp,sp,80
    8000147e:	8082                	ret
  return 0;
    80001480:	4501                	li	a0,0
}
    80001482:	8082                	ret

0000000080001484 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001484:	1141                	addi	sp,sp,-16
    80001486:	e406                	sd	ra,8(sp)
    80001488:	e022                	sd	s0,0(sp)
    8000148a:	0800                	addi	s0,sp,16
  pte_t *pte;

  pte = walk(pagetable, va, 0);
    8000148c:	4601                	li	a2,0
    8000148e:	ab5ff0ef          	jal	80000f42 <walk>
  if (pte == 0)
    80001492:	c901                	beqz	a0,800014a2 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001494:	611c                	ld	a5,0(a0)
    80001496:	9bbd                	andi	a5,a5,-17
    80001498:	e11c                	sd	a5,0(a0)
}
    8000149a:	60a2                	ld	ra,8(sp)
    8000149c:	6402                	ld	s0,0(sp)
    8000149e:	0141                	addi	sp,sp,16
    800014a0:	8082                	ret
    panic("uvmclear");
    800014a2:	00007517          	auipc	a0,0x7
    800014a6:	c9e50513          	addi	a0,a0,-866 # 80008140 <etext+0x140>
    800014aa:	b8aff0ef          	jal	80000834 <panic>

00000000800014ae <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800014ae:	1141                	addi	sp,sp,-16
    800014b0:	e406                	sd	ra,8(sp)
    800014b2:	e022                	sd	s0,0(sp)
    800014b4:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800014b6:	4601                	li	a2,0
    800014b8:	a8bff0ef          	jal	80000f42 <walk>
  if (pte == 0) {
    800014bc:	c119                	beqz	a0,800014c2 <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V) {
    800014be:	6108                	ld	a0,0(a0)
    800014c0:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800014c2:	60a2                	ld	ra,8(sp)
    800014c4:	6402                	ld	s0,0(sp)
    800014c6:	0141                	addi	sp,sp,16
    800014c8:	8082                	ret

00000000800014ca <vmfault>:
{
    800014ca:	7179                	addi	sp,sp,-48
    800014cc:	f406                	sd	ra,40(sp)
    800014ce:	f022                	sd	s0,32(sp)
    800014d0:	e052                	sd	s4,0(sp)
    800014d2:	1800                	addi	s0,sp,48
    return 0;
    800014d4:	4a01                	li	s4,0
  if (va >= psz)
    800014d6:	00b66863          	bltu	a2,a1,800014e6 <vmfault+0x1c>
}
    800014da:	8552                	mv	a0,s4
    800014dc:	70a2                	ld	ra,40(sp)
    800014de:	7402                	ld	s0,32(sp)
    800014e0:	6a02                	ld	s4,0(sp)
    800014e2:	6145                	addi	sp,sp,48
    800014e4:	8082                	ret
    800014e6:	ec26                	sd	s1,24(sp)
    800014e8:	e44e                	sd	s3,8(sp)
    800014ea:	84aa                	mv	s1,a0
  va = PGROUNDDOWN(va);
    800014ec:	77fd                	lui	a5,0xfffff
    800014ee:	00f679b3          	and	s3,a2,a5
  if (ismapped(pagetable, va)) {
    800014f2:	85ce                	mv	a1,s3
    800014f4:	fbbff0ef          	jal	800014ae <ismapped>
    return 0;
    800014f8:	4a01                	li	s4,0
  if (ismapped(pagetable, va)) {
    800014fa:	c501                	beqz	a0,80001502 <vmfault+0x38>
    800014fc:	64e2                	ld	s1,24(sp)
    800014fe:	69a2                	ld	s3,8(sp)
    80001500:	bfe9                	j	800014da <vmfault+0x10>
    80001502:	e84a                	sd	s2,16(sp)
  mem = (uint64)kalloc();
    80001504:	e0aff0ef          	jal	80000b0e <kalloc>
    80001508:	892a                	mv	s2,a0
  if (mem == 0)
    8000150a:	c915                	beqz	a0,8000153e <vmfault+0x74>
  mem = (uint64)kalloc();
    8000150c:	8a2a                	mv	s4,a0
  memset((void *)mem, 0, PGSIZE);
    8000150e:	6605                	lui	a2,0x1
    80001510:	4581                	li	a1,0
    80001512:	f96ff0ef          	jal	80000ca8 <memset>
  if (mappages(pagetable, va, PGSIZE, mem, PTE_W | PTE_U | PTE_R) != 0) {
    80001516:	4759                	li	a4,22
    80001518:	86ca                	mv	a3,s2
    8000151a:	6605                	lui	a2,0x1
    8000151c:	85ce                	mv	a1,s3
    8000151e:	8526                	mv	a0,s1
    80001520:	af7ff0ef          	jal	80001016 <mappages>
    80001524:	e509                	bnez	a0,8000152e <vmfault+0x64>
    80001526:	64e2                	ld	s1,24(sp)
    80001528:	6942                	ld	s2,16(sp)
    8000152a:	69a2                	ld	s3,8(sp)
    8000152c:	b77d                	j	800014da <vmfault+0x10>
    kfree((void *)mem);
    8000152e:	854a                	mv	a0,s2
    80001530:	cf6ff0ef          	jal	80000a26 <kfree>
    return 0;
    80001534:	4a01                	li	s4,0
    80001536:	64e2                	ld	s1,24(sp)
    80001538:	6942                	ld	s2,16(sp)
    8000153a:	69a2                	ld	s3,8(sp)
    8000153c:	bf79                	j	800014da <vmfault+0x10>
    8000153e:	64e2                	ld	s1,24(sp)
    80001540:	6942                	ld	s2,16(sp)
    80001542:	69a2                	ld	s3,8(sp)
    80001544:	bf59                	j	800014da <vmfault+0x10>

0000000080001546 <copyout>:
  while (len > 0) {
    80001546:	cf49                	beqz	a4,800015e0 <copyout+0x9a>
{
    80001548:	7159                	addi	sp,sp,-112
    8000154a:	f486                	sd	ra,104(sp)
    8000154c:	f0a2                	sd	s0,96(sp)
    8000154e:	eca6                	sd	s1,88(sp)
    80001550:	e8ca                	sd	s2,80(sp)
    80001552:	e4ce                	sd	s3,72(sp)
    80001554:	e0d2                	sd	s4,64(sp)
    80001556:	fc56                	sd	s5,56(sp)
    80001558:	f85a                	sd	s6,48(sp)
    8000155a:	f45e                	sd	s7,40(sp)
    8000155c:	f062                	sd	s8,32(sp)
    8000155e:	ec66                	sd	s9,24(sp)
    80001560:	e86a                	sd	s10,16(sp)
    80001562:	e46e                	sd	s11,8(sp)
    80001564:	1880                	addi	s0,sp,112
    80001566:	8baa                	mv	s7,a0
    80001568:	8dae                	mv	s11,a1
    8000156a:	8a32                	mv	s4,a2
    8000156c:	8b36                	mv	s6,a3
    8000156e:	8aba                	mv	s5,a4
    va0 = PGROUNDDOWN(dstva);
    80001570:	7d7d                	lui	s10,0xfffff
    if (va0 >= MAXVA)
    80001572:	5cfd                	li	s9,-1
    80001574:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    80001578:	6c05                	lui	s8,0x1
    8000157a:	a005                	j	8000159a <copyout+0x54>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    8000157c:	409a0533          	sub	a0,s4,s1
    80001580:	0009061b          	sext.w	a2,s2
    80001584:	85da                	mv	a1,s6
    80001586:	954e                	add	a0,a0,s3
    80001588:	f80ff0ef          	jal	80000d08 <memmove>
    len -= n;
    8000158c:	412a8ab3          	sub	s5,s5,s2
    src += n;
    80001590:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    80001592:	01848a33          	add	s4,s1,s8
  while (len > 0) {
    80001596:	040a8363          	beqz	s5,800015dc <copyout+0x96>
    va0 = PGROUNDDOWN(dstva);
    8000159a:	01aa74b3          	and	s1,s4,s10
    if (va0 >= MAXVA)
    8000159e:	049ce363          	bltu	s9,s1,800015e4 <copyout+0x9e>
    pa0 = walkaddr(pagetable, va0);
    800015a2:	85a6                	mv	a1,s1
    800015a4:	855e                	mv	a0,s7
    800015a6:	a37ff0ef          	jal	80000fdc <walkaddr>
    800015aa:	89aa                	mv	s3,a0
    if (pa0 == 0) {
    800015ac:	e909                	bnez	a0,800015be <copyout+0x78>
      if ((pa0 = vmfault(pagetable, psz, va0, 0)) == 0) {
    800015ae:	4681                	li	a3,0
    800015b0:	8626                	mv	a2,s1
    800015b2:	85ee                	mv	a1,s11
    800015b4:	855e                	mv	a0,s7
    800015b6:	f15ff0ef          	jal	800014ca <vmfault>
    800015ba:	89aa                	mv	s3,a0
    800015bc:	c521                	beqz	a0,80001604 <copyout+0xbe>
    pte = walk(pagetable, va0, 0);
    800015be:	4601                	li	a2,0
    800015c0:	85a6                	mv	a1,s1
    800015c2:	855e                	mv	a0,s7
    800015c4:	97fff0ef          	jal	80000f42 <walk>
    if ((*pte & PTE_W) == 0)
    800015c8:	611c                	ld	a5,0(a0)
    800015ca:	8b91                	andi	a5,a5,4
    800015cc:	cf95                	beqz	a5,80001608 <copyout+0xc2>
    n = PGSIZE - (dstva - va0);
    800015ce:	41448933          	sub	s2,s1,s4
    800015d2:	9962                	add	s2,s2,s8
    if (n > len)
    800015d4:	fb2af4e3          	bgeu	s5,s2,8000157c <copyout+0x36>
    800015d8:	8956                	mv	s2,s5
    800015da:	b74d                	j	8000157c <copyout+0x36>
  return 0;
    800015dc:	4501                	li	a0,0
    800015de:	a021                	j	800015e6 <copyout+0xa0>
    800015e0:	4501                	li	a0,0
}
    800015e2:	8082                	ret
      return -1;
    800015e4:	557d                	li	a0,-1
}
    800015e6:	70a6                	ld	ra,104(sp)
    800015e8:	7406                	ld	s0,96(sp)
    800015ea:	64e6                	ld	s1,88(sp)
    800015ec:	6946                	ld	s2,80(sp)
    800015ee:	69a6                	ld	s3,72(sp)
    800015f0:	6a06                	ld	s4,64(sp)
    800015f2:	7ae2                	ld	s5,56(sp)
    800015f4:	7b42                	ld	s6,48(sp)
    800015f6:	7ba2                	ld	s7,40(sp)
    800015f8:	7c02                	ld	s8,32(sp)
    800015fa:	6ce2                	ld	s9,24(sp)
    800015fc:	6d42                	ld	s10,16(sp)
    800015fe:	6da2                	ld	s11,8(sp)
    80001600:	6165                	addi	sp,sp,112
    80001602:	8082                	ret
        return -1;
    80001604:	557d                	li	a0,-1
    80001606:	b7c5                	j	800015e6 <copyout+0xa0>
      return -1;
    80001608:	557d                	li	a0,-1
    8000160a:	bff1                	j	800015e6 <copyout+0xa0>

000000008000160c <copyin>:
  while (len > 0) {
    8000160c:	cf41                	beqz	a4,800016a4 <copyin+0x98>
{
    8000160e:	711d                	addi	sp,sp,-96
    80001610:	ec86                	sd	ra,88(sp)
    80001612:	e8a2                	sd	s0,80(sp)
    80001614:	e4a6                	sd	s1,72(sp)
    80001616:	e0ca                	sd	s2,64(sp)
    80001618:	fc4e                	sd	s3,56(sp)
    8000161a:	f852                	sd	s4,48(sp)
    8000161c:	f456                	sd	s5,40(sp)
    8000161e:	f05a                	sd	s6,32(sp)
    80001620:	ec5e                	sd	s7,24(sp)
    80001622:	e862                	sd	s8,16(sp)
    80001624:	e466                	sd	s9,8(sp)
    80001626:	e06a                	sd	s10,0(sp)
    80001628:	1080                	addi	s0,sp,96
    8000162a:	8baa                	mv	s7,a0
    8000162c:	8cae                	mv	s9,a1
    8000162e:	8ab2                	mv	s5,a2
    80001630:	8936                	mv	s2,a3
    80001632:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    80001634:	7c7d                	lui	s8,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001636:	4d05                	li	s10,1
    n = PGSIZE - (srcva - va0);
    80001638:	6b05                	lui	s6,0x1
    8000163a:	a035                	j	80001666 <copyin+0x5a>
    8000163c:	412984b3          	sub	s1,s3,s2
    80001640:	94da                	add	s1,s1,s6
    if (n > len)
    80001642:	009a7363          	bgeu	s4,s1,80001648 <copyin+0x3c>
    80001646:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001648:	413905b3          	sub	a1,s2,s3
    8000164c:	0004861b          	sext.w	a2,s1
    80001650:	95aa                	add	a1,a1,a0
    80001652:	8556                	mv	a0,s5
    80001654:	eb4ff0ef          	jal	80000d08 <memmove>
    len -= n;
    80001658:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000165c:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    8000165e:	01698933          	add	s2,s3,s6
  while (len > 0) {
    80001662:	020a0263          	beqz	s4,80001686 <copyin+0x7a>
    va0 = PGROUNDDOWN(srcva);
    80001666:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    8000166a:	85ce                	mv	a1,s3
    8000166c:	855e                	mv	a0,s7
    8000166e:	96fff0ef          	jal	80000fdc <walkaddr>
    if (pa0 == 0) {
    80001672:	f569                	bnez	a0,8000163c <copyin+0x30>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    80001674:	86ea                	mv	a3,s10
    80001676:	864e                	mv	a2,s3
    80001678:	85e6                	mv	a1,s9
    8000167a:	855e                	mv	a0,s7
    8000167c:	e4fff0ef          	jal	800014ca <vmfault>
    80001680:	fd55                	bnez	a0,8000163c <copyin+0x30>
        return -1;
    80001682:	557d                	li	a0,-1
    80001684:	a011                	j	80001688 <copyin+0x7c>
  return 0;
    80001686:	4501                	li	a0,0
}
    80001688:	60e6                	ld	ra,88(sp)
    8000168a:	6446                	ld	s0,80(sp)
    8000168c:	64a6                	ld	s1,72(sp)
    8000168e:	6906                	ld	s2,64(sp)
    80001690:	79e2                	ld	s3,56(sp)
    80001692:	7a42                	ld	s4,48(sp)
    80001694:	7aa2                	ld	s5,40(sp)
    80001696:	7b02                	ld	s6,32(sp)
    80001698:	6be2                	ld	s7,24(sp)
    8000169a:	6c42                	ld	s8,16(sp)
    8000169c:	6ca2                	ld	s9,8(sp)
    8000169e:	6d02                	ld	s10,0(sp)
    800016a0:	6125                	addi	sp,sp,96
    800016a2:	8082                	ret
  return 0;
    800016a4:	4501                	li	a0,0
}
    800016a6:	8082                	ret

00000000800016a8 <copyinstr>:
  while (got_null == 0 && max > 0) {
    800016a8:	c769                	beqz	a4,80001772 <copyinstr+0xca>
{
    800016aa:	711d                	addi	sp,sp,-96
    800016ac:	ec86                	sd	ra,88(sp)
    800016ae:	e8a2                	sd	s0,80(sp)
    800016b0:	e4a6                	sd	s1,72(sp)
    800016b2:	e0ca                	sd	s2,64(sp)
    800016b4:	fc4e                	sd	s3,56(sp)
    800016b6:	f852                	sd	s4,48(sp)
    800016b8:	f456                	sd	s5,40(sp)
    800016ba:	f05a                	sd	s6,32(sp)
    800016bc:	ec5e                	sd	s7,24(sp)
    800016be:	e862                	sd	s8,16(sp)
    800016c0:	e466                	sd	s9,8(sp)
    800016c2:	1080                	addi	s0,sp,96
    800016c4:	8b2a                	mv	s6,a0
    800016c6:	8c2e                	mv	s8,a1
    800016c8:	89b2                	mv	s3,a2
    800016ca:	84b6                	mv	s1,a3
    800016cc:	8a3a                	mv	s4,a4
    va0 = PGROUNDDOWN(srcva);
    800016ce:	7bfd                	lui	s7,0xfffff
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016d0:	4c85                	li	s9,1
    n = PGSIZE - (srcva - va0);
    800016d2:	6a85                	lui	s5,0x1
    800016d4:	a881                	j	80001724 <copyinstr+0x7c>
      if ((pa0 = vmfault(pagetable, psz, va0, 1)) == 0) {
    800016d6:	86e6                	mv	a3,s9
    800016d8:	864a                	mv	a2,s2
    800016da:	85e2                	mv	a1,s8
    800016dc:	855a                	mv	a0,s6
    800016de:	dedff0ef          	jal	800014ca <vmfault>
    800016e2:	e921                	bnez	a0,80001732 <copyinstr+0x8a>
        return -1;
    800016e4:	557d                	li	a0,-1
    800016e6:	a801                	j	800016f6 <copyinstr+0x4e>
        *dst = '\0';
    800016e8:	00078023          	sb	zero,0(a5) # fffffffffffff000 <end+0xffffffff7ffd9e98>
        got_null = 1;
    800016ec:	4785                	li	a5,1
  if (got_null) {
    800016ee:	0017c793          	xori	a5,a5,1
    800016f2:	40f0053b          	negw	a0,a5
}
    800016f6:	60e6                	ld	ra,88(sp)
    800016f8:	6446                	ld	s0,80(sp)
    800016fa:	64a6                	ld	s1,72(sp)
    800016fc:	6906                	ld	s2,64(sp)
    800016fe:	79e2                	ld	s3,56(sp)
    80001700:	7a42                	ld	s4,48(sp)
    80001702:	7aa2                	ld	s5,40(sp)
    80001704:	7b02                	ld	s6,32(sp)
    80001706:	6be2                	ld	s7,24(sp)
    80001708:	6c42                	ld	s8,16(sp)
    8000170a:	6ca2                	ld	s9,8(sp)
    8000170c:	6125                	addi	sp,sp,96
    8000170e:	8082                	ret
    80001710:	fffa0713          	addi	a4,s4,-1 # fff <_entry-0x7ffff001>
    80001714:	974e                	add	a4,a4,s3
      --max;
    80001716:	40b70a33          	sub	s4,a4,a1
    srcva = va0 + PGSIZE;
    8000171a:	015904b3          	add	s1,s2,s5
  while (got_null == 0 && max > 0) {
    8000171e:	04e58463          	beq	a1,a4,80001766 <copyinstr+0xbe>
{
    80001722:	89be                	mv	s3,a5
    va0 = PGROUNDDOWN(srcva);
    80001724:	0174f933          	and	s2,s1,s7
    pa0 = walkaddr(pagetable, va0);
    80001728:	85ca                	mv	a1,s2
    8000172a:	855a                	mv	a0,s6
    8000172c:	8b1ff0ef          	jal	80000fdc <walkaddr>
    if (pa0 == 0) {
    80001730:	d15d                	beqz	a0,800016d6 <copyinstr+0x2e>
    n = PGSIZE - (srcva - va0);
    80001732:	40990633          	sub	a2,s2,s1
    80001736:	9656                	add	a2,a2,s5
    if (n > max)
    80001738:	00ca7363          	bgeu	s4,a2,8000173e <copyinstr+0x96>
    8000173c:	8652                	mv	a2,s4
    while (n > 0) {
    8000173e:	c615                	beqz	a2,8000176a <copyinstr+0xc2>
    char *p = (char *)(pa0 + (srcva - va0));
    80001740:	412484b3          	sub	s1,s1,s2
    80001744:	94aa                	add	s1,s1,a0
    80001746:	87ce                	mv	a5,s3
      if (*p == '\0') {
    80001748:	413484b3          	sub	s1,s1,s3
    while (n > 0) {
    8000174c:	964e                	add	a2,a2,s3
    8000174e:	85be                	mv	a1,a5
      if (*p == '\0') {
    80001750:	00f48733          	add	a4,s1,a5
    80001754:	00074683          	lbu	a3,0(a4)
    80001758:	dac1                	beqz	a3,800016e8 <copyinstr+0x40>
        *dst = *p;
    8000175a:	00d78023          	sb	a3,0(a5)
      dst++;
    8000175e:	0785                	addi	a5,a5,1
    while (n > 0) {
    80001760:	fec797e3          	bne	a5,a2,8000174e <copyinstr+0xa6>
    80001764:	b775                	j	80001710 <copyinstr+0x68>
    80001766:	4781                	li	a5,0
    80001768:	b759                	j	800016ee <copyinstr+0x46>
    srcva = va0 + PGSIZE;
    8000176a:	6485                	lui	s1,0x1
    8000176c:	94ca                	add	s1,s1,s2
    8000176e:	87ce                	mv	a5,s3
    80001770:	bf4d                	j	80001722 <copyinstr+0x7a>
  int got_null = 0;
    80001772:	4781                	li	a5,0
  if (got_null) {
    80001774:	0017c793          	xori	a5,a5,1
    80001778:	40f0053b          	negw	a0,a5
}
    8000177c:	8082                	ret

000000008000177e <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    8000177e:	715d                	addi	sp,sp,-80
    80001780:	e486                	sd	ra,72(sp)
    80001782:	e0a2                	sd	s0,64(sp)
    80001784:	fc26                	sd	s1,56(sp)
    80001786:	f84a                	sd	s2,48(sp)
    80001788:	f44e                	sd	s3,40(sp)
    8000178a:	f052                	sd	s4,32(sp)
    8000178c:	ec56                	sd	s5,24(sp)
    8000178e:	e85a                	sd	s6,16(sp)
    80001790:	e45e                	sd	s7,8(sp)
    80001792:	e062                	sd	s8,0(sp)
    80001794:	0880                	addi	s0,sp,80
    80001796:	8a2a                	mv	s4,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    80001798:	00012497          	auipc	s1,0x12
    8000179c:	49848493          	addi	s1,s1,1176 # 80013c30 <proc>
    char *pa = kalloc();
    if (pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int)(p - proc));
    800017a0:	8c26                	mv	s8,s1
    800017a2:	aaaab7b7          	lui	a5,0xaaaab
    800017a6:	aab78793          	addi	a5,a5,-1365 # ffffffffaaaaaaab <end+0xffffffff2aa85943>
    800017aa:	02079993          	slli	s3,a5,0x20
    800017ae:	99be                	add	s3,s3,a5
    800017b0:	04000937          	lui	s2,0x4000
    800017b4:	197d                	addi	s2,s2,-1 # 3ffffff <_entry-0x7c000001>
    800017b6:	0932                	slli	s2,s2,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017b8:	4b99                	li	s7,6
    800017ba:	6b05                	lui	s6,0x1
  for (p = proc; p < &proc[NPROC]; p++) {
    800017bc:	00018a97          	auipc	s5,0x18
    800017c0:	474a8a93          	addi	s5,s5,1140 # 80019c30 <semtable_lock>
    char *pa = kalloc();
    800017c4:	b4aff0ef          	jal	80000b0e <kalloc>
    800017c8:	862a                	mv	a2,a0
    if (pa == 0)
    800017ca:	c121                	beqz	a0,8000180a <proc_mapstacks+0x8c>
    uint64 va = KSTACK((int)(p - proc));
    800017cc:	418485b3          	sub	a1,s1,s8
    800017d0:	859d                	srai	a1,a1,0x7
    800017d2:	033585b3          	mul	a1,a1,s3
    800017d6:	05b6                	slli	a1,a1,0xd
    800017d8:	6789                	lui	a5,0x2
    800017da:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017dc:	875e                	mv	a4,s7
    800017de:	86da                	mv	a3,s6
    800017e0:	40b905b3          	sub	a1,s2,a1
    800017e4:	8552                	mv	a0,s4
    800017e6:	8e7ff0ef          	jal	800010cc <kvmmap>
  for (p = proc; p < &proc[NPROC]; p++) {
    800017ea:	18048493          	addi	s1,s1,384
    800017ee:	fd549be3          	bne	s1,s5,800017c4 <proc_mapstacks+0x46>
  }
}
    800017f2:	60a6                	ld	ra,72(sp)
    800017f4:	6406                	ld	s0,64(sp)
    800017f6:	74e2                	ld	s1,56(sp)
    800017f8:	7942                	ld	s2,48(sp)
    800017fa:	79a2                	ld	s3,40(sp)
    800017fc:	7a02                	ld	s4,32(sp)
    800017fe:	6ae2                	ld	s5,24(sp)
    80001800:	6b42                	ld	s6,16(sp)
    80001802:	6ba2                	ld	s7,8(sp)
    80001804:	6c02                	ld	s8,0(sp)
    80001806:	6161                	addi	sp,sp,80
    80001808:	8082                	ret
      panic("kalloc");
    8000180a:	00007517          	auipc	a0,0x7
    8000180e:	94650513          	addi	a0,a0,-1722 # 80008150 <etext+0x150>
    80001812:	822ff0ef          	jal	80000834 <panic>

0000000080001816 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001816:	7139                	addi	sp,sp,-64
    80001818:	fc06                	sd	ra,56(sp)
    8000181a:	f822                	sd	s0,48(sp)
    8000181c:	f426                	sd	s1,40(sp)
    8000181e:	f04a                	sd	s2,32(sp)
    80001820:	ec4e                	sd	s3,24(sp)
    80001822:	e852                	sd	s4,16(sp)
    80001824:	e456                	sd	s5,8(sp)
    80001826:	e05a                	sd	s6,0(sp)
    80001828:	0080                	addi	s0,sp,64
  struct proc *p;

  initlock(&pid_lock, "nextpid");
    8000182a:	00007597          	auipc	a1,0x7
    8000182e:	92e58593          	addi	a1,a1,-1746 # 80008158 <etext+0x158>
    80001832:	00012517          	auipc	a0,0x12
    80001836:	fce50513          	addi	a0,a0,-50 # 80013800 <pid_lock>
    8000183a:	b2eff0ef          	jal	80000b68 <initlock>
  initlock(&wait_lock, "wait_lock");
    8000183e:	00007597          	auipc	a1,0x7
    80001842:	92258593          	addi	a1,a1,-1758 # 80008160 <etext+0x160>
    80001846:	00012517          	auipc	a0,0x12
    8000184a:	fd250513          	addi	a0,a0,-46 # 80013818 <wait_lock>
    8000184e:	b1aff0ef          	jal	80000b68 <initlock>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001852:	00012497          	auipc	s1,0x12
    80001856:	3de48493          	addi	s1,s1,990 # 80013c30 <proc>
    initlock(&p->lock, "proc");
    8000185a:	00007b17          	auipc	s6,0x7
    8000185e:	916b0b13          	addi	s6,s6,-1770 # 80008170 <etext+0x170>
    p->state = UNUSED;
    p->kstack = KSTACK((int)(p - proc));
    80001862:	8aa6                	mv	s5,s1
    80001864:	aaaab7b7          	lui	a5,0xaaaab
    80001868:	aab78793          	addi	a5,a5,-1365 # ffffffffaaaaaaab <end+0xffffffff2aa85943>
    8000186c:	02079993          	slli	s3,a5,0x20
    80001870:	99be                	add	s3,s3,a5
    80001872:	04000937          	lui	s2,0x4000
    80001876:	197d                	addi	s2,s2,-1 # 3ffffff <_entry-0x7c000001>
    80001878:	0932                	slli	s2,s2,0xc
  for (p = proc; p < &proc[NPROC]; p++) {
    8000187a:	00018a17          	auipc	s4,0x18
    8000187e:	3b6a0a13          	addi	s4,s4,950 # 80019c30 <semtable_lock>
    initlock(&p->lock, "proc");
    80001882:	85da                	mv	a1,s6
    80001884:	8526                	mv	a0,s1
    80001886:	ae2ff0ef          	jal	80000b68 <initlock>
    p->state = UNUSED;
    8000188a:	0004ac23          	sw	zero,24(s1)
    p->kstack = KSTACK((int)(p - proc));
    8000188e:	415487b3          	sub	a5,s1,s5
    80001892:	879d                	srai	a5,a5,0x7
    80001894:	033787b3          	mul	a5,a5,s3
    80001898:	07b6                	slli	a5,a5,0xd
    8000189a:	6709                	lui	a4,0x2
    8000189c:	9fb9                	addw	a5,a5,a4
    8000189e:	40f907b3          	sub	a5,s2,a5
    800018a2:	ecbc                	sd	a5,88(s1)
  for (p = proc; p < &proc[NPROC]; p++) {
    800018a4:	18048493          	addi	s1,s1,384
    800018a8:	fd449de3          	bne	s1,s4,80001882 <procinit+0x6c>
  }
}
    800018ac:	70e2                	ld	ra,56(sp)
    800018ae:	7442                	ld	s0,48(sp)
    800018b0:	74a2                	ld	s1,40(sp)
    800018b2:	7902                	ld	s2,32(sp)
    800018b4:	69e2                	ld	s3,24(sp)
    800018b6:	6a42                	ld	s4,16(sp)
    800018b8:	6aa2                	ld	s5,8(sp)
    800018ba:	6b02                	ld	s6,0(sp)
    800018bc:	6121                	addi	sp,sp,64
    800018be:	8082                	ret

00000000800018c0 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018c0:	1141                	addi	sp,sp,-16
    800018c2:	e406                	sd	ra,8(sp)
    800018c4:	e022                	sd	s0,0(sp)
    800018c6:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r"(x));
    800018c8:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018ca:	2501                	sext.w	a0,a0
    800018cc:	60a2                	ld	ra,8(sp)
    800018ce:	6402                	ld	s0,0(sp)
    800018d0:	0141                	addi	sp,sp,16
    800018d2:	8082                	ret

00000000800018d4 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu *
mycpu(void)
{
    800018d4:	1141                	addi	sp,sp,-16
    800018d6:	e406                	sd	ra,8(sp)
    800018d8:	e022                	sd	s0,0(sp)
    800018da:	0800                	addi	s0,sp,16
    800018dc:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    800018de:	2781                	sext.w	a5,a5
    800018e0:	079e                	slli	a5,a5,0x7
  return c;
}
    800018e2:	00012517          	auipc	a0,0x12
    800018e6:	f4e50513          	addi	a0,a0,-178 # 80013830 <cpus>
    800018ea:	953e                	add	a0,a0,a5
    800018ec:	60a2                	ld	ra,8(sp)
    800018ee:	6402                	ld	s0,0(sp)
    800018f0:	0141                	addi	sp,sp,16
    800018f2:	8082                	ret

00000000800018f4 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc *
myproc(void)
{
    800018f4:	1101                	addi	sp,sp,-32
    800018f6:	ec06                	sd	ra,24(sp)
    800018f8:	e822                	sd	s0,16(sp)
    800018fa:	e426                	sd	s1,8(sp)
    800018fc:	1000                	addi	s0,sp,32
  push_off();
    800018fe:	ab0ff0ef          	jal	80000bae <push_off>
    80001902:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001904:	2781                	sext.w	a5,a5
    80001906:	079e                	slli	a5,a5,0x7
    80001908:	00012717          	auipc	a4,0x12
    8000190c:	ef870713          	addi	a4,a4,-264 # 80013800 <pid_lock>
    80001910:	97ba                	add	a5,a5,a4
    80001912:	7b9c                	ld	a5,48(a5)
    80001914:	84be                	mv	s1,a5
  pop_off();
    80001916:	b12ff0ef          	jal	80000c28 <pop_off>
  return p;
}
    8000191a:	8526                	mv	a0,s1
    8000191c:	60e2                	ld	ra,24(sp)
    8000191e:	6442                	ld	s0,16(sp)
    80001920:	64a2                	ld	s1,8(sp)
    80001922:	6105                	addi	sp,sp,32
    80001924:	8082                	ret

0000000080001926 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001926:	7179                	addi	sp,sp,-48
    80001928:	f406                	sd	ra,40(sp)
    8000192a:	f022                	sd	s0,32(sp)
    8000192c:	ec26                	sd	s1,24(sp)
    8000192e:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001930:	fc5ff0ef          	jal	800018f4 <myproc>
    80001934:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001936:	b3aff0ef          	jal	80000c70 <release>

  if (__atomic_load_n(&first, __ATOMIC_ACQUIRE)) {
    8000193a:	0000a797          	auipc	a5,0xa
    8000193e:	d5678793          	addi	a5,a5,-682 # 8000b690 <first.1>
    80001942:	439c                	lw	a5,0(a5)
    80001944:	0230000f          	fence	r,rw
    80001948:	2781                	sext.w	a5,a5
    8000194a:	c3a1                	beqz	a5,8000198a <forkret+0x64>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    8000194c:	4505                	li	a0,1
    8000194e:	470020ef          	jal	80003dbe <fsinit>

    // ensure other cores see first=0.
    __atomic_store_n(&first, 0, __ATOMIC_RELEASE);
    80001952:	0000a797          	auipc	a5,0xa
    80001956:	d3e78793          	addi	a5,a5,-706 # 8000b690 <first.1>
    8000195a:	0310000f          	fence	rw,w
    8000195e:	0007a023          	sw	zero,0(a5)

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){"/init", 0});
    80001962:	00007797          	auipc	a5,0x7
    80001966:	81678793          	addi	a5,a5,-2026 # 80008178 <etext+0x178>
    8000196a:	fcf43823          	sd	a5,-48(s0)
    8000196e:	fc043c23          	sd	zero,-40(s0)
    80001972:	fd040593          	addi	a1,s0,-48
    80001976:	853e                	mv	a0,a5
    80001978:	6b4030ef          	jal	8000502c <kexec>
    8000197c:	78bc                	ld	a5,112(s1)
    8000197e:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001980:	78bc                	ld	a5,112(s1)
    80001982:	7bb8                	ld	a4,112(a5)
    80001984:	57fd                	li	a5,-1
    80001986:	02f70d63          	beq	a4,a5,800019c0 <forkret+0x9a>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    8000198a:	288010ef          	jal	80002c12 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    8000198e:	74a8                	ld	a0,104(s1)
    80001990:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001992:	04000737          	lui	a4,0x4000
    80001996:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001998:	0732                	slli	a4,a4,0xc
    8000199a:	00005797          	auipc	a5,0x5
    8000199e:	70278793          	addi	a5,a5,1794 # 8000709c <userret>
    800019a2:	00005697          	auipc	a3,0x5
    800019a6:	65e68693          	addi	a3,a3,1630 # 80007000 <_trampoline>
    800019aa:	8f95                	sub	a5,a5,a3
    800019ac:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800019ae:	577d                	li	a4,-1
    800019b0:	177e                	slli	a4,a4,0x3f
    800019b2:	8d59                	or	a0,a0,a4
    800019b4:	9782                	jalr	a5
}
    800019b6:	70a2                	ld	ra,40(sp)
    800019b8:	7402                	ld	s0,32(sp)
    800019ba:	64e2                	ld	s1,24(sp)
    800019bc:	6145                	addi	sp,sp,48
    800019be:	8082                	ret
      panic("exec");
    800019c0:	00006517          	auipc	a0,0x6
    800019c4:	7c050513          	addi	a0,a0,1984 # 80008180 <etext+0x180>
    800019c8:	e6dfe0ef          	jal	80000834 <panic>

00000000800019cc <allocpid>:
{
    800019cc:	1101                	addi	sp,sp,-32
    800019ce:	ec06                	sd	ra,24(sp)
    800019d0:	e822                	sd	s0,16(sp)
    800019d2:	e426                	sd	s1,8(sp)
    800019d4:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    800019d6:	00012517          	auipc	a0,0x12
    800019da:	e2a50513          	addi	a0,a0,-470 # 80013800 <pid_lock>
    800019de:	a0aff0ef          	jal	80000be8 <acquire>
  pid = nextpid;
    800019e2:	0000a797          	auipc	a5,0xa
    800019e6:	cb278793          	addi	a5,a5,-846 # 8000b694 <nextpid>
    800019ea:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019ec:	0014871b          	addiw	a4,s1,1
    800019f0:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019f2:	00012517          	auipc	a0,0x12
    800019f6:	e0e50513          	addi	a0,a0,-498 # 80013800 <pid_lock>
    800019fa:	a76ff0ef          	jal	80000c70 <release>
}
    800019fe:	8526                	mv	a0,s1
    80001a00:	60e2                	ld	ra,24(sp)
    80001a02:	6442                	ld	s0,16(sp)
    80001a04:	64a2                	ld	s1,8(sp)
    80001a06:	6105                	addi	sp,sp,32
    80001a08:	8082                	ret

0000000080001a0a <proc_pagetable>:
{
    80001a0a:	1101                	addi	sp,sp,-32
    80001a0c:	ec06                	sd	ra,24(sp)
    80001a0e:	e822                	sd	s0,16(sp)
    80001a10:	e426                	sd	s1,8(sp)
    80001a12:	e04a                	sd	s2,0(sp)
    80001a14:	1000                	addi	s0,sp,32
    80001a16:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a18:	fa6ff0ef          	jal	800011be <uvmcreate>
    80001a1c:	84aa                	mv	s1,a0
  if (pagetable == 0)
    80001a1e:	cd05                	beqz	a0,80001a56 <proc_pagetable+0x4c>
  if (mappages(pagetable, TRAMPOLINE, PGSIZE, (uint64)trampoline,
    80001a20:	4729                	li	a4,10
    80001a22:	00005697          	auipc	a3,0x5
    80001a26:	5de68693          	addi	a3,a3,1502 # 80007000 <_trampoline>
    80001a2a:	6605                	lui	a2,0x1
    80001a2c:	040005b7          	lui	a1,0x4000
    80001a30:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a32:	05b2                	slli	a1,a1,0xc
    80001a34:	de2ff0ef          	jal	80001016 <mappages>
    80001a38:	02054663          	bltz	a0,80001a64 <proc_pagetable+0x5a>
  if (mappages(pagetable, TRAPFRAME, PGSIZE, (uint64)(p->trapframe),
    80001a3c:	4719                	li	a4,6
    80001a3e:	07093683          	ld	a3,112(s2)
    80001a42:	6605                	lui	a2,0x1
    80001a44:	020005b7          	lui	a1,0x2000
    80001a48:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a4a:	05b6                	slli	a1,a1,0xd
    80001a4c:	8526                	mv	a0,s1
    80001a4e:	dc8ff0ef          	jal	80001016 <mappages>
    80001a52:	00054f63          	bltz	a0,80001a70 <proc_pagetable+0x66>
}
    80001a56:	8526                	mv	a0,s1
    80001a58:	60e2                	ld	ra,24(sp)
    80001a5a:	6442                	ld	s0,16(sp)
    80001a5c:	64a2                	ld	s1,8(sp)
    80001a5e:	6902                	ld	s2,0(sp)
    80001a60:	6105                	addi	sp,sp,32
    80001a62:	8082                	ret
    uvmfree(pagetable, 0);
    80001a64:	4581                	li	a1,0
    80001a66:	8526                	mv	a0,s1
    80001a68:	951ff0ef          	jal	800013b8 <uvmfree>
    return 0;
    80001a6c:	4481                	li	s1,0
    80001a6e:	b7e5                	j	80001a56 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a70:	4681                	li	a3,0
    80001a72:	4605                	li	a2,1
    80001a74:	040005b7          	lui	a1,0x4000
    80001a78:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a7a:	05b2                	slli	a1,a1,0xc
    80001a7c:	8526                	mv	a0,s1
    80001a7e:	f66ff0ef          	jal	800011e4 <uvmunmap>
    uvmfree(pagetable, 0);
    80001a82:	4581                	li	a1,0
    80001a84:	8526                	mv	a0,s1
    80001a86:	933ff0ef          	jal	800013b8 <uvmfree>
    return 0;
    80001a8a:	4481                	li	s1,0
    80001a8c:	b7e9                	j	80001a56 <proc_pagetable+0x4c>

0000000080001a8e <proc_freepagetable>:
{
    80001a8e:	1101                	addi	sp,sp,-32
    80001a90:	ec06                	sd	ra,24(sp)
    80001a92:	e822                	sd	s0,16(sp)
    80001a94:	e426                	sd	s1,8(sp)
    80001a96:	e04a                	sd	s2,0(sp)
    80001a98:	1000                	addi	s0,sp,32
    80001a9a:	84aa                	mv	s1,a0
    80001a9c:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a9e:	4681                	li	a3,0
    80001aa0:	4605                	li	a2,1
    80001aa2:	040005b7          	lui	a1,0x4000
    80001aa6:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001aa8:	05b2                	slli	a1,a1,0xc
    80001aaa:	f3aff0ef          	jal	800011e4 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001aae:	4681                	li	a3,0
    80001ab0:	4605                	li	a2,1
    80001ab2:	020005b7          	lui	a1,0x2000
    80001ab6:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001ab8:	05b6                	slli	a1,a1,0xd
    80001aba:	8526                	mv	a0,s1
    80001abc:	f28ff0ef          	jal	800011e4 <uvmunmap>
  uvmfree(pagetable, sz);
    80001ac0:	85ca                	mv	a1,s2
    80001ac2:	8526                	mv	a0,s1
    80001ac4:	8f5ff0ef          	jal	800013b8 <uvmfree>
}
    80001ac8:	60e2                	ld	ra,24(sp)
    80001aca:	6442                	ld	s0,16(sp)
    80001acc:	64a2                	ld	s1,8(sp)
    80001ace:	6902                	ld	s2,0(sp)
    80001ad0:	6105                	addi	sp,sp,32
    80001ad2:	8082                	ret

0000000080001ad4 <freeproc>:
{
    80001ad4:	7139                	addi	sp,sp,-64
    80001ad6:	fc06                	sd	ra,56(sp)
    80001ad8:	f822                	sd	s0,48(sp)
    80001ada:	f426                	sd	s1,40(sp)
    80001adc:	ec4e                	sd	s3,24(sp)
    80001ade:	0080                	addi	s0,sp,64
    80001ae0:	84aa                	mv	s1,a0
  if (p->trapframe)
    80001ae2:	7928                	ld	a0,112(a0)
    80001ae4:	c119                	beqz	a0,80001aea <freeproc+0x16>
    kfree((void *)p->trapframe);
    80001ae6:	f41fe0ef          	jal	80000a26 <kfree>
  p->trapframe = 0;
    80001aea:	0604b823          	sd	zero,112(s1)
  if (p->pagetable) {
    80001aee:	0684b983          	ld	s3,104(s1)
    80001af2:	06098a63          	beqz	s3,80001b66 <freeproc+0x92>
    if (p->is_thread)
    80001af6:	44bc                	lw	a5,72(s1)
    80001af8:	c7dd                	beqz	a5,80001ba6 <freeproc+0xd2>
    80001afa:	e852                	sd	s4,16(sp)
      thread_freepagetable(p->pagetable, p->sz);
    80001afc:	0604ba03          	ld	s4,96(s1)
  for (va = 0; va < sz; va += PGSIZE) {
    80001b00:	020a0c63          	beqz	s4,80001b38 <freeproc+0x64>
    80001b04:	f04a                	sd	s2,32(sp)
    80001b06:	e456                	sd	s5,8(sp)
    80001b08:	4901                	li	s2,0
    80001b0a:	6a85                	lui	s5,0x1
    80001b0c:	a811                	j	80001b20 <freeproc+0x4c>
      uvmunmap(pagetable, va, 1, 0);
    80001b0e:	4681                	li	a3,0
    80001b10:	4605                	li	a2,1
    80001b12:	85ca                	mv	a1,s2
    80001b14:	854e                	mv	a0,s3
    80001b16:	eceff0ef          	jal	800011e4 <uvmunmap>
  for (va = 0; va < sz; va += PGSIZE) {
    80001b1a:	9956                	add	s2,s2,s5
    80001b1c:	01497c63          	bgeu	s2,s4,80001b34 <freeproc+0x60>
    pte_t *pte = walk(pagetable, va, 0);
    80001b20:	4601                	li	a2,0
    80001b22:	85ca                	mv	a1,s2
    80001b24:	854e                	mv	a0,s3
    80001b26:	c1cff0ef          	jal	80000f42 <walk>
    if (pte != 0 && (*pte & PTE_V))
    80001b2a:	d965                	beqz	a0,80001b1a <freeproc+0x46>
    80001b2c:	611c                	ld	a5,0(a0)
    80001b2e:	8b85                	andi	a5,a5,1
    80001b30:	d7ed                	beqz	a5,80001b1a <freeproc+0x46>
    80001b32:	bff1                	j	80001b0e <freeproc+0x3a>
    80001b34:	7902                	ld	s2,32(sp)
    80001b36:	6aa2                	ld	s5,8(sp)
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001b38:	4681                	li	a3,0
    80001b3a:	4605                	li	a2,1
    80001b3c:	040005b7          	lui	a1,0x4000
    80001b40:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001b42:	05b2                	slli	a1,a1,0xc
    80001b44:	854e                	mv	a0,s3
    80001b46:	e9eff0ef          	jal	800011e4 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001b4a:	4681                	li	a3,0
    80001b4c:	4605                	li	a2,1
    80001b4e:	020005b7          	lui	a1,0x2000
    80001b52:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001b54:	05b6                	slli	a1,a1,0xd
    80001b56:	854e                	mv	a0,s3
    80001b58:	e8cff0ef          	jal	800011e4 <uvmunmap>
  uvmfree(pagetable, 0);
    80001b5c:	4581                	li	a1,0
    80001b5e:	854e                	mv	a0,s3
    80001b60:	859ff0ef          	jal	800013b8 <uvmfree>
}
    80001b64:	6a42                	ld	s4,16(sp)
  p->pagetable = 0;
    80001b66:	0604b423          	sd	zero,104(s1)
  p->sz = 0;
    80001b6a:	0604b023          	sd	zero,96(s1)
  p->pid = 0;
    80001b6e:	0204a823          	sw	zero,48(s1)
  p->name[0] = 0;
    80001b72:	16048823          	sb	zero,368(s1)
  p->chan = 0;
    80001b76:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001b7a:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001b7e:	0204a623          	sw	zero,44(s1)
  p->is_thread = 0;
    80001b82:	0404a423          	sw	zero,72(s1)
  p->thread_leader = 0;
    80001b86:	0404b823          	sd	zero,80(s1)
  p->priority = 10;
    80001b8a:	47a9                	li	a5,10
    80001b8c:	d8dc                	sw	a5,52(s1)
  p->waiting_ticks = 0;
    80001b8e:	0204ac23          	sw	zero,56(s1)
  p->aging_ticks = 0;
    80001b92:	0204ae23          	sw	zero,60(s1)
  p->state = UNUSED;
    80001b96:	0004ac23          	sw	zero,24(s1)
}
    80001b9a:	70e2                	ld	ra,56(sp)
    80001b9c:	7442                	ld	s0,48(sp)
    80001b9e:	74a2                	ld	s1,40(sp)
    80001ba0:	69e2                	ld	s3,24(sp)
    80001ba2:	6121                	addi	sp,sp,64
    80001ba4:	8082                	ret
      proc_freepagetable(p->pagetable, p->sz);
    80001ba6:	70ac                	ld	a1,96(s1)
    80001ba8:	854e                	mv	a0,s3
    80001baa:	ee5ff0ef          	jal	80001a8e <proc_freepagetable>
    80001bae:	bf65                	j	80001b66 <freeproc+0x92>

0000000080001bb0 <allocproc>:
{
    80001bb0:	1101                	addi	sp,sp,-32
    80001bb2:	ec06                	sd	ra,24(sp)
    80001bb4:	e822                	sd	s0,16(sp)
    80001bb6:	e426                	sd	s1,8(sp)
    80001bb8:	e04a                	sd	s2,0(sp)
    80001bba:	1000                	addi	s0,sp,32
  for (p = proc; p < &proc[NPROC]; p++) {
    80001bbc:	00012497          	auipc	s1,0x12
    80001bc0:	07448493          	addi	s1,s1,116 # 80013c30 <proc>
    80001bc4:	00018917          	auipc	s2,0x18
    80001bc8:	06c90913          	addi	s2,s2,108 # 80019c30 <semtable_lock>
    acquire(&p->lock);
    80001bcc:	8526                	mv	a0,s1
    80001bce:	81aff0ef          	jal	80000be8 <acquire>
    if (p->state == UNUSED) {
    80001bd2:	4c9c                	lw	a5,24(s1)
    80001bd4:	cb91                	beqz	a5,80001be8 <allocproc+0x38>
      release(&p->lock);
    80001bd6:	8526                	mv	a0,s1
    80001bd8:	898ff0ef          	jal	80000c70 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80001bdc:	18048493          	addi	s1,s1,384
    80001be0:	ff2496e3          	bne	s1,s2,80001bcc <allocproc+0x1c>
  return 0;
    80001be4:	4481                	li	s1,0
    80001be6:	a899                	j	80001c3c <allocproc+0x8c>
  p->pid = allocpid();
    80001be8:	de5ff0ef          	jal	800019cc <allocpid>
    80001bec:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001bee:	4785                	li	a5,1
    80001bf0:	cc9c                	sw	a5,24(s1)
  p->is_thread = 0;
    80001bf2:	0404a423          	sw	zero,72(s1)
  p->thread_leader = 0;
    80001bf6:	0404b823          	sd	zero,80(s1)
  p->priority = 10;
    80001bfa:	47a9                	li	a5,10
    80001bfc:	d8dc                	sw	a5,52(s1)
  p->waiting_ticks = 0;
    80001bfe:	0204ac23          	sw	zero,56(s1)
  p->aging_ticks = 0;
    80001c02:	0204ae23          	sw	zero,60(s1)
  if ((p->trapframe = (struct trapframe *)kalloc()) == 0) {
    80001c06:	f09fe0ef          	jal	80000b0e <kalloc>
    80001c0a:	892a                	mv	s2,a0
    80001c0c:	f8a8                	sd	a0,112(s1)
    80001c0e:	cd15                	beqz	a0,80001c4a <allocproc+0x9a>
  p->pagetable = proc_pagetable(p);
    80001c10:	8526                	mv	a0,s1
    80001c12:	df9ff0ef          	jal	80001a0a <proc_pagetable>
    80001c16:	892a                	mv	s2,a0
    80001c18:	f4a8                	sd	a0,104(s1)
  if (p->pagetable == 0) {
    80001c1a:	c121                	beqz	a0,80001c5a <allocproc+0xaa>
  memset(&p->context, 0, sizeof(p->context));
    80001c1c:	07000613          	li	a2,112
    80001c20:	4581                	li	a1,0
    80001c22:	07848513          	addi	a0,s1,120
    80001c26:	882ff0ef          	jal	80000ca8 <memset>
  p->context.ra = (uint64)forkret;
    80001c2a:	00000797          	auipc	a5,0x0
    80001c2e:	cfc78793          	addi	a5,a5,-772 # 80001926 <forkret>
    80001c32:	fcbc                	sd	a5,120(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001c34:	6cbc                	ld	a5,88(s1)
    80001c36:	6705                	lui	a4,0x1
    80001c38:	97ba                	add	a5,a5,a4
    80001c3a:	e0dc                	sd	a5,128(s1)
}
    80001c3c:	8526                	mv	a0,s1
    80001c3e:	60e2                	ld	ra,24(sp)
    80001c40:	6442                	ld	s0,16(sp)
    80001c42:	64a2                	ld	s1,8(sp)
    80001c44:	6902                	ld	s2,0(sp)
    80001c46:	6105                	addi	sp,sp,32
    80001c48:	8082                	ret
    freeproc(p);
    80001c4a:	8526                	mv	a0,s1
    80001c4c:	e89ff0ef          	jal	80001ad4 <freeproc>
    release(&p->lock);
    80001c50:	8526                	mv	a0,s1
    80001c52:	81eff0ef          	jal	80000c70 <release>
    return 0;
    80001c56:	84ca                	mv	s1,s2
    80001c58:	b7d5                	j	80001c3c <allocproc+0x8c>
    freeproc(p);
    80001c5a:	8526                	mv	a0,s1
    80001c5c:	e79ff0ef          	jal	80001ad4 <freeproc>
    release(&p->lock);
    80001c60:	8526                	mv	a0,s1
    80001c62:	80eff0ef          	jal	80000c70 <release>
    return 0;
    80001c66:	84ca                	mv	s1,s2
    80001c68:	bfd1                	j	80001c3c <allocproc+0x8c>

0000000080001c6a <userinit>:
{
    80001c6a:	1101                	addi	sp,sp,-32
    80001c6c:	ec06                	sd	ra,24(sp)
    80001c6e:	e822                	sd	s0,16(sp)
    80001c70:	e426                	sd	s1,8(sp)
    80001c72:	1000                	addi	s0,sp,32
  p = allocproc();
    80001c74:	f3dff0ef          	jal	80001bb0 <allocproc>
    80001c78:	84aa                	mv	s1,a0
  initproc = p;
    80001c7a:	0000a797          	auipc	a5,0xa
    80001c7e:	a6a7b323          	sd	a0,-1434(a5) # 8000b6e0 <initproc>
  p->cwd = namei("/");
    80001c82:	00006517          	auipc	a0,0x6
    80001c86:	50650513          	addi	a0,a0,1286 # 80008188 <etext+0x188>
    80001c8a:	684020ef          	jal	8000430e <namei>
    80001c8e:	16a4b423          	sd	a0,360(s1)
  p->state = RUNNABLE;
    80001c92:	478d                	li	a5,3
    80001c94:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001c96:	8526                	mv	a0,s1
    80001c98:	fd9fe0ef          	jal	80000c70 <release>
}
    80001c9c:	60e2                	ld	ra,24(sp)
    80001c9e:	6442                	ld	s0,16(sp)
    80001ca0:	64a2                	ld	s1,8(sp)
    80001ca2:	6105                	addi	sp,sp,32
    80001ca4:	8082                	ret

0000000080001ca6 <growproc>:
{
    80001ca6:	1101                	addi	sp,sp,-32
    80001ca8:	ec06                	sd	ra,24(sp)
    80001caa:	e822                	sd	s0,16(sp)
    80001cac:	e426                	sd	s1,8(sp)
    80001cae:	e04a                	sd	s2,0(sp)
    80001cb0:	1000                	addi	s0,sp,32
    80001cb2:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001cb4:	c41ff0ef          	jal	800018f4 <myproc>
    80001cb8:	892a                	mv	s2,a0
  sz = p->sz;
    80001cba:	712c                	ld	a1,96(a0)
  if (n > 0) {
    80001cbc:	02905963          	blez	s1,80001cee <growproc+0x48>
    if (sz + n > TRAPFRAME) {
    80001cc0:	00b48633          	add	a2,s1,a1
    80001cc4:	020007b7          	lui	a5,0x2000
    80001cc8:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001cca:	07b6                	slli	a5,a5,0xd
    80001ccc:	02c7ea63          	bltu	a5,a2,80001d00 <growproc+0x5a>
    if ((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001cd0:	4691                	li	a3,4
    80001cd2:	7528                	ld	a0,104(a0)
    80001cd4:	ddeff0ef          	jal	800012b2 <uvmalloc>
    80001cd8:	85aa                	mv	a1,a0
    80001cda:	c50d                	beqz	a0,80001d04 <growproc+0x5e>
  p->sz = sz;
    80001cdc:	06b93023          	sd	a1,96(s2)
  return 0;
    80001ce0:	4501                	li	a0,0
}
    80001ce2:	60e2                	ld	ra,24(sp)
    80001ce4:	6442                	ld	s0,16(sp)
    80001ce6:	64a2                	ld	s1,8(sp)
    80001ce8:	6902                	ld	s2,0(sp)
    80001cea:	6105                	addi	sp,sp,32
    80001cec:	8082                	ret
  } else if (n < 0) {
    80001cee:	fe04d7e3          	bgez	s1,80001cdc <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001cf2:	00b48633          	add	a2,s1,a1
    80001cf6:	7528                	ld	a0,104(a0)
    80001cf8:	d76ff0ef          	jal	8000126e <uvmdealloc>
    80001cfc:	85aa                	mv	a1,a0
    80001cfe:	bff9                	j	80001cdc <growproc+0x36>
      return -1;
    80001d00:	557d                	li	a0,-1
    80001d02:	b7c5                	j	80001ce2 <growproc+0x3c>
      return -1;
    80001d04:	557d                	li	a0,-1
    80001d06:	bff1                	j	80001ce2 <growproc+0x3c>

0000000080001d08 <kfork>:
{
    80001d08:	7139                	addi	sp,sp,-64
    80001d0a:	fc06                	sd	ra,56(sp)
    80001d0c:	f822                	sd	s0,48(sp)
    80001d0e:	f426                	sd	s1,40(sp)
    80001d10:	e456                	sd	s5,8(sp)
    80001d12:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001d14:	be1ff0ef          	jal	800018f4 <myproc>
    80001d18:	8aaa                	mv	s5,a0
  if ((np = allocproc()) == 0) {
    80001d1a:	e97ff0ef          	jal	80001bb0 <allocproc>
    80001d1e:	0e050a63          	beqz	a0,80001e12 <kfork+0x10a>
    80001d22:	e852                	sd	s4,16(sp)
    80001d24:	8a2a                	mv	s4,a0
  if (uvmcopy(p->pagetable, np->pagetable, p->sz) < 0) {
    80001d26:	060ab603          	ld	a2,96(s5) # 1060 <_entry-0x7fffefa0>
    80001d2a:	752c                	ld	a1,104(a0)
    80001d2c:	068ab503          	ld	a0,104(s5)
    80001d30:	ebaff0ef          	jal	800013ea <uvmcopy>
    80001d34:	04054863          	bltz	a0,80001d84 <kfork+0x7c>
    80001d38:	f04a                	sd	s2,32(sp)
    80001d3a:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001d3c:	060ab783          	ld	a5,96(s5)
    80001d40:	06fa3023          	sd	a5,96(s4)
  *(np->trapframe) = *(p->trapframe);
    80001d44:	070ab683          	ld	a3,112(s5)
    80001d48:	87b6                	mv	a5,a3
    80001d4a:	070a3703          	ld	a4,112(s4)
    80001d4e:	12068693          	addi	a3,a3,288
    80001d52:	6388                	ld	a0,0(a5)
    80001d54:	678c                	ld	a1,8(a5)
    80001d56:	6b90                	ld	a2,16(a5)
    80001d58:	e308                	sd	a0,0(a4)
    80001d5a:	e70c                	sd	a1,8(a4)
    80001d5c:	eb10                	sd	a2,16(a4)
    80001d5e:	6f90                	ld	a2,24(a5)
    80001d60:	ef10                	sd	a2,24(a4)
    80001d62:	02078793          	addi	a5,a5,32
    80001d66:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001d6a:	fed794e3          	bne	a5,a3,80001d52 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001d6e:	070a3783          	ld	a5,112(s4)
    80001d72:	0607b823          	sd	zero,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001d76:	0e8a8493          	addi	s1,s5,232
    80001d7a:	0e8a0913          	addi	s2,s4,232
    80001d7e:	168a8993          	addi	s3,s5,360
    80001d82:	a831                	j	80001d9e <kfork+0x96>
    freeproc(np);
    80001d84:	8552                	mv	a0,s4
    80001d86:	d4fff0ef          	jal	80001ad4 <freeproc>
    release(&np->lock);
    80001d8a:	8552                	mv	a0,s4
    80001d8c:	ee5fe0ef          	jal	80000c70 <release>
    return -1;
    80001d90:	54fd                	li	s1,-1
    80001d92:	6a42                	ld	s4,16(sp)
    80001d94:	a885                	j	80001e04 <kfork+0xfc>
  for (i = 0; i < NOFILE; i++)
    80001d96:	04a1                	addi	s1,s1,8
    80001d98:	0921                	addi	s2,s2,8
    80001d9a:	01348963          	beq	s1,s3,80001dac <kfork+0xa4>
    if (p->ofile[i])
    80001d9e:	6088                	ld	a0,0(s1)
    80001da0:	d97d                	beqz	a0,80001d96 <kfork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001da2:	3bf020ef          	jal	80004960 <filedup>
    80001da6:	00a93023          	sd	a0,0(s2)
    80001daa:	b7f5                	j	80001d96 <kfork+0x8e>
  np->cwd = idup(p->cwd);
    80001dac:	168ab503          	ld	a0,360(s5)
    80001db0:	4e5010ef          	jal	80003a94 <idup>
    80001db4:	16aa3423          	sd	a0,360(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001db8:	4641                	li	a2,16
    80001dba:	170a8593          	addi	a1,s5,368
    80001dbe:	170a0513          	addi	a0,s4,368
    80001dc2:	83aff0ef          	jal	80000dfc <safestrcpy>
  pid = np->pid;
    80001dc6:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001dca:	8552                	mv	a0,s4
    80001dcc:	ea5fe0ef          	jal	80000c70 <release>
  acquire(&wait_lock);
    80001dd0:	00012517          	auipc	a0,0x12
    80001dd4:	a4850513          	addi	a0,a0,-1464 # 80013818 <wait_lock>
    80001dd8:	e11fe0ef          	jal	80000be8 <acquire>
  np->parent = p;
    80001ddc:	055a3023          	sd	s5,64(s4)
  release(&wait_lock);
    80001de0:	00012517          	auipc	a0,0x12
    80001de4:	a3850513          	addi	a0,a0,-1480 # 80013818 <wait_lock>
    80001de8:	e89fe0ef          	jal	80000c70 <release>
  acquire(&np->lock);
    80001dec:	8552                	mv	a0,s4
    80001dee:	dfbfe0ef          	jal	80000be8 <acquire>
  np->state = RUNNABLE;
    80001df2:	478d                	li	a5,3
    80001df4:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001df8:	8552                	mv	a0,s4
    80001dfa:	e77fe0ef          	jal	80000c70 <release>
  return pid;
    80001dfe:	7902                	ld	s2,32(sp)
    80001e00:	69e2                	ld	s3,24(sp)
    80001e02:	6a42                	ld	s4,16(sp)
}
    80001e04:	8526                	mv	a0,s1
    80001e06:	70e2                	ld	ra,56(sp)
    80001e08:	7442                	ld	s0,48(sp)
    80001e0a:	74a2                	ld	s1,40(sp)
    80001e0c:	6aa2                	ld	s5,8(sp)
    80001e0e:	6121                	addi	sp,sp,64
    80001e10:	8082                	ret
    return -1;
    80001e12:	54fd                	li	s1,-1
    80001e14:	bfc5                	j	80001e04 <kfork+0xfc>

0000000080001e16 <kclone>:
{
    80001e16:	7159                	addi	sp,sp,-112
    80001e18:	f486                	sd	ra,104(sp)
    80001e1a:	f0a2                	sd	s0,96(sp)
    80001e1c:	eca6                	sd	s1,88(sp)
    80001e1e:	e8ca                	sd	s2,80(sp)
    80001e20:	f85a                	sd	s6,48(sp)
    80001e22:	f45e                	sd	s7,40(sp)
    80001e24:	e86a                	sd	s10,16(sp)
    80001e26:	e46e                	sd	s11,8(sp)
    80001e28:	1880                	addi	s0,sp,112
    80001e2a:	8d2a                	mv	s10,a0
    80001e2c:	8dae                	mv	s11,a1
    80001e2e:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80001e30:	ac5ff0ef          	jal	800018f4 <myproc>
    80001e34:	8b2a                	mv	s6,a0
  struct proc *leader = p->is_thread ? p->thread_leader : p;
    80001e36:	453c                	lw	a5,72(a0)
    80001e38:	8baa                	mv	s7,a0
    80001e3a:	c399                	beqz	a5,80001e40 <kclone+0x2a>
    80001e3c:	05053b83          	ld	s7,80(a0)
  if (fcn >= leader->sz || stack == 0 || (stack % PGSIZE) != 0 ||
    80001e40:	060bb683          	ld	a3,96(s7) # fffffffffffff060 <end+0xffffffff7ffd9ef8>
    80001e44:	fff90713          	addi	a4,s2,-1
    80001e48:	77fd                	lui	a5,0xfffff
    80001e4a:	17fd                	addi	a5,a5,-1 # ffffffffffffefff <end+0xffffffff7ffd9e97>
    80001e4c:	18f77063          	bgeu	a4,a5,80001fcc <kclone+0x1b6>
    80001e50:	16dd7e63          	bgeu	s10,a3,80001fcc <kclone+0x1b6>
    80001e54:	03491793          	slli	a5,s2,0x34
    80001e58:	0347d493          	srli	s1,a5,0x34
    80001e5c:	16079a63          	bnez	a5,80001fd0 <kclone+0x1ba>
    80001e60:	ec66                	sd	s9,24(sp)
      stack + PGSIZE < stack || stack + PGSIZE > leader->sz ||
    80001e62:	6c85                	lui	s9,0x1
    80001e64:	9cca                	add	s9,s9,s2
    80001e66:	1796e763          	bltu	a3,s9,80001fd4 <kclone+0x1be>
      walkaddr(leader->pagetable, stack) == 0)
    80001e6a:	85ca                	mv	a1,s2
    80001e6c:	068bb503          	ld	a0,104(s7)
    80001e70:	96cff0ef          	jal	80000fdc <walkaddr>
      stack + PGSIZE < stack || stack + PGSIZE > leader->sz ||
    80001e74:	16050363          	beqz	a0,80001fda <kclone+0x1c4>
  if ((np = allocproc()) == 0)
    80001e78:	d39ff0ef          	jal	80001bb0 <allocproc>
    80001e7c:	892a                	mv	s2,a0
    80001e7e:	16050163          	beqz	a0,80001fe0 <kclone+0x1ca>
    80001e82:	e4ce                	sd	s3,72(sp)
    80001e84:	e0d2                	sd	s4,64(sp)
  np->is_thread = 1;
    80001e86:	4785                	li	a5,1
    80001e88:	c53c                	sw	a5,72(a0)
  np->thread_leader = leader;
    80001e8a:	05753823          	sd	s7,80(a0)
  np->sz = leader->sz;
    80001e8e:	060bba03          	ld	s4,96(s7)
    80001e92:	07453023          	sd	s4,96(a0)
  for (va = 0; va < sz; va += PGSIZE) {
    80001e96:	060a0163          	beqz	s4,80001ef8 <kclone+0xe2>
    80001e9a:	fc56                	sd	s5,56(sp)
    80001e9c:	f062                	sd	s8,32(sp)
  if (share_user_memory(leader->pagetable, np->pagetable, np->sz) < 0) {
    80001e9e:	068bba83          	ld	s5,104(s7)
    80001ea2:	06853c03          	ld	s8,104(a0)
    if (mappages(dst, va, PGSIZE, PTE2PA(*pte), PTE_FLAGS(*pte)) != 0)
    80001ea6:	6985                	lui	s3,0x1
    80001ea8:	a021                	j	80001eb0 <kclone+0x9a>
  for (va = 0; va < sz; va += PGSIZE) {
    80001eaa:	94ce                	add	s1,s1,s3
    80001eac:	0544f463          	bgeu	s1,s4,80001ef4 <kclone+0xde>
    pte_t *pte = walk(src, va, 0);
    80001eb0:	4601                	li	a2,0
    80001eb2:	85a6                	mv	a1,s1
    80001eb4:	8556                	mv	a0,s5
    80001eb6:	88cff0ef          	jal	80000f42 <walk>
    if (pte == 0 || (*pte & PTE_V) == 0)
    80001eba:	d965                	beqz	a0,80001eaa <kclone+0x94>
    80001ebc:	6118                	ld	a4,0(a0)
    80001ebe:	00177793          	andi	a5,a4,1
    80001ec2:	d7e5                	beqz	a5,80001eaa <kclone+0x94>
    if (mappages(dst, va, PGSIZE, PTE2PA(*pte), PTE_FLAGS(*pte)) != 0)
    80001ec4:	00a75693          	srli	a3,a4,0xa
    80001ec8:	3ff77713          	andi	a4,a4,1023
    80001ecc:	06b2                	slli	a3,a3,0xc
    80001ece:	864e                	mv	a2,s3
    80001ed0:	85a6                	mv	a1,s1
    80001ed2:	8562                	mv	a0,s8
    80001ed4:	942ff0ef          	jal	80001016 <mappages>
    80001ed8:	d969                	beqz	a0,80001eaa <kclone+0x94>
    freeproc(np);
    80001eda:	854a                	mv	a0,s2
    80001edc:	bf9ff0ef          	jal	80001ad4 <freeproc>
    release(&np->lock);
    80001ee0:	854a                	mv	a0,s2
    80001ee2:	d8ffe0ef          	jal	80000c70 <release>
    return -1;
    80001ee6:	54fd                	li	s1,-1
    80001ee8:	69a6                	ld	s3,72(sp)
    80001eea:	6a06                	ld	s4,64(sp)
    80001eec:	7ae2                	ld	s5,56(sp)
    80001eee:	7c02                	ld	s8,32(sp)
    80001ef0:	6ce2                	ld	s9,24(sp)
    80001ef2:	a0d1                	j	80001fb6 <kclone+0x1a0>
    80001ef4:	7ae2                	ld	s5,56(sp)
    80001ef6:	7c02                	ld	s8,32(sp)
  *(np->trapframe) = *(p->trapframe);
    80001ef8:	070b3683          	ld	a3,112(s6)
    80001efc:	87b6                	mv	a5,a3
    80001efe:	07093703          	ld	a4,112(s2)
    80001f02:	12068693          	addi	a3,a3,288
    80001f06:	6388                	ld	a0,0(a5)
    80001f08:	678c                	ld	a1,8(a5)
    80001f0a:	6b90                	ld	a2,16(a5)
    80001f0c:	e308                	sd	a0,0(a4)
    80001f0e:	e70c                	sd	a1,8(a4)
    80001f10:	eb10                	sd	a2,16(a4)
    80001f12:	6f90                	ld	a2,24(a5)
    80001f14:	ef10                	sd	a2,24(a4)
    80001f16:	02078793          	addi	a5,a5,32
    80001f1a:	02070713          	addi	a4,a4,32
    80001f1e:	fed794e3          	bne	a5,a3,80001f06 <kclone+0xf0>
  np->trapframe->epc = fcn;
    80001f22:	07093783          	ld	a5,112(s2)
    80001f26:	01a7bc23          	sd	s10,24(a5)
  np->trapframe->sp = (stack + PGSIZE) & ~0xFUL;
    80001f2a:	07093783          	ld	a5,112(s2)
    80001f2e:	0397b823          	sd	s9,48(a5)
  np->trapframe->a0 = arg;
    80001f32:	07093783          	ld	a5,112(s2)
    80001f36:	07b7b823          	sd	s11,112(a5)
  for (i = 0; i < NOFILE; i++)
    80001f3a:	0e8b0493          	addi	s1,s6,232
    80001f3e:	0e890993          	addi	s3,s2,232
    80001f42:	168b0a13          	addi	s4,s6,360
    80001f46:	a029                	j	80001f50 <kclone+0x13a>
    80001f48:	04a1                	addi	s1,s1,8
    80001f4a:	09a1                	addi	s3,s3,8 # 1008 <_entry-0x7fffeff8>
    80001f4c:	01448963          	beq	s1,s4,80001f5e <kclone+0x148>
    if (p->ofile[i])
    80001f50:	6088                	ld	a0,0(s1)
    80001f52:	d97d                	beqz	a0,80001f48 <kclone+0x132>
      np->ofile[i] = filedup(p->ofile[i]);
    80001f54:	20d020ef          	jal	80004960 <filedup>
    80001f58:	00a9b023          	sd	a0,0(s3)
    80001f5c:	b7f5                	j	80001f48 <kclone+0x132>
  np->cwd = idup(p->cwd);
    80001f5e:	168b3503          	ld	a0,360(s6)
    80001f62:	333010ef          	jal	80003a94 <idup>
    80001f66:	16a93423          	sd	a0,360(s2)
  safestrcpy(np->name, p->name, sizeof(np->name));
    80001f6a:	4641                	li	a2,16
    80001f6c:	170b0593          	addi	a1,s6,368
    80001f70:	17090513          	addi	a0,s2,368
    80001f74:	e89fe0ef          	jal	80000dfc <safestrcpy>
  pid = np->pid;
    80001f78:	03092483          	lw	s1,48(s2)
  release(&np->lock);
    80001f7c:	854a                	mv	a0,s2
    80001f7e:	cf3fe0ef          	jal	80000c70 <release>
  acquire(&wait_lock);
    80001f82:	00012517          	auipc	a0,0x12
    80001f86:	89650513          	addi	a0,a0,-1898 # 80013818 <wait_lock>
    80001f8a:	c5ffe0ef          	jal	80000be8 <acquire>
  np->parent = leader;
    80001f8e:	05793023          	sd	s7,64(s2)
  release(&wait_lock);
    80001f92:	00012517          	auipc	a0,0x12
    80001f96:	88650513          	addi	a0,a0,-1914 # 80013818 <wait_lock>
    80001f9a:	cd7fe0ef          	jal	80000c70 <release>
  acquire(&np->lock);
    80001f9e:	854a                	mv	a0,s2
    80001fa0:	c49fe0ef          	jal	80000be8 <acquire>
  np->state = RUNNABLE;
    80001fa4:	478d                	li	a5,3
    80001fa6:	00f92c23          	sw	a5,24(s2)
  release(&np->lock);
    80001faa:	854a                	mv	a0,s2
    80001fac:	cc5fe0ef          	jal	80000c70 <release>
  return pid;
    80001fb0:	69a6                	ld	s3,72(sp)
    80001fb2:	6a06                	ld	s4,64(sp)
    80001fb4:	6ce2                	ld	s9,24(sp)
}
    80001fb6:	8526                	mv	a0,s1
    80001fb8:	70a6                	ld	ra,104(sp)
    80001fba:	7406                	ld	s0,96(sp)
    80001fbc:	64e6                	ld	s1,88(sp)
    80001fbe:	6946                	ld	s2,80(sp)
    80001fc0:	7b42                	ld	s6,48(sp)
    80001fc2:	7ba2                	ld	s7,40(sp)
    80001fc4:	6d42                	ld	s10,16(sp)
    80001fc6:	6da2                	ld	s11,8(sp)
    80001fc8:	6165                	addi	sp,sp,112
    80001fca:	8082                	ret
    return -1;
    80001fcc:	54fd                	li	s1,-1
    80001fce:	b7e5                	j	80001fb6 <kclone+0x1a0>
    80001fd0:	54fd                	li	s1,-1
    80001fd2:	b7d5                	j	80001fb6 <kclone+0x1a0>
    80001fd4:	54fd                	li	s1,-1
    80001fd6:	6ce2                	ld	s9,24(sp)
    80001fd8:	bff9                	j	80001fb6 <kclone+0x1a0>
    80001fda:	54fd                	li	s1,-1
    80001fdc:	6ce2                	ld	s9,24(sp)
    80001fde:	bfe1                	j	80001fb6 <kclone+0x1a0>
    return -1;
    80001fe0:	54fd                	li	s1,-1
    80001fe2:	6ce2                	ld	s9,24(sp)
    80001fe4:	bfc9                	j	80001fb6 <kclone+0x1a0>

0000000080001fe6 <scheduler>:
{
    80001fe6:	7119                	addi	sp,sp,-128
    80001fe8:	fc86                	sd	ra,120(sp)
    80001fea:	f8a2                	sd	s0,112(sp)
    80001fec:	f4a6                	sd	s1,104(sp)
    80001fee:	f0ca                	sd	s2,96(sp)
    80001ff0:	ecce                	sd	s3,88(sp)
    80001ff2:	e8d2                	sd	s4,80(sp)
    80001ff4:	e4d6                	sd	s5,72(sp)
    80001ff6:	e0da                	sd	s6,64(sp)
    80001ff8:	fc5e                	sd	s7,56(sp)
    80001ffa:	f862                	sd	s8,48(sp)
    80001ffc:	f466                	sd	s9,40(sp)
    80001ffe:	f06a                	sd	s10,32(sp)
    80002000:	ec6e                	sd	s11,24(sp)
    80002002:	0100                	addi	s0,sp,128
    80002004:	8792                	mv	a5,tp
  int id = r_tp();
    80002006:	2781                	sext.w	a5,a5
  c->proc = 0;
    80002008:	00779693          	slli	a3,a5,0x7
    8000200c:	00011717          	auipc	a4,0x11
    80002010:	7f470713          	addi	a4,a4,2036 # 80013800 <pid_lock>
    80002014:	9736                	add	a4,a4,a3
    80002016:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    8000201a:	00012717          	auipc	a4,0x12
    8000201e:	81e70713          	addi	a4,a4,-2018 # 80013838 <cpus+0x8>
    80002022:	9736                	add	a4,a4,a3
    80002024:	f8e43423          	sd	a4,-120(s0)
      if (p->state == RUNNABLE) {
    80002028:	4a0d                	li	s4,3
        if (p->waiting_ticks >= 30) {
    8000202a:	4cf5                	li	s9,29
          if (p->priority > 1)
    8000202c:	4d85                	li	s11,1
        c->proc = p;
    8000202e:	00011717          	auipc	a4,0x11
    80002032:	7d270713          	addi	a4,a4,2002 # 80013800 <pid_lock>
    80002036:	00d707b3          	add	a5,a4,a3
    8000203a:	f8f43023          	sd	a5,-128(s0)
    8000203e:	a8e9                	j	80002118 <scheduler+0x132>
        p->waiting_ticks = 0;
    80002040:	0204ac23          	sw	zero,56(s1)
      release(&p->lock);
    80002044:	8526                	mv	a0,s1
    80002046:	c2bfe0ef          	jal	80000c70 <release>
    for (p = proc; p < &proc[NPROC]; p++) {
    8000204a:	18048493          	addi	s1,s1,384
    8000204e:	03248d63          	beq	s1,s2,80002088 <scheduler+0xa2>
      acquire(&p->lock);
    80002052:	8526                	mv	a0,s1
    80002054:	b95fe0ef          	jal	80000be8 <acquire>
      if (p->state == RUNNABLE) {
    80002058:	4c9c                	lw	a5,24(s1)
    8000205a:	ff4793e3          	bne	a5,s4,80002040 <scheduler+0x5a>
        p->waiting_ticks++;
    8000205e:	5c9c                	lw	a5,56(s1)
    80002060:	2785                	addiw	a5,a5,1
    80002062:	dc9c                	sw	a5,56(s1)
        if (p->waiting_ticks >= 30) {
    80002064:	fefcd0e3          	bge	s9,a5,80002044 <scheduler+0x5e>
          int old_priority = p->priority;
    80002068:	58d0                	lw	a2,52(s1)
          if (p->priority > 1)
    8000206a:	00cdd563          	bge	s11,a2,80002074 <scheduler+0x8e>
            p->priority--;
    8000206e:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80002072:	d8dc                	sw	a5,52(s1)
          p->waiting_ticks = 0;
    80002074:	0204ac23          	sw	zero,56(s1)
          if (p->priority != old_priority) {
    80002078:	58d4                	lw	a3,52(s1)
    8000207a:	fcc685e3          	beq	a3,a2,80002044 <scheduler+0x5e>
            printk("AGING: PID %d waited 30 scans, priority %d -> %d\n",
    8000207e:	588c                	lw	a1,48(s1)
    80002080:	854e                	mv	a0,s3
    80002082:	c88fe0ef          	jal	8000050a <printk>
    80002086:	bf7d                	j	80002044 <scheduler+0x5e>
    for (int offset = 1; offset <= NPROC; offset++) {
    80002088:	89ee                	mv	s3,s11
    int best_index = -1;
    8000208a:	5d7d                	li	s10,-1
    int best_priority = 21;
    8000208c:	4c55                	li	s8,21
      int i = (last_index + offset) % NPROC;
    8000208e:	00009b97          	auipc	s7,0x9
    80002092:	64ab8b93          	addi	s7,s7,1610 # 8000b6d8 <last_index.2>
      acquire(&p->lock);
    80002096:	00012a97          	auipc	s5,0x12
    8000209a:	b9aa8a93          	addi	s5,s5,-1126 # 80013c30 <proc>
    for (int offset = 1; offset <= NPROC; offset++) {
    8000209e:	04100b13          	li	s6,65
    800020a2:	a039                	j	800020b0 <scheduler+0xca>
      release(&p->lock);
    800020a4:	854a                	mv	a0,s2
    800020a6:	bcbfe0ef          	jal	80000c70 <release>
    for (int offset = 1; offset <= NPROC; offset++) {
    800020aa:	2985                	addiw	s3,s3,1
    800020ac:	05698163          	beq	s3,s6,800020ee <scheduler+0x108>
      int i = (last_index + offset) % NPROC;
    800020b0:	000ba483          	lw	s1,0(s7)
    800020b4:	013484bb          	addw	s1,s1,s3
    800020b8:	41f4d79b          	sraiw	a5,s1,0x1f
    800020bc:	01a7d79b          	srliw	a5,a5,0x1a
    800020c0:	9cbd                	addw	s1,s1,a5
    800020c2:	03f4f493          	andi	s1,s1,63
    800020c6:	9c9d                	subw	s1,s1,a5
      acquire(&p->lock);
    800020c8:	00149913          	slli	s2,s1,0x1
    800020cc:	9926                	add	s2,s2,s1
    800020ce:	091e                	slli	s2,s2,0x7
    800020d0:	9956                	add	s2,s2,s5
    800020d2:	854a                	mv	a0,s2
    800020d4:	b15fe0ef          	jal	80000be8 <acquire>
      if (p->state == RUNNABLE && p->priority < best_priority) {
    800020d8:	01892783          	lw	a5,24(s2)
    800020dc:	fd4794e3          	bne	a5,s4,800020a4 <scheduler+0xbe>
    800020e0:	03492783          	lw	a5,52(s2)
    800020e4:	fd87d0e3          	bge	a5,s8,800020a4 <scheduler+0xbe>
        best_index = i;
    800020e8:	8d26                	mv	s10,s1
        best_priority = p->priority;
    800020ea:	8c3e                	mv	s8,a5
    800020ec:	bf65                	j	800020a4 <scheduler+0xbe>
    if (best_index >= 0) {
    800020ee:	080d4e63          	bltz	s10,8000218a <scheduler+0x1a4>
      p = &proc[best_index];
    800020f2:	001d1493          	slli	s1,s10,0x1
    800020f6:	94ea                	add	s1,s1,s10
    800020f8:	049e                	slli	s1,s1,0x7
    800020fa:	00012917          	auipc	s2,0x12
    800020fe:	b3690913          	addi	s2,s2,-1226 # 80013c30 <proc>
    80002102:	9926                	add	s2,s2,s1
      acquire(&p->lock);
    80002104:	854a                	mv	a0,s2
    80002106:	ae3fe0ef          	jal	80000be8 <acquire>
      if (p->state == RUNNABLE && p->priority == best_priority) {
    8000210a:	01892783          	lw	a5,24(s2)
    8000210e:	03478663          	beq	a5,s4,8000213a <scheduler+0x154>
      release(&p->lock);
    80002112:	854a                	mv	a0,s2
    80002114:	b5dfe0ef          	jal	80000c70 <release>
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80002118:	10016073          	csrsi	sstatus,2
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    8000211c:	10017073          	csrci	sstatus,2
    for (p = proc; p < &proc[NPROC]; p++) {
    80002120:	00012497          	auipc	s1,0x12
    80002124:	b1048493          	addi	s1,s1,-1264 # 80013c30 <proc>
            printk("AGING: PID %d waited 30 scans, priority %d -> %d\n",
    80002128:	00006997          	auipc	s3,0x6
    8000212c:	06898993          	addi	s3,s3,104 # 80008190 <etext+0x190>
    for (p = proc; p < &proc[NPROC]; p++) {
    80002130:	00018917          	auipc	s2,0x18
    80002134:	b0090913          	addi	s2,s2,-1280 # 80019c30 <semtable_lock>
    80002138:	bf29                	j	80002052 <scheduler+0x6c>
      if (p->state == RUNNABLE && p->priority == best_priority) {
    8000213a:	00012717          	auipc	a4,0x12
    8000213e:	af670713          	addi	a4,a4,-1290 # 80013c30 <proc>
    80002142:	03492783          	lw	a5,52(s2)
    80002146:	fd8796e3          	bne	a5,s8,80002112 <scheduler+0x12c>
        p->state = RUNNING;
    8000214a:	85ba                	mv	a1,a4
    8000214c:	4711                	li	a4,4
    8000214e:	00e92c23          	sw	a4,24(s2)
        c->proc = p;
    80002152:	f8043983          	ld	s3,-128(s0)
    80002156:	0329b823          	sd	s2,48(s3)
        last_index = best_index;
    8000215a:	00009797          	auipc	a5,0x9
    8000215e:	57a7af23          	sw	s10,1406(a5) # 8000b6d8 <last_index.2>
        swtch(&c->context, &p->context);
    80002162:	07848493          	addi	s1,s1,120
    80002166:	95a6                	add	a1,a1,s1
    80002168:	f8843503          	ld	a0,-120(s0)
    8000216c:	1fd000ef          	jal	80002b68 <swtch>
  asm volatile("mv %0, tp" : "=r"(x));
    80002170:	8792                	mv	a5,tp
        mycpu()->intena = 0;
    80002172:	2781                	sext.w	a5,a5
    80002174:	079e                	slli	a5,a5,0x7
    80002176:	00011717          	auipc	a4,0x11
    8000217a:	68a70713          	addi	a4,a4,1674 # 80013800 <pid_lock>
    8000217e:	97ba                	add	a5,a5,a4
    80002180:	0a07a623          	sw	zero,172(a5)
        c->proc = 0;
    80002184:	0209b823          	sd	zero,48(s3)
    80002188:	b769                	j	80002112 <scheduler+0x12c>
      asm volatile("wfi");
    8000218a:	10500073          	wfi
    8000218e:	b769                	j	80002118 <scheduler+0x132>

0000000080002190 <sched>:
{
    80002190:	7179                	addi	sp,sp,-48
    80002192:	f406                	sd	ra,40(sp)
    80002194:	f022                	sd	s0,32(sp)
    80002196:	ec26                	sd	s1,24(sp)
    80002198:	e84a                	sd	s2,16(sp)
    8000219a:	e44e                	sd	s3,8(sp)
    8000219c:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    8000219e:	f56ff0ef          	jal	800018f4 <myproc>
    800021a2:	84aa                	mv	s1,a0
  if (!holding(&p->lock))
    800021a4:	9dffe0ef          	jal	80000b82 <holding>
    800021a8:	c935                	beqz	a0,8000221c <sched+0x8c>
    800021aa:	8792                	mv	a5,tp
  if (mycpu()->noff != 1)
    800021ac:	2781                	sext.w	a5,a5
    800021ae:	079e                	slli	a5,a5,0x7
    800021b0:	00011717          	auipc	a4,0x11
    800021b4:	65070713          	addi	a4,a4,1616 # 80013800 <pid_lock>
    800021b8:	97ba                	add	a5,a5,a4
    800021ba:	0a87a703          	lw	a4,168(a5)
    800021be:	4785                	li	a5,1
    800021c0:	06f71463          	bne	a4,a5,80002228 <sched+0x98>
  if (p->state == RUNNING)
    800021c4:	4c98                	lw	a4,24(s1)
    800021c6:	4791                	li	a5,4
    800021c8:	06f70663          	beq	a4,a5,80002234 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    800021cc:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800021d0:	8b89                	andi	a5,a5,2
  if (intr_get())
    800021d2:	e7bd                	bnez	a5,80002240 <sched+0xb0>
  asm volatile("mv %0, tp" : "=r"(x));
    800021d4:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    800021d6:	00011917          	auipc	s2,0x11
    800021da:	62a90913          	addi	s2,s2,1578 # 80013800 <pid_lock>
    800021de:	2781                	sext.w	a5,a5
    800021e0:	079e                	slli	a5,a5,0x7
    800021e2:	97ca                	add	a5,a5,s2
    800021e4:	0ac7a983          	lw	s3,172(a5)
    800021e8:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    800021ea:	2781                	sext.w	a5,a5
    800021ec:	079e                	slli	a5,a5,0x7
    800021ee:	07a1                	addi	a5,a5,8
    800021f0:	00011597          	auipc	a1,0x11
    800021f4:	64058593          	addi	a1,a1,1600 # 80013830 <cpus>
    800021f8:	95be                	add	a1,a1,a5
    800021fa:	07848513          	addi	a0,s1,120
    800021fe:	16b000ef          	jal	80002b68 <swtch>
    80002202:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80002204:	2781                	sext.w	a5,a5
    80002206:	079e                	slli	a5,a5,0x7
    80002208:	993e                	add	s2,s2,a5
    8000220a:	0b392623          	sw	s3,172(s2)
}
    8000220e:	70a2                	ld	ra,40(sp)
    80002210:	7402                	ld	s0,32(sp)
    80002212:	64e2                	ld	s1,24(sp)
    80002214:	6942                	ld	s2,16(sp)
    80002216:	69a2                	ld	s3,8(sp)
    80002218:	6145                	addi	sp,sp,48
    8000221a:	8082                	ret
    panic("sched p->lock");
    8000221c:	00006517          	auipc	a0,0x6
    80002220:	fac50513          	addi	a0,a0,-84 # 800081c8 <etext+0x1c8>
    80002224:	e10fe0ef          	jal	80000834 <panic>
    panic("sched locks");
    80002228:	00006517          	auipc	a0,0x6
    8000222c:	fb050513          	addi	a0,a0,-80 # 800081d8 <etext+0x1d8>
    80002230:	e04fe0ef          	jal	80000834 <panic>
    panic("sched RUNNING");
    80002234:	00006517          	auipc	a0,0x6
    80002238:	fb450513          	addi	a0,a0,-76 # 800081e8 <etext+0x1e8>
    8000223c:	df8fe0ef          	jal	80000834 <panic>
    panic("sched interruptible");
    80002240:	00006517          	auipc	a0,0x6
    80002244:	fb850513          	addi	a0,a0,-72 # 800081f8 <etext+0x1f8>
    80002248:	decfe0ef          	jal	80000834 <panic>

000000008000224c <yield>:
{
    8000224c:	1101                	addi	sp,sp,-32
    8000224e:	ec06                	sd	ra,24(sp)
    80002250:	e822                	sd	s0,16(sp)
    80002252:	e426                	sd	s1,8(sp)
    80002254:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80002256:	e9eff0ef          	jal	800018f4 <myproc>
    8000225a:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000225c:	98dfe0ef          	jal	80000be8 <acquire>
  p->state = RUNNABLE;
    80002260:	478d                	li	a5,3
    80002262:	cc9c                	sw	a5,24(s1)
  sched();
    80002264:	f2dff0ef          	jal	80002190 <sched>
  release(&p->lock);
    80002268:	8526                	mv	a0,s1
    8000226a:	a07fe0ef          	jal	80000c70 <release>
}
    8000226e:	60e2                	ld	ra,24(sp)
    80002270:	6442                	ld	s0,16(sp)
    80002272:	64a2                	ld	s1,8(sp)
    80002274:	6105                	addi	sp,sp,32
    80002276:	8082                	ret

0000000080002278 <sleep_prepare>:

// Register current process as waiting for wakeups on chan.
void
sleep_prepare(void *chan)
{
    80002278:	1101                	addi	sp,sp,-32
    8000227a:	ec06                	sd	ra,24(sp)
    8000227c:	e822                	sd	s0,16(sp)
    8000227e:	e426                	sd	s1,8(sp)
    80002280:	e04a                	sd	s2,0(sp)
    80002282:	1000                	addi	s0,sp,32
    80002284:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002286:	e6eff0ef          	jal	800018f4 <myproc>
    8000228a:	892a                	mv	s2,a0

  acquire(&p->lock);
    8000228c:	95dfe0ef          	jal	80000be8 <acquire>
  if (chan == 0)
    80002290:	cc81                	beqz	s1,800022a8 <sleep_prepare+0x30>
    panic("sleep_prepare: zero chan");
  p->chan = chan;
    80002292:	02993023          	sd	s1,32(s2)
  release(&p->lock);
    80002296:	854a                	mv	a0,s2
    80002298:	9d9fe0ef          	jal	80000c70 <release>
}
    8000229c:	60e2                	ld	ra,24(sp)
    8000229e:	6442                	ld	s0,16(sp)
    800022a0:	64a2                	ld	s1,8(sp)
    800022a2:	6902                	ld	s2,0(sp)
    800022a4:	6105                	addi	sp,sp,32
    800022a6:	8082                	ret
    panic("sleep_prepare: zero chan");
    800022a8:	00006517          	auipc	a0,0x6
    800022ac:	f6850513          	addi	a0,a0,-152 # 80008210 <etext+0x210>
    800022b0:	d84fe0ef          	jal	80000834 <panic>

00000000800022b4 <sleep>:
// Put the thread to sleep.  Assumes sleep_prepare() was called before.
// If the channel registered by sleep_prepare() has been woken up in
// the meantime, do not go to sleep, and instead return immediately.
void
sleep(void)
{
    800022b4:	1101                	addi	sp,sp,-32
    800022b6:	ec06                	sd	ra,24(sp)
    800022b8:	e822                	sd	s0,16(sp)
    800022ba:	e426                	sd	s1,8(sp)
    800022bc:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    800022be:	e36ff0ef          	jal	800018f4 <myproc>
    800022c2:	84aa                	mv	s1,a0

  acquire(&p->lock);
    800022c4:	925fe0ef          	jal	80000be8 <acquire>
  if (p->chan != 0) {
    800022c8:	709c                	ld	a5,32(s1)
    800022ca:	c789                	beqz	a5,800022d4 <sleep+0x20>
    p->state = SLEEPING;
    800022cc:	4789                	li	a5,2
    800022ce:	cc9c                	sw	a5,24(s1)
    sched();
    800022d0:	ec1ff0ef          	jal	80002190 <sched>
  }
  release(&p->lock);
    800022d4:	8526                	mv	a0,s1
    800022d6:	99bfe0ef          	jal	80000c70 <release>
}
    800022da:	60e2                	ld	ra,24(sp)
    800022dc:	6442                	ld	s0,16(sp)
    800022de:	64a2                	ld	s1,8(sp)
    800022e0:	6105                	addi	sp,sp,32
    800022e2:	8082                	ret

00000000800022e4 <wakeup>:

// Wake up all processes sleeping on channel chan.
void
wakeup(void *chan)
{
    800022e4:	7139                	addi	sp,sp,-64
    800022e6:	fc06                	sd	ra,56(sp)
    800022e8:	f822                	sd	s0,48(sp)
    800022ea:	f426                	sd	s1,40(sp)
    800022ec:	f04a                	sd	s2,32(sp)
    800022ee:	ec4e                	sd	s3,24(sp)
    800022f0:	e852                	sd	s4,16(sp)
    800022f2:	e456                	sd	s5,8(sp)
    800022f4:	0080                	addi	s0,sp,64
    800022f6:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    800022f8:	00012497          	auipc	s1,0x12
    800022fc:	93848493          	addi	s1,s1,-1736 # 80013c30 <proc>
      // signal that the wakeup happened by clearing p->chan.
      p->chan = 0;

      // If this waiting process has gotten so far as to actually
      // go to sleep, also set it back to RUNNING.
      if (p->state == SLEEPING) {
    80002300:	4a09                	li	s4,2
        p->state = RUNNABLE;
    80002302:	4a8d                	li	s5,3
  for (p = proc; p < &proc[NPROC]; p++) {
    80002304:	00018997          	auipc	s3,0x18
    80002308:	92c98993          	addi	s3,s3,-1748 # 80019c30 <semtable_lock>
    8000230c:	a801                	j	8000231c <wakeup+0x38>
      }
    }
    release(&p->lock);
    8000230e:	8526                	mv	a0,s1
    80002310:	961fe0ef          	jal	80000c70 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002314:	18048493          	addi	s1,s1,384
    80002318:	03348063          	beq	s1,s3,80002338 <wakeup+0x54>
    acquire(&p->lock);
    8000231c:	8526                	mv	a0,s1
    8000231e:	8cbfe0ef          	jal	80000be8 <acquire>
    if (p->chan == chan) {
    80002322:	709c                	ld	a5,32(s1)
    80002324:	ff2795e3          	bne	a5,s2,8000230e <wakeup+0x2a>
      p->chan = 0;
    80002328:	0204b023          	sd	zero,32(s1)
      if (p->state == SLEEPING) {
    8000232c:	4c9c                	lw	a5,24(s1)
    8000232e:	ff4790e3          	bne	a5,s4,8000230e <wakeup+0x2a>
        p->state = RUNNABLE;
    80002332:	0154ac23          	sw	s5,24(s1)
    80002336:	bfe1                	j	8000230e <wakeup+0x2a>
  }
}
    80002338:	70e2                	ld	ra,56(sp)
    8000233a:	7442                	ld	s0,48(sp)
    8000233c:	74a2                	ld	s1,40(sp)
    8000233e:	7902                	ld	s2,32(sp)
    80002340:	69e2                	ld	s3,24(sp)
    80002342:	6a42                	ld	s4,16(sp)
    80002344:	6aa2                	ld	s5,8(sp)
    80002346:	6121                	addi	sp,sp,64
    80002348:	8082                	ret

000000008000234a <reparent>:
{
    8000234a:	7179                	addi	sp,sp,-48
    8000234c:	f406                	sd	ra,40(sp)
    8000234e:	f022                	sd	s0,32(sp)
    80002350:	ec26                	sd	s1,24(sp)
    80002352:	e84a                	sd	s2,16(sp)
    80002354:	e44e                	sd	s3,8(sp)
    80002356:	e052                	sd	s4,0(sp)
    80002358:	1800                	addi	s0,sp,48
    8000235a:	892a                	mv	s2,a0
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000235c:	00012497          	auipc	s1,0x12
    80002360:	8d448493          	addi	s1,s1,-1836 # 80013c30 <proc>
      pp->parent = initproc;
    80002364:	00009a17          	auipc	s4,0x9
    80002368:	37ca0a13          	addi	s4,s4,892 # 8000b6e0 <initproc>
  for (pp = proc; pp < &proc[NPROC]; pp++) {
    8000236c:	00018997          	auipc	s3,0x18
    80002370:	8c498993          	addi	s3,s3,-1852 # 80019c30 <semtable_lock>
    80002374:	a029                	j	8000237e <reparent+0x34>
    80002376:	18048493          	addi	s1,s1,384
    8000237a:	01348b63          	beq	s1,s3,80002390 <reparent+0x46>
    if (pp->parent == p) {
    8000237e:	60bc                	ld	a5,64(s1)
    80002380:	ff279be3          	bne	a5,s2,80002376 <reparent+0x2c>
      pp->parent = initproc;
    80002384:	000a3503          	ld	a0,0(s4)
    80002388:	e0a8                	sd	a0,64(s1)
      wakeup(initproc);
    8000238a:	f5bff0ef          	jal	800022e4 <wakeup>
    8000238e:	b7e5                	j	80002376 <reparent+0x2c>
}
    80002390:	70a2                	ld	ra,40(sp)
    80002392:	7402                	ld	s0,32(sp)
    80002394:	64e2                	ld	s1,24(sp)
    80002396:	6942                	ld	s2,16(sp)
    80002398:	69a2                	ld	s3,8(sp)
    8000239a:	6a02                	ld	s4,0(sp)
    8000239c:	6145                	addi	sp,sp,48
    8000239e:	8082                	ret

00000000800023a0 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800023a0:	7179                	addi	sp,sp,-48
    800023a2:	f406                	sd	ra,40(sp)
    800023a4:	f022                	sd	s0,32(sp)
    800023a6:	ec26                	sd	s1,24(sp)
    800023a8:	e84a                	sd	s2,16(sp)
    800023aa:	e44e                	sd	s3,8(sp)
    800023ac:	1800                	addi	s0,sp,48
    800023ae:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    800023b0:	00012497          	auipc	s1,0x12
    800023b4:	88048493          	addi	s1,s1,-1920 # 80013c30 <proc>
    800023b8:	00018997          	auipc	s3,0x18
    800023bc:	87898993          	addi	s3,s3,-1928 # 80019c30 <semtable_lock>
    acquire(&p->lock);
    800023c0:	8526                	mv	a0,s1
    800023c2:	827fe0ef          	jal	80000be8 <acquire>
    if (p->pid == pid) {
    800023c6:	589c                	lw	a5,48(s1)
    800023c8:	01278b63          	beq	a5,s2,800023de <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800023cc:	8526                	mv	a0,s1
    800023ce:	8a3fe0ef          	jal	80000c70 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    800023d2:	18048493          	addi	s1,s1,384
    800023d6:	ff3495e3          	bne	s1,s3,800023c0 <kkill+0x20>
  }
  return -1;
    800023da:	557d                	li	a0,-1
    800023dc:	a819                	j	800023f2 <kkill+0x52>
      p->killed = 1;
    800023de:	4785                	li	a5,1
    800023e0:	d49c                	sw	a5,40(s1)
      if (p->state == SLEEPING) {
    800023e2:	4c98                	lw	a4,24(s1)
    800023e4:	4789                	li	a5,2
    800023e6:	00f70d63          	beq	a4,a5,80002400 <kkill+0x60>
      release(&p->lock);
    800023ea:	8526                	mv	a0,s1
    800023ec:	885fe0ef          	jal	80000c70 <release>
      return 0;
    800023f0:	4501                	li	a0,0
}
    800023f2:	70a2                	ld	ra,40(sp)
    800023f4:	7402                	ld	s0,32(sp)
    800023f6:	64e2                	ld	s1,24(sp)
    800023f8:	6942                	ld	s2,16(sp)
    800023fa:	69a2                	ld	s3,8(sp)
    800023fc:	6145                	addi	sp,sp,48
    800023fe:	8082                	ret
        p->state = RUNNABLE;
    80002400:	478d                	li	a5,3
    80002402:	cc9c                	sw	a5,24(s1)
    80002404:	b7dd                	j	800023ea <kkill+0x4a>

0000000080002406 <setkilled>:

void
setkilled(struct proc *p)
{
    80002406:	1101                	addi	sp,sp,-32
    80002408:	ec06                	sd	ra,24(sp)
    8000240a:	e822                	sd	s0,16(sp)
    8000240c:	e426                	sd	s1,8(sp)
    8000240e:	1000                	addi	s0,sp,32
    80002410:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002412:	fd6fe0ef          	jal	80000be8 <acquire>
  p->killed = 1;
    80002416:	4785                	li	a5,1
    80002418:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    8000241a:	8526                	mv	a0,s1
    8000241c:	855fe0ef          	jal	80000c70 <release>
}
    80002420:	60e2                	ld	ra,24(sp)
    80002422:	6442                	ld	s0,16(sp)
    80002424:	64a2                	ld	s1,8(sp)
    80002426:	6105                	addi	sp,sp,32
    80002428:	8082                	ret

000000008000242a <killed>:

int
killed(struct proc *p)
{
    8000242a:	1101                	addi	sp,sp,-32
    8000242c:	ec06                	sd	ra,24(sp)
    8000242e:	e822                	sd	s0,16(sp)
    80002430:	e426                	sd	s1,8(sp)
    80002432:	e04a                	sd	s2,0(sp)
    80002434:	1000                	addi	s0,sp,32
    80002436:	84aa                	mv	s1,a0
  int k;

  acquire(&p->lock);
    80002438:	fb0fe0ef          	jal	80000be8 <acquire>
  k = p->killed;
    8000243c:	549c                	lw	a5,40(s1)
    8000243e:	893e                	mv	s2,a5
  release(&p->lock);
    80002440:	8526                	mv	a0,s1
    80002442:	82ffe0ef          	jal	80000c70 <release>
  return k;
}
    80002446:	854a                	mv	a0,s2
    80002448:	60e2                	ld	ra,24(sp)
    8000244a:	6442                	ld	s0,16(sp)
    8000244c:	64a2                	ld	s1,8(sp)
    8000244e:	6902                	ld	s2,0(sp)
    80002450:	6105                	addi	sp,sp,32
    80002452:	8082                	ret

0000000080002454 <kwait>:
{
    80002454:	715d                	addi	sp,sp,-80
    80002456:	e486                	sd	ra,72(sp)
    80002458:	e0a2                	sd	s0,64(sp)
    8000245a:	fc26                	sd	s1,56(sp)
    8000245c:	f84a                	sd	s2,48(sp)
    8000245e:	f44e                	sd	s3,40(sp)
    80002460:	f052                	sd	s4,32(sp)
    80002462:	ec56                	sd	s5,24(sp)
    80002464:	e85a                	sd	s6,16(sp)
    80002466:	e45e                	sd	s7,8(sp)
    80002468:	0880                	addi	s0,sp,80
    8000246a:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    8000246c:	c88ff0ef          	jal	800018f4 <myproc>
    80002470:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002472:	00011517          	auipc	a0,0x11
    80002476:	3a650513          	addi	a0,a0,934 # 80013818 <wait_lock>
    8000247a:	f6efe0ef          	jal	80000be8 <acquire>
        if (pp->state == ZOMBIE) {
    8000247e:	4a15                	li	s4,5
        havekids = 1;
    80002480:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002482:	00017997          	auipc	s3,0x17
    80002486:	7ae98993          	addi	s3,s3,1966 # 80019c30 <semtable_lock>
    release(&wait_lock);
    8000248a:	00011b17          	auipc	s6,0x11
    8000248e:	38eb0b13          	addi	s6,s6,910 # 80013818 <wait_lock>
    80002492:	a84d                	j	80002544 <kwait+0xf0>
            release(&pp->lock);
    80002494:	8526                	mv	a0,s1
    80002496:	fdafe0ef          	jal	80000c70 <release>
            release(&wait_lock);
    8000249a:	00011517          	auipc	a0,0x11
    8000249e:	37e50513          	addi	a0,a0,894 # 80013818 <wait_lock>
    800024a2:	fcefe0ef          	jal	80000c70 <release>
            return -1;
    800024a6:	59fd                	li	s3,-1
    800024a8:	a095                	j	8000250c <kwait+0xb8>
        release(&pp->lock);
    800024aa:	8526                	mv	a0,s1
    800024ac:	fc4fe0ef          	jal	80000c70 <release>
        havekids = 1;
    800024b0:	8756                	mv	a4,s5
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800024b2:	18048493          	addi	s1,s1,384
    800024b6:	07348763          	beq	s1,s3,80002524 <kwait+0xd0>
      if (pp->parent == p && !pp->is_thread) {
    800024ba:	60bc                	ld	a5,64(s1)
    800024bc:	ff279be3          	bne	a5,s2,800024b2 <kwait+0x5e>
    800024c0:	44bc                	lw	a5,72(s1)
    800024c2:	fbe5                	bnez	a5,800024b2 <kwait+0x5e>
        acquire(&pp->lock);
    800024c4:	8526                	mv	a0,s1
    800024c6:	f22fe0ef          	jal	80000be8 <acquire>
        if (pp->state == ZOMBIE) {
    800024ca:	4c9c                	lw	a5,24(s1)
    800024cc:	fd479fe3          	bne	a5,s4,800024aa <kwait+0x56>
          pid = pp->pid;
    800024d0:	0304a983          	lw	s3,48(s1)
          if (addr != 0 &&
    800024d4:	000b8e63          	beqz	s7,800024f0 <kwait+0x9c>
              copyout(p->pagetable, p->sz, addr, (char *)&pp->xstate,
    800024d8:	4711                	li	a4,4
    800024da:	02c48693          	addi	a3,s1,44
    800024de:	865e                	mv	a2,s7
    800024e0:	06093583          	ld	a1,96(s2)
    800024e4:	06893503          	ld	a0,104(s2)
    800024e8:	85eff0ef          	jal	80001546 <copyout>
          if (addr != 0 &&
    800024ec:	fa0544e3          	bltz	a0,80002494 <kwait+0x40>
          pp->parent = 0;
    800024f0:	0404b023          	sd	zero,64(s1)
          freeproc(pp);
    800024f4:	8526                	mv	a0,s1
    800024f6:	ddeff0ef          	jal	80001ad4 <freeproc>
          release(&pp->lock);
    800024fa:	8526                	mv	a0,s1
    800024fc:	f74fe0ef          	jal	80000c70 <release>
          release(&wait_lock);
    80002500:	00011517          	auipc	a0,0x11
    80002504:	31850513          	addi	a0,a0,792 # 80013818 <wait_lock>
    80002508:	f68fe0ef          	jal	80000c70 <release>
}
    8000250c:	854e                	mv	a0,s3
    8000250e:	60a6                	ld	ra,72(sp)
    80002510:	6406                	ld	s0,64(sp)
    80002512:	74e2                	ld	s1,56(sp)
    80002514:	7942                	ld	s2,48(sp)
    80002516:	79a2                	ld	s3,40(sp)
    80002518:	7a02                	ld	s4,32(sp)
    8000251a:	6ae2                	ld	s5,24(sp)
    8000251c:	6b42                	ld	s6,16(sp)
    8000251e:	6ba2                	ld	s7,8(sp)
    80002520:	6161                	addi	sp,sp,80
    80002522:	8082                	ret
    if (!havekids || killed(p)) {
    80002524:	c715                	beqz	a4,80002550 <kwait+0xfc>
    80002526:	854a                	mv	a0,s2
    80002528:	f03ff0ef          	jal	8000242a <killed>
    8000252c:	e115                	bnez	a0,80002550 <kwait+0xfc>
    sleep_prepare(p); //DOC: wait-sleep
    8000252e:	854a                	mv	a0,s2
    80002530:	d49ff0ef          	jal	80002278 <sleep_prepare>
    release(&wait_lock);
    80002534:	855a                	mv	a0,s6
    80002536:	f3afe0ef          	jal	80000c70 <release>
    sleep();
    8000253a:	d7bff0ef          	jal	800022b4 <sleep>
    acquire(&wait_lock);
    8000253e:	855a                	mv	a0,s6
    80002540:	ea8fe0ef          	jal	80000be8 <acquire>
    havekids = 0;
    80002544:	4701                	li	a4,0
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002546:	00011497          	auipc	s1,0x11
    8000254a:	6ea48493          	addi	s1,s1,1770 # 80013c30 <proc>
    8000254e:	b7b5                	j	800024ba <kwait+0x66>
      release(&wait_lock);
    80002550:	00011517          	auipc	a0,0x11
    80002554:	2c850513          	addi	a0,a0,712 # 80013818 <wait_lock>
    80002558:	f18fe0ef          	jal	80000c70 <release>
      return -1;
    8000255c:	59fd                	li	s3,-1
    8000255e:	b77d                	j	8000250c <kwait+0xb8>

0000000080002560 <kjoin>:
{
    80002560:	715d                	addi	sp,sp,-80
    80002562:	e486                	sd	ra,72(sp)
    80002564:	e0a2                	sd	s0,64(sp)
    80002566:	f84a                	sd	s2,48(sp)
    80002568:	e45e                	sd	s7,8(sp)
    8000256a:	0880                	addi	s0,sp,80
  struct proc *p = myproc();
    8000256c:	b88ff0ef          	jal	800018f4 <myproc>
  if (p->is_thread)
    80002570:	04852b83          	lw	s7,72(a0)
    80002574:	0c0b9b63          	bnez	s7,8000264a <kjoin+0xea>
    80002578:	fc26                	sd	s1,56(sp)
    8000257a:	f44e                	sd	s3,40(sp)
    8000257c:	f052                	sd	s4,32(sp)
    8000257e:	ec56                	sd	s5,24(sp)
    80002580:	e85a                	sd	s6,16(sp)
    80002582:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002584:	00011517          	auipc	a0,0x11
    80002588:	29450513          	addi	a0,a0,660 # 80013818 <wait_lock>
    8000258c:	e5cfe0ef          	jal	80000be8 <acquire>
        if (pp->state == ZOMBIE) {
    80002590:	4a15                	li	s4,5
        have_threads = 1;
    80002592:	4a85                	li	s5,1
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002594:	00017997          	auipc	s3,0x17
    80002598:	69c98993          	addi	s3,s3,1692 # 80019c30 <semtable_lock>
    release(&wait_lock);
    8000259c:	00011b17          	auipc	s6,0x11
    800025a0:	27cb0b13          	addi	s6,s6,636 # 80013818 <wait_lock>
    800025a4:	a041                	j	80002624 <kjoin+0xc4>
        release(&pp->lock);
    800025a6:	8526                	mv	a0,s1
    800025a8:	ec8fe0ef          	jal	80000c70 <release>
        have_threads = 1;
    800025ac:	8756                	mv	a4,s5
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    800025ae:	18048493          	addi	s1,s1,384
    800025b2:	05348963          	beq	s1,s3,80002604 <kjoin+0xa4>
      if (pp->parent == p && pp->is_thread) {
    800025b6:	60bc                	ld	a5,64(s1)
    800025b8:	ff279be3          	bne	a5,s2,800025ae <kjoin+0x4e>
    800025bc:	44bc                	lw	a5,72(s1)
    800025be:	dbe5                	beqz	a5,800025ae <kjoin+0x4e>
        acquire(&pp->lock);
    800025c0:	8526                	mv	a0,s1
    800025c2:	e26fe0ef          	jal	80000be8 <acquire>
        if (pp->state == ZOMBIE) {
    800025c6:	4c9c                	lw	a5,24(s1)
    800025c8:	fd479fe3          	bne	a5,s4,800025a6 <kjoin+0x46>
          pid = pp->pid;
    800025cc:	0304a903          	lw	s2,48(s1)
          pp->parent = 0;
    800025d0:	0404b023          	sd	zero,64(s1)
          freeproc(pp);
    800025d4:	8526                	mv	a0,s1
    800025d6:	cfeff0ef          	jal	80001ad4 <freeproc>
          release(&pp->lock);
    800025da:	8526                	mv	a0,s1
    800025dc:	e94fe0ef          	jal	80000c70 <release>
          release(&wait_lock);
    800025e0:	00011517          	auipc	a0,0x11
    800025e4:	23850513          	addi	a0,a0,568 # 80013818 <wait_lock>
    800025e8:	e88fe0ef          	jal	80000c70 <release>
          return pid;
    800025ec:	74e2                	ld	s1,56(sp)
    800025ee:	79a2                	ld	s3,40(sp)
    800025f0:	7a02                	ld	s4,32(sp)
    800025f2:	6ae2                	ld	s5,24(sp)
    800025f4:	6b42                	ld	s6,16(sp)
}
    800025f6:	854a                	mv	a0,s2
    800025f8:	60a6                	ld	ra,72(sp)
    800025fa:	6406                	ld	s0,64(sp)
    800025fc:	7942                	ld	s2,48(sp)
    800025fe:	6ba2                	ld	s7,8(sp)
    80002600:	6161                	addi	sp,sp,80
    80002602:	8082                	ret
    if (!have_threads || killed(p)) {
    80002604:	c715                	beqz	a4,80002630 <kjoin+0xd0>
    80002606:	854a                	mv	a0,s2
    80002608:	e23ff0ef          	jal	8000242a <killed>
    8000260c:	e115                	bnez	a0,80002630 <kjoin+0xd0>
    sleep_prepare(p);
    8000260e:	854a                	mv	a0,s2
    80002610:	c69ff0ef          	jal	80002278 <sleep_prepare>
    release(&wait_lock);
    80002614:	855a                	mv	a0,s6
    80002616:	e5afe0ef          	jal	80000c70 <release>
    sleep();
    8000261a:	c9bff0ef          	jal	800022b4 <sleep>
    acquire(&wait_lock);
    8000261e:	855a                	mv	a0,s6
    80002620:	dc8fe0ef          	jal	80000be8 <acquire>
    have_threads = 0;
    80002624:	875e                	mv	a4,s7
    for (pp = proc; pp < &proc[NPROC]; pp++) {
    80002626:	00011497          	auipc	s1,0x11
    8000262a:	60a48493          	addi	s1,s1,1546 # 80013c30 <proc>
    8000262e:	b761                	j	800025b6 <kjoin+0x56>
      release(&wait_lock);
    80002630:	00011517          	auipc	a0,0x11
    80002634:	1e850513          	addi	a0,a0,488 # 80013818 <wait_lock>
    80002638:	e38fe0ef          	jal	80000c70 <release>
      return -1;
    8000263c:	597d                	li	s2,-1
    8000263e:	74e2                	ld	s1,56(sp)
    80002640:	79a2                	ld	s3,40(sp)
    80002642:	7a02                	ld	s4,32(sp)
    80002644:	6ae2                	ld	s5,24(sp)
    80002646:	6b42                	ld	s6,16(sp)
    80002648:	b77d                	j	800025f6 <kjoin+0x96>
    return -1;
    8000264a:	597d                	li	s2,-1
    8000264c:	b76d                	j	800025f6 <kjoin+0x96>

000000008000264e <kexit>:
{
    8000264e:	7179                	addi	sp,sp,-48
    80002650:	f406                	sd	ra,40(sp)
    80002652:	f022                	sd	s0,32(sp)
    80002654:	e052                	sd	s4,0(sp)
    80002656:	1800                	addi	s0,sp,48
    80002658:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000265a:	a9aff0ef          	jal	800018f4 <myproc>
    if (p == initproc)
    8000265e:	00009797          	auipc	a5,0x9
    80002662:	0827b783          	ld	a5,130(a5) # 8000b6e0 <initproc>
    80002666:	02a78163          	beq	a5,a0,80002688 <kexit+0x3a>
    8000266a:	ec26                	sd	s1,24(sp)
    8000266c:	e84a                	sd	s2,16(sp)
    8000266e:	e44e                	sd	s3,8(sp)
    80002670:	89aa                	mv	s3,a0
   if (!p->is_thread) {
    80002672:	453c                	lw	a5,72(a0)
    80002674:	e789                	bnez	a5,8000267e <kexit+0x30>
     while (kjoin() >= 0)
    80002676:	eebff0ef          	jal	80002560 <kjoin>
    8000267a:	fe055ee3          	bgez	a0,80002676 <kexit+0x28>
  for (int fd = 0; fd < NOFILE; fd++) {
    8000267e:	0e898493          	addi	s1,s3,232
    80002682:	16898913          	addi	s2,s3,360
    80002686:	a829                	j	800026a0 <kexit+0x52>
    80002688:	ec26                	sd	s1,24(sp)
    8000268a:	e84a                	sd	s2,16(sp)
    8000268c:	e44e                	sd	s3,8(sp)
    panic("init exiting");
    8000268e:	00006517          	auipc	a0,0x6
    80002692:	ba250513          	addi	a0,a0,-1118 # 80008230 <etext+0x230>
    80002696:	99efe0ef          	jal	80000834 <panic>
  for (int fd = 0; fd < NOFILE; fd++) {
    8000269a:	04a1                	addi	s1,s1,8
    8000269c:	01248963          	beq	s1,s2,800026ae <kexit+0x60>
    if (p->ofile[fd]) {
    800026a0:	6088                	ld	a0,0(s1)
    800026a2:	dd65                	beqz	a0,8000269a <kexit+0x4c>
      fileclose(f);
    800026a4:	302020ef          	jal	800049a6 <fileclose>
      p->ofile[fd] = 0;
    800026a8:	0004b023          	sd	zero,0(s1)
    800026ac:	b7fd                	j	8000269a <kexit+0x4c>
  begin_op();
    800026ae:	63f010ef          	jal	800044ec <begin_op>
  iput(p->cwd);
    800026b2:	1689b503          	ld	a0,360(s3)
    800026b6:	596010ef          	jal	80003c4c <iput>
  end_op();
    800026ba:	6bf010ef          	jal	80004578 <end_op>
  p->cwd = 0;
    800026be:	1609b423          	sd	zero,360(s3)
  acquire(&wait_lock);
    800026c2:	00011517          	auipc	a0,0x11
    800026c6:	15650513          	addi	a0,a0,342 # 80013818 <wait_lock>
    800026ca:	d1efe0ef          	jal	80000be8 <acquire>
  reparent(p);
    800026ce:	854e                	mv	a0,s3
    800026d0:	c7bff0ef          	jal	8000234a <reparent>
  wakeup(p->parent);
    800026d4:	0409b503          	ld	a0,64(s3)
    800026d8:	c0dff0ef          	jal	800022e4 <wakeup>
  acquire(&p->lock);
    800026dc:	854e                	mv	a0,s3
    800026de:	d0afe0ef          	jal	80000be8 <acquire>
  p->xstate = status;
    800026e2:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800026e6:	4795                	li	a5,5
    800026e8:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800026ec:	00011517          	auipc	a0,0x11
    800026f0:	12c50513          	addi	a0,a0,300 # 80013818 <wait_lock>
    800026f4:	d7cfe0ef          	jal	80000c70 <release>
  sched();
    800026f8:	a99ff0ef          	jal	80002190 <sched>
  panic("zombie exit");
    800026fc:	00006517          	auipc	a0,0x6
    80002700:	b4450513          	addi	a0,a0,-1212 # 80008240 <etext+0x240>
    80002704:	930fe0ef          	jal	80000834 <panic>

0000000080002708 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002708:	7179                	addi	sp,sp,-48
    8000270a:	f406                	sd	ra,40(sp)
    8000270c:	f022                	sd	s0,32(sp)
    8000270e:	ec26                	sd	s1,24(sp)
    80002710:	e84a                	sd	s2,16(sp)
    80002712:	e44e                	sd	s3,8(sp)
    80002714:	e052                	sd	s4,0(sp)
    80002716:	1800                	addi	s0,sp,48
    80002718:	84aa                	mv	s1,a0
    8000271a:	8a2e                	mv	s4,a1
    8000271c:	89b2                	mv	s3,a2
    8000271e:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002720:	9d4ff0ef          	jal	800018f4 <myproc>
  if (user_dst) {
    80002724:	c085                	beqz	s1,80002744 <either_copyout+0x3c>
    return copyout(p->pagetable, p->sz, dst, src, len);
    80002726:	874a                	mv	a4,s2
    80002728:	86ce                	mv	a3,s3
    8000272a:	8652                	mv	a2,s4
    8000272c:	712c                	ld	a1,96(a0)
    8000272e:	7528                	ld	a0,104(a0)
    80002730:	e17fe0ef          	jal	80001546 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002734:	70a2                	ld	ra,40(sp)
    80002736:	7402                	ld	s0,32(sp)
    80002738:	64e2                	ld	s1,24(sp)
    8000273a:	6942                	ld	s2,16(sp)
    8000273c:	69a2                	ld	s3,8(sp)
    8000273e:	6a02                	ld	s4,0(sp)
    80002740:	6145                	addi	sp,sp,48
    80002742:	8082                	ret
    memmove((char *)dst, src, len);
    80002744:	0009061b          	sext.w	a2,s2
    80002748:	85ce                	mv	a1,s3
    8000274a:	8552                	mv	a0,s4
    8000274c:	dbcfe0ef          	jal	80000d08 <memmove>
    return 0;
    80002750:	8526                	mv	a0,s1
    80002752:	b7cd                	j	80002734 <either_copyout+0x2c>

0000000080002754 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002754:	7179                	addi	sp,sp,-48
    80002756:	f406                	sd	ra,40(sp)
    80002758:	f022                	sd	s0,32(sp)
    8000275a:	ec26                	sd	s1,24(sp)
    8000275c:	e84a                	sd	s2,16(sp)
    8000275e:	e44e                	sd	s3,8(sp)
    80002760:	e052                	sd	s4,0(sp)
    80002762:	1800                	addi	s0,sp,48
    80002764:	8a2a                	mv	s4,a0
    80002766:	84ae                	mv	s1,a1
    80002768:	89b2                	mv	s3,a2
    8000276a:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000276c:	988ff0ef          	jal	800018f4 <myproc>
  if (user_src) {
    80002770:	c085                	beqz	s1,80002790 <either_copyin+0x3c>
    return copyin(p->pagetable, p->sz, dst, src, len);
    80002772:	874a                	mv	a4,s2
    80002774:	86ce                	mv	a3,s3
    80002776:	8652                	mv	a2,s4
    80002778:	712c                	ld	a1,96(a0)
    8000277a:	7528                	ld	a0,104(a0)
    8000277c:	e91fe0ef          	jal	8000160c <copyin>
  } else {
    memmove(dst, (char *)src, len);
    return 0;
  }
}
    80002780:	70a2                	ld	ra,40(sp)
    80002782:	7402                	ld	s0,32(sp)
    80002784:	64e2                	ld	s1,24(sp)
    80002786:	6942                	ld	s2,16(sp)
    80002788:	69a2                	ld	s3,8(sp)
    8000278a:	6a02                	ld	s4,0(sp)
    8000278c:	6145                	addi	sp,sp,48
    8000278e:	8082                	ret
    memmove(dst, (char *)src, len);
    80002790:	0009061b          	sext.w	a2,s2
    80002794:	85ce                	mv	a1,s3
    80002796:	8552                	mv	a0,s4
    80002798:	d70fe0ef          	jal	80000d08 <memmove>
    return 0;
    8000279c:	8526                	mv	a0,s1
    8000279e:	b7cd                	j	80002780 <either_copyin+0x2c>

00000000800027a0 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800027a0:	715d                	addi	sp,sp,-80
    800027a2:	e486                	sd	ra,72(sp)
    800027a4:	e0a2                	sd	s0,64(sp)
    800027a6:	fc26                	sd	s1,56(sp)
    800027a8:	f84a                	sd	s2,48(sp)
    800027aa:	f44e                	sd	s3,40(sp)
    800027ac:	f052                	sd	s4,32(sp)
    800027ae:	ec56                	sd	s5,24(sp)
    800027b0:	e85a                	sd	s6,16(sp)
    800027b2:	e45e                	sd	s7,8(sp)
    800027b4:	0880                	addi	s0,sp,80
    // clang-format on
  };
  struct proc *p;
  char *state;

  printk("\n");
    800027b6:	00006517          	auipc	a0,0x6
    800027ba:	a0a50513          	addi	a0,a0,-1526 # 800081c0 <etext+0x1c0>
    800027be:	d4dfd0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    800027c2:	00011497          	auipc	s1,0x11
    800027c6:	5de48493          	addi	s1,s1,1502 # 80013da0 <proc+0x170>
    800027ca:	00017917          	auipc	s2,0x17
    800027ce:	5d690913          	addi	s2,s2,1494 # 80019da0 <bcache>
    if (p->state == UNUSED)
      continue;
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800027d2:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    800027d4:	00006997          	auipc	s3,0x6
    800027d8:	a7c98993          	addi	s3,s3,-1412 # 80008250 <etext+0x250>
    printk("%d %s %s", p->pid, state, p->name);
    800027dc:	00006a97          	auipc	s5,0x6
    800027e0:	a7ca8a93          	addi	s5,s5,-1412 # 80008258 <etext+0x258>
    printk("\n");
    800027e4:	00006a17          	auipc	s4,0x6
    800027e8:	9dca0a13          	addi	s4,s4,-1572 # 800081c0 <etext+0x1c0>
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800027ec:	00006b97          	auipc	s7,0x6
    800027f0:	facb8b93          	addi	s7,s7,-84 # 80008798 <states.0>
    800027f4:	a829                	j	8000280e <procdump+0x6e>
    printk("%d %s %s", p->pid, state, p->name);
    800027f6:	ec06a583          	lw	a1,-320(a3)
    800027fa:	8556                	mv	a0,s5
    800027fc:	d0ffd0ef          	jal	8000050a <printk>
    printk("\n");
    80002800:	8552                	mv	a0,s4
    80002802:	d09fd0ef          	jal	8000050a <printk>
  for (p = proc; p < &proc[NPROC]; p++) {
    80002806:	18048493          	addi	s1,s1,384
    8000280a:	03248263          	beq	s1,s2,8000282e <procdump+0x8e>
    if (p->state == UNUSED)
    8000280e:	86a6                	mv	a3,s1
    80002810:	ea84a783          	lw	a5,-344(s1)
    80002814:	dbed                	beqz	a5,80002806 <procdump+0x66>
      state = "???";
    80002816:	864e                	mv	a2,s3
    if (p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002818:	fcfb6fe3          	bltu	s6,a5,800027f6 <procdump+0x56>
    8000281c:	02079713          	slli	a4,a5,0x20
    80002820:	01d75793          	srli	a5,a4,0x1d
    80002824:	97de                	add	a5,a5,s7
    80002826:	6390                	ld	a2,0(a5)
    80002828:	f679                	bnez	a2,800027f6 <procdump+0x56>
      state = "???";
    8000282a:	864e                	mv	a2,s3
    8000282c:	b7e9                	j	800027f6 <procdump+0x56>
  }
}
    8000282e:	60a6                	ld	ra,72(sp)
    80002830:	6406                	ld	s0,64(sp)
    80002832:	74e2                	ld	s1,56(sp)
    80002834:	7942                	ld	s2,48(sp)
    80002836:	79a2                	ld	s3,40(sp)
    80002838:	7a02                	ld	s4,32(sp)
    8000283a:	6ae2                	ld	s5,24(sp)
    8000283c:	6b42                	ld	s6,16(sp)
    8000283e:	6ba2                	ld	s7,8(sp)
    80002840:	6161                	addi	sp,sp,80
    80002842:	8082                	ret

0000000080002844 <set_priority_by_pid>:
int
set_priority_by_pid(int pid, int priority)
{
  struct proc *p;

  if (priority < 1 || priority > 20)
    80002844:	fff5871b          	addiw	a4,a1,-1
    80002848:	47cd                	li	a5,19
    8000284a:	06e7e863          	bltu	a5,a4,800028ba <set_priority_by_pid+0x76>
{
    8000284e:	7179                	addi	sp,sp,-48
    80002850:	f406                	sd	ra,40(sp)
    80002852:	f022                	sd	s0,32(sp)
    80002854:	ec26                	sd	s1,24(sp)
    80002856:	e84a                	sd	s2,16(sp)
    80002858:	e44e                	sd	s3,8(sp)
    8000285a:	e052                	sd	s4,0(sp)
    8000285c:	1800                	addi	s0,sp,48
    8000285e:	892a                	mv	s2,a0
    80002860:	8a2e                	mv	s4,a1
    return -1;

  for (p = proc; p < &proc[NPROC]; p++) {
    80002862:	00011497          	auipc	s1,0x11
    80002866:	3ce48493          	addi	s1,s1,974 # 80013c30 <proc>
    8000286a:	00017997          	auipc	s3,0x17
    8000286e:	3c698993          	addi	s3,s3,966 # 80019c30 <semtable_lock>
    80002872:	a801                	j	80002882 <set_priority_by_pid+0x3e>
      p->waiting_ticks = 0;
      p->aging_ticks = 0;
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002874:	8526                	mv	a0,s1
    80002876:	bfafe0ef          	jal	80000c70 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    8000287a:	18048493          	addi	s1,s1,384
    8000287e:	03348c63          	beq	s1,s3,800028b6 <set_priority_by_pid+0x72>
    acquire(&p->lock);
    80002882:	8526                	mv	a0,s1
    80002884:	b64fe0ef          	jal	80000be8 <acquire>
    if (p->pid == pid && p->state != UNUSED) {
    80002888:	589c                	lw	a5,48(s1)
    8000288a:	ff2795e3          	bne	a5,s2,80002874 <set_priority_by_pid+0x30>
    8000288e:	4c9c                	lw	a5,24(s1)
    80002890:	d3f5                	beqz	a5,80002874 <set_priority_by_pid+0x30>
      p->priority = priority;
    80002892:	0344aa23          	sw	s4,52(s1)
      p->waiting_ticks = 0;
    80002896:	0204ac23          	sw	zero,56(s1)
      p->aging_ticks = 0;
    8000289a:	0204ae23          	sw	zero,60(s1)
      release(&p->lock);
    8000289e:	8526                	mv	a0,s1
    800028a0:	bd0fe0ef          	jal	80000c70 <release>
      return 0;
    800028a4:	4501                	li	a0,0
  }
  return -1;
}
    800028a6:	70a2                	ld	ra,40(sp)
    800028a8:	7402                	ld	s0,32(sp)
    800028aa:	64e2                	ld	s1,24(sp)
    800028ac:	6942                	ld	s2,16(sp)
    800028ae:	69a2                	ld	s3,8(sp)
    800028b0:	6a02                	ld	s4,0(sp)
    800028b2:	6145                	addi	sp,sp,48
    800028b4:	8082                	ret
  return -1;
    800028b6:	557d                	li	a0,-1
    800028b8:	b7fd                	j	800028a6 <set_priority_by_pid+0x62>
    return -1;
    800028ba:	557d                	li	a0,-1
}
    800028bc:	8082                	ret

00000000800028be <get_priority_by_pid>:

// Q4: Get a process priority.
int
get_priority_by_pid(int pid)
{
    800028be:	7179                	addi	sp,sp,-48
    800028c0:	f406                	sd	ra,40(sp)
    800028c2:	f022                	sd	s0,32(sp)
    800028c4:	ec26                	sd	s1,24(sp)
    800028c6:	e84a                	sd	s2,16(sp)
    800028c8:	e44e                	sd	s3,8(sp)
    800028ca:	1800                	addi	s0,sp,48
    800028cc:	892a                	mv	s2,a0
  struct proc *p;

  for (p = proc; p < &proc[NPROC]; p++) {
    800028ce:	00011497          	auipc	s1,0x11
    800028d2:	36248493          	addi	s1,s1,866 # 80013c30 <proc>
    800028d6:	00017997          	auipc	s3,0x17
    800028da:	35a98993          	addi	s3,s3,858 # 80019c30 <semtable_lock>
    800028de:	a801                	j	800028ee <get_priority_by_pid+0x30>
    if (p->pid == pid && p->state != UNUSED) {
      int priority = p->priority;
      release(&p->lock);
      return priority;
    }
    release(&p->lock);
    800028e0:	8526                	mv	a0,s1
    800028e2:	b8efe0ef          	jal	80000c70 <release>
  for (p = proc; p < &proc[NPROC]; p++) {
    800028e6:	18048493          	addi	s1,s1,384
    800028ea:	03348763          	beq	s1,s3,80002918 <get_priority_by_pid+0x5a>
    acquire(&p->lock);
    800028ee:	8526                	mv	a0,s1
    800028f0:	af8fe0ef          	jal	80000be8 <acquire>
    if (p->pid == pid && p->state != UNUSED) {
    800028f4:	589c                	lw	a5,48(s1)
    800028f6:	ff2795e3          	bne	a5,s2,800028e0 <get_priority_by_pid+0x22>
    800028fa:	4c9c                	lw	a5,24(s1)
    800028fc:	d3f5                	beqz	a5,800028e0 <get_priority_by_pid+0x22>
      int priority = p->priority;
    800028fe:	0344a903          	lw	s2,52(s1)
      release(&p->lock);
    80002902:	8526                	mv	a0,s1
    80002904:	b6cfe0ef          	jal	80000c70 <release>
  }
  return -1;
}
    80002908:	854a                	mv	a0,s2
    8000290a:	70a2                	ld	ra,40(sp)
    8000290c:	7402                	ld	s0,32(sp)
    8000290e:	64e2                	ld	s1,24(sp)
    80002910:	6942                	ld	s2,16(sp)
    80002912:	69a2                	ld	s3,8(sp)
    80002914:	6145                	addi	sp,sp,48
    80002916:	8082                	ret
  return -1;
    80002918:	597d                	li	s2,-1
    8000291a:	b7fd                	j	80002908 <get_priority_by_pid+0x4a>

000000008000291c <seminit>:
}

// Q2: initialize the fixed kernel semaphore table during xv6 boot.
void
seminit(void)
{
    8000291c:	7179                	addi	sp,sp,-48
    8000291e:	f406                	sd	ra,40(sp)
    80002920:	f022                	sd	s0,32(sp)
    80002922:	ec26                	sd	s1,24(sp)
    80002924:	e84a                	sd	s2,16(sp)
    80002926:	e44e                	sd	s3,8(sp)
    80002928:	1800                	addi	s0,sp,48
  int i;

  initlock(&semtable_lock, "semtable");
    8000292a:	00006597          	auipc	a1,0x6
    8000292e:	96e58593          	addi	a1,a1,-1682 # 80008298 <etext+0x298>
    80002932:	00017517          	auipc	a0,0x17
    80002936:	2fe50513          	addi	a0,a0,766 # 80019c30 <semtable_lock>
    8000293a:	a2efe0ef          	jal	80000b68 <initlock>
  for (i = 0; i < NSEM; i++) {
    8000293e:	00017497          	auipc	s1,0x17
    80002942:	31248493          	addi	s1,s1,786 # 80019c50 <semaphores+0x8>
    80002946:	00017997          	auipc	s3,0x17
    8000294a:	44a98993          	addi	s3,s3,1098 # 80019d90 <tickslock+0x8>
    semaphores[i].value = 0;
    semaphores[i].initialized = 0;
    initlock(&semaphores[i].lk, "semaphore");
    8000294e:	00006917          	auipc	s2,0x6
    80002952:	95a90913          	addi	s2,s2,-1702 # 800082a8 <etext+0x2a8>
    semaphores[i].value = 0;
    80002956:	fe04ac23          	sw	zero,-8(s1)
    semaphores[i].initialized = 0;
    8000295a:	fe04ae23          	sw	zero,-4(s1)
    initlock(&semaphores[i].lk, "semaphore");
    8000295e:	85ca                	mv	a1,s2
    80002960:	8526                	mv	a0,s1
    80002962:	a06fe0ef          	jal	80000b68 <initlock>
  for (i = 0; i < NSEM; i++) {
    80002966:	02048493          	addi	s1,s1,32
    8000296a:	ff3496e3          	bne	s1,s3,80002956 <seminit+0x3a>
  }
}
    8000296e:	70a2                	ld	ra,40(sp)
    80002970:	7402                	ld	s0,32(sp)
    80002972:	64e2                	ld	s1,24(sp)
    80002974:	6942                	ld	s2,16(sp)
    80002976:	69a2                	ld	s3,8(sp)
    80002978:	6145                	addi	sp,sp,48
    8000297a:	8082                	ret

000000008000297c <ksem_init>:
  if (sem_id < 0 || sem_id >= NSEM)
    8000297c:	47a5                	li	a5,9
    8000297e:	06a7e663          	bltu	a5,a0,800029ea <ksem_init+0x6e>

// Q2: initialize a counting semaphore with a non-negative permit count.
int
ksem_init(int sem_id, int value)
{
    80002982:	7179                	addi	sp,sp,-48
    80002984:	f406                	sd	ra,40(sp)
    80002986:	f022                	sd	s0,32(sp)
    80002988:	ec26                	sd	s1,24(sp)
    8000298a:	e84a                	sd	s2,16(sp)
    8000298c:	1800                	addi	s0,sp,48
    8000298e:	84aa                	mv	s1,a0
    80002990:	892e                	mv	s2,a1
  struct semaphore *sem = get_semaphore(sem_id);

  if (sem == 0 || value < 0)
    80002992:	0405ce63          	bltz	a1,800029ee <ksem_init+0x72>
    80002996:	e44e                	sd	s3,8(sp)
    return -1;

  acquire(&semtable_lock);
    80002998:	00017517          	auipc	a0,0x17
    8000299c:	29850513          	addi	a0,a0,664 # 80019c30 <semtable_lock>
    800029a0:	a48fe0ef          	jal	80000be8 <acquire>
  acquire(&sem->lk);
    800029a4:	0496                	slli	s1,s1,0x5
    800029a6:	00017997          	auipc	s3,0x17
    800029aa:	2aa98993          	addi	s3,s3,682 # 80019c50 <semaphores+0x8>
    800029ae:	99a6                	add	s3,s3,s1
    800029b0:	854e                	mv	a0,s3
    800029b2:	a36fe0ef          	jal	80000be8 <acquire>
  sem->value = value;
    800029b6:	00017797          	auipc	a5,0x17
    800029ba:	27a78793          	addi	a5,a5,634 # 80019c30 <semtable_lock>
    800029be:	97a6                	add	a5,a5,s1
    800029c0:	0127ac23          	sw	s2,24(a5)
  sem->initialized = 1;
    800029c4:	4705                	li	a4,1
    800029c6:	cfd8                	sw	a4,28(a5)
  release(&sem->lk);
    800029c8:	854e                	mv	a0,s3
    800029ca:	aa6fe0ef          	jal	80000c70 <release>
  release(&semtable_lock);
    800029ce:	00017517          	auipc	a0,0x17
    800029d2:	26250513          	addi	a0,a0,610 # 80019c30 <semtable_lock>
    800029d6:	a9afe0ef          	jal	80000c70 <release>

  return 0;
    800029da:	4501                	li	a0,0
    800029dc:	69a2                	ld	s3,8(sp)
}
    800029de:	70a2                	ld	ra,40(sp)
    800029e0:	7402                	ld	s0,32(sp)
    800029e2:	64e2                	ld	s1,24(sp)
    800029e4:	6942                	ld	s2,16(sp)
    800029e6:	6145                	addi	sp,sp,48
    800029e8:	8082                	ret
    return -1;
    800029ea:	557d                	li	a0,-1
}
    800029ec:	8082                	ret
    return -1;
    800029ee:	557d                	li	a0,-1
    800029f0:	b7fd                	j	800029de <ksem_init+0x62>

00000000800029f2 <ksem_wait>:
  if (sem_id < 0 || sem_id >= NSEM)
    800029f2:	47a5                	li	a5,9
    800029f4:	0ca7e863          	bltu	a5,a0,80002ac4 <ksem_wait+0xd2>

// Q2: consume one permit. Sleep while no permit is available.
int
ksem_wait(int sem_id)
{
    800029f8:	7179                	addi	sp,sp,-48
    800029fa:	f406                	sd	ra,40(sp)
    800029fc:	f022                	sd	s0,32(sp)
    800029fe:	ec26                	sd	s1,24(sp)
    80002a00:	e84a                	sd	s2,16(sp)
    80002a02:	e052                	sd	s4,0(sp)
    80002a04:	1800                	addi	s0,sp,48
    80002a06:	8a2a                	mv	s4,a0
  struct semaphore *sem = get_semaphore(sem_id);

  if (sem == 0)
    return -1;

  acquire(&semtable_lock);
    80002a08:	00017517          	auipc	a0,0x17
    80002a0c:	22850513          	addi	a0,a0,552 # 80019c30 <semtable_lock>
    80002a10:	9d8fe0ef          	jal	80000be8 <acquire>
  acquire(&sem->lk);
    80002a14:	005a1913          	slli	s2,s4,0x5
    80002a18:	00017497          	auipc	s1,0x17
    80002a1c:	23848493          	addi	s1,s1,568 # 80019c50 <semaphores+0x8>
    80002a20:	94ca                	add	s1,s1,s2
    80002a22:	8526                	mv	a0,s1
    80002a24:	9c4fe0ef          	jal	80000be8 <acquire>
  if (!sem->initialized) {
    80002a28:	00017797          	auipc	a5,0x17
    80002a2c:	20878793          	addi	a5,a5,520 # 80019c30 <semtable_lock>
    80002a30:	97ca                	add	a5,a5,s2
    80002a32:	4fdc                	lw	a5,28(a5)
    80002a34:	cfad                	beqz	a5,80002aae <ksem_wait+0xbc>
    release(&sem->lk);
    release(&semtable_lock);
    return -1;
  }
  release(&semtable_lock);
    80002a36:	00017517          	auipc	a0,0x17
    80002a3a:	1fa50513          	addi	a0,a0,506 # 80019c30 <semtable_lock>
    80002a3e:	a32fe0ef          	jal	80000c70 <release>

  while (sem->value == 0) {
    80002a42:	005a1713          	slli	a4,s4,0x5
    80002a46:	00017797          	auipc	a5,0x17
    80002a4a:	1ea78793          	addi	a5,a5,490 # 80019c30 <semtable_lock>
    80002a4e:	97ba                	add	a5,a5,a4
    80002a50:	4f9c                	lw	a5,24(a5)
    80002a52:	eb9d                	bnez	a5,80002a88 <ksem_wait+0x96>
    80002a54:	e44e                	sd	s3,8(sp)
  return &semaphores[sem_id];
    80002a56:	00017997          	auipc	s3,0x17
    80002a5a:	1f298993          	addi	s3,s3,498 # 80019c48 <semaphores>
    80002a5e:	99ca                	add	s3,s3,s2
  while (sem->value == 0) {
    80002a60:	00017917          	auipc	s2,0x17
    80002a64:	1d090913          	addi	s2,s2,464 # 80019c30 <semtable_lock>
    80002a68:	993a                	add	s2,s2,a4
    // Register the sleep channel before releasing the semaphore lock so a
    // signal cannot be lost between the value check and sleep().
    sleep_prepare(sem);
    80002a6a:	854e                	mv	a0,s3
    80002a6c:	80dff0ef          	jal	80002278 <sleep_prepare>
    release(&sem->lk);
    80002a70:	8526                	mv	a0,s1
    80002a72:	9fefe0ef          	jal	80000c70 <release>
    sleep();
    80002a76:	83fff0ef          	jal	800022b4 <sleep>
    acquire(&sem->lk);
    80002a7a:	8526                	mv	a0,s1
    80002a7c:	96cfe0ef          	jal	80000be8 <acquire>
  while (sem->value == 0) {
    80002a80:	01892783          	lw	a5,24(s2)
    80002a84:	d3fd                	beqz	a5,80002a6a <ksem_wait+0x78>
    80002a86:	69a2                	ld	s3,8(sp)
  }

  sem->value--;
    80002a88:	0a16                	slli	s4,s4,0x5
    80002a8a:	00017717          	auipc	a4,0x17
    80002a8e:	1a670713          	addi	a4,a4,422 # 80019c30 <semtable_lock>
    80002a92:	9752                	add	a4,a4,s4
    80002a94:	37fd                	addiw	a5,a5,-1
    80002a96:	cf1c                	sw	a5,24(a4)
  release(&sem->lk);
    80002a98:	8526                	mv	a0,s1
    80002a9a:	9d6fe0ef          	jal	80000c70 <release>
  return 0;
    80002a9e:	4501                	li	a0,0
}
    80002aa0:	70a2                	ld	ra,40(sp)
    80002aa2:	7402                	ld	s0,32(sp)
    80002aa4:	64e2                	ld	s1,24(sp)
    80002aa6:	6942                	ld	s2,16(sp)
    80002aa8:	6a02                	ld	s4,0(sp)
    80002aaa:	6145                	addi	sp,sp,48
    80002aac:	8082                	ret
    release(&sem->lk);
    80002aae:	8526                	mv	a0,s1
    80002ab0:	9c0fe0ef          	jal	80000c70 <release>
    release(&semtable_lock);
    80002ab4:	00017517          	auipc	a0,0x17
    80002ab8:	17c50513          	addi	a0,a0,380 # 80019c30 <semtable_lock>
    80002abc:	9b4fe0ef          	jal	80000c70 <release>
    return -1;
    80002ac0:	557d                	li	a0,-1
    80002ac2:	bff9                	j	80002aa0 <ksem_wait+0xae>
    return -1;
    80002ac4:	557d                	li	a0,-1
}
    80002ac6:	8082                	ret

0000000080002ac8 <ksem_signal>:
  if (sem_id < 0 || sem_id >= NSEM)
    80002ac8:	47a5                	li	a5,9
    80002aca:	08a7ed63          	bltu	a5,a0,80002b64 <ksem_signal+0x9c>

// Q2: return one permit and wake processes waiting for this semaphore.
int
ksem_signal(int sem_id)
{
    80002ace:	7179                	addi	sp,sp,-48
    80002ad0:	f406                	sd	ra,40(sp)
    80002ad2:	f022                	sd	s0,32(sp)
    80002ad4:	ec26                	sd	s1,24(sp)
    80002ad6:	e84a                	sd	s2,16(sp)
    80002ad8:	e44e                	sd	s3,8(sp)
    80002ada:	1800                	addi	s0,sp,48
    80002adc:	84aa                	mv	s1,a0
  struct semaphore *sem = get_semaphore(sem_id);

  if (sem == 0)
    return -1;

  acquire(&semtable_lock);
    80002ade:	00017517          	auipc	a0,0x17
    80002ae2:	15250513          	addi	a0,a0,338 # 80019c30 <semtable_lock>
    80002ae6:	902fe0ef          	jal	80000be8 <acquire>
  acquire(&sem->lk);
    80002aea:	00549993          	slli	s3,s1,0x5
    80002aee:	00017917          	auipc	s2,0x17
    80002af2:	16290913          	addi	s2,s2,354 # 80019c50 <semaphores+0x8>
    80002af6:	994e                	add	s2,s2,s3
    80002af8:	854a                	mv	a0,s2
    80002afa:	8eefe0ef          	jal	80000be8 <acquire>
  if (!sem->initialized) {
    80002afe:	00017797          	auipc	a5,0x17
    80002b02:	13278793          	addi	a5,a5,306 # 80019c30 <semtable_lock>
    80002b06:	97ce                	add	a5,a5,s3
    80002b08:	4fdc                	lw	a5,28(a5)
    80002b0a:	c3b1                	beqz	a5,80002b4e <ksem_signal+0x86>
    release(&sem->lk);
    release(&semtable_lock);
    return -1;
  }

  sem->value++;
    80002b0c:	0496                	slli	s1,s1,0x5
    80002b0e:	00017797          	auipc	a5,0x17
    80002b12:	12278793          	addi	a5,a5,290 # 80019c30 <semtable_lock>
    80002b16:	97a6                	add	a5,a5,s1
    80002b18:	4f98                	lw	a4,24(a5)
    80002b1a:	2705                	addiw	a4,a4,1
    80002b1c:	cf98                	sw	a4,24(a5)
  release(&sem->lk);
    80002b1e:	854a                	mv	a0,s2
    80002b20:	950fe0ef          	jal	80000c70 <release>
  release(&semtable_lock);
    80002b24:	00017517          	auipc	a0,0x17
    80002b28:	10c50513          	addi	a0,a0,268 # 80019c30 <semtable_lock>
    80002b2c:	944fe0ef          	jal	80000c70 <release>

  wakeup(sem);
    80002b30:	00017517          	auipc	a0,0x17
    80002b34:	11850513          	addi	a0,a0,280 # 80019c48 <semaphores>
    80002b38:	954e                	add	a0,a0,s3
    80002b3a:	faaff0ef          	jal	800022e4 <wakeup>
  return 0;
    80002b3e:	4501                	li	a0,0
}
    80002b40:	70a2                	ld	ra,40(sp)
    80002b42:	7402                	ld	s0,32(sp)
    80002b44:	64e2                	ld	s1,24(sp)
    80002b46:	6942                	ld	s2,16(sp)
    80002b48:	69a2                	ld	s3,8(sp)
    80002b4a:	6145                	addi	sp,sp,48
    80002b4c:	8082                	ret
    release(&sem->lk);
    80002b4e:	854a                	mv	a0,s2
    80002b50:	920fe0ef          	jal	80000c70 <release>
    release(&semtable_lock);
    80002b54:	00017517          	auipc	a0,0x17
    80002b58:	0dc50513          	addi	a0,a0,220 # 80019c30 <semtable_lock>
    80002b5c:	914fe0ef          	jal	80000c70 <release>
    return -1;
    80002b60:	557d                	li	a0,-1
    80002b62:	bff9                	j	80002b40 <ksem_signal+0x78>
    return -1;
    80002b64:	557d                	li	a0,-1
}
    80002b66:	8082                	ret

0000000080002b68 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    80002b68:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    80002b6c:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002b70:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002b72:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002b74:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    80002b78:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    80002b7c:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    80002b80:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002b84:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    80002b88:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    80002b8c:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002b90:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002b94:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002b98:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    80002b9c:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002ba0:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002ba4:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002ba6:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002ba8:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002bac:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002bb0:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002bb4:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002bb8:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    80002bbc:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002bc0:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002bc4:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002bc8:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    80002bcc:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002bd0:	8082                	ret

0000000080002bd2 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002bd2:	1141                	addi	sp,sp,-16
    80002bd4:	e406                	sd	ra,8(sp)
    80002bd6:	e022                	sd	s0,0(sp)
    80002bd8:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002bda:	00005597          	auipc	a1,0x5
    80002bde:	6de58593          	addi	a1,a1,1758 # 800082b8 <etext+0x2b8>
    80002be2:	00017517          	auipc	a0,0x17
    80002be6:	1a650513          	addi	a0,a0,422 # 80019d88 <tickslock>
    80002bea:	f7ffd0ef          	jal	80000b68 <initlock>
}
    80002bee:	60a2                	ld	ra,8(sp)
    80002bf0:	6402                	ld	s0,0(sp)
    80002bf2:	0141                	addi	sp,sp,16
    80002bf4:	8082                	ret

0000000080002bf6 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002bf6:	1141                	addi	sp,sp,-16
    80002bf8:	e406                	sd	ra,8(sp)
    80002bfa:	e022                	sd	s0,0(sp)
    80002bfc:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002bfe:	00003797          	auipc	a5,0x3
    80002c02:	1c278793          	addi	a5,a5,450 # 80005dc0 <kernelvec>
    80002c06:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002c0a:	60a2                	ld	ra,8(sp)
    80002c0c:	6402                	ld	s0,0(sp)
    80002c0e:	0141                	addi	sp,sp,16
    80002c10:	8082                	ret

0000000080002c12 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    80002c12:	1141                	addi	sp,sp,-16
    80002c14:	e406                	sd	ra,8(sp)
    80002c16:	e022                	sd	s0,0(sp)
    80002c18:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002c1a:	cdbfe0ef          	jal	800018f4 <myproc>
  __asm__ __volatile__("csrc sstatus, %0" ::"rK"(x) : "memory");
    80002c1e:	10017073          	csrci	sstatus,2
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002c22:	04000737          	lui	a4,0x4000
    80002c26:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80002c28:	0732                	slli	a4,a4,0xc
    80002c2a:	00004797          	auipc	a5,0x4
    80002c2e:	3d678793          	addi	a5,a5,982 # 80007000 <_trampoline>
    80002c32:	00004697          	auipc	a3,0x4
    80002c36:	3ce68693          	addi	a3,a3,974 # 80007000 <_trampoline>
    80002c3a:	8f95                	sub	a5,a5,a3
    80002c3c:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002c3e:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002c42:	793c                	ld	a5,112(a0)
  asm volatile("csrr %0, satp" : "=r"(x));
    80002c44:	18002773          	csrr	a4,satp
    80002c48:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002c4a:	7938                	ld	a4,112(a0)
    80002c4c:	6d3c                	ld	a5,88(a0)
    80002c4e:	6685                	lui	a3,0x1
    80002c50:	97b6                	add	a5,a5,a3
    80002c52:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002c54:	793c                	ld	a5,112(a0)
    80002c56:	00000717          	auipc	a4,0x0
    80002c5a:	0fc70713          	addi	a4,a4,252 # 80002d52 <usertrap>
    80002c5e:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp(); // hartid for cpuid()
    80002c60:	793c                	ld	a5,112(a0)
  asm volatile("mv %0, tp" : "=r"(x));
    80002c62:	8712                	mv	a4,tp
    80002c64:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002c66:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.

  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002c6a:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002c6e:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002c72:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002c76:	793c                	ld	a5,112(a0)
  asm volatile("csrw sepc, %0" : : "r"(x));
    80002c78:	6f9c                	ld	a5,24(a5)
    80002c7a:	14179073          	csrw	sepc,a5
}
    80002c7e:	60a2                	ld	ra,8(sp)
    80002c80:	6402                	ld	s0,0(sp)
    80002c82:	0141                	addi	sp,sp,16
    80002c84:	8082                	ret

0000000080002c86 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    80002c86:	1141                	addi	sp,sp,-16
    80002c88:	e406                	sd	ra,8(sp)
    80002c8a:	e022                	sd	s0,0(sp)
    80002c8c:	0800                	addi	s0,sp,16
  if (cpuid() == 0) {
    80002c8e:	c33fe0ef          	jal	800018c0 <cpuid>
    80002c92:	cd11                	beqz	a0,80002cae <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r"(x));
    80002c94:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    80002c98:	000f4737          	lui	a4,0xf4
    80002c9c:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002ca0:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r"(x));
    80002ca2:	14d79073          	csrw	stimecmp,a5
}
    80002ca6:	60a2                	ld	ra,8(sp)
    80002ca8:	6402                	ld	s0,0(sp)
    80002caa:	0141                	addi	sp,sp,16
    80002cac:	8082                	ret
    acquire(&tickslock);
    80002cae:	00017517          	auipc	a0,0x17
    80002cb2:	0da50513          	addi	a0,a0,218 # 80019d88 <tickslock>
    80002cb6:	f33fd0ef          	jal	80000be8 <acquire>
    ticks++;
    80002cba:	00009717          	auipc	a4,0x9
    80002cbe:	a2e70713          	addi	a4,a4,-1490 # 8000b6e8 <ticks>
    80002cc2:	431c                	lw	a5,0(a4)
    80002cc4:	2785                	addiw	a5,a5,1
    80002cc6:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    80002cc8:	853a                	mv	a0,a4
    80002cca:	e1aff0ef          	jal	800022e4 <wakeup>
    release(&tickslock);
    80002cce:	00017517          	auipc	a0,0x17
    80002cd2:	0ba50513          	addi	a0,a0,186 # 80019d88 <tickslock>
    80002cd6:	f9bfd0ef          	jal	80000c70 <release>
    80002cda:	bf6d                	j	80002c94 <clockintr+0xe>

0000000080002cdc <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002cdc:	1101                	addi	sp,sp,-32
    80002cde:	ec06                	sd	ra,24(sp)
    80002ce0:	e822                	sd	s0,16(sp)
    80002ce2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r"(x));
    80002ce4:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if (scause == 0x8000000000000009L) {
    80002ce8:	57fd                	li	a5,-1
    80002cea:	17fe                	slli	a5,a5,0x3f
    80002cec:	07a5                	addi	a5,a5,9
    80002cee:	00f70c63          	beq	a4,a5,80002d06 <devintr+0x2a>
    // now allowed to interrupt again.
    if (irq)
      plic_complete(irq);

    return 1;
  } else if (scause == 0x8000000000000005L) {
    80002cf2:	57fd                	li	a5,-1
    80002cf4:	17fe                	slli	a5,a5,0x3f
    80002cf6:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002cf8:	4501                	li	a0,0
  } else if (scause == 0x8000000000000005L) {
    80002cfa:	04f70863          	beq	a4,a5,80002d4a <devintr+0x6e>
  }
}
    80002cfe:	60e2                	ld	ra,24(sp)
    80002d00:	6442                	ld	s0,16(sp)
    80002d02:	6105                	addi	sp,sp,32
    80002d04:	8082                	ret
    80002d06:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002d08:	164030ef          	jal	80005e6c <plic_claim>
    80002d0c:	872a                	mv	a4,a0
    80002d0e:	84aa                	mv	s1,a0
    if (irq == UART0_IRQ) {
    80002d10:	47a9                	li	a5,10
    80002d12:	00f50963          	beq	a0,a5,80002d24 <devintr+0x48>
    } else if (irq == VIRTIO0_IRQ) {
    80002d16:	4785                	li	a5,1
    80002d18:	00f50963          	beq	a0,a5,80002d2a <devintr+0x4e>
    return 1;
    80002d1c:	4505                	li	a0,1
    } else if (irq) {
    80002d1e:	eb09                	bnez	a4,80002d30 <devintr+0x54>
    80002d20:	64a2                	ld	s1,8(sp)
    80002d22:	bff1                	j	80002cfe <devintr+0x22>
      uartintr();
    80002d24:	cabfd0ef          	jal	800009ce <uartintr>
    if (irq)
    80002d28:	a819                	j	80002d3e <devintr+0x62>
      virtio_disk_intr();
    80002d2a:	5fa030ef          	jal	80006324 <virtio_disk_intr>
    if (irq)
    80002d2e:	a801                	j	80002d3e <devintr+0x62>
      printk("unexpected interrupt irq=%d\n", irq);
    80002d30:	85ba                	mv	a1,a4
    80002d32:	00005517          	auipc	a0,0x5
    80002d36:	58e50513          	addi	a0,a0,1422 # 800082c0 <etext+0x2c0>
    80002d3a:	fd0fd0ef          	jal	8000050a <printk>
      plic_complete(irq);
    80002d3e:	8526                	mv	a0,s1
    80002d40:	14c030ef          	jal	80005e8c <plic_complete>
    return 1;
    80002d44:	4505                	li	a0,1
    80002d46:	64a2                	ld	s1,8(sp)
    80002d48:	bf5d                	j	80002cfe <devintr+0x22>
    clockintr();
    80002d4a:	f3dff0ef          	jal	80002c86 <clockintr>
    return 2;
    80002d4e:	4509                	li	a0,2
    80002d50:	b77d                	j	80002cfe <devintr+0x22>

0000000080002d52 <usertrap>:
{
    80002d52:	1101                	addi	sp,sp,-32
    80002d54:	ec06                	sd	ra,24(sp)
    80002d56:	e822                	sd	s0,16(sp)
    80002d58:	e426                	sd	s1,8(sp)
    80002d5a:	e04a                	sd	s2,0(sp)
    80002d5c:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002d5e:	100027f3          	csrr	a5,sstatus
  if ((r_sstatus() & SSTATUS_SPP) != 0)
    80002d62:	1007f793          	andi	a5,a5,256
    80002d66:	eba5                	bnez	a5,80002dd6 <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r"(x));
    80002d68:	00003797          	auipc	a5,0x3
    80002d6c:	05878793          	addi	a5,a5,88 # 80005dc0 <kernelvec>
    80002d70:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002d74:	b81fe0ef          	jal	800018f4 <myproc>
    80002d78:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002d7a:	793c                	ld	a5,112(a0)
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002d7c:	14102773          	csrr	a4,sepc
    80002d80:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r"(x));
    80002d82:	14202773          	csrr	a4,scause
  if (r_scause() == 8) {
    80002d86:	47a1                	li	a5,8
    80002d88:	04f70d63          	beq	a4,a5,80002de2 <usertrap+0x90>
  } else if ((which_dev = devintr()) != 0) {
    80002d8c:	f51ff0ef          	jal	80002cdc <devintr>
    80002d90:	892a                	mv	s2,a0
    80002d92:	e54d                	bnez	a0,80002e3c <usertrap+0xea>
    80002d94:	14202773          	csrr	a4,scause
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002d98:	47bd                	li	a5,15
    80002d9a:	08f70463          	beq	a4,a5,80002e22 <usertrap+0xd0>
    80002d9e:	14202773          	csrr	a4,scause
    80002da2:	47b5                	li	a5,13
    80002da4:	06f70f63          	beq	a4,a5,80002e22 <usertrap+0xd0>
    80002da8:	142025f3          	csrr	a1,scause
    printk("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002dac:	5890                	lw	a2,48(s1)
    80002dae:	00005517          	auipc	a0,0x5
    80002db2:	55250513          	addi	a0,a0,1362 # 80008300 <etext+0x300>
    80002db6:	f54fd0ef          	jal	8000050a <printk>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002dba:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    80002dbe:	14302673          	csrr	a2,stval
    printk("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80002dc2:	00005517          	auipc	a0,0x5
    80002dc6:	56e50513          	addi	a0,a0,1390 # 80008330 <etext+0x330>
    80002dca:	f40fd0ef          	jal	8000050a <printk>
    setkilled(p);
    80002dce:	8526                	mv	a0,s1
    80002dd0:	e36ff0ef          	jal	80002406 <setkilled>
    80002dd4:	a015                	j	80002df8 <usertrap+0xa6>
    panic("usertrap: not from user mode");
    80002dd6:	00005517          	auipc	a0,0x5
    80002dda:	50a50513          	addi	a0,a0,1290 # 800082e0 <etext+0x2e0>
    80002dde:	a57fd0ef          	jal	80000834 <panic>
    if (killed(p))
    80002de2:	e48ff0ef          	jal	8000242a <killed>
    80002de6:	e915                	bnez	a0,80002e1a <usertrap+0xc8>
    p->trapframe->epc += 4;
    80002de8:	78b8                	ld	a4,112(s1)
    80002dea:	6f1c                	ld	a5,24(a4)
    80002dec:	0791                	addi	a5,a5,4
    80002dee:	ef1c                	sd	a5,24(a4)
  __asm__ __volatile__("csrs sstatus, %0" ::"rK"(x) : "memory");
    80002df0:	10016073          	csrsi	sstatus,2
    syscall();
    80002df4:	244000ef          	jal	80003038 <syscall>
  if (killed(p))
    80002df8:	8526                	mv	a0,s1
    80002dfa:	e30ff0ef          	jal	8000242a <killed>
    80002dfe:	e521                	bnez	a0,80002e46 <usertrap+0xf4>
  prepare_return();
    80002e00:	e13ff0ef          	jal	80002c12 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002e04:	74a8                	ld	a0,104(s1)
    80002e06:	8131                	srli	a0,a0,0xc
    80002e08:	57fd                	li	a5,-1
    80002e0a:	17fe                	slli	a5,a5,0x3f
    80002e0c:	8d5d                	or	a0,a0,a5
}
    80002e0e:	60e2                	ld	ra,24(sp)
    80002e10:	6442                	ld	s0,16(sp)
    80002e12:	64a2                	ld	s1,8(sp)
    80002e14:	6902                	ld	s2,0(sp)
    80002e16:	6105                	addi	sp,sp,32
    80002e18:	8082                	ret
      kexit(-1);
    80002e1a:	557d                	li	a0,-1
    80002e1c:	833ff0ef          	jal	8000264e <kexit>
    80002e20:	b7e1                	j	80002de8 <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r"(x));
    80002e22:	14302673          	csrr	a2,stval
  asm volatile("csrr %0, scause" : "=r"(x));
    80002e26:	142026f3          	csrr	a3,scause
             vmfault(p->pagetable, p->sz, r_stval(),
    80002e2a:	16cd                	addi	a3,a3,-13 # ff3 <_entry-0x7ffff00d>
    80002e2c:	0016b693          	seqz	a3,a3
    80002e30:	70ac                	ld	a1,96(s1)
    80002e32:	74a8                	ld	a0,104(s1)
    80002e34:	e96fe0ef          	jal	800014ca <vmfault>
  } else if ((r_scause() == 15 || r_scause() == 13) &&
    80002e38:	f161                	bnez	a0,80002df8 <usertrap+0xa6>
    80002e3a:	b7bd                	j	80002da8 <usertrap+0x56>
  if (killed(p))
    80002e3c:	8526                	mv	a0,s1
    80002e3e:	decff0ef          	jal	8000242a <killed>
    80002e42:	c511                	beqz	a0,80002e4e <usertrap+0xfc>
    80002e44:	a011                	j	80002e48 <usertrap+0xf6>
    80002e46:	4901                	li	s2,0
    kexit(-1);
    80002e48:	557d                	li	a0,-1
    80002e4a:	805ff0ef          	jal	8000264e <kexit>
  if (which_dev == 2)
    80002e4e:	4789                	li	a5,2
    80002e50:	faf918e3          	bne	s2,a5,80002e00 <usertrap+0xae>
    yield();
    80002e54:	bf8ff0ef          	jal	8000224c <yield>
    80002e58:	b765                	j	80002e00 <usertrap+0xae>

0000000080002e5a <kerneltrap>:
{
    80002e5a:	7179                	addi	sp,sp,-48
    80002e5c:	f406                	sd	ra,40(sp)
    80002e5e:	f022                	sd	s0,32(sp)
    80002e60:	ec26                	sd	s1,24(sp)
    80002e62:	e84a                	sd	s2,16(sp)
    80002e64:	e44e                	sd	s3,8(sp)
    80002e66:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002e68:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002e6c:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r"(x));
    80002e70:	142027f3          	csrr	a5,scause
    80002e74:	89be                	mv	s3,a5
  if ((sstatus & SSTATUS_SPP) == 0)
    80002e76:	1004f793          	andi	a5,s1,256
    80002e7a:	c795                	beqz	a5,80002ea6 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r"(x));
    80002e7c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002e80:	8b89                	andi	a5,a5,2
  if (intr_get() != 0)
    80002e82:	eb85                	bnez	a5,80002eb2 <kerneltrap+0x58>
  if ((which_dev = devintr()) == 0) {
    80002e84:	e59ff0ef          	jal	80002cdc <devintr>
    80002e88:	c91d                	beqz	a0,80002ebe <kerneltrap+0x64>
  if (which_dev == 2 && myproc() != 0)
    80002e8a:	4789                	li	a5,2
    80002e8c:	04f50a63          	beq	a0,a5,80002ee0 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r"(x));
    80002e90:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r"(x));
    80002e94:	10049073          	csrw	sstatus,s1
}
    80002e98:	70a2                	ld	ra,40(sp)
    80002e9a:	7402                	ld	s0,32(sp)
    80002e9c:	64e2                	ld	s1,24(sp)
    80002e9e:	6942                	ld	s2,16(sp)
    80002ea0:	69a2                	ld	s3,8(sp)
    80002ea2:	6145                	addi	sp,sp,48
    80002ea4:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002ea6:	00005517          	auipc	a0,0x5
    80002eaa:	4b250513          	addi	a0,a0,1202 # 80008358 <etext+0x358>
    80002eae:	987fd0ef          	jal	80000834 <panic>
    panic("kerneltrap: interrupts enabled");
    80002eb2:	00005517          	auipc	a0,0x5
    80002eb6:	4ce50513          	addi	a0,a0,1230 # 80008380 <etext+0x380>
    80002eba:	97bfd0ef          	jal	80000834 <panic>
  asm volatile("csrr %0, sepc" : "=r"(x));
    80002ebe:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r"(x));
    80002ec2:	143026f3          	csrr	a3,stval
    printk("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(),
    80002ec6:	85ce                	mv	a1,s3
    80002ec8:	00005517          	auipc	a0,0x5
    80002ecc:	4d850513          	addi	a0,a0,1240 # 800083a0 <etext+0x3a0>
    80002ed0:	e3afd0ef          	jal	8000050a <printk>
    panic("kerneltrap");
    80002ed4:	00005517          	auipc	a0,0x5
    80002ed8:	4f450513          	addi	a0,a0,1268 # 800083c8 <etext+0x3c8>
    80002edc:	959fd0ef          	jal	80000834 <panic>
  if (which_dev == 2 && myproc() != 0)
    80002ee0:	a15fe0ef          	jal	800018f4 <myproc>
    80002ee4:	d555                	beqz	a0,80002e90 <kerneltrap+0x36>
    yield();
    80002ee6:	b66ff0ef          	jal	8000224c <yield>
    80002eea:	b75d                	j	80002e90 <kerneltrap+0x36>

0000000080002eec <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002eec:	1101                	addi	sp,sp,-32
    80002eee:	ec06                	sd	ra,24(sp)
    80002ef0:	e822                	sd	s0,16(sp)
    80002ef2:	e426                	sd	s1,8(sp)
    80002ef4:	1000                	addi	s0,sp,32
    80002ef6:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002ef8:	9fdfe0ef          	jal	800018f4 <myproc>
  switch (n) {
    80002efc:	4795                	li	a5,5
    80002efe:	0497e163          	bltu	a5,s1,80002f40 <argraw+0x54>
    80002f02:	048a                	slli	s1,s1,0x2
    80002f04:	00006717          	auipc	a4,0x6
    80002f08:	8c470713          	addi	a4,a4,-1852 # 800087c8 <states.0+0x30>
    80002f0c:	94ba                	add	s1,s1,a4
    80002f0e:	409c                	lw	a5,0(s1)
    80002f10:	97ba                	add	a5,a5,a4
    80002f12:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002f14:	793c                	ld	a5,112(a0)
    80002f16:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002f18:	60e2                	ld	ra,24(sp)
    80002f1a:	6442                	ld	s0,16(sp)
    80002f1c:	64a2                	ld	s1,8(sp)
    80002f1e:	6105                	addi	sp,sp,32
    80002f20:	8082                	ret
    return p->trapframe->a1;
    80002f22:	793c                	ld	a5,112(a0)
    80002f24:	7fa8                	ld	a0,120(a5)
    80002f26:	bfcd                	j	80002f18 <argraw+0x2c>
    return p->trapframe->a2;
    80002f28:	793c                	ld	a5,112(a0)
    80002f2a:	63c8                	ld	a0,128(a5)
    80002f2c:	b7f5                	j	80002f18 <argraw+0x2c>
    return p->trapframe->a3;
    80002f2e:	793c                	ld	a5,112(a0)
    80002f30:	67c8                	ld	a0,136(a5)
    80002f32:	b7dd                	j	80002f18 <argraw+0x2c>
    return p->trapframe->a4;
    80002f34:	793c                	ld	a5,112(a0)
    80002f36:	6bc8                	ld	a0,144(a5)
    80002f38:	b7c5                	j	80002f18 <argraw+0x2c>
    return p->trapframe->a5;
    80002f3a:	793c                	ld	a5,112(a0)
    80002f3c:	6fc8                	ld	a0,152(a5)
    80002f3e:	bfe9                	j	80002f18 <argraw+0x2c>
  panic("argraw");
    80002f40:	00005517          	auipc	a0,0x5
    80002f44:	49850513          	addi	a0,a0,1176 # 800083d8 <etext+0x3d8>
    80002f48:	8edfd0ef          	jal	80000834 <panic>

0000000080002f4c <fetchaddr>:
{
    80002f4c:	1101                	addi	sp,sp,-32
    80002f4e:	ec06                	sd	ra,24(sp)
    80002f50:	e822                	sd	s0,16(sp)
    80002f52:	e426                	sd	s1,8(sp)
    80002f54:	e04a                	sd	s2,0(sp)
    80002f56:	1000                	addi	s0,sp,32
    80002f58:	84aa                	mv	s1,a0
    80002f5a:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002f5c:	999fe0ef          	jal	800018f4 <myproc>
  if (addr >= p->sz ||
    80002f60:	712c                	ld	a1,96(a0)
    80002f62:	02b4f663          	bgeu	s1,a1,80002f8e <fetchaddr+0x42>
      addr + sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002f66:	00848793          	addi	a5,s1,8
  if (addr >= p->sz ||
    80002f6a:	02f5e463          	bltu	a1,a5,80002f92 <fetchaddr+0x46>
  if (copyin(p->pagetable, p->sz, (char *)ip, addr, sizeof(*ip)) != 0)
    80002f6e:	4721                	li	a4,8
    80002f70:	86a6                	mv	a3,s1
    80002f72:	864a                	mv	a2,s2
    80002f74:	7528                	ld	a0,104(a0)
    80002f76:	e96fe0ef          	jal	8000160c <copyin>
    80002f7a:	00a03533          	snez	a0,a0
    80002f7e:	40a0053b          	negw	a0,a0
}
    80002f82:	60e2                	ld	ra,24(sp)
    80002f84:	6442                	ld	s0,16(sp)
    80002f86:	64a2                	ld	s1,8(sp)
    80002f88:	6902                	ld	s2,0(sp)
    80002f8a:	6105                	addi	sp,sp,32
    80002f8c:	8082                	ret
    return -1;
    80002f8e:	557d                	li	a0,-1
    80002f90:	bfcd                	j	80002f82 <fetchaddr+0x36>
    80002f92:	557d                	li	a0,-1
    80002f94:	b7fd                	j	80002f82 <fetchaddr+0x36>

0000000080002f96 <fetchstr>:
{
    80002f96:	7179                	addi	sp,sp,-48
    80002f98:	f406                	sd	ra,40(sp)
    80002f9a:	f022                	sd	s0,32(sp)
    80002f9c:	ec26                	sd	s1,24(sp)
    80002f9e:	e84a                	sd	s2,16(sp)
    80002fa0:	e44e                	sd	s3,8(sp)
    80002fa2:	1800                	addi	s0,sp,48
    80002fa4:	89aa                	mv	s3,a0
    80002fa6:	84ae                	mv	s1,a1
    80002fa8:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002faa:	94bfe0ef          	jal	800018f4 <myproc>
  if (copyinstr(p->pagetable, p->sz, buf, addr, max) < 0)
    80002fae:	874a                	mv	a4,s2
    80002fb0:	86ce                	mv	a3,s3
    80002fb2:	8626                	mv	a2,s1
    80002fb4:	712c                	ld	a1,96(a0)
    80002fb6:	7528                	ld	a0,104(a0)
    80002fb8:	ef0fe0ef          	jal	800016a8 <copyinstr>
    80002fbc:	00054c63          	bltz	a0,80002fd4 <fetchstr+0x3e>
  return strlen(buf);
    80002fc0:	8526                	mv	a0,s1
    80002fc2:	e71fd0ef          	jal	80000e32 <strlen>
}
    80002fc6:	70a2                	ld	ra,40(sp)
    80002fc8:	7402                	ld	s0,32(sp)
    80002fca:	64e2                	ld	s1,24(sp)
    80002fcc:	6942                	ld	s2,16(sp)
    80002fce:	69a2                	ld	s3,8(sp)
    80002fd0:	6145                	addi	sp,sp,48
    80002fd2:	8082                	ret
    return -1;
    80002fd4:	557d                	li	a0,-1
    80002fd6:	bfc5                	j	80002fc6 <fetchstr+0x30>

0000000080002fd8 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002fd8:	1101                	addi	sp,sp,-32
    80002fda:	ec06                	sd	ra,24(sp)
    80002fdc:	e822                	sd	s0,16(sp)
    80002fde:	e426                	sd	s1,8(sp)
    80002fe0:	1000                	addi	s0,sp,32
    80002fe2:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002fe4:	f09ff0ef          	jal	80002eec <argraw>
    80002fe8:	c088                	sw	a0,0(s1)
}
    80002fea:	60e2                	ld	ra,24(sp)
    80002fec:	6442                	ld	s0,16(sp)
    80002fee:	64a2                	ld	s1,8(sp)
    80002ff0:	6105                	addi	sp,sp,32
    80002ff2:	8082                	ret

0000000080002ff4 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002ff4:	1101                	addi	sp,sp,-32
    80002ff6:	ec06                	sd	ra,24(sp)
    80002ff8:	e822                	sd	s0,16(sp)
    80002ffa:	e426                	sd	s1,8(sp)
    80002ffc:	1000                	addi	s0,sp,32
    80002ffe:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80003000:	eedff0ef          	jal	80002eec <argraw>
    80003004:	e088                	sd	a0,0(s1)
}
    80003006:	60e2                	ld	ra,24(sp)
    80003008:	6442                	ld	s0,16(sp)
    8000300a:	64a2                	ld	s1,8(sp)
    8000300c:	6105                	addi	sp,sp,32
    8000300e:	8082                	ret

0000000080003010 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (not including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80003010:	1101                	addi	sp,sp,-32
    80003012:	ec06                	sd	ra,24(sp)
    80003014:	e822                	sd	s0,16(sp)
    80003016:	e426                	sd	s1,8(sp)
    80003018:	e04a                	sd	s2,0(sp)
    8000301a:	1000                	addi	s0,sp,32
    8000301c:	892e                	mv	s2,a1
    8000301e:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80003020:	ecdff0ef          	jal	80002eec <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80003024:	8626                	mv	a2,s1
    80003026:	85ca                	mv	a1,s2
    80003028:	f6fff0ef          	jal	80002f96 <fetchstr>
}
    8000302c:	60e2                	ld	ra,24(sp)
    8000302e:	6442                	ld	s0,16(sp)
    80003030:	64a2                	ld	s1,8(sp)
    80003032:	6902                	ld	s2,0(sp)
    80003034:	6105                	addi	sp,sp,32
    80003036:	8082                	ret

0000000080003038 <syscall>:
  // clang-format on
};

void
syscall(void)
{
    80003038:	1101                	addi	sp,sp,-32
    8000303a:	ec06                	sd	ra,24(sp)
    8000303c:	e822                	sd	s0,16(sp)
    8000303e:	e426                	sd	s1,8(sp)
    80003040:	e04a                	sd	s2,0(sp)
    80003042:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80003044:	8b1fe0ef          	jal	800018f4 <myproc>
    80003048:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    8000304a:	07053903          	ld	s2,112(a0)
    8000304e:	0a893783          	ld	a5,168(s2)
    80003052:	0007869b          	sext.w	a3,a5
  if (num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80003056:	37fd                	addiw	a5,a5,-1
    80003058:	4771                	li	a4,28
    8000305a:	00f76f63          	bltu	a4,a5,80003078 <syscall+0x40>
    8000305e:	00369713          	slli	a4,a3,0x3
    80003062:	00005797          	auipc	a5,0x5
    80003066:	77e78793          	addi	a5,a5,1918 # 800087e0 <syscalls>
    8000306a:	97ba                	add	a5,a5,a4
    8000306c:	639c                	ld	a5,0(a5)
    8000306e:	c789                	beqz	a5,80003078 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80003070:	9782                	jalr	a5
    80003072:	06a93823          	sd	a0,112(s2)
    80003076:	a829                	j	80003090 <syscall+0x58>
  } else {
    printk("%d %s: unknown sys call %d\n", p->pid, p->name, num);
    80003078:	17048613          	addi	a2,s1,368
    8000307c:	588c                	lw	a1,48(s1)
    8000307e:	00005517          	auipc	a0,0x5
    80003082:	36250513          	addi	a0,a0,866 # 800083e0 <etext+0x3e0>
    80003086:	c84fd0ef          	jal	8000050a <printk>
    p->trapframe->a0 = -1;
    8000308a:	78bc                	ld	a5,112(s1)
    8000308c:	577d                	li	a4,-1
    8000308e:	fbb8                	sd	a4,112(a5)
  }
}
    80003090:	60e2                	ld	ra,24(sp)
    80003092:	6442                	ld	s0,16(sp)
    80003094:	64a2                	ld	s1,8(sp)
    80003096:	6902                	ld	s2,0(sp)
    80003098:	6105                	addi	sp,sp,32
    8000309a:	8082                	ret

000000008000309c <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    8000309c:	1101                	addi	sp,sp,-32
    8000309e:	ec06                	sd	ra,24(sp)
    800030a0:	e822                	sd	s0,16(sp)
    800030a2:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    800030a4:	fec40593          	addi	a1,s0,-20
    800030a8:	4501                	li	a0,0
    800030aa:	f2fff0ef          	jal	80002fd8 <argint>
  kexit(n);
    800030ae:	fec42503          	lw	a0,-20(s0)
    800030b2:	d9cff0ef          	jal	8000264e <kexit>
  return 0; // not reached
}
    800030b6:	4501                	li	a0,0
    800030b8:	60e2                	ld	ra,24(sp)
    800030ba:	6442                	ld	s0,16(sp)
    800030bc:	6105                	addi	sp,sp,32
    800030be:	8082                	ret

00000000800030c0 <sys_getpid>:

uint64
sys_getpid(void)
{
    800030c0:	1141                	addi	sp,sp,-16
    800030c2:	e406                	sd	ra,8(sp)
    800030c4:	e022                	sd	s0,0(sp)
    800030c6:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800030c8:	82dfe0ef          	jal	800018f4 <myproc>
}
    800030cc:	5908                	lw	a0,48(a0)
    800030ce:	60a2                	ld	ra,8(sp)
    800030d0:	6402                	ld	s0,0(sp)
    800030d2:	0141                	addi	sp,sp,16
    800030d4:	8082                	ret

00000000800030d6 <sys_fork>:

uint64
sys_fork(void)
{
    800030d6:	1141                	addi	sp,sp,-16
    800030d8:	e406                	sd	ra,8(sp)
    800030da:	e022                	sd	s0,0(sp)
    800030dc:	0800                	addi	s0,sp,16
  return kfork();
    800030de:	c2bfe0ef          	jal	80001d08 <kfork>
}
    800030e2:	60a2                	ld	ra,8(sp)
    800030e4:	6402                	ld	s0,0(sp)
    800030e6:	0141                	addi	sp,sp,16
    800030e8:	8082                	ret

00000000800030ea <sys_wait>:

uint64
sys_wait(void)
{
    800030ea:	1101                	addi	sp,sp,-32
    800030ec:	ec06                	sd	ra,24(sp)
    800030ee:	e822                	sd	s0,16(sp)
    800030f0:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    800030f2:	fe840593          	addi	a1,s0,-24
    800030f6:	4501                	li	a0,0
    800030f8:	efdff0ef          	jal	80002ff4 <argaddr>
  return kwait(p);
    800030fc:	fe843503          	ld	a0,-24(s0)
    80003100:	b54ff0ef          	jal	80002454 <kwait>
}
    80003104:	60e2                	ld	ra,24(sp)
    80003106:	6442                	ld	s0,16(sp)
    80003108:	6105                	addi	sp,sp,32
    8000310a:	8082                	ret

000000008000310c <sys_sbrk>:

uint64
sys_sbrk(void)
{
    8000310c:	7179                	addi	sp,sp,-48
    8000310e:	f406                	sd	ra,40(sp)
    80003110:	f022                	sd	s0,32(sp)
    80003112:	ec26                	sd	s1,24(sp)
    80003114:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80003116:	fd840593          	addi	a1,s0,-40
    8000311a:	4501                	li	a0,0
    8000311c:	ebdff0ef          	jal	80002fd8 <argint>
  argint(1, &t);
    80003120:	fdc40593          	addi	a1,s0,-36
    80003124:	4505                	li	a0,1
    80003126:	eb3ff0ef          	jal	80002fd8 <argint>
  addr = myproc()->sz;
    8000312a:	fcafe0ef          	jal	800018f4 <myproc>
    8000312e:	7124                	ld	s1,96(a0)

  if (t == SBRK_EAGER || n < 0) {
    80003130:	fdc42703          	lw	a4,-36(s0)
    80003134:	4785                	li	a5,1
    80003136:	02f70763          	beq	a4,a5,80003164 <sys_sbrk+0x58>
    8000313a:	fd842783          	lw	a5,-40(s0)
    8000313e:	0207c363          	bltz	a5,80003164 <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if (addr + n < addr)
    80003142:	97a6                	add	a5,a5,s1
      return -1;
    if (addr + n > TRAPFRAME)
    80003144:	02000737          	lui	a4,0x2000
    80003148:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    8000314a:	0736                	slli	a4,a4,0xd
    8000314c:	02f76a63          	bltu	a4,a5,80003180 <sys_sbrk+0x74>
    80003150:	0297e863          	bltu	a5,s1,80003180 <sys_sbrk+0x74>
      return -1;
    myproc()->sz += n;
    80003154:	fa0fe0ef          	jal	800018f4 <myproc>
    80003158:	fd842703          	lw	a4,-40(s0)
    8000315c:	713c                	ld	a5,96(a0)
    8000315e:	97ba                	add	a5,a5,a4
    80003160:	f13c                	sd	a5,96(a0)
    80003162:	a039                	j	80003170 <sys_sbrk+0x64>
    if (growproc(n) < 0) {
    80003164:	fd842503          	lw	a0,-40(s0)
    80003168:	b3ffe0ef          	jal	80001ca6 <growproc>
    8000316c:	00054863          	bltz	a0,8000317c <sys_sbrk+0x70>
  }
  return addr;
}
    80003170:	8526                	mv	a0,s1
    80003172:	70a2                	ld	ra,40(sp)
    80003174:	7402                	ld	s0,32(sp)
    80003176:	64e2                	ld	s1,24(sp)
    80003178:	6145                	addi	sp,sp,48
    8000317a:	8082                	ret
      return -1;
    8000317c:	54fd                	li	s1,-1
    8000317e:	bfcd                	j	80003170 <sys_sbrk+0x64>
      return -1;
    80003180:	54fd                	li	s1,-1
    80003182:	b7fd                	j	80003170 <sys_sbrk+0x64>

0000000080003184 <sys_pause>:

uint64
sys_pause(void)
{
    80003184:	7139                	addi	sp,sp,-64
    80003186:	fc06                	sd	ra,56(sp)
    80003188:	f822                	sd	s0,48(sp)
    8000318a:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    8000318c:	fcc40593          	addi	a1,s0,-52
    80003190:	4501                	li	a0,0
    80003192:	e47ff0ef          	jal	80002fd8 <argint>
  if (n < 0)
    80003196:	fcc42783          	lw	a5,-52(s0)
    8000319a:	0807c063          	bltz	a5,8000321a <sys_pause+0x96>
    n = 0;
  acquire(&tickslock);
    8000319e:	00017517          	auipc	a0,0x17
    800031a2:	bea50513          	addi	a0,a0,-1046 # 80019d88 <tickslock>
    800031a6:	a43fd0ef          	jal	80000be8 <acquire>
  ticks0 = ticks;
  while (ticks - ticks0 < n) {
    800031aa:	fcc42783          	lw	a5,-52(s0)
    800031ae:	cbb9                	beqz	a5,80003204 <sys_pause+0x80>
    800031b0:	f426                	sd	s1,40(sp)
    800031b2:	f04a                	sd	s2,32(sp)
    800031b4:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    800031b6:	00008997          	auipc	s3,0x8
    800031ba:	5329a983          	lw	s3,1330(s3) # 8000b6e8 <ticks>
    if (killed(myproc())) {
      release(&tickslock);
      return -1;
    }
    sleep_prepare(&ticks);
    800031be:	00008917          	auipc	s2,0x8
    800031c2:	52a90913          	addi	s2,s2,1322 # 8000b6e8 <ticks>
    release(&tickslock);
    800031c6:	00017497          	auipc	s1,0x17
    800031ca:	bc248493          	addi	s1,s1,-1086 # 80019d88 <tickslock>
    if (killed(myproc())) {
    800031ce:	f26fe0ef          	jal	800018f4 <myproc>
    800031d2:	a58ff0ef          	jal	8000242a <killed>
    800031d6:	e529                	bnez	a0,80003220 <sys_pause+0x9c>
    sleep_prepare(&ticks);
    800031d8:	854a                	mv	a0,s2
    800031da:	89eff0ef          	jal	80002278 <sleep_prepare>
    release(&tickslock);
    800031de:	8526                	mv	a0,s1
    800031e0:	a91fd0ef          	jal	80000c70 <release>
    sleep();
    800031e4:	8d0ff0ef          	jal	800022b4 <sleep>
    acquire(&tickslock);
    800031e8:	8526                	mv	a0,s1
    800031ea:	9fffd0ef          	jal	80000be8 <acquire>
  while (ticks - ticks0 < n) {
    800031ee:	00092783          	lw	a5,0(s2)
    800031f2:	413787bb          	subw	a5,a5,s3
    800031f6:	fcc42703          	lw	a4,-52(s0)
    800031fa:	fce7eae3          	bltu	a5,a4,800031ce <sys_pause+0x4a>
    800031fe:	74a2                	ld	s1,40(sp)
    80003200:	7902                	ld	s2,32(sp)
    80003202:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80003204:	00017517          	auipc	a0,0x17
    80003208:	b8450513          	addi	a0,a0,-1148 # 80019d88 <tickslock>
    8000320c:	a65fd0ef          	jal	80000c70 <release>
  return 0;
    80003210:	4501                	li	a0,0
}
    80003212:	70e2                	ld	ra,56(sp)
    80003214:	7442                	ld	s0,48(sp)
    80003216:	6121                	addi	sp,sp,64
    80003218:	8082                	ret
    n = 0;
    8000321a:	fc042623          	sw	zero,-52(s0)
    8000321e:	b741                	j	8000319e <sys_pause+0x1a>
      release(&tickslock);
    80003220:	00017517          	auipc	a0,0x17
    80003224:	b6850513          	addi	a0,a0,-1176 # 80019d88 <tickslock>
    80003228:	a49fd0ef          	jal	80000c70 <release>
      return -1;
    8000322c:	557d                	li	a0,-1
    8000322e:	74a2                	ld	s1,40(sp)
    80003230:	7902                	ld	s2,32(sp)
    80003232:	69e2                	ld	s3,24(sp)
    80003234:	bff9                	j	80003212 <sys_pause+0x8e>

0000000080003236 <sys_kill>:

uint64
sys_kill(void)
{
    80003236:	1101                	addi	sp,sp,-32
    80003238:	ec06                	sd	ra,24(sp)
    8000323a:	e822                	sd	s0,16(sp)
    8000323c:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    8000323e:	fec40593          	addi	a1,s0,-20
    80003242:	4501                	li	a0,0
    80003244:	d95ff0ef          	jal	80002fd8 <argint>
  return kkill(pid);
    80003248:	fec42503          	lw	a0,-20(s0)
    8000324c:	954ff0ef          	jal	800023a0 <kkill>
}
    80003250:	60e2                	ld	ra,24(sp)
    80003252:	6442                	ld	s0,16(sp)
    80003254:	6105                	addi	sp,sp,32
    80003256:	8082                	ret

0000000080003258 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80003258:	1101                	addi	sp,sp,-32
    8000325a:	ec06                	sd	ra,24(sp)
    8000325c:	e822                	sd	s0,16(sp)
    8000325e:	e426                	sd	s1,8(sp)
    80003260:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80003262:	00017517          	auipc	a0,0x17
    80003266:	b2650513          	addi	a0,a0,-1242 # 80019d88 <tickslock>
    8000326a:	97ffd0ef          	jal	80000be8 <acquire>
  xticks = ticks;
    8000326e:	00008797          	auipc	a5,0x8
    80003272:	47a7a783          	lw	a5,1146(a5) # 8000b6e8 <ticks>
    80003276:	84be                	mv	s1,a5
  release(&tickslock);
    80003278:	00017517          	auipc	a0,0x17
    8000327c:	b1050513          	addi	a0,a0,-1264 # 80019d88 <tickslock>
    80003280:	9f1fd0ef          	jal	80000c70 <release>
  return xticks;
}
    80003284:	02049513          	slli	a0,s1,0x20
    80003288:	9101                	srli	a0,a0,0x20
    8000328a:	60e2                	ld	ra,24(sp)
    8000328c:	6442                	ld	s0,16(sp)
    8000328e:	64a2                	ld	s1,8(sp)
    80003290:	6105                	addi	sp,sp,32
    80003292:	8082                	ret

0000000080003294 <sys_clone>:
// Q1: read the user arguments and create a thread in the caller's address space.
uint64
sys_clone(void)
{
    80003294:	7179                	addi	sp,sp,-48
    80003296:	f406                	sd	ra,40(sp)
    80003298:	f022                	sd	s0,32(sp)
    8000329a:	1800                	addi	s0,sp,48
  uint64 fcn;
  uint64 arg;
  uint64 stack;

  argaddr(0, &fcn);
    8000329c:	fe840593          	addi	a1,s0,-24
    800032a0:	4501                	li	a0,0
    800032a2:	d53ff0ef          	jal	80002ff4 <argaddr>
  argaddr(1, &arg);
    800032a6:	fe040593          	addi	a1,s0,-32
    800032aa:	4505                	li	a0,1
    800032ac:	d49ff0ef          	jal	80002ff4 <argaddr>
  argaddr(2, &stack);
    800032b0:	fd840593          	addi	a1,s0,-40
    800032b4:	4509                	li	a0,2
    800032b6:	d3fff0ef          	jal	80002ff4 <argaddr>
  return kclone(fcn, arg, stack);
    800032ba:	fd843603          	ld	a2,-40(s0)
    800032be:	fe043583          	ld	a1,-32(s0)
    800032c2:	fe843503          	ld	a0,-24(s0)
    800032c6:	b51fe0ef          	jal	80001e16 <kclone>
}
    800032ca:	70a2                	ld	ra,40(sp)
    800032cc:	7402                	ld	s0,32(sp)
    800032ce:	6145                	addi	sp,sp,48
    800032d0:	8082                	ret

00000000800032d2 <sys_join>:

// Q1: wait for one child thread to exit and reclaim its kernel resources.
uint64
sys_join(void)
{
    800032d2:	1141                	addi	sp,sp,-16
    800032d4:	e406                	sd	ra,8(sp)
    800032d6:	e022                	sd	s0,0(sp)
    800032d8:	0800                	addi	s0,sp,16
  return kjoin();
    800032da:	a86ff0ef          	jal	80002560 <kjoin>
}
    800032de:	60a2                	ld	ra,8(sp)
    800032e0:	6402                	ld	s0,0(sp)
    800032e2:	0141                	addi	sp,sp,16
    800032e4:	8082                	ret

00000000800032e6 <sys_sem_init>:
// Q2: initialize a semaphore identified by sem_id.
uint64
sys_sem_init(void)
{
    800032e6:	1101                	addi	sp,sp,-32
    800032e8:	ec06                	sd	ra,24(sp)
    800032ea:	e822                	sd	s0,16(sp)
    800032ec:	1000                	addi	s0,sp,32
  int sem_id;
  int value;

  argint(0, &sem_id);
    800032ee:	fec40593          	addi	a1,s0,-20
    800032f2:	4501                	li	a0,0
    800032f4:	ce5ff0ef          	jal	80002fd8 <argint>
  argint(1, &value);
    800032f8:	fe840593          	addi	a1,s0,-24
    800032fc:	4505                	li	a0,1
    800032fe:	cdbff0ef          	jal	80002fd8 <argint>
  return ksem_init(sem_id, value);
    80003302:	fe842583          	lw	a1,-24(s0)
    80003306:	fec42503          	lw	a0,-20(s0)
    8000330a:	e72ff0ef          	jal	8000297c <ksem_init>
}
    8000330e:	60e2                	ld	ra,24(sp)
    80003310:	6442                	ld	s0,16(sp)
    80003312:	6105                	addi	sp,sp,32
    80003314:	8082                	ret

0000000080003316 <sys_sem_wait>:

// Q2: wait until one semaphore permit is available.
uint64
sys_sem_wait(void)
{
    80003316:	1101                	addi	sp,sp,-32
    80003318:	ec06                	sd	ra,24(sp)
    8000331a:	e822                	sd	s0,16(sp)
    8000331c:	1000                	addi	s0,sp,32
  int sem_id;

  argint(0, &sem_id);
    8000331e:	fec40593          	addi	a1,s0,-20
    80003322:	4501                	li	a0,0
    80003324:	cb5ff0ef          	jal	80002fd8 <argint>
  return ksem_wait(sem_id);
    80003328:	fec42503          	lw	a0,-20(s0)
    8000332c:	ec6ff0ef          	jal	800029f2 <ksem_wait>
}
    80003330:	60e2                	ld	ra,24(sp)
    80003332:	6442                	ld	s0,16(sp)
    80003334:	6105                	addi	sp,sp,32
    80003336:	8082                	ret

0000000080003338 <sys_sem_signal>:

// Q2: release one semaphore permit.
uint64
sys_sem_signal(void)
{
    80003338:	1101                	addi	sp,sp,-32
    8000333a:	ec06                	sd	ra,24(sp)
    8000333c:	e822                	sd	s0,16(sp)
    8000333e:	1000                	addi	s0,sp,32
  int sem_id;

  argint(0, &sem_id);
    80003340:	fec40593          	addi	a1,s0,-20
    80003344:	4501                	li	a0,0
    80003346:	c93ff0ef          	jal	80002fd8 <argint>
  return ksem_signal(sem_id);
    8000334a:	fec42503          	lw	a0,-20(s0)
    8000334e:	f7aff0ef          	jal	80002ac8 <ksem_signal>
}
    80003352:	60e2                	ld	ra,24(sp)
    80003354:	6442                	ld	s0,16(sp)
    80003356:	6105                	addi	sp,sp,32
    80003358:	8082                	ret

000000008000335a <sys_set_priority>:
// Q4: Set process priority system call.
uint64
sys_set_priority(void)
{
    8000335a:	1101                	addi	sp,sp,-32
    8000335c:	ec06                	sd	ra,24(sp)
    8000335e:	e822                	sd	s0,16(sp)
    80003360:	1000                	addi	s0,sp,32
  int pid, priority;

  argint(0, &pid);
    80003362:	fec40593          	addi	a1,s0,-20
    80003366:	4501                	li	a0,0
    80003368:	c71ff0ef          	jal	80002fd8 <argint>
  argint(1, &priority);
    8000336c:	fe840593          	addi	a1,s0,-24
    80003370:	4505                	li	a0,1
    80003372:	c67ff0ef          	jal	80002fd8 <argint>

  return set_priority_by_pid(pid, priority);
    80003376:	fe842583          	lw	a1,-24(s0)
    8000337a:	fec42503          	lw	a0,-20(s0)
    8000337e:	cc6ff0ef          	jal	80002844 <set_priority_by_pid>
}
    80003382:	60e2                	ld	ra,24(sp)
    80003384:	6442                	ld	s0,16(sp)
    80003386:	6105                	addi	sp,sp,32
    80003388:	8082                	ret

000000008000338a <sys_get_priority>:
// Q4: Get process priority system call.
uint64
sys_get_priority(void)
{
    8000338a:	1101                	addi	sp,sp,-32
    8000338c:	ec06                	sd	ra,24(sp)
    8000338e:	e822                	sd	s0,16(sp)
    80003390:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80003392:	fec40593          	addi	a1,s0,-20
    80003396:	4501                	li	a0,0
    80003398:	c41ff0ef          	jal	80002fd8 <argint>

  return get_priority_by_pid(pid);
    8000339c:	fec42503          	lw	a0,-20(s0)
    800033a0:	d1eff0ef          	jal	800028be <get_priority_by_pid>
}
    800033a4:	60e2                	ld	ra,24(sp)
    800033a6:	6442                	ld	s0,16(sp)
    800033a8:	6105                	addi	sp,sp,32
    800033aa:	8082                	ret

00000000800033ac <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    800033ac:	7179                	addi	sp,sp,-48
    800033ae:	f406                	sd	ra,40(sp)
    800033b0:	f022                	sd	s0,32(sp)
    800033b2:	ec26                	sd	s1,24(sp)
    800033b4:	e84a                	sd	s2,16(sp)
    800033b6:	e44e                	sd	s3,8(sp)
    800033b8:	e052                	sd	s4,0(sp)
    800033ba:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    800033bc:	00005597          	auipc	a1,0x5
    800033c0:	04458593          	addi	a1,a1,68 # 80008400 <etext+0x400>
    800033c4:	00017517          	auipc	a0,0x17
    800033c8:	9dc50513          	addi	a0,a0,-1572 # 80019da0 <bcache>
    800033cc:	f9cfd0ef          	jal	80000b68 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    800033d0:	0001f797          	auipc	a5,0x1f
    800033d4:	9d078793          	addi	a5,a5,-1584 # 80021da0 <bcache+0x8000>
    800033d8:	0001f717          	auipc	a4,0x1f
    800033dc:	c3070713          	addi	a4,a4,-976 # 80022008 <bcache+0x8268>
    800033e0:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    800033e4:	2ae7bc23          	sd	a4,696(a5)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    800033e8:	00017497          	auipc	s1,0x17
    800033ec:	9d048493          	addi	s1,s1,-1584 # 80019db8 <bcache+0x18>
    b->next = bcache.head.next;
    800033f0:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    800033f2:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    800033f4:	00005a17          	auipc	s4,0x5
    800033f8:	014a0a13          	addi	s4,s4,20 # 80008408 <etext+0x408>
    b->next = bcache.head.next;
    800033fc:	2b893783          	ld	a5,696(s2)
    80003400:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80003402:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80003406:	85d2                	mv	a1,s4
    80003408:	01048513          	addi	a0,s1,16
    8000340c:	3c6010ef          	jal	800047d2 <initsleeplock>
    bcache.head.next->prev = b;
    80003410:	2b893783          	ld	a5,696(s2)
    80003414:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80003416:	2a993c23          	sd	s1,696(s2)
  for (b = bcache.buf; b < bcache.buf + NBUF; b++) {
    8000341a:	45848493          	addi	s1,s1,1112
    8000341e:	fd349fe3          	bne	s1,s3,800033fc <binit+0x50>
  }
}
    80003422:	70a2                	ld	ra,40(sp)
    80003424:	7402                	ld	s0,32(sp)
    80003426:	64e2                	ld	s1,24(sp)
    80003428:	6942                	ld	s2,16(sp)
    8000342a:	69a2                	ld	s3,8(sp)
    8000342c:	6a02                	ld	s4,0(sp)
    8000342e:	6145                	addi	sp,sp,48
    80003430:	8082                	ret

0000000080003432 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf *
bread(uint dev, uint blockno)
{
    80003432:	7179                	addi	sp,sp,-48
    80003434:	f406                	sd	ra,40(sp)
    80003436:	f022                	sd	s0,32(sp)
    80003438:	ec26                	sd	s1,24(sp)
    8000343a:	e84a                	sd	s2,16(sp)
    8000343c:	e44e                	sd	s3,8(sp)
    8000343e:	1800                	addi	s0,sp,48
    80003440:	892a                	mv	s2,a0
    80003442:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80003444:	00017517          	auipc	a0,0x17
    80003448:	95c50513          	addi	a0,a0,-1700 # 80019da0 <bcache>
    8000344c:	f9cfd0ef          	jal	80000be8 <acquire>
  for (b = bcache.head.next; b != &bcache.head; b = b->next) {
    80003450:	0001f497          	auipc	s1,0x1f
    80003454:	c084b483          	ld	s1,-1016(s1) # 80022058 <bcache+0x82b8>
    80003458:	0001f797          	auipc	a5,0x1f
    8000345c:	bb078793          	addi	a5,a5,-1104 # 80022008 <bcache+0x8268>
    80003460:	02f48b63          	beq	s1,a5,80003496 <bread+0x64>
    80003464:	873e                	mv	a4,a5
    80003466:	a021                	j	8000346e <bread+0x3c>
    80003468:	68a4                	ld	s1,80(s1)
    8000346a:	02e48663          	beq	s1,a4,80003496 <bread+0x64>
    if (b->dev == dev && b->blockno == blockno) {
    8000346e:	449c                	lw	a5,8(s1)
    80003470:	ff279ce3          	bne	a5,s2,80003468 <bread+0x36>
    80003474:	44dc                	lw	a5,12(s1)
    80003476:	ff3799e3          	bne	a5,s3,80003468 <bread+0x36>
      b->refcnt++;
    8000347a:	40bc                	lw	a5,64(s1)
    8000347c:	2785                	addiw	a5,a5,1
    8000347e:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80003480:	00017517          	auipc	a0,0x17
    80003484:	92050513          	addi	a0,a0,-1760 # 80019da0 <bcache>
    80003488:	fe8fd0ef          	jal	80000c70 <release>
      acquiresleep(&b->lock);
    8000348c:	01048513          	addi	a0,s1,16
    80003490:	378010ef          	jal	80004808 <acquiresleep>
      return b;
    80003494:	a889                	j	800034e6 <bread+0xb4>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    80003496:	0001f497          	auipc	s1,0x1f
    8000349a:	bba4b483          	ld	s1,-1094(s1) # 80022050 <bcache+0x82b0>
    8000349e:	0001f797          	auipc	a5,0x1f
    800034a2:	b6a78793          	addi	a5,a5,-1174 # 80022008 <bcache+0x8268>
    800034a6:	00f48863          	beq	s1,a5,800034b6 <bread+0x84>
    800034aa:	873e                	mv	a4,a5
    if (b->refcnt == 0) {
    800034ac:	40bc                	lw	a5,64(s1)
    800034ae:	cb91                	beqz	a5,800034c2 <bread+0x90>
  for (b = bcache.head.prev; b != &bcache.head; b = b->prev) {
    800034b0:	64a4                	ld	s1,72(s1)
    800034b2:	fee49de3          	bne	s1,a4,800034ac <bread+0x7a>
  panic("bget: no buffers");
    800034b6:	00005517          	auipc	a0,0x5
    800034ba:	f5a50513          	addi	a0,a0,-166 # 80008410 <etext+0x410>
    800034be:	b76fd0ef          	jal	80000834 <panic>
      b->dev = dev;
    800034c2:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    800034c6:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    800034ca:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    800034ce:	4785                	li	a5,1
    800034d0:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    800034d2:	00017517          	auipc	a0,0x17
    800034d6:	8ce50513          	addi	a0,a0,-1842 # 80019da0 <bcache>
    800034da:	f96fd0ef          	jal	80000c70 <release>
      acquiresleep(&b->lock);
    800034de:	01048513          	addi	a0,s1,16
    800034e2:	326010ef          	jal	80004808 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if (!b->valid) {
    800034e6:	409c                	lw	a5,0(s1)
    800034e8:	cb89                	beqz	a5,800034fa <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    800034ea:	8526                	mv	a0,s1
    800034ec:	70a2                	ld	ra,40(sp)
    800034ee:	7402                	ld	s0,32(sp)
    800034f0:	64e2                	ld	s1,24(sp)
    800034f2:	6942                	ld	s2,16(sp)
    800034f4:	69a2                	ld	s3,8(sp)
    800034f6:	6145                	addi	sp,sp,48
    800034f8:	8082                	ret
    virtio_disk_rw(b, 0);
    800034fa:	4581                	li	a1,0
    800034fc:	8526                	mv	a0,s1
    800034fe:	3f3020ef          	jal	800060f0 <virtio_disk_rw>
    b->valid = 1;
    80003502:	4785                	li	a5,1
    80003504:	c09c                	sw	a5,0(s1)
  return b;
    80003506:	b7d5                	j	800034ea <bread+0xb8>

0000000080003508 <bwrite>:

// Write b's contents to disk.  Must be locked.
// Only the log calls bwrite.
void
bwrite(struct buf *b)
{
    80003508:	1101                	addi	sp,sp,-32
    8000350a:	ec06                	sd	ra,24(sp)
    8000350c:	e822                	sd	s0,16(sp)
    8000350e:	e426                	sd	s1,8(sp)
    80003510:	1000                	addi	s0,sp,32
    80003512:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80003514:	0541                	addi	a0,a0,16
    80003516:	37e010ef          	jal	80004894 <holdingsleep>
    8000351a:	c911                	beqz	a0,8000352e <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    8000351c:	4585                	li	a1,1
    8000351e:	8526                	mv	a0,s1
    80003520:	3d1020ef          	jal	800060f0 <virtio_disk_rw>
}
    80003524:	60e2                	ld	ra,24(sp)
    80003526:	6442                	ld	s0,16(sp)
    80003528:	64a2                	ld	s1,8(sp)
    8000352a:	6105                	addi	sp,sp,32
    8000352c:	8082                	ret
    panic("bwrite");
    8000352e:	00005517          	auipc	a0,0x5
    80003532:	efa50513          	addi	a0,a0,-262 # 80008428 <etext+0x428>
    80003536:	afefd0ef          	jal	80000834 <panic>

000000008000353a <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    8000353a:	1101                	addi	sp,sp,-32
    8000353c:	ec06                	sd	ra,24(sp)
    8000353e:	e822                	sd	s0,16(sp)
    80003540:	e426                	sd	s1,8(sp)
    80003542:	e04a                	sd	s2,0(sp)
    80003544:	1000                	addi	s0,sp,32
    80003546:	84aa                	mv	s1,a0
  if (!holdingsleep(&b->lock))
    80003548:	01050913          	addi	s2,a0,16
    8000354c:	854a                	mv	a0,s2
    8000354e:	346010ef          	jal	80004894 <holdingsleep>
    80003552:	c125                	beqz	a0,800035b2 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80003554:	854a                	mv	a0,s2
    80003556:	306010ef          	jal	8000485c <releasesleep>

  acquire(&bcache.lock);
    8000355a:	00017517          	auipc	a0,0x17
    8000355e:	84650513          	addi	a0,a0,-1978 # 80019da0 <bcache>
    80003562:	e86fd0ef          	jal	80000be8 <acquire>
  b->refcnt--;
    80003566:	40bc                	lw	a5,64(s1)
    80003568:	37fd                	addiw	a5,a5,-1
    8000356a:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    8000356c:	e79d                	bnez	a5,8000359a <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    8000356e:	68b8                	ld	a4,80(s1)
    80003570:	64bc                	ld	a5,72(s1)
    80003572:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80003574:	68b8                	ld	a4,80(s1)
    80003576:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80003578:	0001f797          	auipc	a5,0x1f
    8000357c:	82878793          	addi	a5,a5,-2008 # 80021da0 <bcache+0x8000>
    80003580:	2b87b703          	ld	a4,696(a5)
    80003584:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80003586:	0001f717          	auipc	a4,0x1f
    8000358a:	a8270713          	addi	a4,a4,-1406 # 80022008 <bcache+0x8268>
    8000358e:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80003590:	2b87b703          	ld	a4,696(a5)
    80003594:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80003596:	2a97bc23          	sd	s1,696(a5)
  }

  release(&bcache.lock);
    8000359a:	00017517          	auipc	a0,0x17
    8000359e:	80650513          	addi	a0,a0,-2042 # 80019da0 <bcache>
    800035a2:	ecefd0ef          	jal	80000c70 <release>
}
    800035a6:	60e2                	ld	ra,24(sp)
    800035a8:	6442                	ld	s0,16(sp)
    800035aa:	64a2                	ld	s1,8(sp)
    800035ac:	6902                	ld	s2,0(sp)
    800035ae:	6105                	addi	sp,sp,32
    800035b0:	8082                	ret
    panic("brelse");
    800035b2:	00005517          	auipc	a0,0x5
    800035b6:	e7e50513          	addi	a0,a0,-386 # 80008430 <etext+0x430>
    800035ba:	a7afd0ef          	jal	80000834 <panic>

00000000800035be <bpin>:

void
bpin(struct buf *b)
{
    800035be:	1101                	addi	sp,sp,-32
    800035c0:	ec06                	sd	ra,24(sp)
    800035c2:	e822                	sd	s0,16(sp)
    800035c4:	e426                	sd	s1,8(sp)
    800035c6:	1000                	addi	s0,sp,32
    800035c8:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800035ca:	00016517          	auipc	a0,0x16
    800035ce:	7d650513          	addi	a0,a0,2006 # 80019da0 <bcache>
    800035d2:	e16fd0ef          	jal	80000be8 <acquire>
  b->refcnt++;
    800035d6:	40bc                	lw	a5,64(s1)
    800035d8:	2785                	addiw	a5,a5,1
    800035da:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    800035dc:	00016517          	auipc	a0,0x16
    800035e0:	7c450513          	addi	a0,a0,1988 # 80019da0 <bcache>
    800035e4:	e8cfd0ef          	jal	80000c70 <release>
}
    800035e8:	60e2                	ld	ra,24(sp)
    800035ea:	6442                	ld	s0,16(sp)
    800035ec:	64a2                	ld	s1,8(sp)
    800035ee:	6105                	addi	sp,sp,32
    800035f0:	8082                	ret

00000000800035f2 <bunpin>:

void
bunpin(struct buf *b)
{
    800035f2:	1101                	addi	sp,sp,-32
    800035f4:	ec06                	sd	ra,24(sp)
    800035f6:	e822                	sd	s0,16(sp)
    800035f8:	e426                	sd	s1,8(sp)
    800035fa:	1000                	addi	s0,sp,32
    800035fc:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    800035fe:	00016517          	auipc	a0,0x16
    80003602:	7a250513          	addi	a0,a0,1954 # 80019da0 <bcache>
    80003606:	de2fd0ef          	jal	80000be8 <acquire>
  b->refcnt--;
    8000360a:	40bc                	lw	a5,64(s1)
    8000360c:	37fd                	addiw	a5,a5,-1
    8000360e:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003610:	00016517          	auipc	a0,0x16
    80003614:	79050513          	addi	a0,a0,1936 # 80019da0 <bcache>
    80003618:	e58fd0ef          	jal	80000c70 <release>
}
    8000361c:	60e2                	ld	ra,24(sp)
    8000361e:	6442                	ld	s0,16(sp)
    80003620:	64a2                	ld	s1,8(sp)
    80003622:	6105                	addi	sp,sp,32
    80003624:	8082                	ret

0000000080003626 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80003626:	1101                	addi	sp,sp,-32
    80003628:	ec06                	sd	ra,24(sp)
    8000362a:	e822                	sd	s0,16(sp)
    8000362c:	e426                	sd	s1,8(sp)
    8000362e:	e04a                	sd	s2,0(sp)
    80003630:	1000                	addi	s0,sp,32
    80003632:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80003634:	00d5d79b          	srliw	a5,a1,0xd
    80003638:	0001f597          	auipc	a1,0x1f
    8000363c:	e445a583          	lw	a1,-444(a1) # 8002247c <sb+0x1c>
    80003640:	9dbd                	addw	a1,a1,a5
    80003642:	df1ff0ef          	jal	80003432 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003646:	0074f713          	andi	a4,s1,7
    8000364a:	4785                	li	a5,1
    8000364c:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80003650:	14ce                	slli	s1,s1,0x33
  if ((bp->data[bi / 8] & m) == 0)
    80003652:	90d9                	srli	s1,s1,0x36
    80003654:	00950733          	add	a4,a0,s1
    80003658:	05874703          	lbu	a4,88(a4)
    8000365c:	00e7f6b3          	and	a3,a5,a4
    80003660:	c29d                	beqz	a3,80003686 <bfree+0x60>
    80003662:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi / 8] &= ~m;
    80003664:	94aa                	add	s1,s1,a0
    80003666:	fff7c793          	not	a5,a5
    8000366a:	8f7d                	and	a4,a4,a5
    8000366c:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80003670:	02a010ef          	jal	8000469a <log_write>
  brelse(bp);
    80003674:	854a                	mv	a0,s2
    80003676:	ec5ff0ef          	jal	8000353a <brelse>
}
    8000367a:	60e2                	ld	ra,24(sp)
    8000367c:	6442                	ld	s0,16(sp)
    8000367e:	64a2                	ld	s1,8(sp)
    80003680:	6902                	ld	s2,0(sp)
    80003682:	6105                	addi	sp,sp,32
    80003684:	8082                	ret
    panic("freeing free block");
    80003686:	00005517          	auipc	a0,0x5
    8000368a:	db250513          	addi	a0,a0,-590 # 80008438 <etext+0x438>
    8000368e:	9a6fd0ef          	jal	80000834 <panic>

0000000080003692 <balloc>:
{
    80003692:	715d                	addi	sp,sp,-80
    80003694:	e486                	sd	ra,72(sp)
    80003696:	e0a2                	sd	s0,64(sp)
    80003698:	fc26                	sd	s1,56(sp)
    8000369a:	0880                	addi	s0,sp,80
  for (b = 0; b < sb.size; b += BPB) {
    8000369c:	0001f797          	auipc	a5,0x1f
    800036a0:	dc87a783          	lw	a5,-568(a5) # 80022464 <sb+0x4>
    800036a4:	0e078263          	beqz	a5,80003788 <balloc+0xf6>
    800036a8:	f84a                	sd	s2,48(sp)
    800036aa:	f44e                	sd	s3,40(sp)
    800036ac:	f052                	sd	s4,32(sp)
    800036ae:	ec56                	sd	s5,24(sp)
    800036b0:	e85a                	sd	s6,16(sp)
    800036b2:	e45e                	sd	s7,8(sp)
    800036b4:	e062                	sd	s8,0(sp)
    800036b6:	8baa                	mv	s7,a0
    800036b8:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    800036ba:	0001fb17          	auipc	s6,0x1f
    800036be:	da6b0b13          	addi	s6,s6,-602 # 80022460 <sb>
      m = 1 << (bi % 8);
    800036c2:	4985                	li	s3,1
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    800036c4:	6a09                	lui	s4,0x2
  for (b = 0; b < sb.size; b += BPB) {
    800036c6:	6c09                	lui	s8,0x2
    800036c8:	a09d                	j	8000372e <balloc+0x9c>
        bp->data[bi / 8] |= m;           // Mark block in use.
    800036ca:	97ca                	add	a5,a5,s2
    800036cc:	8e55                	or	a2,a2,a3
    800036ce:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    800036d2:	854a                	mv	a0,s2
    800036d4:	7c7000ef          	jal	8000469a <log_write>
        brelse(bp);
    800036d8:	854a                	mv	a0,s2
    800036da:	e61ff0ef          	jal	8000353a <brelse>
  bp = bread(dev, bno);
    800036de:	85a6                	mv	a1,s1
    800036e0:	855e                	mv	a0,s7
    800036e2:	d51ff0ef          	jal	80003432 <bread>
    800036e6:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    800036e8:	40000613          	li	a2,1024
    800036ec:	4581                	li	a1,0
    800036ee:	05850513          	addi	a0,a0,88
    800036f2:	db6fd0ef          	jal	80000ca8 <memset>
  log_write(bp);
    800036f6:	854a                	mv	a0,s2
    800036f8:	7a3000ef          	jal	8000469a <log_write>
  brelse(bp);
    800036fc:	854a                	mv	a0,s2
    800036fe:	e3dff0ef          	jal	8000353a <brelse>
}
    80003702:	7942                	ld	s2,48(sp)
    80003704:	79a2                	ld	s3,40(sp)
    80003706:	7a02                	ld	s4,32(sp)
    80003708:	6ae2                	ld	s5,24(sp)
    8000370a:	6b42                	ld	s6,16(sp)
    8000370c:	6ba2                	ld	s7,8(sp)
    8000370e:	6c02                	ld	s8,0(sp)
}
    80003710:	8526                	mv	a0,s1
    80003712:	60a6                	ld	ra,72(sp)
    80003714:	6406                	ld	s0,64(sp)
    80003716:	74e2                	ld	s1,56(sp)
    80003718:	6161                	addi	sp,sp,80
    8000371a:	8082                	ret
    brelse(bp);
    8000371c:	854a                	mv	a0,s2
    8000371e:	e1dff0ef          	jal	8000353a <brelse>
  for (b = 0; b < sb.size; b += BPB) {
    80003722:	015c0abb          	addw	s5,s8,s5
    80003726:	004b2783          	lw	a5,4(s6)
    8000372a:	04faf863          	bgeu	s5,a5,8000377a <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    8000372e:	40dad59b          	sraiw	a1,s5,0xd
    80003732:	01cb2783          	lw	a5,28(s6)
    80003736:	9dbd                	addw	a1,a1,a5
    80003738:	855e                	mv	a0,s7
    8000373a:	cf9ff0ef          	jal	80003432 <bread>
    8000373e:	892a                	mv	s2,a0
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003740:	004b2503          	lw	a0,4(s6)
    80003744:	84d6                	mv	s1,s5
    80003746:	4701                	li	a4,0
    80003748:	fca4fae3          	bgeu	s1,a0,8000371c <balloc+0x8a>
      m = 1 << (bi % 8);
    8000374c:	00777693          	andi	a3,a4,7
    80003750:	00d996bb          	sllw	a3,s3,a3
      if ((bp->data[bi / 8] & m) == 0) { // Is block free?
    80003754:	41f7579b          	sraiw	a5,a4,0x1f
    80003758:	01d7d79b          	srliw	a5,a5,0x1d
    8000375c:	9fb9                	addw	a5,a5,a4
    8000375e:	4037d79b          	sraiw	a5,a5,0x3
    80003762:	00f90633          	add	a2,s2,a5
    80003766:	05864603          	lbu	a2,88(a2)
    8000376a:	00c6f5b3          	and	a1,a3,a2
    8000376e:	ddb1                	beqz	a1,800036ca <balloc+0x38>
    for (bi = 0; bi < BPB && b + bi < sb.size; bi++) {
    80003770:	2705                	addiw	a4,a4,1
    80003772:	2485                	addiw	s1,s1,1
    80003774:	fd471ae3          	bne	a4,s4,80003748 <balloc+0xb6>
    80003778:	b755                	j	8000371c <balloc+0x8a>
    8000377a:	7942                	ld	s2,48(sp)
    8000377c:	79a2                	ld	s3,40(sp)
    8000377e:	7a02                	ld	s4,32(sp)
    80003780:	6ae2                	ld	s5,24(sp)
    80003782:	6b42                	ld	s6,16(sp)
    80003784:	6ba2                	ld	s7,8(sp)
    80003786:	6c02                	ld	s8,0(sp)
  printk("balloc: out of blocks\n");
    80003788:	00005517          	auipc	a0,0x5
    8000378c:	cc850513          	addi	a0,a0,-824 # 80008450 <etext+0x450>
    80003790:	d7bfc0ef          	jal	8000050a <printk>
  return 0;
    80003794:	4481                	li	s1,0
    80003796:	bfad                	j	80003710 <balloc+0x7e>

0000000080003798 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80003798:	7179                	addi	sp,sp,-48
    8000379a:	f406                	sd	ra,40(sp)
    8000379c:	f022                	sd	s0,32(sp)
    8000379e:	ec26                	sd	s1,24(sp)
    800037a0:	e84a                	sd	s2,16(sp)
    800037a2:	e44e                	sd	s3,8(sp)
    800037a4:	1800                	addi	s0,sp,48
    800037a6:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if (bn < NDIRECT) {
    800037a8:	47ad                	li	a5,11
    800037aa:	02b7e363          	bltu	a5,a1,800037d0 <bmap+0x38>
    if ((addr = ip->addrs[bn]) == 0) {
    800037ae:	02059793          	slli	a5,a1,0x20
    800037b2:	01e7d593          	srli	a1,a5,0x1e
    800037b6:	00b509b3          	add	s3,a0,a1
    800037ba:	0509a483          	lw	s1,80(s3)
    800037be:	e0b5                	bnez	s1,80003822 <bmap+0x8a>
      addr = balloc(ip->dev);
    800037c0:	4108                	lw	a0,0(a0)
    800037c2:	ed1ff0ef          	jal	80003692 <balloc>
    800037c6:	84aa                	mv	s1,a0
      if (addr == 0)
    800037c8:	cd29                	beqz	a0,80003822 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    800037ca:	04a9a823          	sw	a0,80(s3)
    800037ce:	a891                	j	80003822 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    800037d0:	ff45879b          	addiw	a5,a1,-12
    800037d4:	873e                	mv	a4,a5
    800037d6:	89be                	mv	s3,a5

  if (bn < NINDIRECT) {
    800037d8:	0ff00793          	li	a5,255
    800037dc:	06e7e763          	bltu	a5,a4,8000384a <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if ((addr = ip->addrs[NDIRECT]) == 0) {
    800037e0:	08052483          	lw	s1,128(a0)
    800037e4:	e891                	bnez	s1,800037f8 <bmap+0x60>
      addr = balloc(ip->dev);
    800037e6:	4108                	lw	a0,0(a0)
    800037e8:	eabff0ef          	jal	80003692 <balloc>
    800037ec:	84aa                	mv	s1,a0
      if (addr == 0)
    800037ee:	c915                	beqz	a0,80003822 <bmap+0x8a>
    800037f0:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    800037f2:	08a92023          	sw	a0,128(s2)
    800037f6:	a011                	j	800037fa <bmap+0x62>
    800037f8:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    800037fa:	85a6                	mv	a1,s1
    800037fc:	00092503          	lw	a0,0(s2)
    80003800:	c33ff0ef          	jal	80003432 <bread>
    80003804:	8a2a                	mv	s4,a0
    a = (uint *)bp->data;
    80003806:	05850793          	addi	a5,a0,88
    if ((addr = a[bn]) == 0) {
    8000380a:	02099713          	slli	a4,s3,0x20
    8000380e:	01e75593          	srli	a1,a4,0x1e
    80003812:	97ae                	add	a5,a5,a1
    80003814:	89be                	mv	s3,a5
    80003816:	4384                	lw	s1,0(a5)
    80003818:	cc89                	beqz	s1,80003832 <bmap+0x9a>
      if (addr) {
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    8000381a:	8552                	mv	a0,s4
    8000381c:	d1fff0ef          	jal	8000353a <brelse>
    return addr;
    80003820:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80003822:	8526                	mv	a0,s1
    80003824:	70a2                	ld	ra,40(sp)
    80003826:	7402                	ld	s0,32(sp)
    80003828:	64e2                	ld	s1,24(sp)
    8000382a:	6942                	ld	s2,16(sp)
    8000382c:	69a2                	ld	s3,8(sp)
    8000382e:	6145                	addi	sp,sp,48
    80003830:	8082                	ret
      addr = balloc(ip->dev);
    80003832:	00092503          	lw	a0,0(s2)
    80003836:	e5dff0ef          	jal	80003692 <balloc>
    8000383a:	84aa                	mv	s1,a0
      if (addr) {
    8000383c:	dd79                	beqz	a0,8000381a <bmap+0x82>
        a[bn] = addr;
    8000383e:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80003842:	8552                	mv	a0,s4
    80003844:	657000ef          	jal	8000469a <log_write>
    80003848:	bfc9                	j	8000381a <bmap+0x82>
    8000384a:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    8000384c:	00005517          	auipc	a0,0x5
    80003850:	c1c50513          	addi	a0,a0,-996 # 80008468 <etext+0x468>
    80003854:	fe1fc0ef          	jal	80000834 <panic>

0000000080003858 <iget>:
{
    80003858:	7179                	addi	sp,sp,-48
    8000385a:	f406                	sd	ra,40(sp)
    8000385c:	f022                	sd	s0,32(sp)
    8000385e:	ec26                	sd	s1,24(sp)
    80003860:	e84a                	sd	s2,16(sp)
    80003862:	e44e                	sd	s3,8(sp)
    80003864:	e052                	sd	s4,0(sp)
    80003866:	1800                	addi	s0,sp,48
    80003868:	892a                	mv	s2,a0
    8000386a:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000386c:	0001f517          	auipc	a0,0x1f
    80003870:	c1450513          	addi	a0,a0,-1004 # 80022480 <itable>
    80003874:	b74fd0ef          	jal	80000be8 <acquire>
  empty = 0;
    80003878:	4981                	li	s3,0
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    8000387a:	0001f497          	auipc	s1,0x1f
    8000387e:	c1e48493          	addi	s1,s1,-994 # 80022498 <itable+0x18>
    80003882:	00020697          	auipc	a3,0x20
    80003886:	6a668693          	addi	a3,a3,1702 # 80023f28 <log>
    8000388a:	a809                	j	8000389c <iget+0x44>
    if (empty == 0 && ip->ref == 0) // Remember empty slot.
    8000388c:	e781                	bnez	a5,80003894 <iget+0x3c>
    8000388e:	00099363          	bnez	s3,80003894 <iget+0x3c>
      empty = ip;
    80003892:	89a6                	mv	s3,s1
  for (ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++) {
    80003894:	08848493          	addi	s1,s1,136
    80003898:	02d48563          	beq	s1,a3,800038c2 <iget+0x6a>
    if (ip->ref > 0 && ip->dev == dev && ip->inum == inum) {
    8000389c:	449c                	lw	a5,8(s1)
    8000389e:	fef057e3          	blez	a5,8000388c <iget+0x34>
    800038a2:	4098                	lw	a4,0(s1)
    800038a4:	ff2718e3          	bne	a4,s2,80003894 <iget+0x3c>
    800038a8:	40d8                	lw	a4,4(s1)
    800038aa:	ff4715e3          	bne	a4,s4,80003894 <iget+0x3c>
      ip->ref++;
    800038ae:	2785                	addiw	a5,a5,1
    800038b0:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800038b2:	0001f517          	auipc	a0,0x1f
    800038b6:	bce50513          	addi	a0,a0,-1074 # 80022480 <itable>
    800038ba:	bb6fd0ef          	jal	80000c70 <release>
      return ip;
    800038be:	89a6                	mv	s3,s1
    800038c0:	a015                	j	800038e4 <iget+0x8c>
  if (empty == 0)
    800038c2:	02098a63          	beqz	s3,800038f6 <iget+0x9e>
  ip->dev = dev;
    800038c6:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    800038ca:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    800038ce:	4785                	li	a5,1
    800038d0:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    800038d4:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    800038d8:	0001f517          	auipc	a0,0x1f
    800038dc:	ba850513          	addi	a0,a0,-1112 # 80022480 <itable>
    800038e0:	b90fd0ef          	jal	80000c70 <release>
}
    800038e4:	854e                	mv	a0,s3
    800038e6:	70a2                	ld	ra,40(sp)
    800038e8:	7402                	ld	s0,32(sp)
    800038ea:	64e2                	ld	s1,24(sp)
    800038ec:	6942                	ld	s2,16(sp)
    800038ee:	69a2                	ld	s3,8(sp)
    800038f0:	6a02                	ld	s4,0(sp)
    800038f2:	6145                	addi	sp,sp,48
    800038f4:	8082                	ret
    panic("iget: no inodes");
    800038f6:	00005517          	auipc	a0,0x5
    800038fa:	b8a50513          	addi	a0,a0,-1142 # 80008480 <etext+0x480>
    800038fe:	f37fc0ef          	jal	80000834 <panic>

0000000080003902 <iinit>:
{
    80003902:	7179                	addi	sp,sp,-48
    80003904:	f406                	sd	ra,40(sp)
    80003906:	f022                	sd	s0,32(sp)
    80003908:	ec26                	sd	s1,24(sp)
    8000390a:	e84a                	sd	s2,16(sp)
    8000390c:	e44e                	sd	s3,8(sp)
    8000390e:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003910:	00005597          	auipc	a1,0x5
    80003914:	b8058593          	addi	a1,a1,-1152 # 80008490 <etext+0x490>
    80003918:	0001f517          	auipc	a0,0x1f
    8000391c:	b6850513          	addi	a0,a0,-1176 # 80022480 <itable>
    80003920:	a48fd0ef          	jal	80000b68 <initlock>
  for (i = 0; i < NINODE; i++) {
    80003924:	0001f497          	auipc	s1,0x1f
    80003928:	b8448493          	addi	s1,s1,-1148 # 800224a8 <itable+0x28>
    8000392c:	00020997          	auipc	s3,0x20
    80003930:	60c98993          	addi	s3,s3,1548 # 80023f38 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003934:	00005917          	auipc	s2,0x5
    80003938:	b6490913          	addi	s2,s2,-1180 # 80008498 <etext+0x498>
    8000393c:	85ca                	mv	a1,s2
    8000393e:	8526                	mv	a0,s1
    80003940:	693000ef          	jal	800047d2 <initsleeplock>
  for (i = 0; i < NINODE; i++) {
    80003944:	08848493          	addi	s1,s1,136
    80003948:	ff349ae3          	bne	s1,s3,8000393c <iinit+0x3a>
}
    8000394c:	70a2                	ld	ra,40(sp)
    8000394e:	7402                	ld	s0,32(sp)
    80003950:	64e2                	ld	s1,24(sp)
    80003952:	6942                	ld	s2,16(sp)
    80003954:	69a2                	ld	s3,8(sp)
    80003956:	6145                	addi	sp,sp,48
    80003958:	8082                	ret

000000008000395a <ialloc>:
{
    8000395a:	7139                	addi	sp,sp,-64
    8000395c:	fc06                	sd	ra,56(sp)
    8000395e:	f822                	sd	s0,48(sp)
    80003960:	0080                	addi	s0,sp,64
  for (inum = 1; inum < sb.ninodes; inum++) {
    80003962:	0001f717          	auipc	a4,0x1f
    80003966:	b0a72703          	lw	a4,-1270(a4) # 8002246c <sb+0xc>
    8000396a:	4785                	li	a5,1
    8000396c:	06e7f063          	bgeu	a5,a4,800039cc <ialloc+0x72>
    80003970:	f426                	sd	s1,40(sp)
    80003972:	f04a                	sd	s2,32(sp)
    80003974:	ec4e                	sd	s3,24(sp)
    80003976:	e852                	sd	s4,16(sp)
    80003978:	e456                	sd	s5,8(sp)
    8000397a:	e05a                	sd	s6,0(sp)
    8000397c:	8aaa                	mv	s5,a0
    8000397e:	8b2e                	mv	s6,a1
    80003980:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80003982:	0001fa17          	auipc	s4,0x1f
    80003986:	adea0a13          	addi	s4,s4,-1314 # 80022460 <sb>
    8000398a:	00495593          	srli	a1,s2,0x4
    8000398e:	018a2783          	lw	a5,24(s4)
    80003992:	9dbd                	addw	a1,a1,a5
    80003994:	8556                	mv	a0,s5
    80003996:	a9dff0ef          	jal	80003432 <bread>
    8000399a:	84aa                	mv	s1,a0
    dip = (struct dinode *)bp->data + inum % IPB;
    8000399c:	05850993          	addi	s3,a0,88
    800039a0:	00f97793          	andi	a5,s2,15
    800039a4:	079a                	slli	a5,a5,0x6
    800039a6:	99be                	add	s3,s3,a5
    if (dip->type == 0) { // a free inode
    800039a8:	00099783          	lh	a5,0(s3)
    800039ac:	cb9d                	beqz	a5,800039e2 <ialloc+0x88>
    brelse(bp);
    800039ae:	b8dff0ef          	jal	8000353a <brelse>
  for (inum = 1; inum < sb.ninodes; inum++) {
    800039b2:	0905                	addi	s2,s2,1
    800039b4:	00ca2703          	lw	a4,12(s4)
    800039b8:	0009079b          	sext.w	a5,s2
    800039bc:	fce7e7e3          	bltu	a5,a4,8000398a <ialloc+0x30>
    800039c0:	74a2                	ld	s1,40(sp)
    800039c2:	7902                	ld	s2,32(sp)
    800039c4:	69e2                	ld	s3,24(sp)
    800039c6:	6a42                	ld	s4,16(sp)
    800039c8:	6aa2                	ld	s5,8(sp)
    800039ca:	6b02                	ld	s6,0(sp)
  printk("ialloc: no inodes\n");
    800039cc:	00005517          	auipc	a0,0x5
    800039d0:	ad450513          	addi	a0,a0,-1324 # 800084a0 <etext+0x4a0>
    800039d4:	b37fc0ef          	jal	8000050a <printk>
  return 0;
    800039d8:	4501                	li	a0,0
}
    800039da:	70e2                	ld	ra,56(sp)
    800039dc:	7442                	ld	s0,48(sp)
    800039de:	6121                	addi	sp,sp,64
    800039e0:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800039e2:	04000613          	li	a2,64
    800039e6:	4581                	li	a1,0
    800039e8:	854e                	mv	a0,s3
    800039ea:	abefd0ef          	jal	80000ca8 <memset>
      dip->type = type;
    800039ee:	01699023          	sh	s6,0(s3)
      log_write(bp); // mark it allocated on the disk
    800039f2:	8526                	mv	a0,s1
    800039f4:	4a7000ef          	jal	8000469a <log_write>
      brelse(bp);
    800039f8:	8526                	mv	a0,s1
    800039fa:	b41ff0ef          	jal	8000353a <brelse>
      return iget(dev, inum);
    800039fe:	0009059b          	sext.w	a1,s2
    80003a02:	8556                	mv	a0,s5
    80003a04:	e55ff0ef          	jal	80003858 <iget>
    80003a08:	74a2                	ld	s1,40(sp)
    80003a0a:	7902                	ld	s2,32(sp)
    80003a0c:	69e2                	ld	s3,24(sp)
    80003a0e:	6a42                	ld	s4,16(sp)
    80003a10:	6aa2                	ld	s5,8(sp)
    80003a12:	6b02                	ld	s6,0(sp)
    80003a14:	b7d9                	j	800039da <ialloc+0x80>

0000000080003a16 <iupdate>:
{
    80003a16:	1101                	addi	sp,sp,-32
    80003a18:	ec06                	sd	ra,24(sp)
    80003a1a:	e822                	sd	s0,16(sp)
    80003a1c:	e426                	sd	s1,8(sp)
    80003a1e:	e04a                	sd	s2,0(sp)
    80003a20:	1000                	addi	s0,sp,32
    80003a22:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003a24:	415c                	lw	a5,4(a0)
    80003a26:	0047d79b          	srliw	a5,a5,0x4
    80003a2a:	0001f597          	auipc	a1,0x1f
    80003a2e:	a4e5a583          	lw	a1,-1458(a1) # 80022478 <sb+0x18>
    80003a32:	9dbd                	addw	a1,a1,a5
    80003a34:	4108                	lw	a0,0(a0)
    80003a36:	9fdff0ef          	jal	80003432 <bread>
    80003a3a:	892a                	mv	s2,a0
  dip = (struct dinode *)bp->data + ip->inum % IPB;
    80003a3c:	05850793          	addi	a5,a0,88
    80003a40:	40d8                	lw	a4,4(s1)
    80003a42:	8b3d                	andi	a4,a4,15
    80003a44:	071a                	slli	a4,a4,0x6
    80003a46:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003a48:	04449703          	lh	a4,68(s1)
    80003a4c:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003a50:	04649703          	lh	a4,70(s1)
    80003a54:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003a58:	04849703          	lh	a4,72(s1)
    80003a5c:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003a60:	04a49703          	lh	a4,74(s1)
    80003a64:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003a68:	44f8                	lw	a4,76(s1)
    80003a6a:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    80003a6c:	03400613          	li	a2,52
    80003a70:	05048593          	addi	a1,s1,80
    80003a74:	00c78513          	addi	a0,a5,12
    80003a78:	a90fd0ef          	jal	80000d08 <memmove>
  log_write(bp);
    80003a7c:	854a                	mv	a0,s2
    80003a7e:	41d000ef          	jal	8000469a <log_write>
  brelse(bp);
    80003a82:	854a                	mv	a0,s2
    80003a84:	ab7ff0ef          	jal	8000353a <brelse>
}
    80003a88:	60e2                	ld	ra,24(sp)
    80003a8a:	6442                	ld	s0,16(sp)
    80003a8c:	64a2                	ld	s1,8(sp)
    80003a8e:	6902                	ld	s2,0(sp)
    80003a90:	6105                	addi	sp,sp,32
    80003a92:	8082                	ret

0000000080003a94 <idup>:
{
    80003a94:	1101                	addi	sp,sp,-32
    80003a96:	ec06                	sd	ra,24(sp)
    80003a98:	e822                	sd	s0,16(sp)
    80003a9a:	e426                	sd	s1,8(sp)
    80003a9c:	1000                	addi	s0,sp,32
    80003a9e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003aa0:	0001f517          	auipc	a0,0x1f
    80003aa4:	9e050513          	addi	a0,a0,-1568 # 80022480 <itable>
    80003aa8:	940fd0ef          	jal	80000be8 <acquire>
  ip->ref++;
    80003aac:	449c                	lw	a5,8(s1)
    80003aae:	2785                	addiw	a5,a5,1
    80003ab0:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003ab2:	0001f517          	auipc	a0,0x1f
    80003ab6:	9ce50513          	addi	a0,a0,-1586 # 80022480 <itable>
    80003aba:	9b6fd0ef          	jal	80000c70 <release>
}
    80003abe:	8526                	mv	a0,s1
    80003ac0:	60e2                	ld	ra,24(sp)
    80003ac2:	6442                	ld	s0,16(sp)
    80003ac4:	64a2                	ld	s1,8(sp)
    80003ac6:	6105                	addi	sp,sp,32
    80003ac8:	8082                	ret

0000000080003aca <ilock>:
{
    80003aca:	1101                	addi	sp,sp,-32
    80003acc:	ec06                	sd	ra,24(sp)
    80003ace:	e822                	sd	s0,16(sp)
    80003ad0:	e426                	sd	s1,8(sp)
    80003ad2:	1000                	addi	s0,sp,32
  if (ip == 0 || ip->ref < 1)
    80003ad4:	cd19                	beqz	a0,80003af2 <ilock+0x28>
    80003ad6:	84aa                	mv	s1,a0
    80003ad8:	451c                	lw	a5,8(a0)
    80003ada:	00f05c63          	blez	a5,80003af2 <ilock+0x28>
  acquiresleep(&ip->lock);
    80003ade:	0541                	addi	a0,a0,16
    80003ae0:	529000ef          	jal	80004808 <acquiresleep>
  if (ip->valid == 0) {
    80003ae4:	40bc                	lw	a5,64(s1)
    80003ae6:	cf89                	beqz	a5,80003b00 <ilock+0x36>
}
    80003ae8:	60e2                	ld	ra,24(sp)
    80003aea:	6442                	ld	s0,16(sp)
    80003aec:	64a2                	ld	s1,8(sp)
    80003aee:	6105                	addi	sp,sp,32
    80003af0:	8082                	ret
    80003af2:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003af4:	00005517          	auipc	a0,0x5
    80003af8:	9c450513          	addi	a0,a0,-1596 # 800084b8 <etext+0x4b8>
    80003afc:	d39fc0ef          	jal	80000834 <panic>
    80003b00:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003b02:	40dc                	lw	a5,4(s1)
    80003b04:	0047d79b          	srliw	a5,a5,0x4
    80003b08:	0001f597          	auipc	a1,0x1f
    80003b0c:	9705a583          	lw	a1,-1680(a1) # 80022478 <sb+0x18>
    80003b10:	9dbd                	addw	a1,a1,a5
    80003b12:	4088                	lw	a0,0(s1)
    80003b14:	91fff0ef          	jal	80003432 <bread>
    80003b18:	892a                	mv	s2,a0
    dip = (struct dinode *)bp->data + ip->inum % IPB;
    80003b1a:	05850593          	addi	a1,a0,88
    80003b1e:	40dc                	lw	a5,4(s1)
    80003b20:	8bbd                	andi	a5,a5,15
    80003b22:	079a                	slli	a5,a5,0x6
    80003b24:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003b26:	00059783          	lh	a5,0(a1)
    80003b2a:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003b2e:	00259783          	lh	a5,2(a1)
    80003b32:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003b36:	00459783          	lh	a5,4(a1)
    80003b3a:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003b3e:	00659783          	lh	a5,6(a1)
    80003b42:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003b46:	459c                	lw	a5,8(a1)
    80003b48:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003b4a:	03400613          	li	a2,52
    80003b4e:	05b1                	addi	a1,a1,12
    80003b50:	05048513          	addi	a0,s1,80
    80003b54:	9b4fd0ef          	jal	80000d08 <memmove>
    brelse(bp);
    80003b58:	854a                	mv	a0,s2
    80003b5a:	9e1ff0ef          	jal	8000353a <brelse>
    ip->valid = 1;
    80003b5e:	4785                	li	a5,1
    80003b60:	c0bc                	sw	a5,64(s1)
    if (ip->type == 0)
    80003b62:	04449783          	lh	a5,68(s1)
    80003b66:	c399                	beqz	a5,80003b6c <ilock+0xa2>
    80003b68:	6902                	ld	s2,0(sp)
    80003b6a:	bfbd                	j	80003ae8 <ilock+0x1e>
      panic("ilock: no type");
    80003b6c:	00005517          	auipc	a0,0x5
    80003b70:	95450513          	addi	a0,a0,-1708 # 800084c0 <etext+0x4c0>
    80003b74:	cc1fc0ef          	jal	80000834 <panic>

0000000080003b78 <iunlock>:
{
    80003b78:	1101                	addi	sp,sp,-32
    80003b7a:	ec06                	sd	ra,24(sp)
    80003b7c:	e822                	sd	s0,16(sp)
    80003b7e:	e426                	sd	s1,8(sp)
    80003b80:	e04a                	sd	s2,0(sp)
    80003b82:	1000                	addi	s0,sp,32
  if (ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003b84:	c505                	beqz	a0,80003bac <iunlock+0x34>
    80003b86:	84aa                	mv	s1,a0
    80003b88:	01050913          	addi	s2,a0,16
    80003b8c:	854a                	mv	a0,s2
    80003b8e:	507000ef          	jal	80004894 <holdingsleep>
    80003b92:	cd09                	beqz	a0,80003bac <iunlock+0x34>
    80003b94:	449c                	lw	a5,8(s1)
    80003b96:	00f05b63          	blez	a5,80003bac <iunlock+0x34>
  releasesleep(&ip->lock);
    80003b9a:	854a                	mv	a0,s2
    80003b9c:	4c1000ef          	jal	8000485c <releasesleep>
}
    80003ba0:	60e2                	ld	ra,24(sp)
    80003ba2:	6442                	ld	s0,16(sp)
    80003ba4:	64a2                	ld	s1,8(sp)
    80003ba6:	6902                	ld	s2,0(sp)
    80003ba8:	6105                	addi	sp,sp,32
    80003baa:	8082                	ret
    panic("iunlock");
    80003bac:	00005517          	auipc	a0,0x5
    80003bb0:	92450513          	addi	a0,a0,-1756 # 800084d0 <etext+0x4d0>
    80003bb4:	c81fc0ef          	jal	80000834 <panic>

0000000080003bb8 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    80003bb8:	7179                	addi	sp,sp,-48
    80003bba:	f406                	sd	ra,40(sp)
    80003bbc:	f022                	sd	s0,32(sp)
    80003bbe:	ec26                	sd	s1,24(sp)
    80003bc0:	e84a                	sd	s2,16(sp)
    80003bc2:	e44e                	sd	s3,8(sp)
    80003bc4:	1800                	addi	s0,sp,48
    80003bc6:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for (i = 0; i < NDIRECT; i++) {
    80003bc8:	05050493          	addi	s1,a0,80
    80003bcc:	08050913          	addi	s2,a0,128
    80003bd0:	a021                	j	80003bd8 <itrunc+0x20>
    80003bd2:	0491                	addi	s1,s1,4
    80003bd4:	01248b63          	beq	s1,s2,80003bea <itrunc+0x32>
    if (ip->addrs[i]) {
    80003bd8:	408c                	lw	a1,0(s1)
    80003bda:	dde5                	beqz	a1,80003bd2 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80003bdc:	0009a503          	lw	a0,0(s3)
    80003be0:	a47ff0ef          	jal	80003626 <bfree>
      ip->addrs[i] = 0;
    80003be4:	0004a023          	sw	zero,0(s1)
    80003be8:	b7ed                	j	80003bd2 <itrunc+0x1a>
    }
  }

  if (ip->addrs[NDIRECT]) {
    80003bea:	0809a583          	lw	a1,128(s3)
    80003bee:	ed89                	bnez	a1,80003c08 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003bf0:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003bf4:	854e                	mv	a0,s3
    80003bf6:	e21ff0ef          	jal	80003a16 <iupdate>
}
    80003bfa:	70a2                	ld	ra,40(sp)
    80003bfc:	7402                	ld	s0,32(sp)
    80003bfe:	64e2                	ld	s1,24(sp)
    80003c00:	6942                	ld	s2,16(sp)
    80003c02:	69a2                	ld	s3,8(sp)
    80003c04:	6145                	addi	sp,sp,48
    80003c06:	8082                	ret
    80003c08:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003c0a:	0009a503          	lw	a0,0(s3)
    80003c0e:	825ff0ef          	jal	80003432 <bread>
    80003c12:	8a2a                	mv	s4,a0
    for (j = 0; j < NINDIRECT; j++) {
    80003c14:	05850493          	addi	s1,a0,88
    80003c18:	45850913          	addi	s2,a0,1112
    80003c1c:	a021                	j	80003c24 <itrunc+0x6c>
    80003c1e:	0491                	addi	s1,s1,4
    80003c20:	01248963          	beq	s1,s2,80003c32 <itrunc+0x7a>
      if (a[j])
    80003c24:	408c                	lw	a1,0(s1)
    80003c26:	dde5                	beqz	a1,80003c1e <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003c28:	0009a503          	lw	a0,0(s3)
    80003c2c:	9fbff0ef          	jal	80003626 <bfree>
    80003c30:	b7fd                	j	80003c1e <itrunc+0x66>
    brelse(bp);
    80003c32:	8552                	mv	a0,s4
    80003c34:	907ff0ef          	jal	8000353a <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003c38:	0809a583          	lw	a1,128(s3)
    80003c3c:	0009a503          	lw	a0,0(s3)
    80003c40:	9e7ff0ef          	jal	80003626 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003c44:	0809a023          	sw	zero,128(s3)
    80003c48:	6a02                	ld	s4,0(sp)
    80003c4a:	b75d                	j	80003bf0 <itrunc+0x38>

0000000080003c4c <iput>:
{
    80003c4c:	1101                	addi	sp,sp,-32
    80003c4e:	ec06                	sd	ra,24(sp)
    80003c50:	e822                	sd	s0,16(sp)
    80003c52:	e426                	sd	s1,8(sp)
    80003c54:	1000                	addi	s0,sp,32
    80003c56:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003c58:	0001f517          	auipc	a0,0x1f
    80003c5c:	82850513          	addi	a0,a0,-2008 # 80022480 <itable>
    80003c60:	f89fc0ef          	jal	80000be8 <acquire>
  if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    80003c64:	4498                	lw	a4,8(s1)
    80003c66:	4785                	li	a5,1
    80003c68:	02f70063          	beq	a4,a5,80003c88 <iput+0x3c>
  ip->ref--;
    80003c6c:	449c                	lw	a5,8(s1)
    80003c6e:	37fd                	addiw	a5,a5,-1
    80003c70:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003c72:	0001f517          	auipc	a0,0x1f
    80003c76:	80e50513          	addi	a0,a0,-2034 # 80022480 <itable>
    80003c7a:	ff7fc0ef          	jal	80000c70 <release>
}
    80003c7e:	60e2                	ld	ra,24(sp)
    80003c80:	6442                	ld	s0,16(sp)
    80003c82:	64a2                	ld	s1,8(sp)
    80003c84:	6105                	addi	sp,sp,32
    80003c86:	8082                	ret
  if (ip->ref == 1 && ip->valid && ip->nlink == 0) {
    80003c88:	40bc                	lw	a5,64(s1)
    80003c8a:	d3ed                	beqz	a5,80003c6c <iput+0x20>
    80003c8c:	04a49783          	lh	a5,74(s1)
    80003c90:	fff1                	bnez	a5,80003c6c <iput+0x20>
    80003c92:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80003c94:	01048793          	addi	a5,s1,16
    80003c98:	893e                	mv	s2,a5
    80003c9a:	853e                	mv	a0,a5
    80003c9c:	36d000ef          	jal	80004808 <acquiresleep>
    release(&itable.lock);
    80003ca0:	0001e517          	auipc	a0,0x1e
    80003ca4:	7e050513          	addi	a0,a0,2016 # 80022480 <itable>
    80003ca8:	fc9fc0ef          	jal	80000c70 <release>
    itrunc(ip);
    80003cac:	8526                	mv	a0,s1
    80003cae:	f0bff0ef          	jal	80003bb8 <itrunc>
    ip->type = 0;
    80003cb2:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003cb6:	8526                	mv	a0,s1
    80003cb8:	d5fff0ef          	jal	80003a16 <iupdate>
    ip->valid = 0;
    80003cbc:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003cc0:	854a                	mv	a0,s2
    80003cc2:	39b000ef          	jal	8000485c <releasesleep>
    acquire(&itable.lock);
    80003cc6:	0001e517          	auipc	a0,0x1e
    80003cca:	7ba50513          	addi	a0,a0,1978 # 80022480 <itable>
    80003cce:	f1bfc0ef          	jal	80000be8 <acquire>
    80003cd2:	6902                	ld	s2,0(sp)
    80003cd4:	bf61                	j	80003c6c <iput+0x20>

0000000080003cd6 <iunlockput>:
{
    80003cd6:	1101                	addi	sp,sp,-32
    80003cd8:	ec06                	sd	ra,24(sp)
    80003cda:	e822                	sd	s0,16(sp)
    80003cdc:	e426                	sd	s1,8(sp)
    80003cde:	1000                	addi	s0,sp,32
    80003ce0:	84aa                	mv	s1,a0
  iunlock(ip);
    80003ce2:	e97ff0ef          	jal	80003b78 <iunlock>
  iput(ip);
    80003ce6:	8526                	mv	a0,s1
    80003ce8:	f65ff0ef          	jal	80003c4c <iput>
}
    80003cec:	60e2                	ld	ra,24(sp)
    80003cee:	6442                	ld	s0,16(sp)
    80003cf0:	64a2                	ld	s1,8(sp)
    80003cf2:	6105                	addi	sp,sp,32
    80003cf4:	8082                	ret

0000000080003cf6 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003cf6:	0001e717          	auipc	a4,0x1e
    80003cfa:	77672703          	lw	a4,1910(a4) # 8002246c <sb+0xc>
    80003cfe:	4785                	li	a5,1
    80003d00:	0ae7fe63          	bgeu	a5,a4,80003dbc <ireclaim+0xc6>
{
    80003d04:	7139                	addi	sp,sp,-64
    80003d06:	fc06                	sd	ra,56(sp)
    80003d08:	f822                	sd	s0,48(sp)
    80003d0a:	f426                	sd	s1,40(sp)
    80003d0c:	f04a                	sd	s2,32(sp)
    80003d0e:	ec4e                	sd	s3,24(sp)
    80003d10:	e852                	sd	s4,16(sp)
    80003d12:	e456                	sd	s5,8(sp)
    80003d14:	e05a                	sd	s6,0(sp)
    80003d16:	0080                	addi	s0,sp,64
    80003d18:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003d1a:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003d1c:	0001ea17          	auipc	s4,0x1e
    80003d20:	744a0a13          	addi	s4,s4,1860 # 80022460 <sb>
      printk("ireclaim: orphaned inode %d\n", inum);
    80003d24:	00004b17          	auipc	s6,0x4
    80003d28:	7b4b0b13          	addi	s6,s6,1972 # 800084d8 <etext+0x4d8>
    80003d2c:	a099                	j	80003d72 <ireclaim+0x7c>
    80003d2e:	85ce                	mv	a1,s3
    80003d30:	855a                	mv	a0,s6
    80003d32:	fd8fc0ef          	jal	8000050a <printk>
      ip = iget(dev, inum);
    80003d36:	85ce                	mv	a1,s3
    80003d38:	8556                	mv	a0,s5
    80003d3a:	b1fff0ef          	jal	80003858 <iget>
    80003d3e:	89aa                	mv	s3,a0
    brelse(bp);
    80003d40:	854a                	mv	a0,s2
    80003d42:	ff8ff0ef          	jal	8000353a <brelse>
    if (ip) {
    80003d46:	00098f63          	beqz	s3,80003d64 <ireclaim+0x6e>
      begin_op();
    80003d4a:	7a2000ef          	jal	800044ec <begin_op>
      ilock(ip);
    80003d4e:	854e                	mv	a0,s3
    80003d50:	d7bff0ef          	jal	80003aca <ilock>
      iunlock(ip);
    80003d54:	854e                	mv	a0,s3
    80003d56:	e23ff0ef          	jal	80003b78 <iunlock>
      iput(ip);
    80003d5a:	854e                	mv	a0,s3
    80003d5c:	ef1ff0ef          	jal	80003c4c <iput>
      end_op();
    80003d60:	019000ef          	jal	80004578 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003d64:	0485                	addi	s1,s1,1
    80003d66:	00ca2703          	lw	a4,12(s4)
    80003d6a:	0004879b          	sext.w	a5,s1
    80003d6e:	02e7fd63          	bgeu	a5,a4,80003da8 <ireclaim+0xb2>
    80003d72:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003d76:	0044d593          	srli	a1,s1,0x4
    80003d7a:	018a2783          	lw	a5,24(s4)
    80003d7e:	9dbd                	addw	a1,a1,a5
    80003d80:	8556                	mv	a0,s5
    80003d82:	eb0ff0ef          	jal	80003432 <bread>
    80003d86:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003d88:	05850793          	addi	a5,a0,88
    80003d8c:	00f9f713          	andi	a4,s3,15
    80003d90:	071a                	slli	a4,a4,0x6
    80003d92:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) { // is an orphaned inode
    80003d94:	00079703          	lh	a4,0(a5)
    80003d98:	c701                	beqz	a4,80003da0 <ireclaim+0xaa>
    80003d9a:	00679783          	lh	a5,6(a5)
    80003d9e:	dbc1                	beqz	a5,80003d2e <ireclaim+0x38>
    brelse(bp);
    80003da0:	854a                	mv	a0,s2
    80003da2:	f98ff0ef          	jal	8000353a <brelse>
    if (ip) {
    80003da6:	bf7d                	j	80003d64 <ireclaim+0x6e>
}
    80003da8:	70e2                	ld	ra,56(sp)
    80003daa:	7442                	ld	s0,48(sp)
    80003dac:	74a2                	ld	s1,40(sp)
    80003dae:	7902                	ld	s2,32(sp)
    80003db0:	69e2                	ld	s3,24(sp)
    80003db2:	6a42                	ld	s4,16(sp)
    80003db4:	6aa2                	ld	s5,8(sp)
    80003db6:	6b02                	ld	s6,0(sp)
    80003db8:	6121                	addi	sp,sp,64
    80003dba:	8082                	ret
    80003dbc:	8082                	ret

0000000080003dbe <fsinit>:
{
    80003dbe:	1101                	addi	sp,sp,-32
    80003dc0:	ec06                	sd	ra,24(sp)
    80003dc2:	e822                	sd	s0,16(sp)
    80003dc4:	e426                	sd	s1,8(sp)
    80003dc6:	e04a                	sd	s2,0(sp)
    80003dc8:	1000                	addi	s0,sp,32
    80003dca:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003dcc:	4585                	li	a1,1
    80003dce:	e64ff0ef          	jal	80003432 <bread>
    80003dd2:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003dd4:	02000613          	li	a2,32
    80003dd8:	05850593          	addi	a1,a0,88
    80003ddc:	0001e517          	auipc	a0,0x1e
    80003de0:	68450513          	addi	a0,a0,1668 # 80022460 <sb>
    80003de4:	f25fc0ef          	jal	80000d08 <memmove>
  brelse(bp);
    80003de8:	8526                	mv	a0,s1
    80003dea:	f50ff0ef          	jal	8000353a <brelse>
  if (sb.magic != FSMAGIC)
    80003dee:	0001e717          	auipc	a4,0x1e
    80003df2:	67272703          	lw	a4,1650(a4) # 80022460 <sb>
    80003df6:	102037b7          	lui	a5,0x10203
    80003dfa:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003dfe:	02f71263          	bne	a4,a5,80003e22 <fsinit+0x64>
  initlog(dev, &sb);
    80003e02:	0001e597          	auipc	a1,0x1e
    80003e06:	65e58593          	addi	a1,a1,1630 # 80022460 <sb>
    80003e0a:	854a                	mv	a0,s2
    80003e0c:	65e000ef          	jal	8000446a <initlog>
  ireclaim(dev);
    80003e10:	854a                	mv	a0,s2
    80003e12:	ee5ff0ef          	jal	80003cf6 <ireclaim>
}
    80003e16:	60e2                	ld	ra,24(sp)
    80003e18:	6442                	ld	s0,16(sp)
    80003e1a:	64a2                	ld	s1,8(sp)
    80003e1c:	6902                	ld	s2,0(sp)
    80003e1e:	6105                	addi	sp,sp,32
    80003e20:	8082                	ret
    panic("invalid file system");
    80003e22:	00004517          	auipc	a0,0x4
    80003e26:	6d650513          	addi	a0,a0,1750 # 800084f8 <etext+0x4f8>
    80003e2a:	a0bfc0ef          	jal	80000834 <panic>

0000000080003e2e <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003e2e:	1141                	addi	sp,sp,-16
    80003e30:	e406                	sd	ra,8(sp)
    80003e32:	e022                	sd	s0,0(sp)
    80003e34:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003e36:	411c                	lw	a5,0(a0)
    80003e38:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003e3a:	415c                	lw	a5,4(a0)
    80003e3c:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003e3e:	04451783          	lh	a5,68(a0)
    80003e42:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003e46:	04a51783          	lh	a5,74(a0)
    80003e4a:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003e4e:	04c56783          	lwu	a5,76(a0)
    80003e52:	e99c                	sd	a5,16(a1)
}
    80003e54:	60a2                	ld	ra,8(sp)
    80003e56:	6402                	ld	s0,0(sp)
    80003e58:	0141                	addi	sp,sp,16
    80003e5a:	8082                	ret

0000000080003e5c <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003e5c:	457c                	lw	a5,76(a0)
    80003e5e:	0ed7e663          	bltu	a5,a3,80003f4a <readi+0xee>
{
    80003e62:	7159                	addi	sp,sp,-112
    80003e64:	f486                	sd	ra,104(sp)
    80003e66:	f0a2                	sd	s0,96(sp)
    80003e68:	eca6                	sd	s1,88(sp)
    80003e6a:	e0d2                	sd	s4,64(sp)
    80003e6c:	fc56                	sd	s5,56(sp)
    80003e6e:	f85a                	sd	s6,48(sp)
    80003e70:	f45e                	sd	s7,40(sp)
    80003e72:	1880                	addi	s0,sp,112
    80003e74:	8b2a                	mv	s6,a0
    80003e76:	8bae                	mv	s7,a1
    80003e78:	8a32                	mv	s4,a2
    80003e7a:	84b6                	mv	s1,a3
    80003e7c:	8aba                	mv	s5,a4
  if (off > ip->size || off + n < off)
    80003e7e:	9f35                	addw	a4,a4,a3
    return 0;
    80003e80:	4501                	li	a0,0
  if (off > ip->size || off + n < off)
    80003e82:	0ad76b63          	bltu	a4,a3,80003f38 <readi+0xdc>
    80003e86:	e4ce                	sd	s3,72(sp)
  if (off + n > ip->size)
    80003e88:	00e7f463          	bgeu	a5,a4,80003e90 <readi+0x34>
    n = ip->size - off;
    80003e8c:	40d78abb          	subw	s5,a5,a3

  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003e90:	080a8b63          	beqz	s5,80003f26 <readi+0xca>
    80003e94:	e8ca                	sd	s2,80(sp)
    80003e96:	f062                	sd	s8,32(sp)
    80003e98:	ec66                	sd	s9,24(sp)
    80003e9a:	e86a                	sd	s10,16(sp)
    80003e9c:	e46e                	sd	s11,8(sp)
    80003e9e:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003ea0:	40000c93          	li	s9,1024
    if (either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003ea4:	5c7d                	li	s8,-1
    80003ea6:	a80d                	j	80003ed8 <readi+0x7c>
    80003ea8:	020d1d93          	slli	s11,s10,0x20
    80003eac:	020ddd93          	srli	s11,s11,0x20
    80003eb0:	05890613          	addi	a2,s2,88
    80003eb4:	86ee                	mv	a3,s11
    80003eb6:	963e                	add	a2,a2,a5
    80003eb8:	85d2                	mv	a1,s4
    80003eba:	855e                	mv	a0,s7
    80003ebc:	84dfe0ef          	jal	80002708 <either_copyout>
    80003ec0:	05850363          	beq	a0,s8,80003f06 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003ec4:	854a                	mv	a0,s2
    80003ec6:	e74ff0ef          	jal	8000353a <brelse>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003eca:	013d09bb          	addw	s3,s10,s3
    80003ece:	009d04bb          	addw	s1,s10,s1
    80003ed2:	9a6e                	add	s4,s4,s11
    80003ed4:	0559f363          	bgeu	s3,s5,80003f1a <readi+0xbe>
    uint addr = bmap(ip, off / BSIZE);
    80003ed8:	00a4d59b          	srliw	a1,s1,0xa
    80003edc:	855a                	mv	a0,s6
    80003ede:	8bbff0ef          	jal	80003798 <bmap>
    80003ee2:	85aa                	mv	a1,a0
    if (addr == 0)
    80003ee4:	c139                	beqz	a0,80003f2a <readi+0xce>
    bp = bread(ip->dev, addr);
    80003ee6:	000b2503          	lw	a0,0(s6)
    80003eea:	d48ff0ef          	jal	80003432 <bread>
    80003eee:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    80003ef0:	3ff4f793          	andi	a5,s1,1023
    80003ef4:	40fc873b          	subw	a4,s9,a5
    80003ef8:	413a86bb          	subw	a3,s5,s3
    80003efc:	8d3a                	mv	s10,a4
    80003efe:	fae6f5e3          	bgeu	a3,a4,80003ea8 <readi+0x4c>
    80003f02:	8d36                	mv	s10,a3
    80003f04:	b755                	j	80003ea8 <readi+0x4c>
      brelse(bp);
    80003f06:	854a                	mv	a0,s2
    80003f08:	e32ff0ef          	jal	8000353a <brelse>
      tot = -1;
    80003f0c:	59fd                	li	s3,-1
      break;
    80003f0e:	6946                	ld	s2,80(sp)
    80003f10:	7c02                	ld	s8,32(sp)
    80003f12:	6ce2                	ld	s9,24(sp)
    80003f14:	6d42                	ld	s10,16(sp)
    80003f16:	6da2                	ld	s11,8(sp)
    80003f18:	a831                	j	80003f34 <readi+0xd8>
    80003f1a:	6946                	ld	s2,80(sp)
    80003f1c:	7c02                	ld	s8,32(sp)
    80003f1e:	6ce2                	ld	s9,24(sp)
    80003f20:	6d42                	ld	s10,16(sp)
    80003f22:	6da2                	ld	s11,8(sp)
    80003f24:	a801                	j	80003f34 <readi+0xd8>
  for (tot = 0; tot < n; tot += m, off += m, dst += m) {
    80003f26:	89d6                	mv	s3,s5
    80003f28:	a031                	j	80003f34 <readi+0xd8>
    80003f2a:	6946                	ld	s2,80(sp)
    80003f2c:	7c02                	ld	s8,32(sp)
    80003f2e:	6ce2                	ld	s9,24(sp)
    80003f30:	6d42                	ld	s10,16(sp)
    80003f32:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003f34:	854e                	mv	a0,s3
    80003f36:	69a6                	ld	s3,72(sp)
}
    80003f38:	70a6                	ld	ra,104(sp)
    80003f3a:	7406                	ld	s0,96(sp)
    80003f3c:	64e6                	ld	s1,88(sp)
    80003f3e:	6a06                	ld	s4,64(sp)
    80003f40:	7ae2                	ld	s5,56(sp)
    80003f42:	7b42                	ld	s6,48(sp)
    80003f44:	7ba2                	ld	s7,40(sp)
    80003f46:	6165                	addi	sp,sp,112
    80003f48:	8082                	ret
    return 0;
    80003f4a:	4501                	li	a0,0
}
    80003f4c:	8082                	ret

0000000080003f4e <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if (off > ip->size || off + n < off)
    80003f4e:	457c                	lw	a5,76(a0)
    80003f50:	0ed7ee63          	bltu	a5,a3,8000404c <writei+0xfe>
{
    80003f54:	7159                	addi	sp,sp,-112
    80003f56:	f486                	sd	ra,104(sp)
    80003f58:	f0a2                	sd	s0,96(sp)
    80003f5a:	e8ca                	sd	s2,80(sp)
    80003f5c:	e0d2                	sd	s4,64(sp)
    80003f5e:	fc56                	sd	s5,56(sp)
    80003f60:	f85a                	sd	s6,48(sp)
    80003f62:	f45e                	sd	s7,40(sp)
    80003f64:	1880                	addi	s0,sp,112
    80003f66:	8aaa                	mv	s5,a0
    80003f68:	8bae                	mv	s7,a1
    80003f6a:	8a32                	mv	s4,a2
    80003f6c:	8936                	mv	s2,a3
    80003f6e:	8b3a                	mv	s6,a4
  if (off > ip->size || off + n < off)
    80003f70:	00e687bb          	addw	a5,a3,a4
    return -1;
  if (off + n > MAXFILE * BSIZE)
    80003f74:	00043737          	lui	a4,0x43
    80003f78:	0cf76c63          	bltu	a4,a5,80004050 <writei+0x102>
    80003f7c:	0cd7ea63          	bltu	a5,a3,80004050 <writei+0x102>
    80003f80:	e4ce                	sd	s3,72(sp)
    return -1;

  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003f82:	0a0b0d63          	beqz	s6,8000403c <writei+0xee>
    80003f86:	eca6                	sd	s1,88(sp)
    80003f88:	f062                	sd	s8,32(sp)
    80003f8a:	ec66                	sd	s9,24(sp)
    80003f8c:	e86a                	sd	s10,16(sp)
    80003f8e:	e46e                	sd	s11,8(sp)
    80003f90:	4981                	li	s3,0
    uint addr = bmap(ip, off / BSIZE);
    if (addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off % BSIZE);
    80003f92:	40000c93          	li	s9,1024
    if (either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003f96:	5c7d                	li	s8,-1
    80003f98:	a825                	j	80003fd0 <writei+0x82>
    80003f9a:	020d1d93          	slli	s11,s10,0x20
    80003f9e:	020ddd93          	srli	s11,s11,0x20
    80003fa2:	05848513          	addi	a0,s1,88
    80003fa6:	86ee                	mv	a3,s11
    80003fa8:	8652                	mv	a2,s4
    80003faa:	85de                	mv	a1,s7
    80003fac:	953e                	add	a0,a0,a5
    80003fae:	fa6fe0ef          	jal	80002754 <either_copyin>
    80003fb2:	05850663          	beq	a0,s8,80003ffe <writei+0xb0>
      // Might have partially updated the block, so we need to log it.
      log_write(bp);
      brelse(bp);
      break;
    }
    log_write(bp);
    80003fb6:	8526                	mv	a0,s1
    80003fb8:	6e2000ef          	jal	8000469a <log_write>
    brelse(bp);
    80003fbc:	8526                	mv	a0,s1
    80003fbe:	d7cff0ef          	jal	8000353a <brelse>
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    80003fc2:	013d09bb          	addw	s3,s10,s3
    80003fc6:	012d093b          	addw	s2,s10,s2
    80003fca:	9a6e                	add	s4,s4,s11
    80003fcc:	0369ff63          	bgeu	s3,s6,8000400a <writei+0xbc>
    uint addr = bmap(ip, off / BSIZE);
    80003fd0:	00a9559b          	srliw	a1,s2,0xa
    80003fd4:	8556                	mv	a0,s5
    80003fd6:	fc2ff0ef          	jal	80003798 <bmap>
    80003fda:	85aa                	mv	a1,a0
    if (addr == 0)
    80003fdc:	c51d                	beqz	a0,8000400a <writei+0xbc>
    bp = bread(ip->dev, addr);
    80003fde:	000aa503          	lw	a0,0(s5)
    80003fe2:	c50ff0ef          	jal	80003432 <bread>
    80003fe6:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off % BSIZE);
    80003fe8:	3ff97793          	andi	a5,s2,1023
    80003fec:	40fc873b          	subw	a4,s9,a5
    80003ff0:	413b06bb          	subw	a3,s6,s3
    80003ff4:	8d3a                	mv	s10,a4
    80003ff6:	fae6f2e3          	bgeu	a3,a4,80003f9a <writei+0x4c>
    80003ffa:	8d36                	mv	s10,a3
    80003ffc:	bf79                	j	80003f9a <writei+0x4c>
      log_write(bp);
    80003ffe:	8526                	mv	a0,s1
    80004000:	69a000ef          	jal	8000469a <log_write>
      brelse(bp);
    80004004:	8526                	mv	a0,s1
    80004006:	d34ff0ef          	jal	8000353a <brelse>
  }

  if (off > ip->size)
    8000400a:	04caa783          	lw	a5,76(s5)
    8000400e:	0327f963          	bgeu	a5,s2,80004040 <writei+0xf2>
    ip->size = off;
    80004012:	052aa623          	sw	s2,76(s5)
    80004016:	64e6                	ld	s1,88(sp)
    80004018:	7c02                	ld	s8,32(sp)
    8000401a:	6ce2                	ld	s9,24(sp)
    8000401c:	6d42                	ld	s10,16(sp)
    8000401e:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80004020:	8556                	mv	a0,s5
    80004022:	9f5ff0ef          	jal	80003a16 <iupdate>

  return tot;
    80004026:	854e                	mv	a0,s3
    80004028:	69a6                	ld	s3,72(sp)
}
    8000402a:	70a6                	ld	ra,104(sp)
    8000402c:	7406                	ld	s0,96(sp)
    8000402e:	6946                	ld	s2,80(sp)
    80004030:	6a06                	ld	s4,64(sp)
    80004032:	7ae2                	ld	s5,56(sp)
    80004034:	7b42                	ld	s6,48(sp)
    80004036:	7ba2                	ld	s7,40(sp)
    80004038:	6165                	addi	sp,sp,112
    8000403a:	8082                	ret
  for (tot = 0; tot < n; tot += m, off += m, src += m) {
    8000403c:	89da                	mv	s3,s6
    8000403e:	b7cd                	j	80004020 <writei+0xd2>
    80004040:	64e6                	ld	s1,88(sp)
    80004042:	7c02                	ld	s8,32(sp)
    80004044:	6ce2                	ld	s9,24(sp)
    80004046:	6d42                	ld	s10,16(sp)
    80004048:	6da2                	ld	s11,8(sp)
    8000404a:	bfd9                	j	80004020 <writei+0xd2>
    return -1;
    8000404c:	557d                	li	a0,-1
}
    8000404e:	8082                	ret
    return -1;
    80004050:	557d                	li	a0,-1
    80004052:	bfe1                	j	8000402a <writei+0xdc>

0000000080004054 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80004054:	1141                	addi	sp,sp,-16
    80004056:	e406                	sd	ra,8(sp)
    80004058:	e022                	sd	s0,0(sp)
    8000405a:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    8000405c:	4639                	li	a2,14
    8000405e:	d1ffc0ef          	jal	80000d7c <strncmp>
}
    80004062:	60a2                	ld	ra,8(sp)
    80004064:	6402                	ld	s0,0(sp)
    80004066:	0141                	addi	sp,sp,16
    80004068:	8082                	ret

000000008000406a <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode *
dirlookup(struct inode *dp, char *name, uint *poff)
{
    8000406a:	711d                	addi	sp,sp,-96
    8000406c:	ec86                	sd	ra,88(sp)
    8000406e:	e8a2                	sd	s0,80(sp)
    80004070:	e4a6                	sd	s1,72(sp)
    80004072:	e0ca                	sd	s2,64(sp)
    80004074:	fc4e                	sd	s3,56(sp)
    80004076:	f852                	sd	s4,48(sp)
    80004078:	f456                	sd	s5,40(sp)
    8000407a:	f05a                	sd	s6,32(sp)
    8000407c:	ec5e                	sd	s7,24(sp)
    8000407e:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if (dp->type != T_DIR)
    80004080:	04451703          	lh	a4,68(a0)
    80004084:	4785                	li	a5,1
    80004086:	00f71f63          	bne	a4,a5,800040a4 <dirlookup+0x3a>
    8000408a:	892a                	mv	s2,a0
    8000408c:	8aae                	mv	s5,a1
    8000408e:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for (off = 0; off < dp->size; off += sizeof(de)) {
    80004090:	457c                	lw	a5,76(a0)
    80004092:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004094:	fa040a13          	addi	s4,s0,-96
    80004098:	49c1                	li	s3,16
      panic("dirlookup read");
    if (de.inum == 0)
      continue;
    if (namecmp(name, de.name) == 0) {
    8000409a:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    8000409e:	4501                	li	a0,0
  for (off = 0; off < dp->size; off += sizeof(de)) {
    800040a0:	e39d                	bnez	a5,800040c6 <dirlookup+0x5c>
    800040a2:	a8b9                	j	80004100 <dirlookup+0x96>
    panic("dirlookup not DIR");
    800040a4:	00004517          	auipc	a0,0x4
    800040a8:	46c50513          	addi	a0,a0,1132 # 80008510 <etext+0x510>
    800040ac:	f88fc0ef          	jal	80000834 <panic>
      panic("dirlookup read");
    800040b0:	00004517          	auipc	a0,0x4
    800040b4:	47850513          	addi	a0,a0,1144 # 80008528 <etext+0x528>
    800040b8:	f7cfc0ef          	jal	80000834 <panic>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    800040bc:	24c1                	addiw	s1,s1,16
    800040be:	04c92783          	lw	a5,76(s2)
    800040c2:	02f4fe63          	bgeu	s1,a5,800040fe <dirlookup+0x94>
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800040c6:	874e                	mv	a4,s3
    800040c8:	86a6                	mv	a3,s1
    800040ca:	8652                	mv	a2,s4
    800040cc:	4581                	li	a1,0
    800040ce:	854a                	mv	a0,s2
    800040d0:	d8dff0ef          	jal	80003e5c <readi>
    800040d4:	fd351ee3          	bne	a0,s3,800040b0 <dirlookup+0x46>
    if (de.inum == 0)
    800040d8:	fa045783          	lhu	a5,-96(s0)
    800040dc:	d3e5                	beqz	a5,800040bc <dirlookup+0x52>
    if (namecmp(name, de.name) == 0) {
    800040de:	85da                	mv	a1,s6
    800040e0:	8556                	mv	a0,s5
    800040e2:	f73ff0ef          	jal	80004054 <namecmp>
    800040e6:	f979                	bnez	a0,800040bc <dirlookup+0x52>
      if (poff)
    800040e8:	000b8463          	beqz	s7,800040f0 <dirlookup+0x86>
        *poff = off;
    800040ec:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    800040f0:	fa045583          	lhu	a1,-96(s0)
    800040f4:	00092503          	lw	a0,0(s2)
    800040f8:	f60ff0ef          	jal	80003858 <iget>
    800040fc:	a011                	j	80004100 <dirlookup+0x96>
  return 0;
    800040fe:	4501                	li	a0,0
}
    80004100:	60e6                	ld	ra,88(sp)
    80004102:	6446                	ld	s0,80(sp)
    80004104:	64a6                	ld	s1,72(sp)
    80004106:	6906                	ld	s2,64(sp)
    80004108:	79e2                	ld	s3,56(sp)
    8000410a:	7a42                	ld	s4,48(sp)
    8000410c:	7aa2                	ld	s5,40(sp)
    8000410e:	7b02                	ld	s6,32(sp)
    80004110:	6be2                	ld	s7,24(sp)
    80004112:	6125                	addi	sp,sp,96
    80004114:	8082                	ret

0000000080004116 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode *
namex(char *path, int nameiparent, char *name)
{
    80004116:	711d                	addi	sp,sp,-96
    80004118:	ec86                	sd	ra,88(sp)
    8000411a:	e8a2                	sd	s0,80(sp)
    8000411c:	e4a6                	sd	s1,72(sp)
    8000411e:	e0ca                	sd	s2,64(sp)
    80004120:	fc4e                	sd	s3,56(sp)
    80004122:	f852                	sd	s4,48(sp)
    80004124:	f456                	sd	s5,40(sp)
    80004126:	f05a                	sd	s6,32(sp)
    80004128:	ec5e                	sd	s7,24(sp)
    8000412a:	e862                	sd	s8,16(sp)
    8000412c:	e466                	sd	s9,8(sp)
    8000412e:	e06a                	sd	s10,0(sp)
    80004130:	1080                	addi	s0,sp,96
    80004132:	84aa                	mv	s1,a0
    80004134:	8b2e                	mv	s6,a1
    80004136:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if (*path == '/')
    80004138:	00054703          	lbu	a4,0(a0)
    8000413c:	02f00793          	li	a5,47
    80004140:	00f70f63          	beq	a4,a5,8000415e <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80004144:	fb0fd0ef          	jal	800018f4 <myproc>
    80004148:	16853503          	ld	a0,360(a0)
    8000414c:	949ff0ef          	jal	80003a94 <idup>
    80004150:	8a2a                	mv	s4,a0
  while (*path == '/')
    80004152:	02f00993          	li	s3,47
  if (len >= DIRSIZ)
    80004156:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80004158:	4cb9                	li	s9,14

  while ((path = skipelem(path, name)) != 0) {
    ilock(ip);
    if (ip->type != T_DIR) {
    8000415a:	4b85                	li	s7,1
    8000415c:	a07d                	j	8000420a <namex+0xf4>
    ip = iget(ROOTDEV, ROOTINO);
    8000415e:	4585                	li	a1,1
    80004160:	852e                	mv	a0,a1
    80004162:	ef6ff0ef          	jal	80003858 <iget>
    80004166:	8a2a                	mv	s4,a0
    80004168:	b7ed                	j	80004152 <namex+0x3c>
      iunlockput(ip);
    8000416a:	8552                	mv	a0,s4
    8000416c:	b6bff0ef          	jal	80003cd6 <iunlockput>
      return 0;
    80004170:	4a01                	li	s4,0
  if (nameiparent) {
    iput(ip);
    return 0;
  }
  return ip;
}
    80004172:	8552                	mv	a0,s4
    80004174:	60e6                	ld	ra,88(sp)
    80004176:	6446                	ld	s0,80(sp)
    80004178:	64a6                	ld	s1,72(sp)
    8000417a:	6906                	ld	s2,64(sp)
    8000417c:	79e2                	ld	s3,56(sp)
    8000417e:	7a42                	ld	s4,48(sp)
    80004180:	7aa2                	ld	s5,40(sp)
    80004182:	7b02                	ld	s6,32(sp)
    80004184:	6be2                	ld	s7,24(sp)
    80004186:	6c42                	ld	s8,16(sp)
    80004188:	6ca2                	ld	s9,8(sp)
    8000418a:	6d02                	ld	s10,0(sp)
    8000418c:	6125                	addi	sp,sp,96
    8000418e:	8082                	ret
      iunlockput(ip);
    80004190:	8552                	mv	a0,s4
    80004192:	b45ff0ef          	jal	80003cd6 <iunlockput>
      return 0;
    80004196:	4a01                	li	s4,0
    80004198:	bfe9                	j	80004172 <namex+0x5c>
      iunlock(ip);
    8000419a:	8552                	mv	a0,s4
    8000419c:	9ddff0ef          	jal	80003b78 <iunlock>
      return ip;
    800041a0:	bfc9                	j	80004172 <namex+0x5c>
      iunlockput(ip);
    800041a2:	8552                	mv	a0,s4
    800041a4:	b33ff0ef          	jal	80003cd6 <iunlockput>
      return 0;
    800041a8:	8a4a                	mv	s4,s2
    800041aa:	b7e1                	j	80004172 <namex+0x5c>
  len = path - s;
    800041ac:	40990633          	sub	a2,s2,s1
    800041b0:	00060d1b          	sext.w	s10,a2
  if (len >= DIRSIZ)
    800041b4:	09ac5763          	bge	s8,s10,80004242 <namex+0x12c>
    memmove(name, s, DIRSIZ);
    800041b8:	8666                	mv	a2,s9
    800041ba:	85a6                	mv	a1,s1
    800041bc:	8556                	mv	a0,s5
    800041be:	b4bfc0ef          	jal	80000d08 <memmove>
    800041c2:	84ca                	mv	s1,s2
  while (*path == '/')
    800041c4:	0004c783          	lbu	a5,0(s1)
    800041c8:	01379763          	bne	a5,s3,800041d6 <namex+0xc0>
    path++;
    800041cc:	0485                	addi	s1,s1,1
  while (*path == '/')
    800041ce:	0004c783          	lbu	a5,0(s1)
    800041d2:	ff378de3          	beq	a5,s3,800041cc <namex+0xb6>
    ilock(ip);
    800041d6:	8552                	mv	a0,s4
    800041d8:	8f3ff0ef          	jal	80003aca <ilock>
    if (ip->type != T_DIR) {
    800041dc:	044a1783          	lh	a5,68(s4)
    800041e0:	f97795e3          	bne	a5,s7,8000416a <namex+0x54>
    if (ip->nlink == 0) {
    800041e4:	04aa1783          	lh	a5,74(s4)
    800041e8:	d7c5                	beqz	a5,80004190 <namex+0x7a>
    if (nameiparent && *path == '\0') {
    800041ea:	000b0563          	beqz	s6,800041f4 <namex+0xde>
    800041ee:	0004c783          	lbu	a5,0(s1)
    800041f2:	d7c5                	beqz	a5,8000419a <namex+0x84>
    if ((next = dirlookup(ip, name, 0)) == 0) {
    800041f4:	4601                	li	a2,0
    800041f6:	85d6                	mv	a1,s5
    800041f8:	8552                	mv	a0,s4
    800041fa:	e71ff0ef          	jal	8000406a <dirlookup>
    800041fe:	892a                	mv	s2,a0
    80004200:	d14d                	beqz	a0,800041a2 <namex+0x8c>
    iunlockput(ip);
    80004202:	8552                	mv	a0,s4
    80004204:	ad3ff0ef          	jal	80003cd6 <iunlockput>
    ip = next;
    80004208:	8a4a                	mv	s4,s2
  while (*path == '/')
    8000420a:	0004c783          	lbu	a5,0(s1)
    8000420e:	01379763          	bne	a5,s3,8000421c <namex+0x106>
    path++;
    80004212:	0485                	addi	s1,s1,1
  while (*path == '/')
    80004214:	0004c783          	lbu	a5,0(s1)
    80004218:	ff378de3          	beq	a5,s3,80004212 <namex+0xfc>
  if (*path == 0)
    8000421c:	cf8d                	beqz	a5,80004256 <namex+0x140>
  while (*path != '/' && *path != 0)
    8000421e:	0004c783          	lbu	a5,0(s1)
    80004222:	fd178713          	addi	a4,a5,-47
    80004226:	cb19                	beqz	a4,8000423c <namex+0x126>
    80004228:	cb91                	beqz	a5,8000423c <namex+0x126>
    8000422a:	8926                	mv	s2,s1
    path++;
    8000422c:	0905                	addi	s2,s2,1
  while (*path != '/' && *path != 0)
    8000422e:	00094783          	lbu	a5,0(s2)
    80004232:	fd178713          	addi	a4,a5,-47
    80004236:	db3d                	beqz	a4,800041ac <namex+0x96>
    80004238:	fbf5                	bnez	a5,8000422c <namex+0x116>
    8000423a:	bf8d                	j	800041ac <namex+0x96>
    8000423c:	8926                	mv	s2,s1
  len = path - s;
    8000423e:	4d01                	li	s10,0
    80004240:	4601                	li	a2,0
    memmove(name, s, len);
    80004242:	2601                	sext.w	a2,a2
    80004244:	85a6                	mv	a1,s1
    80004246:	8556                	mv	a0,s5
    80004248:	ac1fc0ef          	jal	80000d08 <memmove>
    name[len] = 0;
    8000424c:	9d56                	add	s10,s10,s5
    8000424e:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffd9e98>
    80004252:	84ca                	mv	s1,s2
    80004254:	bf85                	j	800041c4 <namex+0xae>
  if (nameiparent) {
    80004256:	f00b0ee3          	beqz	s6,80004172 <namex+0x5c>
    iput(ip);
    8000425a:	8552                	mv	a0,s4
    8000425c:	9f1ff0ef          	jal	80003c4c <iput>
    return 0;
    80004260:	4a01                	li	s4,0
    80004262:	bf01                	j	80004172 <namex+0x5c>

0000000080004264 <dirlink>:
{
    80004264:	715d                	addi	sp,sp,-80
    80004266:	e486                	sd	ra,72(sp)
    80004268:	e0a2                	sd	s0,64(sp)
    8000426a:	f84a                	sd	s2,48(sp)
    8000426c:	ec56                	sd	s5,24(sp)
    8000426e:	e85a                	sd	s6,16(sp)
    80004270:	0880                	addi	s0,sp,80
    80004272:	892a                	mv	s2,a0
    80004274:	8aae                	mv	s5,a1
    80004276:	8b32                	mv	s6,a2
  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80004278:	4601                	li	a2,0
    8000427a:	df1ff0ef          	jal	8000406a <dirlookup>
    8000427e:	ed1d                	bnez	a0,800042bc <dirlink+0x58>
    80004280:	fc26                	sd	s1,56(sp)
  for (off = 0; off < dp->size; off += sizeof(de)) {
    80004282:	04c92483          	lw	s1,76(s2)
    80004286:	c4b9                	beqz	s1,800042d4 <dirlink+0x70>
    80004288:	f44e                	sd	s3,40(sp)
    8000428a:	f052                	sd	s4,32(sp)
    8000428c:	4481                	li	s1,0
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000428e:	fb040a13          	addi	s4,s0,-80
    80004292:	49c1                	li	s3,16
    80004294:	874e                	mv	a4,s3
    80004296:	86a6                	mv	a3,s1
    80004298:	8652                	mv	a2,s4
    8000429a:	4581                	li	a1,0
    8000429c:	854a                	mv	a0,s2
    8000429e:	bbfff0ef          	jal	80003e5c <readi>
    800042a2:	03351163          	bne	a0,s3,800042c4 <dirlink+0x60>
    if (de.inum == 0)
    800042a6:	fb045783          	lhu	a5,-80(s0)
    800042aa:	c39d                	beqz	a5,800042d0 <dirlink+0x6c>
  for (off = 0; off < dp->size; off += sizeof(de)) {
    800042ac:	24c1                	addiw	s1,s1,16
    800042ae:	04c92783          	lw	a5,76(s2)
    800042b2:	fef4e1e3          	bltu	s1,a5,80004294 <dirlink+0x30>
    800042b6:	79a2                	ld	s3,40(sp)
    800042b8:	7a02                	ld	s4,32(sp)
    800042ba:	a829                	j	800042d4 <dirlink+0x70>
    iput(ip);
    800042bc:	991ff0ef          	jal	80003c4c <iput>
    return -1;
    800042c0:	557d                	li	a0,-1
    800042c2:	a83d                	j	80004300 <dirlink+0x9c>
      panic("dirlink read");
    800042c4:	00004517          	auipc	a0,0x4
    800042c8:	27450513          	addi	a0,a0,628 # 80008538 <etext+0x538>
    800042cc:	d68fc0ef          	jal	80000834 <panic>
    800042d0:	79a2                	ld	s3,40(sp)
    800042d2:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    800042d4:	4639                	li	a2,14
    800042d6:	85d6                	mv	a1,s5
    800042d8:	fb240513          	addi	a0,s0,-78
    800042dc:	adbfc0ef          	jal	80000db6 <strncpy>
  de.inum = inum;
    800042e0:	fb641823          	sh	s6,-80(s0)
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800042e4:	4741                	li	a4,16
    800042e6:	86a6                	mv	a3,s1
    800042e8:	fb040613          	addi	a2,s0,-80
    800042ec:	4581                	li	a1,0
    800042ee:	854a                	mv	a0,s2
    800042f0:	c5fff0ef          	jal	80003f4e <writei>
    800042f4:	1541                	addi	a0,a0,-16
    800042f6:	00a03533          	snez	a0,a0
    800042fa:	40a0053b          	negw	a0,a0
    800042fe:	74e2                	ld	s1,56(sp)
}
    80004300:	60a6                	ld	ra,72(sp)
    80004302:	6406                	ld	s0,64(sp)
    80004304:	7942                	ld	s2,48(sp)
    80004306:	6ae2                	ld	s5,24(sp)
    80004308:	6b42                	ld	s6,16(sp)
    8000430a:	6161                	addi	sp,sp,80
    8000430c:	8082                	ret

000000008000430e <namei>:

struct inode *
namei(char *path)
{
    8000430e:	1101                	addi	sp,sp,-32
    80004310:	ec06                	sd	ra,24(sp)
    80004312:	e822                	sd	s0,16(sp)
    80004314:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80004316:	fe040613          	addi	a2,s0,-32
    8000431a:	4581                	li	a1,0
    8000431c:	dfbff0ef          	jal	80004116 <namex>
}
    80004320:	60e2                	ld	ra,24(sp)
    80004322:	6442                	ld	s0,16(sp)
    80004324:	6105                	addi	sp,sp,32
    80004326:	8082                	ret

0000000080004328 <nameiparent>:

struct inode *
nameiparent(char *path, char *name)
{
    80004328:	1141                	addi	sp,sp,-16
    8000432a:	e406                	sd	ra,8(sp)
    8000432c:	e022                	sd	s0,0(sp)
    8000432e:	0800                	addi	s0,sp,16
    80004330:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80004332:	4585                	li	a1,1
    80004334:	de3ff0ef          	jal	80004116 <namex>
}
    80004338:	60a2                	ld	ra,8(sp)
    8000433a:	6402                	ld	s0,0(sp)
    8000433c:	0141                	addi	sp,sp,16
    8000433e:	8082                	ret

0000000080004340 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80004340:	1101                	addi	sp,sp,-32
    80004342:	ec06                	sd	ra,24(sp)
    80004344:	e822                	sd	s0,16(sp)
    80004346:	e426                	sd	s1,8(sp)
    80004348:	e04a                	sd	s2,0(sp)
    8000434a:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    8000434c:	00020917          	auipc	s2,0x20
    80004350:	bdc90913          	addi	s2,s2,-1060 # 80023f28 <log>
    80004354:	01892583          	lw	a1,24(s2)
    80004358:	02492503          	lw	a0,36(s2)
    8000435c:	8d6ff0ef          	jal	80003432 <bread>
    80004360:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *)(buf->data);
  int i;
  hb->n = log.lh.n;
    80004362:	02c92603          	lw	a2,44(s2)
    80004366:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80004368:	00c05f63          	blez	a2,80004386 <write_head+0x46>
    8000436c:	00020717          	auipc	a4,0x20
    80004370:	bec70713          	addi	a4,a4,-1044 # 80023f58 <log+0x30>
    80004374:	87aa                	mv	a5,a0
    80004376:	060a                	slli	a2,a2,0x2
    80004378:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    8000437a:	4314                	lw	a3,0(a4)
    8000437c:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    8000437e:	0711                	addi	a4,a4,4
    80004380:	0791                	addi	a5,a5,4
    80004382:	fec79ce3          	bne	a5,a2,8000437a <write_head+0x3a>
  }
  bwrite(buf);
    80004386:	8526                	mv	a0,s1
    80004388:	980ff0ef          	jal	80003508 <bwrite>
  brelse(buf);
    8000438c:	8526                	mv	a0,s1
    8000438e:	9acff0ef          	jal	8000353a <brelse>
}
    80004392:	60e2                	ld	ra,24(sp)
    80004394:	6442                	ld	s0,16(sp)
    80004396:	64a2                	ld	s1,8(sp)
    80004398:	6902                	ld	s2,0(sp)
    8000439a:	6105                	addi	sp,sp,32
    8000439c:	8082                	ret

000000008000439e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    8000439e:	00020797          	auipc	a5,0x20
    800043a2:	bb67a783          	lw	a5,-1098(a5) # 80023f54 <log+0x2c>
    800043a6:	0cf05163          	blez	a5,80004468 <install_trans+0xca>
{
    800043aa:	715d                	addi	sp,sp,-80
    800043ac:	e486                	sd	ra,72(sp)
    800043ae:	e0a2                	sd	s0,64(sp)
    800043b0:	fc26                	sd	s1,56(sp)
    800043b2:	f84a                	sd	s2,48(sp)
    800043b4:	f44e                	sd	s3,40(sp)
    800043b6:	f052                	sd	s4,32(sp)
    800043b8:	ec56                	sd	s5,24(sp)
    800043ba:	e85a                	sd	s6,16(sp)
    800043bc:	e45e                	sd	s7,8(sp)
    800043be:	e062                	sd	s8,0(sp)
    800043c0:	0880                	addi	s0,sp,80
    800043c2:	8b2a                	mv	s6,a0
    800043c4:	00020a97          	auipc	s5,0x20
    800043c8:	b94a8a93          	addi	s5,s5,-1132 # 80023f58 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    800043cc:	4981                	li	s3,0
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    800043ce:	00004c17          	auipc	s8,0x4
    800043d2:	17ac0c13          	addi	s8,s8,378 # 80008548 <etext+0x548>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    800043d6:	00020a17          	auipc	s4,0x20
    800043da:	b52a0a13          	addi	s4,s4,-1198 # 80023f28 <log>
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    800043de:	40000b93          	li	s7,1024
    800043e2:	a025                	j	8000440a <install_trans+0x6c>
      printk("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    800043e4:	000aa603          	lw	a2,0(s5)
    800043e8:	85ce                	mv	a1,s3
    800043ea:	8562                	mv	a0,s8
    800043ec:	91efc0ef          	jal	8000050a <printk>
    800043f0:	a839                	j	8000440e <install_trans+0x70>
    brelse(lbuf);
    800043f2:	854a                	mv	a0,s2
    800043f4:	946ff0ef          	jal	8000353a <brelse>
    brelse(dbuf);
    800043f8:	8526                	mv	a0,s1
    800043fa:	940ff0ef          	jal	8000353a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800043fe:	2985                	addiw	s3,s3,1
    80004400:	0a91                	addi	s5,s5,4
    80004402:	02ca2783          	lw	a5,44(s4)
    80004406:	04f9d563          	bge	s3,a5,80004450 <install_trans+0xb2>
    if (recovering) {
    8000440a:	fc0b1de3          	bnez	s6,800043e4 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start + tail + 1); // read log block
    8000440e:	018a2583          	lw	a1,24(s4)
    80004412:	013585bb          	addw	a1,a1,s3
    80004416:	2585                	addiw	a1,a1,1
    80004418:	024a2503          	lw	a0,36(s4)
    8000441c:	816ff0ef          	jal	80003432 <bread>
    80004420:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]);   // read dst
    80004422:	000aa583          	lw	a1,0(s5)
    80004426:	024a2503          	lw	a0,36(s4)
    8000442a:	808ff0ef          	jal	80003432 <bread>
    8000442e:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE); // copy block to dst
    80004430:	865e                	mv	a2,s7
    80004432:	05890593          	addi	a1,s2,88
    80004436:	05850513          	addi	a0,a0,88
    8000443a:	8cffc0ef          	jal	80000d08 <memmove>
    bwrite(dbuf);                           // write dst to disk
    8000443e:	8526                	mv	a0,s1
    80004440:	8c8ff0ef          	jal	80003508 <bwrite>
    if (recovering == 0)
    80004444:	fa0b17e3          	bnez	s6,800043f2 <install_trans+0x54>
      bunpin(dbuf);
    80004448:	8526                	mv	a0,s1
    8000444a:	9a8ff0ef          	jal	800035f2 <bunpin>
    8000444e:	b755                	j	800043f2 <install_trans+0x54>
}
    80004450:	60a6                	ld	ra,72(sp)
    80004452:	6406                	ld	s0,64(sp)
    80004454:	74e2                	ld	s1,56(sp)
    80004456:	7942                	ld	s2,48(sp)
    80004458:	79a2                	ld	s3,40(sp)
    8000445a:	7a02                	ld	s4,32(sp)
    8000445c:	6ae2                	ld	s5,24(sp)
    8000445e:	6b42                	ld	s6,16(sp)
    80004460:	6ba2                	ld	s7,8(sp)
    80004462:	6c02                	ld	s8,0(sp)
    80004464:	6161                	addi	sp,sp,80
    80004466:	8082                	ret
    80004468:	8082                	ret

000000008000446a <initlog>:
{
    8000446a:	7179                	addi	sp,sp,-48
    8000446c:	f406                	sd	ra,40(sp)
    8000446e:	f022                	sd	s0,32(sp)
    80004470:	ec26                	sd	s1,24(sp)
    80004472:	e84a                	sd	s2,16(sp)
    80004474:	e44e                	sd	s3,8(sp)
    80004476:	1800                	addi	s0,sp,48
    80004478:	84aa                	mv	s1,a0
    8000447a:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    8000447c:	00020917          	auipc	s2,0x20
    80004480:	aac90913          	addi	s2,s2,-1364 # 80023f28 <log>
    80004484:	00004597          	auipc	a1,0x4
    80004488:	0e458593          	addi	a1,a1,228 # 80008568 <etext+0x568>
    8000448c:	854a                	mv	a0,s2
    8000448e:	edafc0ef          	jal	80000b68 <initlock>
  log.start = sb->logstart;
    80004492:	0149a583          	lw	a1,20(s3)
    80004496:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    8000449a:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    8000449e:	8526                	mv	a0,s1
    800044a0:	f93fe0ef          	jal	80003432 <bread>
  log.lh.n = lh->n;
    800044a4:	4d30                	lw	a2,88(a0)
    800044a6:	02c92623          	sw	a2,44(s2)
  for (i = 0; i < log.lh.n; i++) {
    800044aa:	00c05f63          	blez	a2,800044c8 <initlog+0x5e>
    800044ae:	87aa                	mv	a5,a0
    800044b0:	00020717          	auipc	a4,0x20
    800044b4:	aa870713          	addi	a4,a4,-1368 # 80023f58 <log+0x30>
    800044b8:	060a                	slli	a2,a2,0x2
    800044ba:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    800044bc:	4ff4                	lw	a3,92(a5)
    800044be:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    800044c0:	0791                	addi	a5,a5,4
    800044c2:	0711                	addi	a4,a4,4
    800044c4:	fec79ce3          	bne	a5,a2,800044bc <initlog+0x52>
  brelse(buf);
    800044c8:	872ff0ef          	jal	8000353a <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    800044cc:	4505                	li	a0,1
    800044ce:	ed1ff0ef          	jal	8000439e <install_trans>
  log.lh.n = 0;
    800044d2:	00020797          	auipc	a5,0x20
    800044d6:	a807a123          	sw	zero,-1406(a5) # 80023f54 <log+0x2c>
  write_head(); // clear the log
    800044da:	e67ff0ef          	jal	80004340 <write_head>
}
    800044de:	70a2                	ld	ra,40(sp)
    800044e0:	7402                	ld	s0,32(sp)
    800044e2:	64e2                	ld	s1,24(sp)
    800044e4:	6942                	ld	s2,16(sp)
    800044e6:	69a2                	ld	s3,8(sp)
    800044e8:	6145                	addi	sp,sp,48
    800044ea:	8082                	ret

00000000800044ec <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    800044ec:	1101                	addi	sp,sp,-32
    800044ee:	ec06                	sd	ra,24(sp)
    800044f0:	e822                	sd	s0,16(sp)
    800044f2:	e426                	sd	s1,8(sp)
    800044f4:	e04a                	sd	s2,0(sp)
    800044f6:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    800044f8:	00020517          	auipc	a0,0x20
    800044fc:	a3050513          	addi	a0,a0,-1488 # 80023f28 <log>
    80004500:	ee8fc0ef          	jal	80000be8 <acquire>
  while (1) {
    if (log.committing) {
    80004504:	00020497          	auipc	s1,0x20
    80004508:	a2448493          	addi	s1,s1,-1500 # 80023f28 <log>
      sleep_prepare(&log);
      release(&log.lock);
      sleep();
      acquire(&log.lock);
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    8000450c:	4979                	li	s2,30
    8000450e:	a821                	j	80004526 <begin_op+0x3a>
      sleep_prepare(&log);
    80004510:	8526                	mv	a0,s1
    80004512:	d67fd0ef          	jal	80002278 <sleep_prepare>
      release(&log.lock);
    80004516:	8526                	mv	a0,s1
    80004518:	f58fc0ef          	jal	80000c70 <release>
      sleep();
    8000451c:	d99fd0ef          	jal	800022b4 <sleep>
      acquire(&log.lock);
    80004520:	8526                	mv	a0,s1
    80004522:	ec6fc0ef          	jal	80000be8 <acquire>
    if (log.committing) {
    80004526:	509c                	lw	a5,32(s1)
    80004528:	f7e5                	bnez	a5,80004510 <begin_op+0x24>
    } else if (log.lh.n + (log.outstanding + 1) * MAXOPBLOCKS > LOGBLOCKS) {
    8000452a:	4cd8                	lw	a4,28(s1)
    8000452c:	2705                	addiw	a4,a4,1
    8000452e:	0027179b          	slliw	a5,a4,0x2
    80004532:	9fb9                	addw	a5,a5,a4
    80004534:	0017979b          	slliw	a5,a5,0x1
    80004538:	54d4                	lw	a3,44(s1)
    8000453a:	9fb5                	addw	a5,a5,a3
    8000453c:	00f95e63          	bge	s2,a5,80004558 <begin_op+0x6c>
      // this op might exhaust log space; wait for commit.
      sleep_prepare(&log);
    80004540:	8526                	mv	a0,s1
    80004542:	d37fd0ef          	jal	80002278 <sleep_prepare>
      release(&log.lock);
    80004546:	8526                	mv	a0,s1
    80004548:	f28fc0ef          	jal	80000c70 <release>
      sleep();
    8000454c:	d69fd0ef          	jal	800022b4 <sleep>
      acquire(&log.lock);
    80004550:	8526                	mv	a0,s1
    80004552:	e96fc0ef          	jal	80000be8 <acquire>
    80004556:	bfc1                	j	80004526 <begin_op+0x3a>
    } else {
      log.outstanding += 1;
    80004558:	00020797          	auipc	a5,0x20
    8000455c:	9ee7a623          	sw	a4,-1556(a5) # 80023f44 <log+0x1c>
      release(&log.lock);
    80004560:	00020517          	auipc	a0,0x20
    80004564:	9c850513          	addi	a0,a0,-1592 # 80023f28 <log>
    80004568:	f08fc0ef          	jal	80000c70 <release>
      break;
    }
  }
}
    8000456c:	60e2                	ld	ra,24(sp)
    8000456e:	6442                	ld	s0,16(sp)
    80004570:	64a2                	ld	s1,8(sp)
    80004572:	6902                	ld	s2,0(sp)
    80004574:	6105                	addi	sp,sp,32
    80004576:	8082                	ret

0000000080004578 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80004578:	7139                	addi	sp,sp,-64
    8000457a:	fc06                	sd	ra,56(sp)
    8000457c:	f822                	sd	s0,48(sp)
    8000457e:	f426                	sd	s1,40(sp)
    80004580:	f04a                	sd	s2,32(sp)
    80004582:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80004584:	00020497          	auipc	s1,0x20
    80004588:	9a448493          	addi	s1,s1,-1628 # 80023f28 <log>
    8000458c:	8526                	mv	a0,s1
    8000458e:	e5afc0ef          	jal	80000be8 <acquire>
  log.outstanding -= 1;
    80004592:	4cdc                	lw	a5,28(s1)
    80004594:	37fd                	addiw	a5,a5,-1
    80004596:	893e                	mv	s2,a5
    80004598:	ccdc                	sw	a5,28(s1)
  if (log.committing)
    8000459a:	509c                	lw	a5,32(s1)
    8000459c:	e3b1                	bnez	a5,800045e0 <end_op+0x68>
    panic("log.committing");
  if (log.outstanding == 0) {
    8000459e:	04091a63          	bnez	s2,800045f2 <end_op+0x7a>
    do_commit = 1;
    log.committing = 1;
    800045a2:	00020497          	auipc	s1,0x20
    800045a6:	98648493          	addi	s1,s1,-1658 # 80023f28 <log>
    800045aa:	4785                	li	a5,1
    800045ac:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    800045ae:	8526                	mv	a0,s1
    800045b0:	ec0fc0ef          	jal	80000c70 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    800045b4:	54dc                	lw	a5,44(s1)
    800045b6:	06f04063          	bgtz	a5,80004616 <end_op+0x9e>
    acquire(&log.lock);
    800045ba:	00020497          	auipc	s1,0x20
    800045be:	96e48493          	addi	s1,s1,-1682 # 80023f28 <log>
    800045c2:	8526                	mv	a0,s1
    800045c4:	e24fc0ef          	jal	80000be8 <acquire>
    log.committing = 0;
    800045c8:	0204a023          	sw	zero,32(s1)
    log.ncommit += 1;
    800045cc:	549c                	lw	a5,40(s1)
    800045ce:	2785                	addiw	a5,a5,1
    800045d0:	d49c                	sw	a5,40(s1)
    wakeup(&log);
    800045d2:	8526                	mv	a0,s1
    800045d4:	d11fd0ef          	jal	800022e4 <wakeup>
    release(&log.lock);
    800045d8:	8526                	mv	a0,s1
    800045da:	e96fc0ef          	jal	80000c70 <release>
}
    800045de:	a035                	j	8000460a <end_op+0x92>
    800045e0:	ec4e                	sd	s3,24(sp)
    800045e2:	e852                	sd	s4,16(sp)
    800045e4:	e456                	sd	s5,8(sp)
    panic("log.committing");
    800045e6:	00004517          	auipc	a0,0x4
    800045ea:	f8a50513          	addi	a0,a0,-118 # 80008570 <etext+0x570>
    800045ee:	a46fc0ef          	jal	80000834 <panic>
    wakeup(&log);
    800045f2:	00020517          	auipc	a0,0x20
    800045f6:	93650513          	addi	a0,a0,-1738 # 80023f28 <log>
    800045fa:	cebfd0ef          	jal	800022e4 <wakeup>
  release(&log.lock);
    800045fe:	00020517          	auipc	a0,0x20
    80004602:	92a50513          	addi	a0,a0,-1750 # 80023f28 <log>
    80004606:	e6afc0ef          	jal	80000c70 <release>
}
    8000460a:	70e2                	ld	ra,56(sp)
    8000460c:	7442                	ld	s0,48(sp)
    8000460e:	74a2                	ld	s1,40(sp)
    80004610:	7902                	ld	s2,32(sp)
    80004612:	6121                	addi	sp,sp,64
    80004614:	8082                	ret
    80004616:	ec4e                	sd	s3,24(sp)
    80004618:	e852                	sd	s4,16(sp)
    8000461a:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    8000461c:	00020a97          	auipc	s5,0x20
    80004620:	93ca8a93          	addi	s5,s5,-1732 # 80023f58 <log+0x30>
    struct buf *to = bread(log.dev, log.start + tail + 1); // log block
    80004624:	00020a17          	auipc	s4,0x20
    80004628:	904a0a13          	addi	s4,s4,-1788 # 80023f28 <log>
    8000462c:	018a2583          	lw	a1,24(s4)
    80004630:	012585bb          	addw	a1,a1,s2
    80004634:	2585                	addiw	a1,a1,1
    80004636:	024a2503          	lw	a0,36(s4)
    8000463a:	df9fe0ef          	jal	80003432 <bread>
    8000463e:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80004640:	000aa583          	lw	a1,0(s5)
    80004644:	024a2503          	lw	a0,36(s4)
    80004648:	debfe0ef          	jal	80003432 <bread>
    8000464c:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    8000464e:	40000613          	li	a2,1024
    80004652:	05850593          	addi	a1,a0,88
    80004656:	05848513          	addi	a0,s1,88
    8000465a:	eaefc0ef          	jal	80000d08 <memmove>
    bwrite(to); // write the log
    8000465e:	8526                	mv	a0,s1
    80004660:	ea9fe0ef          	jal	80003508 <bwrite>
    brelse(from);
    80004664:	854e                	mv	a0,s3
    80004666:	ed5fe0ef          	jal	8000353a <brelse>
    brelse(to);
    8000466a:	8526                	mv	a0,s1
    8000466c:	ecffe0ef          	jal	8000353a <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004670:	2905                	addiw	s2,s2,1
    80004672:	0a91                	addi	s5,s5,4
    80004674:	02ca2783          	lw	a5,44(s4)
    80004678:	faf94ae3          	blt	s2,a5,8000462c <end_op+0xb4>
    write_log();      // Write modified blocks from cache to log
    write_head();     // Write header to disk -- the real commit
    8000467c:	cc5ff0ef          	jal	80004340 <write_head>
    install_trans(0); // Now install writes to home locations
    80004680:	4501                	li	a0,0
    80004682:	d1dff0ef          	jal	8000439e <install_trans>
    log.lh.n = 0;
    80004686:	00020797          	auipc	a5,0x20
    8000468a:	8c07a723          	sw	zero,-1842(a5) # 80023f54 <log+0x2c>
    write_head(); // Erase the transaction from the log
    8000468e:	cb3ff0ef          	jal	80004340 <write_head>
    80004692:	69e2                	ld	s3,24(sp)
    80004694:	6a42                	ld	s4,16(sp)
    80004696:	6aa2                	ld	s5,8(sp)
    80004698:	b70d                	j	800045ba <end_op+0x42>

000000008000469a <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000469a:	1101                	addi	sp,sp,-32
    8000469c:	ec06                	sd	ra,24(sp)
    8000469e:	e822                	sd	s0,16(sp)
    800046a0:	e426                	sd	s1,8(sp)
    800046a2:	1000                	addi	s0,sp,32
    800046a4:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    800046a6:	00020517          	auipc	a0,0x20
    800046aa:	88250513          	addi	a0,a0,-1918 # 80023f28 <log>
    800046ae:	d3afc0ef          	jal	80000be8 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    800046b2:	00020617          	auipc	a2,0x20
    800046b6:	8a262603          	lw	a2,-1886(a2) # 80023f54 <log+0x2c>
    800046ba:	47f5                	li	a5,29
    800046bc:	04c7cd63          	blt	a5,a2,80004716 <log_write+0x7c>
    panic("too big a transaction");
  if (log.outstanding < 1)
    800046c0:	00020797          	auipc	a5,0x20
    800046c4:	8847a783          	lw	a5,-1916(a5) # 80023f44 <log+0x1c>
    800046c8:	04f05d63          	blez	a5,80004722 <log_write+0x88>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    800046cc:	4781                	li	a5,0
    800046ce:	06c05063          	blez	a2,8000472e <log_write+0x94>
    if (log.lh.block[i] == b->blockno) // log absorption
    800046d2:	44cc                	lw	a1,12(s1)
    800046d4:	00020717          	auipc	a4,0x20
    800046d8:	88470713          	addi	a4,a4,-1916 # 80023f58 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    800046dc:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno) // log absorption
    800046de:	4314                	lw	a3,0(a4)
    800046e0:	04b68763          	beq	a3,a1,8000472e <log_write+0x94>
  for (i = 0; i < log.lh.n; i++) {
    800046e4:	2785                	addiw	a5,a5,1
    800046e6:	0711                	addi	a4,a4,4
    800046e8:	fef61be3          	bne	a2,a5,800046de <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    800046ec:	060a                	slli	a2,a2,0x2
    800046ee:	02060613          	addi	a2,a2,32
    800046f2:	00020797          	auipc	a5,0x20
    800046f6:	83678793          	addi	a5,a5,-1994 # 80023f28 <log>
    800046fa:	97b2                	add	a5,a5,a2
    800046fc:	44d8                	lw	a4,12(s1)
    800046fe:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) { // Add new block to log?
    bpin(b);
    80004700:	8526                	mv	a0,s1
    80004702:	ebdfe0ef          	jal	800035be <bpin>
    log.lh.n++;
    80004706:	00020717          	auipc	a4,0x20
    8000470a:	82270713          	addi	a4,a4,-2014 # 80023f28 <log>
    8000470e:	575c                	lw	a5,44(a4)
    80004710:	2785                	addiw	a5,a5,1
    80004712:	d75c                	sw	a5,44(a4)
    80004714:	a815                	j	80004748 <log_write+0xae>
    panic("too big a transaction");
    80004716:	00004517          	auipc	a0,0x4
    8000471a:	e6a50513          	addi	a0,a0,-406 # 80008580 <etext+0x580>
    8000471e:	916fc0ef          	jal	80000834 <panic>
    panic("log_write outside of trans");
    80004722:	00004517          	auipc	a0,0x4
    80004726:	e7650513          	addi	a0,a0,-394 # 80008598 <etext+0x598>
    8000472a:	90afc0ef          	jal	80000834 <panic>
  log.lh.block[i] = b->blockno;
    8000472e:	00279693          	slli	a3,a5,0x2
    80004732:	02068693          	addi	a3,a3,32
    80004736:	0001f717          	auipc	a4,0x1f
    8000473a:	7f270713          	addi	a4,a4,2034 # 80023f28 <log>
    8000473e:	9736                	add	a4,a4,a3
    80004740:	44d4                	lw	a3,12(s1)
    80004742:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) { // Add new block to log?
    80004744:	faf60ee3          	beq	a2,a5,80004700 <log_write+0x66>
  }
  release(&log.lock);
    80004748:	0001f517          	auipc	a0,0x1f
    8000474c:	7e050513          	addi	a0,a0,2016 # 80023f28 <log>
    80004750:	d20fc0ef          	jal	80000c70 <release>
}
    80004754:	60e2                	ld	ra,24(sp)
    80004756:	6442                	ld	s0,16(sp)
    80004758:	64a2                	ld	s1,8(sp)
    8000475a:	6105                	addi	sp,sp,32
    8000475c:	8082                	ret

000000008000475e <sys_sync>:

uint64
sys_sync(void)
{
    8000475e:	1101                	addi	sp,sp,-32
    80004760:	ec06                	sd	ra,24(sp)
    80004762:	e822                	sd	s0,16(sp)
    80004764:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80004766:	0001f517          	auipc	a0,0x1f
    8000476a:	7c250513          	addi	a0,a0,1986 # 80023f28 <log>
    8000476e:	c7afc0ef          	jal	80000be8 <acquire>
  if (log.committing || log.outstanding > 0) {
    80004772:	0001f797          	auipc	a5,0x1f
    80004776:	7d67a783          	lw	a5,2006(a5) # 80023f48 <log+0x20>
    8000477a:	e799                	bnez	a5,80004788 <sys_sync+0x2a>
    8000477c:	0001f797          	auipc	a5,0x1f
    80004780:	7c87a783          	lw	a5,1992(a5) # 80023f44 <log+0x1c>
    80004784:	02f05c63          	blez	a5,800047bc <sys_sync+0x5e>
    80004788:	e426                	sd	s1,8(sp)
    8000478a:	e04a                	sd	s2,0(sp)
    int n = log.ncommit + 1;
    8000478c:	0001f917          	auipc	s2,0x1f
    80004790:	7c492903          	lw	s2,1988(s2) # 80023f50 <log+0x28>
    while (log.ncommit < n) {
      sleep_prepare(&log);
    80004794:	0001f497          	auipc	s1,0x1f
    80004798:	79448493          	addi	s1,s1,1940 # 80023f28 <log>
    8000479c:	8526                	mv	a0,s1
    8000479e:	adbfd0ef          	jal	80002278 <sleep_prepare>
      release(&log.lock);
    800047a2:	8526                	mv	a0,s1
    800047a4:	cccfc0ef          	jal	80000c70 <release>
      sleep();
    800047a8:	b0dfd0ef          	jal	800022b4 <sleep>
      acquire(&log.lock);
    800047ac:	8526                	mv	a0,s1
    800047ae:	c3afc0ef          	jal	80000be8 <acquire>
    while (log.ncommit < n) {
    800047b2:	549c                	lw	a5,40(s1)
    800047b4:	fef954e3          	bge	s2,a5,8000479c <sys_sync+0x3e>
    800047b8:	64a2                	ld	s1,8(sp)
    800047ba:	6902                	ld	s2,0(sp)
    }
  }
  release(&log.lock);
    800047bc:	0001f517          	auipc	a0,0x1f
    800047c0:	76c50513          	addi	a0,a0,1900 # 80023f28 <log>
    800047c4:	cacfc0ef          	jal	80000c70 <release>
  return 0;
}
    800047c8:	4501                	li	a0,0
    800047ca:	60e2                	ld	ra,24(sp)
    800047cc:	6442                	ld	s0,16(sp)
    800047ce:	6105                	addi	sp,sp,32
    800047d0:	8082                	ret

00000000800047d2 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800047d2:	1101                	addi	sp,sp,-32
    800047d4:	ec06                	sd	ra,24(sp)
    800047d6:	e822                	sd	s0,16(sp)
    800047d8:	e426                	sd	s1,8(sp)
    800047da:	e04a                	sd	s2,0(sp)
    800047dc:	1000                	addi	s0,sp,32
    800047de:	84aa                	mv	s1,a0
    800047e0:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800047e2:	00004597          	auipc	a1,0x4
    800047e6:	dd658593          	addi	a1,a1,-554 # 800085b8 <etext+0x5b8>
    800047ea:	0521                	addi	a0,a0,8
    800047ec:	b7cfc0ef          	jal	80000b68 <initlock>
  lk->name = name;
    800047f0:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800047f4:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800047f8:	0204a423          	sw	zero,40(s1)
}
    800047fc:	60e2                	ld	ra,24(sp)
    800047fe:	6442                	ld	s0,16(sp)
    80004800:	64a2                	ld	s1,8(sp)
    80004802:	6902                	ld	s2,0(sp)
    80004804:	6105                	addi	sp,sp,32
    80004806:	8082                	ret

0000000080004808 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004808:	1101                	addi	sp,sp,-32
    8000480a:	ec06                	sd	ra,24(sp)
    8000480c:	e822                	sd	s0,16(sp)
    8000480e:	e426                	sd	s1,8(sp)
    80004810:	e04a                	sd	s2,0(sp)
    80004812:	1000                	addi	s0,sp,32
    80004814:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004816:	00850913          	addi	s2,a0,8
    8000481a:	854a                	mv	a0,s2
    8000481c:	bccfc0ef          	jal	80000be8 <acquire>
  while (lk->locked) {
    80004820:	409c                	lw	a5,0(s1)
    80004822:	cf91                	beqz	a5,8000483e <acquiresleep+0x36>
    sleep_prepare(lk);
    80004824:	8526                	mv	a0,s1
    80004826:	a53fd0ef          	jal	80002278 <sleep_prepare>
    release(&lk->lk);
    8000482a:	854a                	mv	a0,s2
    8000482c:	c44fc0ef          	jal	80000c70 <release>
    sleep();
    80004830:	a85fd0ef          	jal	800022b4 <sleep>
    acquire(&lk->lk);
    80004834:	854a                	mv	a0,s2
    80004836:	bb2fc0ef          	jal	80000be8 <acquire>
  while (lk->locked) {
    8000483a:	409c                	lw	a5,0(s1)
    8000483c:	f7e5                	bnez	a5,80004824 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    8000483e:	4785                	li	a5,1
    80004840:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004842:	8b2fd0ef          	jal	800018f4 <myproc>
    80004846:	591c                	lw	a5,48(a0)
    80004848:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    8000484a:	854a                	mv	a0,s2
    8000484c:	c24fc0ef          	jal	80000c70 <release>
}
    80004850:	60e2                	ld	ra,24(sp)
    80004852:	6442                	ld	s0,16(sp)
    80004854:	64a2                	ld	s1,8(sp)
    80004856:	6902                	ld	s2,0(sp)
    80004858:	6105                	addi	sp,sp,32
    8000485a:	8082                	ret

000000008000485c <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    8000485c:	1101                	addi	sp,sp,-32
    8000485e:	ec06                	sd	ra,24(sp)
    80004860:	e822                	sd	s0,16(sp)
    80004862:	e426                	sd	s1,8(sp)
    80004864:	e04a                	sd	s2,0(sp)
    80004866:	1000                	addi	s0,sp,32
    80004868:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000486a:	00850913          	addi	s2,a0,8
    8000486e:	854a                	mv	a0,s2
    80004870:	b78fc0ef          	jal	80000be8 <acquire>
  lk->locked = 0;
    80004874:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80004878:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000487c:	8526                	mv	a0,s1
    8000487e:	a67fd0ef          	jal	800022e4 <wakeup>
  release(&lk->lk);
    80004882:	854a                	mv	a0,s2
    80004884:	becfc0ef          	jal	80000c70 <release>
}
    80004888:	60e2                	ld	ra,24(sp)
    8000488a:	6442                	ld	s0,16(sp)
    8000488c:	64a2                	ld	s1,8(sp)
    8000488e:	6902                	ld	s2,0(sp)
    80004890:	6105                	addi	sp,sp,32
    80004892:	8082                	ret

0000000080004894 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80004894:	7179                	addi	sp,sp,-48
    80004896:	f406                	sd	ra,40(sp)
    80004898:	f022                	sd	s0,32(sp)
    8000489a:	ec26                	sd	s1,24(sp)
    8000489c:	e84a                	sd	s2,16(sp)
    8000489e:	1800                	addi	s0,sp,48
    800048a0:	84aa                	mv	s1,a0
  int r;

  acquire(&lk->lk);
    800048a2:	00850913          	addi	s2,a0,8
    800048a6:	854a                	mv	a0,s2
    800048a8:	b40fc0ef          	jal	80000be8 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    800048ac:	409c                	lw	a5,0(s1)
    800048ae:	ef81                	bnez	a5,800048c6 <holdingsleep+0x32>
    800048b0:	4481                	li	s1,0
  release(&lk->lk);
    800048b2:	854a                	mv	a0,s2
    800048b4:	bbcfc0ef          	jal	80000c70 <release>
  return r;
}
    800048b8:	8526                	mv	a0,s1
    800048ba:	70a2                	ld	ra,40(sp)
    800048bc:	7402                	ld	s0,32(sp)
    800048be:	64e2                	ld	s1,24(sp)
    800048c0:	6942                	ld	s2,16(sp)
    800048c2:	6145                	addi	sp,sp,48
    800048c4:	8082                	ret
    800048c6:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800048c8:	0284a983          	lw	s3,40(s1)
    800048cc:	828fd0ef          	jal	800018f4 <myproc>
    800048d0:	5904                	lw	s1,48(a0)
    800048d2:	413484b3          	sub	s1,s1,s3
    800048d6:	0014b493          	seqz	s1,s1
    800048da:	69a2                	ld	s3,8(sp)
    800048dc:	bfd9                	j	800048b2 <holdingsleep+0x1e>

00000000800048de <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800048de:	1141                	addi	sp,sp,-16
    800048e0:	e406                	sd	ra,8(sp)
    800048e2:	e022                	sd	s0,0(sp)
    800048e4:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800048e6:	00004597          	auipc	a1,0x4
    800048ea:	ce258593          	addi	a1,a1,-798 # 800085c8 <etext+0x5c8>
    800048ee:	0001f517          	auipc	a0,0x1f
    800048f2:	78250513          	addi	a0,a0,1922 # 80024070 <ftable>
    800048f6:	a72fc0ef          	jal	80000b68 <initlock>
}
    800048fa:	60a2                	ld	ra,8(sp)
    800048fc:	6402                	ld	s0,0(sp)
    800048fe:	0141                	addi	sp,sp,16
    80004900:	8082                	ret

0000000080004902 <filealloc>:

// Allocate a file structure.
struct file *
filealloc(void)
{
    80004902:	1101                	addi	sp,sp,-32
    80004904:	ec06                	sd	ra,24(sp)
    80004906:	e822                	sd	s0,16(sp)
    80004908:	e426                	sd	s1,8(sp)
    8000490a:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    8000490c:	0001f517          	auipc	a0,0x1f
    80004910:	76450513          	addi	a0,a0,1892 # 80024070 <ftable>
    80004914:	ad4fc0ef          	jal	80000be8 <acquire>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    80004918:	0001f497          	auipc	s1,0x1f
    8000491c:	77048493          	addi	s1,s1,1904 # 80024088 <ftable+0x18>
    80004920:	00020717          	auipc	a4,0x20
    80004924:	70870713          	addi	a4,a4,1800 # 80025028 <disk>
    if (f->ref == 0) {
    80004928:	40dc                	lw	a5,4(s1)
    8000492a:	cf89                	beqz	a5,80004944 <filealloc+0x42>
  for (f = ftable.file; f < ftable.file + NFILE; f++) {
    8000492c:	02848493          	addi	s1,s1,40
    80004930:	fee49ce3          	bne	s1,a4,80004928 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004934:	0001f517          	auipc	a0,0x1f
    80004938:	73c50513          	addi	a0,a0,1852 # 80024070 <ftable>
    8000493c:	b34fc0ef          	jal	80000c70 <release>
  return 0;
    80004940:	4481                	li	s1,0
    80004942:	a809                	j	80004954 <filealloc+0x52>
      f->ref = 1;
    80004944:	4785                	li	a5,1
    80004946:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004948:	0001f517          	auipc	a0,0x1f
    8000494c:	72850513          	addi	a0,a0,1832 # 80024070 <ftable>
    80004950:	b20fc0ef          	jal	80000c70 <release>
}
    80004954:	8526                	mv	a0,s1
    80004956:	60e2                	ld	ra,24(sp)
    80004958:	6442                	ld	s0,16(sp)
    8000495a:	64a2                	ld	s1,8(sp)
    8000495c:	6105                	addi	sp,sp,32
    8000495e:	8082                	ret

0000000080004960 <filedup>:

// Increment ref count for file f.
struct file *
filedup(struct file *f)
{
    80004960:	1101                	addi	sp,sp,-32
    80004962:	ec06                	sd	ra,24(sp)
    80004964:	e822                	sd	s0,16(sp)
    80004966:	e426                	sd	s1,8(sp)
    80004968:	1000                	addi	s0,sp,32
    8000496a:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    8000496c:	0001f517          	auipc	a0,0x1f
    80004970:	70450513          	addi	a0,a0,1796 # 80024070 <ftable>
    80004974:	a74fc0ef          	jal	80000be8 <acquire>
  if (f->ref < 1)
    80004978:	40dc                	lw	a5,4(s1)
    8000497a:	02f05063          	blez	a5,8000499a <filedup+0x3a>
    panic("filedup");
  f->ref++;
    8000497e:	2785                	addiw	a5,a5,1
    80004980:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004982:	0001f517          	auipc	a0,0x1f
    80004986:	6ee50513          	addi	a0,a0,1774 # 80024070 <ftable>
    8000498a:	ae6fc0ef          	jal	80000c70 <release>
  return f;
}
    8000498e:	8526                	mv	a0,s1
    80004990:	60e2                	ld	ra,24(sp)
    80004992:	6442                	ld	s0,16(sp)
    80004994:	64a2                	ld	s1,8(sp)
    80004996:	6105                	addi	sp,sp,32
    80004998:	8082                	ret
    panic("filedup");
    8000499a:	00004517          	auipc	a0,0x4
    8000499e:	c3650513          	addi	a0,a0,-970 # 800085d0 <etext+0x5d0>
    800049a2:	e93fb0ef          	jal	80000834 <panic>

00000000800049a6 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    800049a6:	7139                	addi	sp,sp,-64
    800049a8:	fc06                	sd	ra,56(sp)
    800049aa:	f822                	sd	s0,48(sp)
    800049ac:	f426                	sd	s1,40(sp)
    800049ae:	0080                	addi	s0,sp,64
    800049b0:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800049b2:	0001f517          	auipc	a0,0x1f
    800049b6:	6be50513          	addi	a0,a0,1726 # 80024070 <ftable>
    800049ba:	a2efc0ef          	jal	80000be8 <acquire>
  if (f->ref < 1)
    800049be:	40dc                	lw	a5,4(s1)
    800049c0:	04f05a63          	blez	a5,80004a14 <fileclose+0x6e>
    panic("fileclose");
  if (--f->ref > 0) {
    800049c4:	37fd                	addiw	a5,a5,-1
    800049c6:	c0dc                	sw	a5,4(s1)
    800049c8:	06f04063          	bgtz	a5,80004a28 <fileclose+0x82>
    800049cc:	f04a                	sd	s2,32(sp)
    800049ce:	ec4e                	sd	s3,24(sp)
    800049d0:	e852                	sd	s4,16(sp)
    800049d2:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800049d4:	0004a903          	lw	s2,0(s1)
    800049d8:	0094c783          	lbu	a5,9(s1)
    800049dc:	89be                	mv	s3,a5
    800049de:	689c                	ld	a5,16(s1)
    800049e0:	8a3e                	mv	s4,a5
    800049e2:	6c9c                	ld	a5,24(s1)
    800049e4:	8abe                	mv	s5,a5
  f->ref = 0;
    800049e6:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800049ea:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800049ee:	0001f517          	auipc	a0,0x1f
    800049f2:	68250513          	addi	a0,a0,1666 # 80024070 <ftable>
    800049f6:	a7afc0ef          	jal	80000c70 <release>

  if (ff.type == FD_PIPE) {
    800049fa:	4785                	li	a5,1
    800049fc:	04f90163          	beq	s2,a5,80004a3e <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if (ff.type == FD_INODE || ff.type == FD_DEVICE) {
    80004a00:	ffe9079b          	addiw	a5,s2,-2
    80004a04:	4705                	li	a4,1
    80004a06:	04f77563          	bgeu	a4,a5,80004a50 <fileclose+0xaa>
    80004a0a:	7902                	ld	s2,32(sp)
    80004a0c:	69e2                	ld	s3,24(sp)
    80004a0e:	6a42                	ld	s4,16(sp)
    80004a10:	6aa2                	ld	s5,8(sp)
    80004a12:	a00d                	j	80004a34 <fileclose+0x8e>
    80004a14:	f04a                	sd	s2,32(sp)
    80004a16:	ec4e                	sd	s3,24(sp)
    80004a18:	e852                	sd	s4,16(sp)
    80004a1a:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004a1c:	00004517          	auipc	a0,0x4
    80004a20:	bbc50513          	addi	a0,a0,-1092 # 800085d8 <etext+0x5d8>
    80004a24:	e11fb0ef          	jal	80000834 <panic>
    release(&ftable.lock);
    80004a28:	0001f517          	auipc	a0,0x1f
    80004a2c:	64850513          	addi	a0,a0,1608 # 80024070 <ftable>
    80004a30:	a40fc0ef          	jal	80000c70 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80004a34:	70e2                	ld	ra,56(sp)
    80004a36:	7442                	ld	s0,48(sp)
    80004a38:	74a2                	ld	s1,40(sp)
    80004a3a:	6121                	addi	sp,sp,64
    80004a3c:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004a3e:	85ce                	mv	a1,s3
    80004a40:	8552                	mv	a0,s4
    80004a42:	34c000ef          	jal	80004d8e <pipeclose>
    80004a46:	7902                	ld	s2,32(sp)
    80004a48:	69e2                	ld	s3,24(sp)
    80004a4a:	6a42                	ld	s4,16(sp)
    80004a4c:	6aa2                	ld	s5,8(sp)
    80004a4e:	b7dd                	j	80004a34 <fileclose+0x8e>
    begin_op();
    80004a50:	a9dff0ef          	jal	800044ec <begin_op>
    iput(ff.ip);
    80004a54:	8556                	mv	a0,s5
    80004a56:	9f6ff0ef          	jal	80003c4c <iput>
    end_op();
    80004a5a:	b1fff0ef          	jal	80004578 <end_op>
    80004a5e:	7902                	ld	s2,32(sp)
    80004a60:	69e2                	ld	s3,24(sp)
    80004a62:	6a42                	ld	s4,16(sp)
    80004a64:	6aa2                	ld	s5,8(sp)
    80004a66:	b7f9                	j	80004a34 <fileclose+0x8e>

0000000080004a68 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004a68:	715d                	addi	sp,sp,-80
    80004a6a:	e486                	sd	ra,72(sp)
    80004a6c:	e0a2                	sd	s0,64(sp)
    80004a6e:	fc26                	sd	s1,56(sp)
    80004a70:	f052                	sd	s4,32(sp)
    80004a72:	0880                	addi	s0,sp,80
    80004a74:	84aa                	mv	s1,a0
    80004a76:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80004a78:	e7dfc0ef          	jal	800018f4 <myproc>
  struct stat st;

  if (f->type == FD_INODE || f->type == FD_DEVICE) {
    80004a7c:	409c                	lw	a5,0(s1)
    80004a7e:	37f9                	addiw	a5,a5,-2
    80004a80:	4705                	li	a4,1
    80004a82:	04f76463          	bltu	a4,a5,80004aca <filestat+0x62>
    80004a86:	f84a                	sd	s2,48(sp)
    80004a88:	f44e                	sd	s3,40(sp)
    80004a8a:	892a                	mv	s2,a0
    ilock(f->ip);
    80004a8c:	6c88                	ld	a0,24(s1)
    80004a8e:	83cff0ef          	jal	80003aca <ilock>
    stati(f->ip, &st);
    80004a92:	fb840993          	addi	s3,s0,-72
    80004a96:	85ce                	mv	a1,s3
    80004a98:	6c88                	ld	a0,24(s1)
    80004a9a:	b94ff0ef          	jal	80003e2e <stati>
    iunlock(f->ip);
    80004a9e:	6c88                	ld	a0,24(s1)
    80004aa0:	8d8ff0ef          	jal	80003b78 <iunlock>
    if (copyout(p->pagetable, p->sz, addr, (char *)&st, sizeof(st)) < 0)
    80004aa4:	4761                	li	a4,24
    80004aa6:	86ce                	mv	a3,s3
    80004aa8:	8652                	mv	a2,s4
    80004aaa:	06093583          	ld	a1,96(s2)
    80004aae:	06893503          	ld	a0,104(s2)
    80004ab2:	a95fc0ef          	jal	80001546 <copyout>
    80004ab6:	41f5551b          	sraiw	a0,a0,0x1f
    80004aba:	7942                	ld	s2,48(sp)
    80004abc:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004abe:	60a6                	ld	ra,72(sp)
    80004ac0:	6406                	ld	s0,64(sp)
    80004ac2:	74e2                	ld	s1,56(sp)
    80004ac4:	7a02                	ld	s4,32(sp)
    80004ac6:	6161                	addi	sp,sp,80
    80004ac8:	8082                	ret
  return -1;
    80004aca:	557d                	li	a0,-1
    80004acc:	bfcd                	j	80004abe <filestat+0x56>

0000000080004ace <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004ace:	7179                	addi	sp,sp,-48
    80004ad0:	f406                	sd	ra,40(sp)
    80004ad2:	f022                	sd	s0,32(sp)
    80004ad4:	e84a                	sd	s2,16(sp)
    80004ad6:	1800                	addi	s0,sp,48
  int r = 0;

  if (f->readable == 0)
    80004ad8:	00854783          	lbu	a5,8(a0)
    80004adc:	cfd1                	beqz	a5,80004b78 <fileread+0xaa>
    80004ade:	ec26                	sd	s1,24(sp)
    80004ae0:	e44e                	sd	s3,8(sp)
    80004ae2:	84aa                	mv	s1,a0
    80004ae4:	892e                	mv	s2,a1
    80004ae6:	89b2                	mv	s3,a2
    return -1;

  if (f->type == FD_PIPE) {
    80004ae8:	411c                	lw	a5,0(a0)
    80004aea:	4705                	li	a4,1
    80004aec:	04e78363          	beq	a5,a4,80004b32 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004af0:	470d                	li	a4,3
    80004af2:	04e78763          	beq	a5,a4,80004b40 <fileread+0x72>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if (f->type == FD_INODE) {
    80004af6:	4709                	li	a4,2
    80004af8:	06e79a63          	bne	a5,a4,80004b6c <fileread+0x9e>
    ilock(f->ip);
    80004afc:	6d08                	ld	a0,24(a0)
    80004afe:	fcdfe0ef          	jal	80003aca <ilock>
    if ((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004b02:	874e                	mv	a4,s3
    80004b04:	5094                	lw	a3,32(s1)
    80004b06:	864a                	mv	a2,s2
    80004b08:	4585                	li	a1,1
    80004b0a:	6c88                	ld	a0,24(s1)
    80004b0c:	b50ff0ef          	jal	80003e5c <readi>
    80004b10:	892a                	mv	s2,a0
    80004b12:	00a05563          	blez	a0,80004b1c <fileread+0x4e>
      f->off += r;
    80004b16:	509c                	lw	a5,32(s1)
    80004b18:	9fa9                	addw	a5,a5,a0
    80004b1a:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004b1c:	6c88                	ld	a0,24(s1)
    80004b1e:	85aff0ef          	jal	80003b78 <iunlock>
    80004b22:	64e2                	ld	s1,24(sp)
    80004b24:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004b26:	854a                	mv	a0,s2
    80004b28:	70a2                	ld	ra,40(sp)
    80004b2a:	7402                	ld	s0,32(sp)
    80004b2c:	6942                	ld	s2,16(sp)
    80004b2e:	6145                	addi	sp,sp,48
    80004b30:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004b32:	6908                	ld	a0,16(a0)
    80004b34:	3d4000ef          	jal	80004f08 <piperead>
    80004b38:	892a                	mv	s2,a0
    80004b3a:	64e2                	ld	s1,24(sp)
    80004b3c:	69a2                	ld	s3,8(sp)
    80004b3e:	b7e5                	j	80004b26 <fileread+0x58>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004b40:	02451783          	lh	a5,36(a0)
    80004b44:	03079693          	slli	a3,a5,0x30
    80004b48:	92c1                	srli	a3,a3,0x30
    80004b4a:	4725                	li	a4,9
    80004b4c:	02d76963          	bltu	a4,a3,80004b7e <fileread+0xb0>
    80004b50:	0792                	slli	a5,a5,0x4
    80004b52:	0001f717          	auipc	a4,0x1f
    80004b56:	47e70713          	addi	a4,a4,1150 # 80023fd0 <devsw>
    80004b5a:	97ba                	add	a5,a5,a4
    80004b5c:	639c                	ld	a5,0(a5)
    80004b5e:	c78d                	beqz	a5,80004b88 <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    80004b60:	4505                	li	a0,1
    80004b62:	9782                	jalr	a5
    80004b64:	892a                	mv	s2,a0
    80004b66:	64e2                	ld	s1,24(sp)
    80004b68:	69a2                	ld	s3,8(sp)
    80004b6a:	bf75                	j	80004b26 <fileread+0x58>
    panic("fileread");
    80004b6c:	00004517          	auipc	a0,0x4
    80004b70:	a7c50513          	addi	a0,a0,-1412 # 800085e8 <etext+0x5e8>
    80004b74:	cc1fb0ef          	jal	80000834 <panic>
    return -1;
    80004b78:	57fd                	li	a5,-1
    80004b7a:	893e                	mv	s2,a5
    80004b7c:	b76d                	j	80004b26 <fileread+0x58>
      return -1;
    80004b7e:	57fd                	li	a5,-1
    80004b80:	893e                	mv	s2,a5
    80004b82:	64e2                	ld	s1,24(sp)
    80004b84:	69a2                	ld	s3,8(sp)
    80004b86:	b745                	j	80004b26 <fileread+0x58>
    80004b88:	57fd                	li	a5,-1
    80004b8a:	893e                	mv	s2,a5
    80004b8c:	64e2                	ld	s1,24(sp)
    80004b8e:	69a2                	ld	s3,8(sp)
    80004b90:	bf59                	j	80004b26 <fileread+0x58>

0000000080004b92 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if (f->writable == 0)
    80004b92:	00954783          	lbu	a5,9(a0)
    80004b96:	10078f63          	beqz	a5,80004cb4 <filewrite+0x122>
{
    80004b9a:	711d                	addi	sp,sp,-96
    80004b9c:	ec86                	sd	ra,88(sp)
    80004b9e:	e8a2                	sd	s0,80(sp)
    80004ba0:	e0ca                	sd	s2,64(sp)
    80004ba2:	f456                	sd	s5,40(sp)
    80004ba4:	f05a                	sd	s6,32(sp)
    80004ba6:	1080                	addi	s0,sp,96
    80004ba8:	892a                	mv	s2,a0
    80004baa:	8b2e                	mv	s6,a1
    80004bac:	8ab2                	mv	s5,a2
    return -1;

  if (f->type == FD_PIPE) {
    80004bae:	411c                	lw	a5,0(a0)
    80004bb0:	4705                	li	a4,1
    80004bb2:	02e78a63          	beq	a5,a4,80004be6 <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if (f->type == FD_DEVICE) {
    80004bb6:	470d                	li	a4,3
    80004bb8:	02e78b63          	beq	a5,a4,80004bee <filewrite+0x5c>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if (f->type == FD_INODE) {
    80004bbc:	4709                	li	a4,2
    80004bbe:	0ce79f63          	bne	a5,a4,80004c9c <filewrite+0x10a>
    80004bc2:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS - 1 - 1 - 2) / 2) * BSIZE;
    int i = 0;
    while (i < n) {
    80004bc4:	0ac05a63          	blez	a2,80004c78 <filewrite+0xe6>
    80004bc8:	e4a6                	sd	s1,72(sp)
    80004bca:	fc4e                	sd	s3,56(sp)
    80004bcc:	ec5e                	sd	s7,24(sp)
    80004bce:	e862                	sd	s8,16(sp)
    80004bd0:	e466                	sd	s9,8(sp)
    int i = 0;
    80004bd2:	4a01                	li	s4,0
      int n1 = n - i;
      if (n1 > max)
    80004bd4:	6b85                	lui	s7,0x1
    80004bd6:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004bda:	6785                	lui	a5,0x1
    80004bdc:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    80004be0:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004be2:	4c05                	li	s8,1
    80004be4:	a8ad                	j	80004c5e <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80004be6:	6908                	ld	a0,16(a0)
    80004be8:	204000ef          	jal	80004dec <pipewrite>
    80004bec:	a04d                	j	80004c8e <filewrite+0xfc>
    if (f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004bee:	02451783          	lh	a5,36(a0)
    80004bf2:	03079693          	slli	a3,a5,0x30
    80004bf6:	92c1                	srli	a3,a3,0x30
    80004bf8:	4725                	li	a4,9
    80004bfa:	0ad76f63          	bltu	a4,a3,80004cb8 <filewrite+0x126>
    80004bfe:	0792                	slli	a5,a5,0x4
    80004c00:	0001f717          	auipc	a4,0x1f
    80004c04:	3d070713          	addi	a4,a4,976 # 80023fd0 <devsw>
    80004c08:	97ba                	add	a5,a5,a4
    80004c0a:	679c                	ld	a5,8(a5)
    80004c0c:	cbc5                	beqz	a5,80004cbc <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    80004c0e:	4505                	li	a0,1
    80004c10:	9782                	jalr	a5
    80004c12:	a8b5                	j	80004c8e <filewrite+0xfc>
      if (n1 > max)
    80004c14:	2981                	sext.w	s3,s3
      begin_op();
    80004c16:	8d7ff0ef          	jal	800044ec <begin_op>
      ilock(f->ip);
    80004c1a:	01893503          	ld	a0,24(s2)
    80004c1e:	eadfe0ef          	jal	80003aca <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004c22:	874e                	mv	a4,s3
    80004c24:	02092683          	lw	a3,32(s2)
    80004c28:	016a0633          	add	a2,s4,s6
    80004c2c:	85e2                	mv	a1,s8
    80004c2e:	01893503          	ld	a0,24(s2)
    80004c32:	b1cff0ef          	jal	80003f4e <writei>
    80004c36:	84aa                	mv	s1,a0
    80004c38:	00a05763          	blez	a0,80004c46 <filewrite+0xb4>
        f->off += r;
    80004c3c:	02092783          	lw	a5,32(s2)
    80004c40:	9fa9                	addw	a5,a5,a0
    80004c42:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004c46:	01893503          	ld	a0,24(s2)
    80004c4a:	f2ffe0ef          	jal	80003b78 <iunlock>
      end_op();
    80004c4e:	92bff0ef          	jal	80004578 <end_op>

      if (r != n1) {
    80004c52:	02999563          	bne	s3,s1,80004c7c <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    80004c56:	01448a3b          	addw	s4,s1,s4
    while (i < n) {
    80004c5a:	015a5963          	bge	s4,s5,80004c6c <filewrite+0xda>
      int n1 = n - i;
    80004c5e:	414a87bb          	subw	a5,s5,s4
    80004c62:	89be                	mv	s3,a5
      if (n1 > max)
    80004c64:	fafbd8e3          	bge	s7,a5,80004c14 <filewrite+0x82>
    80004c68:	89e6                	mv	s3,s9
    80004c6a:	b76d                	j	80004c14 <filewrite+0x82>
    80004c6c:	64a6                	ld	s1,72(sp)
    80004c6e:	79e2                	ld	s3,56(sp)
    80004c70:	6be2                	ld	s7,24(sp)
    80004c72:	6c42                	ld	s8,16(sp)
    80004c74:	6ca2                	ld	s9,8(sp)
    80004c76:	a801                	j	80004c86 <filewrite+0xf4>
    int i = 0;
    80004c78:	4a01                	li	s4,0
    80004c7a:	a031                	j	80004c86 <filewrite+0xf4>
    80004c7c:	64a6                	ld	s1,72(sp)
    80004c7e:	79e2                	ld	s3,56(sp)
    80004c80:	6be2                	ld	s7,24(sp)
    80004c82:	6c42                	ld	s8,16(sp)
    80004c84:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    80004c86:	034a9d63          	bne	s5,s4,80004cc0 <filewrite+0x12e>
    80004c8a:	8556                	mv	a0,s5
    80004c8c:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004c8e:	60e6                	ld	ra,88(sp)
    80004c90:	6446                	ld	s0,80(sp)
    80004c92:	6906                	ld	s2,64(sp)
    80004c94:	7aa2                	ld	s5,40(sp)
    80004c96:	7b02                	ld	s6,32(sp)
    80004c98:	6125                	addi	sp,sp,96
    80004c9a:	8082                	ret
    80004c9c:	e4a6                	sd	s1,72(sp)
    80004c9e:	fc4e                	sd	s3,56(sp)
    80004ca0:	f852                	sd	s4,48(sp)
    80004ca2:	ec5e                	sd	s7,24(sp)
    80004ca4:	e862                	sd	s8,16(sp)
    80004ca6:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80004ca8:	00004517          	auipc	a0,0x4
    80004cac:	95050513          	addi	a0,a0,-1712 # 800085f8 <etext+0x5f8>
    80004cb0:	b85fb0ef          	jal	80000834 <panic>
    return -1;
    80004cb4:	557d                	li	a0,-1
}
    80004cb6:	8082                	ret
      return -1;
    80004cb8:	557d                	li	a0,-1
    80004cba:	bfd1                	j	80004c8e <filewrite+0xfc>
    80004cbc:	557d                	li	a0,-1
    80004cbe:	bfc1                	j	80004c8e <filewrite+0xfc>
    ret = (i == n ? n : -1);
    80004cc0:	557d                	li	a0,-1
    80004cc2:	7a42                	ld	s4,48(sp)
    80004cc4:	b7e9                	j	80004c8e <filewrite+0xfc>

0000000080004cc6 <pipealloc>:
  int writeopen; // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004cc6:	7179                	addi	sp,sp,-48
    80004cc8:	f406                	sd	ra,40(sp)
    80004cca:	f022                	sd	s0,32(sp)
    80004ccc:	ec26                	sd	s1,24(sp)
    80004cce:	e052                	sd	s4,0(sp)
    80004cd0:	1800                	addi	s0,sp,48
    80004cd2:	84aa                	mv	s1,a0
    80004cd4:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004cd6:	0005b023          	sd	zero,0(a1)
    80004cda:	00053023          	sd	zero,0(a0)
  if ((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004cde:	c25ff0ef          	jal	80004902 <filealloc>
    80004ce2:	e088                	sd	a0,0(s1)
    80004ce4:	c549                	beqz	a0,80004d6e <pipealloc+0xa8>
    80004ce6:	c1dff0ef          	jal	80004902 <filealloc>
    80004cea:	00aa3023          	sd	a0,0(s4)
    80004cee:	cd25                	beqz	a0,80004d66 <pipealloc+0xa0>
    80004cf0:	e84a                	sd	s2,16(sp)
    goto bad;
  if ((pi = (struct pipe *)kalloc()) == 0)
    80004cf2:	e1dfb0ef          	jal	80000b0e <kalloc>
    80004cf6:	892a                	mv	s2,a0
    80004cf8:	c12d                	beqz	a0,80004d5a <pipealloc+0x94>
    80004cfa:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004cfc:	4985                	li	s3,1
    80004cfe:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004d02:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004d06:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004d0a:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004d0e:	00004597          	auipc	a1,0x4
    80004d12:	8fa58593          	addi	a1,a1,-1798 # 80008608 <etext+0x608>
    80004d16:	e53fb0ef          	jal	80000b68 <initlock>
  (*f0)->type = FD_PIPE;
    80004d1a:	609c                	ld	a5,0(s1)
    80004d1c:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004d20:	609c                	ld	a5,0(s1)
    80004d22:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004d26:	609c                	ld	a5,0(s1)
    80004d28:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004d2c:	609c                	ld	a5,0(s1)
    80004d2e:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004d32:	000a3783          	ld	a5,0(s4)
    80004d36:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004d3a:	000a3783          	ld	a5,0(s4)
    80004d3e:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004d42:	000a3783          	ld	a5,0(s4)
    80004d46:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004d4a:	000a3783          	ld	a5,0(s4)
    80004d4e:	0127b823          	sd	s2,16(a5)
  return 0;
    80004d52:	4501                	li	a0,0
    80004d54:	6942                	ld	s2,16(sp)
    80004d56:	69a2                	ld	s3,8(sp)
    80004d58:	a01d                	j	80004d7e <pipealloc+0xb8>

bad:
  if (pi)
    kfree((char *)pi);
  if (*f0)
    80004d5a:	6088                	ld	a0,0(s1)
    80004d5c:	c119                	beqz	a0,80004d62 <pipealloc+0x9c>
    80004d5e:	6942                	ld	s2,16(sp)
    80004d60:	a029                	j	80004d6a <pipealloc+0xa4>
    80004d62:	6942                	ld	s2,16(sp)
    80004d64:	a029                	j	80004d6e <pipealloc+0xa8>
    80004d66:	6088                	ld	a0,0(s1)
    80004d68:	c10d                	beqz	a0,80004d8a <pipealloc+0xc4>
    fileclose(*f0);
    80004d6a:	c3dff0ef          	jal	800049a6 <fileclose>
  if (*f1)
    80004d6e:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004d72:	557d                	li	a0,-1
  if (*f1)
    80004d74:	c789                	beqz	a5,80004d7e <pipealloc+0xb8>
    fileclose(*f1);
    80004d76:	853e                	mv	a0,a5
    80004d78:	c2fff0ef          	jal	800049a6 <fileclose>
  return -1;
    80004d7c:	557d                	li	a0,-1
}
    80004d7e:	70a2                	ld	ra,40(sp)
    80004d80:	7402                	ld	s0,32(sp)
    80004d82:	64e2                	ld	s1,24(sp)
    80004d84:	6a02                	ld	s4,0(sp)
    80004d86:	6145                	addi	sp,sp,48
    80004d88:	8082                	ret
  return -1;
    80004d8a:	557d                	li	a0,-1
    80004d8c:	bfcd                	j	80004d7e <pipealloc+0xb8>

0000000080004d8e <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004d8e:	1101                	addi	sp,sp,-32
    80004d90:	ec06                	sd	ra,24(sp)
    80004d92:	e822                	sd	s0,16(sp)
    80004d94:	e426                	sd	s1,8(sp)
    80004d96:	e04a                	sd	s2,0(sp)
    80004d98:	1000                	addi	s0,sp,32
    80004d9a:	84aa                	mv	s1,a0
    80004d9c:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004d9e:	e4bfb0ef          	jal	80000be8 <acquire>
  if (writable) {
    80004da2:	02090763          	beqz	s2,80004dd0 <pipeclose+0x42>
    pi->writeopen = 0;
    80004da6:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004daa:	21848513          	addi	a0,s1,536
    80004dae:	d36fd0ef          	jal	800022e4 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if (pi->readopen == 0 && pi->writeopen == 0) {
    80004db2:	2204a783          	lw	a5,544(s1)
    80004db6:	e781                	bnez	a5,80004dbe <pipeclose+0x30>
    80004db8:	2244a783          	lw	a5,548(s1)
    80004dbc:	c38d                	beqz	a5,80004dde <pipeclose+0x50>
    release(&pi->lock);
    kfree((char *)pi);
  } else
    release(&pi->lock);
    80004dbe:	8526                	mv	a0,s1
    80004dc0:	eb1fb0ef          	jal	80000c70 <release>
}
    80004dc4:	60e2                	ld	ra,24(sp)
    80004dc6:	6442                	ld	s0,16(sp)
    80004dc8:	64a2                	ld	s1,8(sp)
    80004dca:	6902                	ld	s2,0(sp)
    80004dcc:	6105                	addi	sp,sp,32
    80004dce:	8082                	ret
    pi->readopen = 0;
    80004dd0:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004dd4:	21c48513          	addi	a0,s1,540
    80004dd8:	d0cfd0ef          	jal	800022e4 <wakeup>
    80004ddc:	bfd9                	j	80004db2 <pipeclose+0x24>
    release(&pi->lock);
    80004dde:	8526                	mv	a0,s1
    80004de0:	e91fb0ef          	jal	80000c70 <release>
    kfree((char *)pi);
    80004de4:	8526                	mv	a0,s1
    80004de6:	c41fb0ef          	jal	80000a26 <kfree>
    80004dea:	bfe9                	j	80004dc4 <pipeclose+0x36>

0000000080004dec <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004dec:	7159                	addi	sp,sp,-112
    80004dee:	f486                	sd	ra,104(sp)
    80004df0:	f0a2                	sd	s0,96(sp)
    80004df2:	eca6                	sd	s1,88(sp)
    80004df4:	e8ca                	sd	s2,80(sp)
    80004df6:	e4ce                	sd	s3,72(sp)
    80004df8:	e0d2                	sd	s4,64(sp)
    80004dfa:	fc56                	sd	s5,56(sp)
    80004dfc:	1880                	addi	s0,sp,112
    80004dfe:	84aa                	mv	s1,a0
    80004e00:	8aae                	mv	s5,a1
    80004e02:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004e04:	af1fc0ef          	jal	800018f4 <myproc>
    80004e08:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004e0a:	8526                	mv	a0,s1
    80004e0c:	dddfb0ef          	jal	80000be8 <acquire>
  while (i < n) {
    80004e10:	0f405a63          	blez	s4,80004f04 <pipewrite+0x118>
    80004e14:	f85a                	sd	s6,48(sp)
    80004e16:	f45e                	sd	s7,40(sp)
    80004e18:	f062                	sd	s8,32(sp)
    80004e1a:	ec66                	sd	s9,24(sp)
    80004e1c:	e86a                	sd	s10,16(sp)
  int i = 0;
    80004e1e:	4901                	li	s2,0
      release(&pi->lock);
      sleep();
      acquire(&pi->lock);
    } else {
      char ch;
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    80004e20:	f9f40c13          	addi	s8,s0,-97
    80004e24:	4b85                	li	s7,1
    80004e26:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004e28:	21848d13          	addi	s10,s1,536
      sleep_prepare(&pi->nwrite);
    80004e2c:	21c48c93          	addi	s9,s1,540
    80004e30:	a0a1                	j	80004e78 <pipewrite+0x8c>
      release(&pi->lock);
    80004e32:	8526                	mv	a0,s1
    80004e34:	e3dfb0ef          	jal	80000c70 <release>
      return -1;
    80004e38:	597d                	li	s2,-1
    80004e3a:	7b42                	ld	s6,48(sp)
    80004e3c:	7ba2                	ld	s7,40(sp)
    80004e3e:	7c02                	ld	s8,32(sp)
    80004e40:	6ce2                	ld	s9,24(sp)
    80004e42:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004e44:	854a                	mv	a0,s2
    80004e46:	70a6                	ld	ra,104(sp)
    80004e48:	7406                	ld	s0,96(sp)
    80004e4a:	64e6                	ld	s1,88(sp)
    80004e4c:	6946                	ld	s2,80(sp)
    80004e4e:	69a6                	ld	s3,72(sp)
    80004e50:	6a06                	ld	s4,64(sp)
    80004e52:	7ae2                	ld	s5,56(sp)
    80004e54:	6165                	addi	sp,sp,112
    80004e56:	8082                	ret
      wakeup(&pi->nread);
    80004e58:	856a                	mv	a0,s10
    80004e5a:	c8afd0ef          	jal	800022e4 <wakeup>
      sleep_prepare(&pi->nwrite);
    80004e5e:	8566                	mv	a0,s9
    80004e60:	c18fd0ef          	jal	80002278 <sleep_prepare>
      release(&pi->lock);
    80004e64:	8526                	mv	a0,s1
    80004e66:	e0bfb0ef          	jal	80000c70 <release>
      sleep();
    80004e6a:	c4afd0ef          	jal	800022b4 <sleep>
      acquire(&pi->lock);
    80004e6e:	8526                	mv	a0,s1
    80004e70:	d79fb0ef          	jal	80000be8 <acquire>
  while (i < n) {
    80004e74:	07495b63          	bge	s2,s4,80004eea <pipewrite+0xfe>
    if (pi->readopen == 0 || killed(pr)) {
    80004e78:	2204a783          	lw	a5,544(s1)
    80004e7c:	dbdd                	beqz	a5,80004e32 <pipewrite+0x46>
    80004e7e:	854e                	mv	a0,s3
    80004e80:	daafd0ef          	jal	8000242a <killed>
    80004e84:	f55d                	bnez	a0,80004e32 <pipewrite+0x46>
    if (pi->nwrite == pi->nread + PIPESIZE) { //DOC: pipewrite-full
    80004e86:	2184a783          	lw	a5,536(s1)
    80004e8a:	21c4a703          	lw	a4,540(s1)
    80004e8e:	2007879b          	addiw	a5,a5,512
    80004e92:	fcf703e3          	beq	a4,a5,80004e58 <pipewrite+0x6c>
      if (copyin(pr->pagetable, pr->sz, &ch, addr + i, 1) == -1) {
    80004e96:	875e                	mv	a4,s7
    80004e98:	015906b3          	add	a3,s2,s5
    80004e9c:	8662                	mv	a2,s8
    80004e9e:	0609b583          	ld	a1,96(s3)
    80004ea2:	0689b503          	ld	a0,104(s3)
    80004ea6:	f66fc0ef          	jal	8000160c <copyin>
    80004eaa:	03650163          	beq	a0,s6,80004ecc <pipewrite+0xe0>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004eae:	21c4a783          	lw	a5,540(s1)
    80004eb2:	0017871b          	addiw	a4,a5,1
    80004eb6:	20e4ae23          	sw	a4,540(s1)
    80004eba:	1ff7f793          	andi	a5,a5,511
    80004ebe:	97a6                	add	a5,a5,s1
    80004ec0:	f9f44703          	lbu	a4,-97(s0)
    80004ec4:	00e78c23          	sb	a4,24(a5)
      i++;
    80004ec8:	2905                	addiw	s2,s2,1
    80004eca:	b76d                	j	80004e74 <pipewrite+0x88>
        if (i == 0)
    80004ecc:	00090863          	beqz	s2,80004edc <pipewrite+0xf0>
    80004ed0:	7b42                	ld	s6,48(sp)
    80004ed2:	7ba2                	ld	s7,40(sp)
    80004ed4:	7c02                	ld	s8,32(sp)
    80004ed6:	6ce2                	ld	s9,24(sp)
    80004ed8:	6d42                	ld	s10,16(sp)
    80004eda:	a829                	j	80004ef4 <pipewrite+0x108>
          i = -1;
    80004edc:	892a                	mv	s2,a0
        break;
    80004ede:	7b42                	ld	s6,48(sp)
    80004ee0:	7ba2                	ld	s7,40(sp)
    80004ee2:	7c02                	ld	s8,32(sp)
    80004ee4:	6ce2                	ld	s9,24(sp)
    80004ee6:	6d42                	ld	s10,16(sp)
    80004ee8:	a031                	j	80004ef4 <pipewrite+0x108>
    80004eea:	7b42                	ld	s6,48(sp)
    80004eec:	7ba2                	ld	s7,40(sp)
    80004eee:	7c02                	ld	s8,32(sp)
    80004ef0:	6ce2                	ld	s9,24(sp)
    80004ef2:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80004ef4:	21848513          	addi	a0,s1,536
    80004ef8:	becfd0ef          	jal	800022e4 <wakeup>
  release(&pi->lock);
    80004efc:	8526                	mv	a0,s1
    80004efe:	d73fb0ef          	jal	80000c70 <release>
  return i;
    80004f02:	b789                	j	80004e44 <pipewrite+0x58>
  int i = 0;
    80004f04:	4901                	li	s2,0
    80004f06:	b7fd                	j	80004ef4 <pipewrite+0x108>

0000000080004f08 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004f08:	711d                	addi	sp,sp,-96
    80004f0a:	ec86                	sd	ra,88(sp)
    80004f0c:	e8a2                	sd	s0,80(sp)
    80004f0e:	e4a6                	sd	s1,72(sp)
    80004f10:	e0ca                	sd	s2,64(sp)
    80004f12:	fc4e                	sd	s3,56(sp)
    80004f14:	f852                	sd	s4,48(sp)
    80004f16:	f456                	sd	s5,40(sp)
    80004f18:	1080                	addi	s0,sp,96
    80004f1a:	84aa                	mv	s1,a0
    80004f1c:	89ae                	mv	s3,a1
    80004f1e:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004f20:	9d5fc0ef          	jal	800018f4 <myproc>
    80004f24:	892a                	mv	s2,a0
  char ch;

  acquire(&pi->lock);
    80004f26:	8526                	mv	a0,s1
    80004f28:	cc1fb0ef          	jal	80000be8 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004f2c:	2184a703          	lw	a4,536(s1)
    80004f30:	21c4a783          	lw	a5,540(s1)
    if (killed(pr)) {
      release(&pi->lock);
      return -1;
    }
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    80004f34:	21848a13          	addi	s4,s1,536
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004f38:	02f71e63          	bne	a4,a5,80004f74 <piperead+0x6c>
    80004f3c:	2244a783          	lw	a5,548(s1)
    80004f40:	c3b9                	beqz	a5,80004f86 <piperead+0x7e>
    if (killed(pr)) {
    80004f42:	854a                	mv	a0,s2
    80004f44:	ce6fd0ef          	jal	8000242a <killed>
    80004f48:	e915                	bnez	a0,80004f7c <piperead+0x74>
    sleep_prepare(&pi->nread); //DOC: piperead-sleep
    80004f4a:	8552                	mv	a0,s4
    80004f4c:	b2cfd0ef          	jal	80002278 <sleep_prepare>
    release(&pi->lock);
    80004f50:	8526                	mv	a0,s1
    80004f52:	d1ffb0ef          	jal	80000c70 <release>
    sleep();
    80004f56:	b5efd0ef          	jal	800022b4 <sleep>
    acquire(&pi->lock);
    80004f5a:	8526                	mv	a0,s1
    80004f5c:	c8dfb0ef          	jal	80000be8 <acquire>
  while (pi->nread == pi->nwrite && pi->writeopen) { //DOC: pipe-empty
    80004f60:	2184a703          	lw	a4,536(s1)
    80004f64:	21c4a783          	lw	a5,540(s1)
    80004f68:	fcf70ae3          	beq	a4,a5,80004f3c <piperead+0x34>
    80004f6c:	f05a                	sd	s6,32(sp)
    80004f6e:	ec5e                	sd	s7,24(sp)
    80004f70:	e862                	sd	s8,16(sp)
    80004f72:	a829                	j	80004f8c <piperead+0x84>
    80004f74:	f05a                	sd	s6,32(sp)
    80004f76:	ec5e                	sd	s7,24(sp)
    80004f78:	e862                	sd	s8,16(sp)
    80004f7a:	a809                	j	80004f8c <piperead+0x84>
      release(&pi->lock);
    80004f7c:	8526                	mv	a0,s1
    80004f7e:	cf3fb0ef          	jal	80000c70 <release>
      return -1;
    80004f82:	5a7d                	li	s4,-1
    80004f84:	a0b5                	j	80004ff0 <piperead+0xe8>
    80004f86:	f05a                	sd	s6,32(sp)
    80004f88:	ec5e                	sd	s7,24(sp)
    80004f8a:	e862                	sd	s8,16(sp)
  }
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004f8c:	4a01                	li	s4,0
    if (pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004f8e:	faf40c13          	addi	s8,s0,-81
    80004f92:	4b85                	li	s7,1
    80004f94:	5b7d                	li	s6,-1
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004f96:	05505363          	blez	s5,80004fdc <piperead+0xd4>
    if (pi->nread == pi->nwrite)
    80004f9a:	2184a783          	lw	a5,536(s1)
    80004f9e:	21c4a703          	lw	a4,540(s1)
    80004fa2:	02f70d63          	beq	a4,a5,80004fdc <piperead+0xd4>
    ch = pi->data[pi->nread % PIPESIZE];
    80004fa6:	1ff7f793          	andi	a5,a5,511
    80004faa:	97a6                	add	a5,a5,s1
    80004fac:	0187c783          	lbu	a5,24(a5)
    80004fb0:	faf407a3          	sb	a5,-81(s0)
    if (copyout(pr->pagetable, pr->sz, addr + i, &ch, 1) == -1) {
    80004fb4:	875e                	mv	a4,s7
    80004fb6:	86e2                	mv	a3,s8
    80004fb8:	864e                	mv	a2,s3
    80004fba:	06093583          	ld	a1,96(s2)
    80004fbe:	06893503          	ld	a0,104(s2)
    80004fc2:	d84fc0ef          	jal	80001546 <copyout>
    80004fc6:	03650f63          	beq	a0,s6,80005004 <piperead+0xfc>
      if (i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    80004fca:	2184a783          	lw	a5,536(s1)
    80004fce:	2785                	addiw	a5,a5,1
    80004fd0:	20f4ac23          	sw	a5,536(s1)
  for (i = 0; i < n; i++) { //DOC: piperead-copy
    80004fd4:	2a05                	addiw	s4,s4,1
    80004fd6:	0985                	addi	s3,s3,1
    80004fd8:	fd4a91e3          	bne	s5,s4,80004f9a <piperead+0x92>
  }
  wakeup(&pi->nwrite); //DOC: piperead-wakeup
    80004fdc:	21c48513          	addi	a0,s1,540
    80004fe0:	b04fd0ef          	jal	800022e4 <wakeup>
  release(&pi->lock);
    80004fe4:	8526                	mv	a0,s1
    80004fe6:	c8bfb0ef          	jal	80000c70 <release>
    80004fea:	7b02                	ld	s6,32(sp)
    80004fec:	6be2                	ld	s7,24(sp)
    80004fee:	6c42                	ld	s8,16(sp)
  return i;
}
    80004ff0:	8552                	mv	a0,s4
    80004ff2:	60e6                	ld	ra,88(sp)
    80004ff4:	6446                	ld	s0,80(sp)
    80004ff6:	64a6                	ld	s1,72(sp)
    80004ff8:	6906                	ld	s2,64(sp)
    80004ffa:	79e2                	ld	s3,56(sp)
    80004ffc:	7a42                	ld	s4,48(sp)
    80004ffe:	7aa2                	ld	s5,40(sp)
    80005000:	6125                	addi	sp,sp,96
    80005002:	8082                	ret
      if (i == 0)
    80005004:	fc0a1ce3          	bnez	s4,80004fdc <piperead+0xd4>
        i = -1;
    80005008:	8a2a                	mv	s4,a0
    8000500a:	bfc9                	j	80004fdc <piperead+0xd4>

000000008000500c <flags2perm>:
static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int
flags2perm(int flags)
{
    8000500c:	1141                	addi	sp,sp,-16
    8000500e:	e406                	sd	ra,8(sp)
    80005010:	e022                	sd	s0,0(sp)
    80005012:	0800                	addi	s0,sp,16
    80005014:	87aa                	mv	a5,a0
  int perm = 0;
  if (flags & 0x1)
    80005016:	0035151b          	slliw	a0,a0,0x3
    8000501a:	8921                	andi	a0,a0,8
    perm = PTE_X;
  if (flags & 0x2)
    8000501c:	8b89                	andi	a5,a5,2
    8000501e:	c399                	beqz	a5,80005024 <flags2perm+0x18>
    perm |= PTE_W;
    80005020:	00456513          	ori	a0,a0,4
  return perm;
}
    80005024:	60a2                	ld	ra,8(sp)
    80005026:	6402                	ld	s0,0(sp)
    80005028:	0141                	addi	sp,sp,16
    8000502a:	8082                	ret

000000008000502c <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    8000502c:	de010113          	addi	sp,sp,-544
    80005030:	20113c23          	sd	ra,536(sp)
    80005034:	20813823          	sd	s0,528(sp)
    80005038:	20913423          	sd	s1,520(sp)
    8000503c:	21213023          	sd	s2,512(sp)
    80005040:	1400                	addi	s0,sp,544
    80005042:	892a                	mv	s2,a0
    80005044:	dea43823          	sd	a0,-528(s0)
    80005048:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    8000504c:	8a9fc0ef          	jal	800018f4 <myproc>
    80005050:	84aa                	mv	s1,a0

  begin_op();
    80005052:	c9aff0ef          	jal	800044ec <begin_op>

  // Open the executable file.
  if ((ip = namei(path)) == 0) {
    80005056:	854a                	mv	a0,s2
    80005058:	ab6ff0ef          	jal	8000430e <namei>
    8000505c:	cd21                	beqz	a0,800050b4 <kexec+0x88>
    8000505e:	fbd2                	sd	s4,496(sp)
    80005060:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80005062:	a69fe0ef          	jal	80003aca <ilock>

  // Read the ELF header.
  if (readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80005066:	04000713          	li	a4,64
    8000506a:	4681                	li	a3,0
    8000506c:	e5040613          	addi	a2,s0,-432
    80005070:	4581                	li	a1,0
    80005072:	8552                	mv	a0,s4
    80005074:	de9fe0ef          	jal	80003e5c <readi>
    80005078:	04000793          	li	a5,64
    8000507c:	00f51a63          	bne	a0,a5,80005090 <kexec+0x64>
    goto bad;

  // Is this really an ELF file?
  if (elf.magic != ELF_MAGIC)
    80005080:	e5042703          	lw	a4,-432(s0)
    80005084:	464c47b7          	lui	a5,0x464c4
    80005088:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    8000508c:	02f70863          	beq	a4,a5,800050bc <kexec+0x90>

bad:
  if (pagetable)
    proc_freepagetable(pagetable, sz);
  if (ip) {
    iunlockput(ip);
    80005090:	8552                	mv	a0,s4
    80005092:	c45fe0ef          	jal	80003cd6 <iunlockput>
    end_op();
    80005096:	ce2ff0ef          	jal	80004578 <end_op>
  }
  return -1;
    8000509a:	557d                	li	a0,-1
    8000509c:	7a5e                	ld	s4,496(sp)
}
    8000509e:	21813083          	ld	ra,536(sp)
    800050a2:	21013403          	ld	s0,528(sp)
    800050a6:	20813483          	ld	s1,520(sp)
    800050aa:	20013903          	ld	s2,512(sp)
    800050ae:	22010113          	addi	sp,sp,544
    800050b2:	8082                	ret
    end_op();
    800050b4:	cc4ff0ef          	jal	80004578 <end_op>
    return -1;
    800050b8:	557d                	li	a0,-1
    800050ba:	b7d5                	j	8000509e <kexec+0x72>
    800050bc:	f3da                	sd	s6,480(sp)
  if ((pagetable = proc_pagetable(p)) == 0)
    800050be:	8526                	mv	a0,s1
    800050c0:	94bfc0ef          	jal	80001a0a <proc_pagetable>
    800050c4:	8b2a                	mv	s6,a0
    800050c6:	26050e63          	beqz	a0,80005342 <kexec+0x316>
    800050ca:	ffce                	sd	s3,504(sp)
    800050cc:	f7d6                	sd	s5,488(sp)
    800050ce:	efde                	sd	s7,472(sp)
    800050d0:	ebe2                	sd	s8,464(sp)
    800050d2:	e7e6                	sd	s9,456(sp)
    800050d4:	e3ea                	sd	s10,448(sp)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    800050d6:	e8845783          	lhu	a5,-376(s0)
    800050da:	14078263          	beqz	a5,8000521e <kexec+0x1f2>
    800050de:	ff6e                	sd	s11,440(sp)
    800050e0:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800050e4:	4901                	li	s2,0
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    800050e6:	4d01                	li	s10,0
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800050e8:	03800d93          	li	s11,56
    if (ph.vaddr % PGSIZE != 0)
    800050ec:	6c85                	lui	s9,0x1
    800050ee:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    800050f2:	def43423          	sd	a5,-536(s0)

  for (i = 0; i < sz; i += PGSIZE) {
    pa = walkaddr(pagetable, va + i);
    if (pa == 0)
      panic("loadseg: address should exist");
    if (sz - i < PGSIZE)
    800050f6:	6a85                	lui	s5,0x1
    800050f8:	a085                	j	80005158 <kexec+0x12c>
      panic("loadseg: address should exist");
    800050fa:	00003517          	auipc	a0,0x3
    800050fe:	51650513          	addi	a0,a0,1302 # 80008610 <etext+0x610>
    80005102:	f32fb0ef          	jal	80000834 <panic>
    if (sz - i < PGSIZE)
    80005106:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if (readi(ip, 0, (uint64)pa, offset + i, n) != n)
    80005108:	874a                	mv	a4,s2
    8000510a:	009b86bb          	addw	a3,s7,s1
    8000510e:	4581                	li	a1,0
    80005110:	8552                	mv	a0,s4
    80005112:	d4bfe0ef          	jal	80003e5c <readi>
    80005116:	22a91a63          	bne	s2,a0,8000534a <kexec+0x31e>
  for (i = 0; i < sz; i += PGSIZE) {
    8000511a:	009a84bb          	addw	s1,s5,s1
    8000511e:	0334f263          	bgeu	s1,s3,80005142 <kexec+0x116>
    pa = walkaddr(pagetable, va + i);
    80005122:	02049593          	slli	a1,s1,0x20
    80005126:	9181                	srli	a1,a1,0x20
    80005128:	95e2                	add	a1,a1,s8
    8000512a:	855a                	mv	a0,s6
    8000512c:	eb1fb0ef          	jal	80000fdc <walkaddr>
    80005130:	862a                	mv	a2,a0
    if (pa == 0)
    80005132:	d561                	beqz	a0,800050fa <kexec+0xce>
    if (sz - i < PGSIZE)
    80005134:	409987bb          	subw	a5,s3,s1
    80005138:	893e                	mv	s2,a5
    8000513a:	fcfcf6e3          	bgeu	s9,a5,80005106 <kexec+0xda>
    8000513e:	8956                	mv	s2,s5
    80005140:	b7d9                	j	80005106 <kexec+0xda>
    sz = sz1;
    80005142:	df843903          	ld	s2,-520(s0)
  for (i = 0, off = elf.phoff; i < elf.phnum; i++, off += sizeof(ph)) {
    80005146:	2d05                	addiw	s10,s10,1
    80005148:	e0843783          	ld	a5,-504(s0)
    8000514c:	0387869b          	addiw	a3,a5,56
    80005150:	e8845783          	lhu	a5,-376(s0)
    80005154:	06fd5d63          	bge	s10,a5,800051ce <kexec+0x1a2>
    if (readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80005158:	e0d43423          	sd	a3,-504(s0)
    8000515c:	876e                	mv	a4,s11
    8000515e:	e1840613          	addi	a2,s0,-488
    80005162:	4581                	li	a1,0
    80005164:	8552                	mv	a0,s4
    80005166:	cf7fe0ef          	jal	80003e5c <readi>
    8000516a:	1db51e63          	bne	a0,s11,80005346 <kexec+0x31a>
    if (ph.type != ELF_PROG_LOAD)
    8000516e:	e1842783          	lw	a5,-488(s0)
    80005172:	4705                	li	a4,1
    80005174:	fce799e3          	bne	a5,a4,80005146 <kexec+0x11a>
    if (ph.memsz < ph.filesz)
    80005178:	e4043483          	ld	s1,-448(s0)
    8000517c:	e3843783          	ld	a5,-456(s0)
    80005180:	1ef4e363          	bltu	s1,a5,80005366 <kexec+0x33a>
    if (ph.vaddr + ph.memsz < ph.vaddr)
    80005184:	e2843783          	ld	a5,-472(s0)
    80005188:	94be                	add	s1,s1,a5
    8000518a:	1ef4e163          	bltu	s1,a5,8000536c <kexec+0x340>
    if (ph.vaddr % PGSIZE != 0)
    8000518e:	de843703          	ld	a4,-536(s0)
    80005192:	8ff9                	and	a5,a5,a4
    80005194:	1c079f63          	bnez	a5,80005372 <kexec+0x346>
    if ((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz,
    80005198:	e1c42503          	lw	a0,-484(s0)
    8000519c:	e71ff0ef          	jal	8000500c <flags2perm>
    800051a0:	86aa                	mv	a3,a0
    800051a2:	8626                	mv	a2,s1
    800051a4:	85ca                	mv	a1,s2
    800051a6:	855a                	mv	a0,s6
    800051a8:	90afc0ef          	jal	800012b2 <uvmalloc>
    800051ac:	dea43c23          	sd	a0,-520(s0)
    800051b0:	1c050463          	beqz	a0,80005378 <kexec+0x34c>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    800051b4:	e3842983          	lw	s3,-456(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    800051b8:	00098863          	beqz	s3,800051c8 <kexec+0x19c>
    if (loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    800051bc:	e2843c03          	ld	s8,-472(s0)
    800051c0:	e2042b83          	lw	s7,-480(s0)
  for (i = 0; i < sz; i += PGSIZE) {
    800051c4:	4481                	li	s1,0
    800051c6:	bfb1                	j	80005122 <kexec+0xf6>
    sz = sz1;
    800051c8:	df843903          	ld	s2,-520(s0)
    800051cc:	bfad                	j	80005146 <kexec+0x11a>
    800051ce:	7dfa                	ld	s11,440(sp)
  iunlockput(ip);
    800051d0:	8552                	mv	a0,s4
    800051d2:	b05fe0ef          	jal	80003cd6 <iunlockput>
  end_op();
    800051d6:	ba2ff0ef          	jal	80004578 <end_op>
  p = myproc();
    800051da:	f1afc0ef          	jal	800018f4 <myproc>
    800051de:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    800051e0:	06053a83          	ld	s5,96(a0)
  sz = PGROUNDUP(sz);
    800051e4:	6c05                	lui	s8,0x1
    800051e6:	1c7d                	addi	s8,s8,-1 # fff <_entry-0x7ffff001>
    800051e8:	9c4a                	add	s8,s8,s2
    800051ea:	77fd                	lui	a5,0xfffff
    800051ec:	00fc7c33          	and	s8,s8,a5
  if ((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK + 1) * PGSIZE, PTE_W)) ==
    800051f0:	4691                	li	a3,4
    800051f2:	6609                	lui	a2,0x2
    800051f4:	9662                	add	a2,a2,s8
    800051f6:	85e2                	mv	a1,s8
    800051f8:	855a                	mv	a0,s6
    800051fa:	8b8fc0ef          	jal	800012b2 <uvmalloc>
    800051fe:	892a                	mv	s2,a0
    80005200:	e10d                	bnez	a0,80005222 <kexec+0x1f6>
    proc_freepagetable(pagetable, sz);
    80005202:	85e2                	mv	a1,s8
    80005204:	855a                	mv	a0,s6
    80005206:	889fc0ef          	jal	80001a8e <proc_freepagetable>
  return -1;
    8000520a:	557d                	li	a0,-1
    8000520c:	79fe                	ld	s3,504(sp)
    8000520e:	7a5e                	ld	s4,496(sp)
    80005210:	7abe                	ld	s5,488(sp)
    80005212:	7b1e                	ld	s6,480(sp)
    80005214:	6bfe                	ld	s7,472(sp)
    80005216:	6c5e                	ld	s8,464(sp)
    80005218:	6cbe                	ld	s9,456(sp)
    8000521a:	6d1e                	ld	s10,448(sp)
    8000521c:	b549                	j	8000509e <kexec+0x72>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000521e:	4901                	li	s2,0
    80005220:	bf45                	j	800051d0 <kexec+0x1a4>
  uvmclear(pagetable, sz - (USERSTACK + 1) * PGSIZE);
    80005222:	75f9                	lui	a1,0xffffe
    80005224:	95aa                	add	a1,a1,a0
    80005226:	855a                	mv	a0,s6
    80005228:	a5cfc0ef          	jal	80001484 <uvmclear>
  stackbase = sp - USERSTACK * PGSIZE;
    8000522c:	80090a13          	addi	s4,s2,-2048
    80005230:	800a0a13          	addi	s4,s4,-2048
  for (argc = 0; argv[argc]; argc++) {
    80005234:	e0043783          	ld	a5,-512(s0)
    80005238:	6388                	ld	a0,0(a5)
    8000523a:	c545                	beqz	a0,800052e2 <kexec+0x2b6>
  sp = sz;
    8000523c:	8c4a                	mv	s8,s2
  for (argc = 0; argv[argc]; argc++) {
    8000523e:	4481                	li	s1,0
    ustack[argc] = sp;
    80005240:	e9040b93          	addi	s7,s0,-368
    sp -= strlen(argv[argc]) + 1;
    80005244:	beffb0ef          	jal	80000e32 <strlen>
    80005248:	0015079b          	addiw	a5,a0,1
    8000524c:	40fc07b3          	sub	a5,s8,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80005250:	ff07fc13          	andi	s8,a5,-16
    if (sp < stackbase)
    80005254:	134c6563          	bltu	s8,s4,8000537e <kexec+0x352>
    if (copyout(pagetable, sz, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80005258:	e0043d03          	ld	s10,-512(s0)
    8000525c:	000d3c83          	ld	s9,0(s10)
    80005260:	8566                	mv	a0,s9
    80005262:	bd1fb0ef          	jal	80000e32 <strlen>
    80005266:	0015071b          	addiw	a4,a0,1
    8000526a:	86e6                	mv	a3,s9
    8000526c:	8662                	mv	a2,s8
    8000526e:	85ca                	mv	a1,s2
    80005270:	855a                	mv	a0,s6
    80005272:	ad4fc0ef          	jal	80001546 <copyout>
    80005276:	10054663          	bltz	a0,80005382 <kexec+0x356>
    ustack[argc] = sp;
    8000527a:	00349793          	slli	a5,s1,0x3
    8000527e:	97de                	add	a5,a5,s7
    80005280:	0187b023          	sd	s8,0(a5) # fffffffffffff000 <end+0xffffffff7ffd9e98>
  for (argc = 0; argv[argc]; argc++) {
    80005284:	0485                	addi	s1,s1,1
    80005286:	008d0793          	addi	a5,s10,8
    8000528a:	e0f43023          	sd	a5,-512(s0)
    8000528e:	008d3503          	ld	a0,8(s10)
    80005292:	f94d                	bnez	a0,80005244 <kexec+0x218>
  ustack[argc] = 0;
    80005294:	00349793          	slli	a5,s1,0x3
    80005298:	f9078793          	addi	a5,a5,-112
    8000529c:	97a2                	add	a5,a5,s0
    8000529e:	f007b023          	sd	zero,-256(a5)
  sp -= (argc + 1) * sizeof(uint64);
    800052a2:	00349713          	slli	a4,s1,0x3
    800052a6:	0721                	addi	a4,a4,8
    800052a8:	40ec0bb3          	sub	s7,s8,a4
  sp -= sp % 16;
    800052ac:	ff0bfb93          	andi	s7,s7,-16
  sz = sz1;
    800052b0:	8c4a                	mv	s8,s2
  if (sp < stackbase)
    800052b2:	f54be8e3          	bltu	s7,s4,80005202 <kexec+0x1d6>
  if (copyout(pagetable, sz, sp, (char *)ustack, (argc + 1) * sizeof(uint64)) <
    800052b6:	e9040693          	addi	a3,s0,-368
    800052ba:	865e                	mv	a2,s7
    800052bc:	85ca                	mv	a1,s2
    800052be:	855a                	mv	a0,s6
    800052c0:	a86fc0ef          	jal	80001546 <copyout>
    800052c4:	f2054fe3          	bltz	a0,80005202 <kexec+0x1d6>
  p->trapframe->a1 = sp;
    800052c8:	0709b783          	ld	a5,112(s3)
    800052cc:	0777bc23          	sd	s7,120(a5)
  for (last = s = path; *s; s++)
    800052d0:	df043783          	ld	a5,-528(s0)
    800052d4:	0007c703          	lbu	a4,0(a5)
    800052d8:	c30d                	beqz	a4,800052fa <kexec+0x2ce>
    800052da:	0785                	addi	a5,a5,1
    if (*s == '/')
    800052dc:	02f00693          	li	a3,47
    800052e0:	a801                	j	800052f0 <kexec+0x2c4>
  sp = sz;
    800052e2:	8c4a                	mv	s8,s2
  for (argc = 0; argv[argc]; argc++) {
    800052e4:	4481                	li	s1,0
    800052e6:	b77d                	j	80005294 <kexec+0x268>
  for (last = s = path; *s; s++)
    800052e8:	0785                	addi	a5,a5,1
    800052ea:	fff7c703          	lbu	a4,-1(a5)
    800052ee:	c711                	beqz	a4,800052fa <kexec+0x2ce>
    if (*s == '/')
    800052f0:	fed71ce3          	bne	a4,a3,800052e8 <kexec+0x2bc>
      last = s + 1;
    800052f4:	def43823          	sd	a5,-528(s0)
    800052f8:	bfc5                	j	800052e8 <kexec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    800052fa:	4641                	li	a2,16
    800052fc:	df043583          	ld	a1,-528(s0)
    80005300:	17098513          	addi	a0,s3,368
    80005304:	af9fb0ef          	jal	80000dfc <safestrcpy>
  oldpagetable = p->pagetable;
    80005308:	0689b503          	ld	a0,104(s3)
  p->pagetable = pagetable;
    8000530c:	0769b423          	sd	s6,104(s3)
  p->sz = sz;
    80005310:	0729b023          	sd	s2,96(s3)
  p->trapframe->epc = elf.entry; // initial program counter = ulib.c:start()
    80005314:	0709b783          	ld	a5,112(s3)
    80005318:	e6843703          	ld	a4,-408(s0)
    8000531c:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp;         // initial stack pointer
    8000531e:	0709b783          	ld	a5,112(s3)
    80005322:	0377b823          	sd	s7,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80005326:	85d6                	mv	a1,s5
    80005328:	f66fc0ef          	jal	80001a8e <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    8000532c:	0004851b          	sext.w	a0,s1
    80005330:	79fe                	ld	s3,504(sp)
    80005332:	7a5e                	ld	s4,496(sp)
    80005334:	7abe                	ld	s5,488(sp)
    80005336:	7b1e                	ld	s6,480(sp)
    80005338:	6bfe                	ld	s7,472(sp)
    8000533a:	6c5e                	ld	s8,464(sp)
    8000533c:	6cbe                	ld	s9,456(sp)
    8000533e:	6d1e                	ld	s10,448(sp)
    80005340:	bbb9                	j	8000509e <kexec+0x72>
    80005342:	7b1e                	ld	s6,480(sp)
    80005344:	b3b1                	j	80005090 <kexec+0x64>
    80005346:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    8000534a:	df843583          	ld	a1,-520(s0)
    8000534e:	855a                	mv	a0,s6
    80005350:	f3efc0ef          	jal	80001a8e <proc_freepagetable>
  if (ip) {
    80005354:	79fe                	ld	s3,504(sp)
    80005356:	7abe                	ld	s5,488(sp)
    80005358:	7b1e                	ld	s6,480(sp)
    8000535a:	6bfe                	ld	s7,472(sp)
    8000535c:	6c5e                	ld	s8,464(sp)
    8000535e:	6cbe                	ld	s9,456(sp)
    80005360:	6d1e                	ld	s10,448(sp)
    80005362:	7dfa                	ld	s11,440(sp)
    80005364:	b335                	j	80005090 <kexec+0x64>
    80005366:	df243c23          	sd	s2,-520(s0)
    8000536a:	b7c5                	j	8000534a <kexec+0x31e>
    8000536c:	df243c23          	sd	s2,-520(s0)
    80005370:	bfe9                	j	8000534a <kexec+0x31e>
    80005372:	df243c23          	sd	s2,-520(s0)
    80005376:	bfd1                	j	8000534a <kexec+0x31e>
    80005378:	df243c23          	sd	s2,-520(s0)
    8000537c:	b7f9                	j	8000534a <kexec+0x31e>
  sz = sz1;
    8000537e:	8c4a                	mv	s8,s2
    80005380:	b549                	j	80005202 <kexec+0x1d6>
    80005382:	8c4a                	mv	s8,s2
    80005384:	bdbd                	j	80005202 <kexec+0x1d6>

0000000080005386 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80005386:	7179                	addi	sp,sp,-48
    80005388:	f406                	sd	ra,40(sp)
    8000538a:	f022                	sd	s0,32(sp)
    8000538c:	ec26                	sd	s1,24(sp)
    8000538e:	e84a                	sd	s2,16(sp)
    80005390:	1800                	addi	s0,sp,48
    80005392:	892e                	mv	s2,a1
    80005394:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80005396:	fdc40593          	addi	a1,s0,-36
    8000539a:	c3ffd0ef          	jal	80002fd8 <argint>
  if (fd < 0 || fd >= NOFILE || (f = myproc()->ofile[fd]) == 0)
    8000539e:	fdc42703          	lw	a4,-36(s0)
    800053a2:	47bd                	li	a5,15
    800053a4:	02e7ea63          	bltu	a5,a4,800053d8 <argfd+0x52>
    800053a8:	d4cfc0ef          	jal	800018f4 <myproc>
    800053ac:	fdc42703          	lw	a4,-36(s0)
    800053b0:	00371793          	slli	a5,a4,0x3
    800053b4:	0e078793          	addi	a5,a5,224
    800053b8:	953e                	add	a0,a0,a5
    800053ba:	651c                	ld	a5,8(a0)
    800053bc:	c385                	beqz	a5,800053dc <argfd+0x56>
    return -1;
  if (pfd)
    800053be:	00090463          	beqz	s2,800053c6 <argfd+0x40>
    *pfd = fd;
    800053c2:	00e92023          	sw	a4,0(s2)
  if (pf)
    *pf = f;
  return 0;
    800053c6:	4501                	li	a0,0
  if (pf)
    800053c8:	c091                	beqz	s1,800053cc <argfd+0x46>
    *pf = f;
    800053ca:	e09c                	sd	a5,0(s1)
}
    800053cc:	70a2                	ld	ra,40(sp)
    800053ce:	7402                	ld	s0,32(sp)
    800053d0:	64e2                	ld	s1,24(sp)
    800053d2:	6942                	ld	s2,16(sp)
    800053d4:	6145                	addi	sp,sp,48
    800053d6:	8082                	ret
    return -1;
    800053d8:	557d                	li	a0,-1
    800053da:	bfcd                	j	800053cc <argfd+0x46>
    800053dc:	557d                	li	a0,-1
    800053de:	b7fd                	j	800053cc <argfd+0x46>

00000000800053e0 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    800053e0:	1101                	addi	sp,sp,-32
    800053e2:	ec06                	sd	ra,24(sp)
    800053e4:	e822                	sd	s0,16(sp)
    800053e6:	e426                	sd	s1,8(sp)
    800053e8:	1000                	addi	s0,sp,32
    800053ea:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    800053ec:	d08fc0ef          	jal	800018f4 <myproc>
    800053f0:	862a                	mv	a2,a0

  for (fd = 0; fd < NOFILE; fd++) {
    800053f2:	0e850793          	addi	a5,a0,232
    800053f6:	4501                	li	a0,0
    800053f8:	46c1                	li	a3,16
    if (p->ofile[fd] == 0) {
    800053fa:	6398                	ld	a4,0(a5)
    800053fc:	cb19                	beqz	a4,80005412 <fdalloc+0x32>
  for (fd = 0; fd < NOFILE; fd++) {
    800053fe:	2505                	addiw	a0,a0,1
    80005400:	07a1                	addi	a5,a5,8
    80005402:	fed51ce3          	bne	a0,a3,800053fa <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80005406:	557d                	li	a0,-1
}
    80005408:	60e2                	ld	ra,24(sp)
    8000540a:	6442                	ld	s0,16(sp)
    8000540c:	64a2                	ld	s1,8(sp)
    8000540e:	6105                	addi	sp,sp,32
    80005410:	8082                	ret
      p->ofile[fd] = f;
    80005412:	00351793          	slli	a5,a0,0x3
    80005416:	0e078793          	addi	a5,a5,224
    8000541a:	963e                	add	a2,a2,a5
    8000541c:	e604                	sd	s1,8(a2)
      return fd;
    8000541e:	b7ed                	j	80005408 <fdalloc+0x28>

0000000080005420 <create>:
  return -1;
}

static struct inode *
create(char *path, short type, short major, short minor)
{
    80005420:	715d                	addi	sp,sp,-80
    80005422:	e486                	sd	ra,72(sp)
    80005424:	e0a2                	sd	s0,64(sp)
    80005426:	fc26                	sd	s1,56(sp)
    80005428:	f84a                	sd	s2,48(sp)
    8000542a:	f052                	sd	s4,32(sp)
    8000542c:	ec56                	sd	s5,24(sp)
    8000542e:	e85a                	sd	s6,16(sp)
    80005430:	0880                	addi	s0,sp,80
    80005432:	8a2e                	mv	s4,a1
    80005434:	8ab2                	mv	s5,a2
    80005436:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if ((dp = nameiparent(path, name)) == 0)
    80005438:	fb040593          	addi	a1,s0,-80
    8000543c:	eedfe0ef          	jal	80004328 <nameiparent>
    80005440:	84aa                	mv	s1,a0
    80005442:	12050363          	beqz	a0,80005568 <create+0x148>
    return 0;

  ilock(dp);
    80005446:	e84fe0ef          	jal	80003aca <ilock>

  if (dp->nlink == 0) {
    8000544a:	04a49783          	lh	a5,74(s1)
    8000544e:	c7a1                	beqz	a5,80005496 <create+0x76>
    iunlockput(dp);
    return 0;
  }

  if ((ip = dirlookup(dp, name, 0)) != 0) {
    80005450:	4601                	li	a2,0
    80005452:	fb040593          	addi	a1,s0,-80
    80005456:	8526                	mv	a0,s1
    80005458:	c13fe0ef          	jal	8000406a <dirlookup>
    8000545c:	892a                	mv	s2,a0
    8000545e:	c531                	beqz	a0,800054aa <create+0x8a>
    iunlockput(dp);
    80005460:	8526                	mv	a0,s1
    80005462:	875fe0ef          	jal	80003cd6 <iunlockput>
    ilock(ip);
    80005466:	854a                	mv	a0,s2
    80005468:	e62fe0ef          	jal	80003aca <ilock>
    if (type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    8000546c:	4789                	li	a5,2
    8000546e:	02fa1963          	bne	s4,a5,800054a0 <create+0x80>
    80005472:	04495783          	lhu	a5,68(s2)
    80005476:	37f9                	addiw	a5,a5,-2
    80005478:	17c2                	slli	a5,a5,0x30
    8000547a:	93c1                	srli	a5,a5,0x30
    8000547c:	4705                	li	a4,1
    8000547e:	02f76163          	bltu	a4,a5,800054a0 <create+0x80>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80005482:	854a                	mv	a0,s2
    80005484:	60a6                	ld	ra,72(sp)
    80005486:	6406                	ld	s0,64(sp)
    80005488:	74e2                	ld	s1,56(sp)
    8000548a:	7942                	ld	s2,48(sp)
    8000548c:	7a02                	ld	s4,32(sp)
    8000548e:	6ae2                	ld	s5,24(sp)
    80005490:	6b42                	ld	s6,16(sp)
    80005492:	6161                	addi	sp,sp,80
    80005494:	8082                	ret
    iunlockput(dp);
    80005496:	8526                	mv	a0,s1
    80005498:	83ffe0ef          	jal	80003cd6 <iunlockput>
    return 0;
    8000549c:	4901                	li	s2,0
    8000549e:	b7d5                	j	80005482 <create+0x62>
    iunlockput(ip);
    800054a0:	854a                	mv	a0,s2
    800054a2:	835fe0ef          	jal	80003cd6 <iunlockput>
    return 0;
    800054a6:	4901                	li	s2,0
    800054a8:	bfe9                	j	80005482 <create+0x62>
    800054aa:	f44e                	sd	s3,40(sp)
  if ((ip = ialloc(dp->dev, type)) == 0) {
    800054ac:	85d2                	mv	a1,s4
    800054ae:	4088                	lw	a0,0(s1)
    800054b0:	caafe0ef          	jal	8000395a <ialloc>
    800054b4:	89aa                	mv	s3,a0
    800054b6:	cd1d                	beqz	a0,800054f4 <create+0xd4>
  ilock(ip);
    800054b8:	e12fe0ef          	jal	80003aca <ilock>
  ip->major = major;
    800054bc:	05599323          	sh	s5,70(s3)
  ip->minor = minor;
    800054c0:	05699423          	sh	s6,72(s3)
  ip->nlink = 1;
    800054c4:	4705                	li	a4,1
    800054c6:	04e99523          	sh	a4,74(s3)
  iupdate(ip);
    800054ca:	854e                	mv	a0,s3
    800054cc:	d4afe0ef          	jal	80003a16 <iupdate>
  if (type == T_DIR) { // Create . and .. entries.
    800054d0:	4705                	li	a4,1
    800054d2:	02ea0763          	beq	s4,a4,80005500 <create+0xe0>
  if (dirlink(dp, name, ip->inum) < 0)
    800054d6:	0049a603          	lw	a2,4(s3)
    800054da:	fb040593          	addi	a1,s0,-80
    800054de:	8526                	mv	a0,s1
    800054e0:	d85fe0ef          	jal	80004264 <dirlink>
    800054e4:	06054563          	bltz	a0,8000554e <create+0x12e>
  iunlockput(dp);
    800054e8:	8526                	mv	a0,s1
    800054ea:	fecfe0ef          	jal	80003cd6 <iunlockput>
  return ip;
    800054ee:	894e                	mv	s2,s3
    800054f0:	79a2                	ld	s3,40(sp)
    800054f2:	bf41                	j	80005482 <create+0x62>
    iunlockput(dp);
    800054f4:	8526                	mv	a0,s1
    800054f6:	fe0fe0ef          	jal	80003cd6 <iunlockput>
    return 0;
    800054fa:	894e                	mv	s2,s3
    800054fc:	79a2                	ld	s3,40(sp)
    800054fe:	b751                	j	80005482 <create+0x62>
    if (dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80005500:	0049a603          	lw	a2,4(s3)
    80005504:	00003597          	auipc	a1,0x3
    80005508:	12c58593          	addi	a1,a1,300 # 80008630 <etext+0x630>
    8000550c:	854e                	mv	a0,s3
    8000550e:	d57fe0ef          	jal	80004264 <dirlink>
    80005512:	02054e63          	bltz	a0,8000554e <create+0x12e>
    80005516:	40d0                	lw	a2,4(s1)
    80005518:	00003597          	auipc	a1,0x3
    8000551c:	12058593          	addi	a1,a1,288 # 80008638 <etext+0x638>
    80005520:	854e                	mv	a0,s3
    80005522:	d43fe0ef          	jal	80004264 <dirlink>
    80005526:	02054463          	bltz	a0,8000554e <create+0x12e>
  if (dirlink(dp, name, ip->inum) < 0)
    8000552a:	0049a603          	lw	a2,4(s3)
    8000552e:	fb040593          	addi	a1,s0,-80
    80005532:	8526                	mv	a0,s1
    80005534:	d31fe0ef          	jal	80004264 <dirlink>
    80005538:	00054b63          	bltz	a0,8000554e <create+0x12e>
    dp->nlink++; // for ".."
    8000553c:	04a4d783          	lhu	a5,74(s1)
    80005540:	2785                	addiw	a5,a5,1
    80005542:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005546:	8526                	mv	a0,s1
    80005548:	ccefe0ef          	jal	80003a16 <iupdate>
    8000554c:	bf71                	j	800054e8 <create+0xc8>
  ip->nlink = 0;
    8000554e:	04099523          	sh	zero,74(s3)
  iupdate(ip);
    80005552:	854e                	mv	a0,s3
    80005554:	cc2fe0ef          	jal	80003a16 <iupdate>
  iunlockput(ip);
    80005558:	854e                	mv	a0,s3
    8000555a:	f7cfe0ef          	jal	80003cd6 <iunlockput>
  iunlockput(dp);
    8000555e:	8526                	mv	a0,s1
    80005560:	f76fe0ef          	jal	80003cd6 <iunlockput>
  return 0;
    80005564:	79a2                	ld	s3,40(sp)
    80005566:	bf31                	j	80005482 <create+0x62>
    return 0;
    80005568:	892a                	mv	s2,a0
    8000556a:	bf21                	j	80005482 <create+0x62>

000000008000556c <sys_dup>:
{
    8000556c:	7179                	addi	sp,sp,-48
    8000556e:	f406                	sd	ra,40(sp)
    80005570:	f022                	sd	s0,32(sp)
    80005572:	1800                	addi	s0,sp,48
  if (argfd(0, 0, &f) < 0)
    80005574:	fd840613          	addi	a2,s0,-40
    80005578:	4581                	li	a1,0
    8000557a:	4501                	li	a0,0
    8000557c:	e0bff0ef          	jal	80005386 <argfd>
    return -1;
    80005580:	57fd                	li	a5,-1
  if (argfd(0, 0, &f) < 0)
    80005582:	02054363          	bltz	a0,800055a8 <sys_dup+0x3c>
    80005586:	ec26                	sd	s1,24(sp)
    80005588:	e84a                	sd	s2,16(sp)
  if ((fd = fdalloc(f)) < 0)
    8000558a:	fd843483          	ld	s1,-40(s0)
    8000558e:	8526                	mv	a0,s1
    80005590:	e51ff0ef          	jal	800053e0 <fdalloc>
    80005594:	892a                	mv	s2,a0
    return -1;
    80005596:	57fd                	li	a5,-1
  if ((fd = fdalloc(f)) < 0)
    80005598:	00054d63          	bltz	a0,800055b2 <sys_dup+0x46>
  filedup(f);
    8000559c:	8526                	mv	a0,s1
    8000559e:	bc2ff0ef          	jal	80004960 <filedup>
  return fd;
    800055a2:	87ca                	mv	a5,s2
    800055a4:	64e2                	ld	s1,24(sp)
    800055a6:	6942                	ld	s2,16(sp)
}
    800055a8:	853e                	mv	a0,a5
    800055aa:	70a2                	ld	ra,40(sp)
    800055ac:	7402                	ld	s0,32(sp)
    800055ae:	6145                	addi	sp,sp,48
    800055b0:	8082                	ret
    800055b2:	64e2                	ld	s1,24(sp)
    800055b4:	6942                	ld	s2,16(sp)
    800055b6:	bfcd                	j	800055a8 <sys_dup+0x3c>

00000000800055b8 <sys_read>:
{
    800055b8:	7179                	addi	sp,sp,-48
    800055ba:	f406                	sd	ra,40(sp)
    800055bc:	f022                	sd	s0,32(sp)
    800055be:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800055c0:	fd840593          	addi	a1,s0,-40
    800055c4:	4505                	li	a0,1
    800055c6:	a2ffd0ef          	jal	80002ff4 <argaddr>
  argint(2, &n);
    800055ca:	fe440593          	addi	a1,s0,-28
    800055ce:	4509                	li	a0,2
    800055d0:	a09fd0ef          	jal	80002fd8 <argint>
  if (argfd(0, 0, &f) < 0)
    800055d4:	fe840613          	addi	a2,s0,-24
    800055d8:	4581                	li	a1,0
    800055da:	4501                	li	a0,0
    800055dc:	dabff0ef          	jal	80005386 <argfd>
    800055e0:	87aa                	mv	a5,a0
    return -1;
    800055e2:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    800055e4:	0007ca63          	bltz	a5,800055f8 <sys_read+0x40>
  return fileread(f, p, n);
    800055e8:	fe442603          	lw	a2,-28(s0)
    800055ec:	fd843583          	ld	a1,-40(s0)
    800055f0:	fe843503          	ld	a0,-24(s0)
    800055f4:	cdaff0ef          	jal	80004ace <fileread>
}
    800055f8:	70a2                	ld	ra,40(sp)
    800055fa:	7402                	ld	s0,32(sp)
    800055fc:	6145                	addi	sp,sp,48
    800055fe:	8082                	ret

0000000080005600 <sys_write>:
{
    80005600:	7179                	addi	sp,sp,-48
    80005602:	f406                	sd	ra,40(sp)
    80005604:	f022                	sd	s0,32(sp)
    80005606:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80005608:	fd840593          	addi	a1,s0,-40
    8000560c:	4505                	li	a0,1
    8000560e:	9e7fd0ef          	jal	80002ff4 <argaddr>
  argint(2, &n);
    80005612:	fe440593          	addi	a1,s0,-28
    80005616:	4509                	li	a0,2
    80005618:	9c1fd0ef          	jal	80002fd8 <argint>
  if (argfd(0, 0, &f) < 0)
    8000561c:	fe840613          	addi	a2,s0,-24
    80005620:	4581                	li	a1,0
    80005622:	4501                	li	a0,0
    80005624:	d63ff0ef          	jal	80005386 <argfd>
    80005628:	87aa                	mv	a5,a0
    return -1;
    8000562a:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    8000562c:	0007ca63          	bltz	a5,80005640 <sys_write+0x40>
  return filewrite(f, p, n);
    80005630:	fe442603          	lw	a2,-28(s0)
    80005634:	fd843583          	ld	a1,-40(s0)
    80005638:	fe843503          	ld	a0,-24(s0)
    8000563c:	d56ff0ef          	jal	80004b92 <filewrite>
}
    80005640:	70a2                	ld	ra,40(sp)
    80005642:	7402                	ld	s0,32(sp)
    80005644:	6145                	addi	sp,sp,48
    80005646:	8082                	ret

0000000080005648 <sys_close>:
{
    80005648:	1101                	addi	sp,sp,-32
    8000564a:	ec06                	sd	ra,24(sp)
    8000564c:	e822                	sd	s0,16(sp)
    8000564e:	1000                	addi	s0,sp,32
  if (argfd(0, &fd, &f) < 0)
    80005650:	fe040613          	addi	a2,s0,-32
    80005654:	fec40593          	addi	a1,s0,-20
    80005658:	4501                	li	a0,0
    8000565a:	d2dff0ef          	jal	80005386 <argfd>
    return -1;
    8000565e:	57fd                	li	a5,-1
  if (argfd(0, &fd, &f) < 0)
    80005660:	02054163          	bltz	a0,80005682 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80005664:	a90fc0ef          	jal	800018f4 <myproc>
    80005668:	fec42783          	lw	a5,-20(s0)
    8000566c:	078e                	slli	a5,a5,0x3
    8000566e:	0e078793          	addi	a5,a5,224
    80005672:	953e                	add	a0,a0,a5
    80005674:	00053423          	sd	zero,8(a0)
  fileclose(f);
    80005678:	fe043503          	ld	a0,-32(s0)
    8000567c:	b2aff0ef          	jal	800049a6 <fileclose>
  return 0;
    80005680:	4781                	li	a5,0
}
    80005682:	853e                	mv	a0,a5
    80005684:	60e2                	ld	ra,24(sp)
    80005686:	6442                	ld	s0,16(sp)
    80005688:	6105                	addi	sp,sp,32
    8000568a:	8082                	ret

000000008000568c <sys_fstat>:
{
    8000568c:	1101                	addi	sp,sp,-32
    8000568e:	ec06                	sd	ra,24(sp)
    80005690:	e822                	sd	s0,16(sp)
    80005692:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80005694:	fe040593          	addi	a1,s0,-32
    80005698:	4505                	li	a0,1
    8000569a:	95bfd0ef          	jal	80002ff4 <argaddr>
  if (argfd(0, 0, &f) < 0)
    8000569e:	fe840613          	addi	a2,s0,-24
    800056a2:	4581                	li	a1,0
    800056a4:	4501                	li	a0,0
    800056a6:	ce1ff0ef          	jal	80005386 <argfd>
    800056aa:	87aa                	mv	a5,a0
    return -1;
    800056ac:	557d                	li	a0,-1
  if (argfd(0, 0, &f) < 0)
    800056ae:	0007c863          	bltz	a5,800056be <sys_fstat+0x32>
  return filestat(f, st);
    800056b2:	fe043583          	ld	a1,-32(s0)
    800056b6:	fe843503          	ld	a0,-24(s0)
    800056ba:	baeff0ef          	jal	80004a68 <filestat>
}
    800056be:	60e2                	ld	ra,24(sp)
    800056c0:	6442                	ld	s0,16(sp)
    800056c2:	6105                	addi	sp,sp,32
    800056c4:	8082                	ret

00000000800056c6 <sys_link>:
{
    800056c6:	7169                	addi	sp,sp,-304
    800056c8:	f606                	sd	ra,296(sp)
    800056ca:	f222                	sd	s0,288(sp)
    800056cc:	1a00                	addi	s0,sp,304
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800056ce:	08000613          	li	a2,128
    800056d2:	ed040593          	addi	a1,s0,-304
    800056d6:	4501                	li	a0,0
    800056d8:	939fd0ef          	jal	80003010 <argstr>
    return -1;
    800056dc:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800056de:	0c054e63          	bltz	a0,800057ba <sys_link+0xf4>
    800056e2:	08000613          	li	a2,128
    800056e6:	f5040593          	addi	a1,s0,-176
    800056ea:	4505                	li	a0,1
    800056ec:	925fd0ef          	jal	80003010 <argstr>
    return -1;
    800056f0:	57fd                	li	a5,-1
  if (argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    800056f2:	0c054463          	bltz	a0,800057ba <sys_link+0xf4>
    800056f6:	ee26                	sd	s1,280(sp)
  begin_op();
    800056f8:	df5fe0ef          	jal	800044ec <begin_op>
  if ((ip = namei(old)) == 0) {
    800056fc:	ed040513          	addi	a0,s0,-304
    80005700:	c0ffe0ef          	jal	8000430e <namei>
    80005704:	84aa                	mv	s1,a0
    80005706:	c53d                	beqz	a0,80005774 <sys_link+0xae>
  ilock(ip);
    80005708:	bc2fe0ef          	jal	80003aca <ilock>
  if (ip->type == T_DIR) {
    8000570c:	04449703          	lh	a4,68(s1)
    80005710:	4785                	li	a5,1
    80005712:	06f70663          	beq	a4,a5,8000577e <sys_link+0xb8>
    80005716:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80005718:	04a4d783          	lhu	a5,74(s1)
    8000571c:	2785                	addiw	a5,a5,1
    8000571e:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005722:	8526                	mv	a0,s1
    80005724:	af2fe0ef          	jal	80003a16 <iupdate>
  iunlock(ip);
    80005728:	8526                	mv	a0,s1
    8000572a:	c4efe0ef          	jal	80003b78 <iunlock>
  if ((dp = nameiparent(new, name)) == 0)
    8000572e:	fd040593          	addi	a1,s0,-48
    80005732:	f5040513          	addi	a0,s0,-176
    80005736:	bf3fe0ef          	jal	80004328 <nameiparent>
    8000573a:	892a                	mv	s2,a0
    8000573c:	cd21                	beqz	a0,80005794 <sys_link+0xce>
  ilock(dp);
    8000573e:	b8cfe0ef          	jal	80003aca <ilock>
  if (dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0) {
    80005742:	854a                	mv	a0,s2
    80005744:	00092703          	lw	a4,0(s2)
    80005748:	409c                	lw	a5,0(s1)
    8000574a:	04f71263          	bne	a4,a5,8000578e <sys_link+0xc8>
    8000574e:	40d0                	lw	a2,4(s1)
    80005750:	fd040593          	addi	a1,s0,-48
    80005754:	b11fe0ef          	jal	80004264 <dirlink>
    80005758:	02054b63          	bltz	a0,8000578e <sys_link+0xc8>
  iunlockput(dp);
    8000575c:	854a                	mv	a0,s2
    8000575e:	d78fe0ef          	jal	80003cd6 <iunlockput>
  iput(ip);
    80005762:	8526                	mv	a0,s1
    80005764:	ce8fe0ef          	jal	80003c4c <iput>
  end_op();
    80005768:	e11fe0ef          	jal	80004578 <end_op>
  return 0;
    8000576c:	4781                	li	a5,0
    8000576e:	64f2                	ld	s1,280(sp)
    80005770:	6952                	ld	s2,272(sp)
    80005772:	a0a1                	j	800057ba <sys_link+0xf4>
    end_op();
    80005774:	e05fe0ef          	jal	80004578 <end_op>
    return -1;
    80005778:	57fd                	li	a5,-1
    8000577a:	64f2                	ld	s1,280(sp)
    8000577c:	a83d                	j	800057ba <sys_link+0xf4>
    iunlockput(ip);
    8000577e:	8526                	mv	a0,s1
    80005780:	d56fe0ef          	jal	80003cd6 <iunlockput>
    end_op();
    80005784:	df5fe0ef          	jal	80004578 <end_op>
    return -1;
    80005788:	57fd                	li	a5,-1
    8000578a:	64f2                	ld	s1,280(sp)
    8000578c:	a03d                	j	800057ba <sys_link+0xf4>
    iunlockput(dp);
    8000578e:	854a                	mv	a0,s2
    80005790:	d46fe0ef          	jal	80003cd6 <iunlockput>
  ilock(ip);
    80005794:	8526                	mv	a0,s1
    80005796:	b34fe0ef          	jal	80003aca <ilock>
  ip->nlink--;
    8000579a:	04a4d783          	lhu	a5,74(s1)
    8000579e:	37fd                	addiw	a5,a5,-1
    800057a0:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800057a4:	8526                	mv	a0,s1
    800057a6:	a70fe0ef          	jal	80003a16 <iupdate>
  iunlockput(ip);
    800057aa:	8526                	mv	a0,s1
    800057ac:	d2afe0ef          	jal	80003cd6 <iunlockput>
  end_op();
    800057b0:	dc9fe0ef          	jal	80004578 <end_op>
  return -1;
    800057b4:	57fd                	li	a5,-1
    800057b6:	64f2                	ld	s1,280(sp)
    800057b8:	6952                	ld	s2,272(sp)
}
    800057ba:	853e                	mv	a0,a5
    800057bc:	70b2                	ld	ra,296(sp)
    800057be:	7412                	ld	s0,288(sp)
    800057c0:	6155                	addi	sp,sp,304
    800057c2:	8082                	ret

00000000800057c4 <sys_unlink>:
{
    800057c4:	7151                	addi	sp,sp,-240
    800057c6:	f586                	sd	ra,232(sp)
    800057c8:	f1a2                	sd	s0,224(sp)
    800057ca:	1980                	addi	s0,sp,240
  if (argstr(0, path, MAXPATH) < 0)
    800057cc:	08000613          	li	a2,128
    800057d0:	f3040593          	addi	a1,s0,-208
    800057d4:	4501                	li	a0,0
    800057d6:	83bfd0ef          	jal	80003010 <argstr>
    800057da:	14054d63          	bltz	a0,80005934 <sys_unlink+0x170>
    800057de:	eda6                	sd	s1,216(sp)
  begin_op();
    800057e0:	d0dfe0ef          	jal	800044ec <begin_op>
  if ((dp = nameiparent(path, name)) == 0) {
    800057e4:	fb040593          	addi	a1,s0,-80
    800057e8:	f3040513          	addi	a0,s0,-208
    800057ec:	b3dfe0ef          	jal	80004328 <nameiparent>
    800057f0:	84aa                	mv	s1,a0
    800057f2:	c955                	beqz	a0,800058a6 <sys_unlink+0xe2>
  ilock(dp);
    800057f4:	ad6fe0ef          	jal	80003aca <ilock>
  if (namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    800057f8:	00003597          	auipc	a1,0x3
    800057fc:	e3858593          	addi	a1,a1,-456 # 80008630 <etext+0x630>
    80005800:	fb040513          	addi	a0,s0,-80
    80005804:	851fe0ef          	jal	80004054 <namecmp>
    80005808:	10050b63          	beqz	a0,8000591e <sys_unlink+0x15a>
    8000580c:	00003597          	auipc	a1,0x3
    80005810:	e2c58593          	addi	a1,a1,-468 # 80008638 <etext+0x638>
    80005814:	fb040513          	addi	a0,s0,-80
    80005818:	83dfe0ef          	jal	80004054 <namecmp>
    8000581c:	10050163          	beqz	a0,8000591e <sys_unlink+0x15a>
    80005820:	e9ca                	sd	s2,208(sp)
  if ((ip = dirlookup(dp, name, &off)) == 0)
    80005822:	f2c40613          	addi	a2,s0,-212
    80005826:	fb040593          	addi	a1,s0,-80
    8000582a:	8526                	mv	a0,s1
    8000582c:	83ffe0ef          	jal	8000406a <dirlookup>
    80005830:	892a                	mv	s2,a0
    80005832:	0e050563          	beqz	a0,8000591c <sys_unlink+0x158>
    80005836:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80005838:	a92fe0ef          	jal	80003aca <ilock>
  if (ip->nlink < 1)
    8000583c:	04a91783          	lh	a5,74(s2)
    80005840:	06f05863          	blez	a5,800058b0 <sys_unlink+0xec>
  if (ip->type == T_DIR && !isdirempty(ip)) {
    80005844:	04491703          	lh	a4,68(s2)
    80005848:	4785                	li	a5,1
    8000584a:	06f70963          	beq	a4,a5,800058bc <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    8000584e:	fc040993          	addi	s3,s0,-64
    80005852:	4641                	li	a2,16
    80005854:	4581                	li	a1,0
    80005856:	854e                	mv	a0,s3
    80005858:	c50fb0ef          	jal	80000ca8 <memset>
  if (writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000585c:	4741                	li	a4,16
    8000585e:	f2c42683          	lw	a3,-212(s0)
    80005862:	864e                	mv	a2,s3
    80005864:	4581                	li	a1,0
    80005866:	8526                	mv	a0,s1
    80005868:	ee6fe0ef          	jal	80003f4e <writei>
    8000586c:	47c1                	li	a5,16
    8000586e:	08f51863          	bne	a0,a5,800058fe <sys_unlink+0x13a>
  if (ip->type == T_DIR) {
    80005872:	04491703          	lh	a4,68(s2)
    80005876:	4785                	li	a5,1
    80005878:	08f70963          	beq	a4,a5,8000590a <sys_unlink+0x146>
  iunlockput(dp);
    8000587c:	8526                	mv	a0,s1
    8000587e:	c58fe0ef          	jal	80003cd6 <iunlockput>
  ip->nlink--;
    80005882:	04a95783          	lhu	a5,74(s2)
    80005886:	37fd                	addiw	a5,a5,-1
    80005888:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000588c:	854a                	mv	a0,s2
    8000588e:	988fe0ef          	jal	80003a16 <iupdate>
  iunlockput(ip);
    80005892:	854a                	mv	a0,s2
    80005894:	c42fe0ef          	jal	80003cd6 <iunlockput>
  end_op();
    80005898:	ce1fe0ef          	jal	80004578 <end_op>
  return 0;
    8000589c:	4501                	li	a0,0
    8000589e:	64ee                	ld	s1,216(sp)
    800058a0:	694e                	ld	s2,208(sp)
    800058a2:	69ae                	ld	s3,200(sp)
    800058a4:	a061                	j	8000592c <sys_unlink+0x168>
    end_op();
    800058a6:	cd3fe0ef          	jal	80004578 <end_op>
    return -1;
    800058aa:	557d                	li	a0,-1
    800058ac:	64ee                	ld	s1,216(sp)
    800058ae:	a8bd                	j	8000592c <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    800058b0:	00003517          	auipc	a0,0x3
    800058b4:	d9050513          	addi	a0,a0,-624 # 80008640 <etext+0x640>
    800058b8:	f7dfa0ef          	jal	80000834 <panic>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    800058bc:	04c92703          	lw	a4,76(s2)
    800058c0:	02000793          	li	a5,32
    800058c4:	f8e7f5e3          	bgeu	a5,a4,8000584e <sys_unlink+0x8a>
    800058c8:	89be                	mv	s3,a5
    if (readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800058ca:	4741                	li	a4,16
    800058cc:	86ce                	mv	a3,s3
    800058ce:	f1840613          	addi	a2,s0,-232
    800058d2:	4581                	li	a1,0
    800058d4:	854a                	mv	a0,s2
    800058d6:	d86fe0ef          	jal	80003e5c <readi>
    800058da:	47c1                	li	a5,16
    800058dc:	00f51b63          	bne	a0,a5,800058f2 <sys_unlink+0x12e>
    if (de.inum != 0)
    800058e0:	f1845783          	lhu	a5,-232(s0)
    800058e4:	ebb1                	bnez	a5,80005938 <sys_unlink+0x174>
  for (off = 2 * sizeof(de); off < dp->size; off += sizeof(de)) {
    800058e6:	29c1                	addiw	s3,s3,16
    800058e8:	04c92783          	lw	a5,76(s2)
    800058ec:	fcf9efe3          	bltu	s3,a5,800058ca <sys_unlink+0x106>
    800058f0:	bfb9                	j	8000584e <sys_unlink+0x8a>
      panic("isdirempty: readi");
    800058f2:	00003517          	auipc	a0,0x3
    800058f6:	d6650513          	addi	a0,a0,-666 # 80008658 <etext+0x658>
    800058fa:	f3bfa0ef          	jal	80000834 <panic>
    panic("unlink: writei");
    800058fe:	00003517          	auipc	a0,0x3
    80005902:	d7250513          	addi	a0,a0,-654 # 80008670 <etext+0x670>
    80005906:	f2ffa0ef          	jal	80000834 <panic>
    dp->nlink--;
    8000590a:	04a4d783          	lhu	a5,74(s1)
    8000590e:	37fd                	addiw	a5,a5,-1
    80005910:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80005914:	8526                	mv	a0,s1
    80005916:	900fe0ef          	jal	80003a16 <iupdate>
    8000591a:	b78d                	j	8000587c <sys_unlink+0xb8>
    8000591c:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    8000591e:	8526                	mv	a0,s1
    80005920:	bb6fe0ef          	jal	80003cd6 <iunlockput>
  end_op();
    80005924:	c55fe0ef          	jal	80004578 <end_op>
  return -1;
    80005928:	557d                	li	a0,-1
    8000592a:	64ee                	ld	s1,216(sp)
}
    8000592c:	70ae                	ld	ra,232(sp)
    8000592e:	740e                	ld	s0,224(sp)
    80005930:	616d                	addi	sp,sp,240
    80005932:	8082                	ret
    return -1;
    80005934:	557d                	li	a0,-1
    80005936:	bfdd                	j	8000592c <sys_unlink+0x168>
    iunlockput(ip);
    80005938:	854a                	mv	a0,s2
    8000593a:	b9cfe0ef          	jal	80003cd6 <iunlockput>
    goto bad;
    8000593e:	694e                	ld	s2,208(sp)
    80005940:	69ae                	ld	s3,200(sp)
    80005942:	bff1                	j	8000591e <sys_unlink+0x15a>

0000000080005944 <sys_open>:

uint64
sys_open(void)
{
    80005944:	7131                	addi	sp,sp,-192
    80005946:	fd06                	sd	ra,184(sp)
    80005948:	f922                	sd	s0,176(sp)
    8000594a:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    8000594c:	f4c40593          	addi	a1,s0,-180
    80005950:	4505                	li	a0,1
    80005952:	e86fd0ef          	jal	80002fd8 <argint>
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005956:	08000613          	li	a2,128
    8000595a:	f5040593          	addi	a1,s0,-176
    8000595e:	4501                	li	a0,0
    80005960:	eb0fd0ef          	jal	80003010 <argstr>
    80005964:	87aa                	mv	a5,a0
    return -1;
    80005966:	557d                	li	a0,-1
  if ((n = argstr(0, path, MAXPATH)) < 0)
    80005968:	0a07c363          	bltz	a5,80005a0e <sys_open+0xca>
    8000596c:	f526                	sd	s1,168(sp)

  begin_op();
    8000596e:	b7ffe0ef          	jal	800044ec <begin_op>

  if (omode & O_CREATE) {
    80005972:	f4c42783          	lw	a5,-180(s0)
    80005976:	2007f793          	andi	a5,a5,512
    8000597a:	c3dd                	beqz	a5,80005a20 <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    8000597c:	4681                	li	a3,0
    8000597e:	4601                	li	a2,0
    80005980:	4589                	li	a1,2
    80005982:	f5040513          	addi	a0,s0,-176
    80005986:	a9bff0ef          	jal	80005420 <create>
    8000598a:	84aa                	mv	s1,a0
    if (ip == 0) {
    8000598c:	c549                	beqz	a0,80005a16 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if (ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)) {
    8000598e:	04449703          	lh	a4,68(s1)
    80005992:	478d                	li	a5,3
    80005994:	00f71763          	bne	a4,a5,800059a2 <sys_open+0x5e>
    80005998:	0464d703          	lhu	a4,70(s1)
    8000599c:	47a5                	li	a5,9
    8000599e:	0ae7ee63          	bltu	a5,a4,80005a5a <sys_open+0x116>
    800059a2:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if ((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0) {
    800059a4:	f5ffe0ef          	jal	80004902 <filealloc>
    800059a8:	892a                	mv	s2,a0
    800059aa:	c561                	beqz	a0,80005a72 <sys_open+0x12e>
    800059ac:	ed4e                	sd	s3,152(sp)
    800059ae:	a33ff0ef          	jal	800053e0 <fdalloc>
    800059b2:	89aa                	mv	s3,a0
    800059b4:	0a054b63          	bltz	a0,80005a6a <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if (ip->type == T_DEVICE) {
    800059b8:	04449703          	lh	a4,68(s1)
    800059bc:	478d                	li	a5,3
    800059be:	0cf70363          	beq	a4,a5,80005a84 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    800059c2:	4789                	li	a5,2
    800059c4:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    800059c8:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    800059cc:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    800059d0:	f4c42783          	lw	a5,-180(s0)
    800059d4:	0017f713          	andi	a4,a5,1
    800059d8:	00174713          	xori	a4,a4,1
    800059dc:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    800059e0:	0037f713          	andi	a4,a5,3
    800059e4:	00e03733          	snez	a4,a4
    800059e8:	00e904a3          	sb	a4,9(s2)

  if ((omode & O_TRUNC) && ip->type == T_FILE) {
    800059ec:	4007f793          	andi	a5,a5,1024
    800059f0:	c791                	beqz	a5,800059fc <sys_open+0xb8>
    800059f2:	04449703          	lh	a4,68(s1)
    800059f6:	4789                	li	a5,2
    800059f8:	08f70d63          	beq	a4,a5,80005a92 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    800059fc:	8526                	mv	a0,s1
    800059fe:	97afe0ef          	jal	80003b78 <iunlock>
  end_op();
    80005a02:	b77fe0ef          	jal	80004578 <end_op>

  return fd;
    80005a06:	854e                	mv	a0,s3
    80005a08:	74aa                	ld	s1,168(sp)
    80005a0a:	790a                	ld	s2,160(sp)
    80005a0c:	69ea                	ld	s3,152(sp)
}
    80005a0e:	70ea                	ld	ra,184(sp)
    80005a10:	744a                	ld	s0,176(sp)
    80005a12:	6129                	addi	sp,sp,192
    80005a14:	8082                	ret
      end_op();
    80005a16:	b63fe0ef          	jal	80004578 <end_op>
      return -1;
    80005a1a:	557d                	li	a0,-1
    80005a1c:	74aa                	ld	s1,168(sp)
    80005a1e:	bfc5                	j	80005a0e <sys_open+0xca>
    if ((ip = namei(path)) == 0) {
    80005a20:	f5040513          	addi	a0,s0,-176
    80005a24:	8ebfe0ef          	jal	8000430e <namei>
    80005a28:	84aa                	mv	s1,a0
    80005a2a:	c11d                	beqz	a0,80005a50 <sys_open+0x10c>
    ilock(ip);
    80005a2c:	89efe0ef          	jal	80003aca <ilock>
    if (ip->type == T_DIR && omode != O_RDONLY) {
    80005a30:	04449703          	lh	a4,68(s1)
    80005a34:	4785                	li	a5,1
    80005a36:	f4f71ce3          	bne	a4,a5,8000598e <sys_open+0x4a>
    80005a3a:	f4c42783          	lw	a5,-180(s0)
    80005a3e:	d3b5                	beqz	a5,800059a2 <sys_open+0x5e>
      iunlockput(ip);
    80005a40:	8526                	mv	a0,s1
    80005a42:	a94fe0ef          	jal	80003cd6 <iunlockput>
      end_op();
    80005a46:	b33fe0ef          	jal	80004578 <end_op>
      return -1;
    80005a4a:	557d                	li	a0,-1
    80005a4c:	74aa                	ld	s1,168(sp)
    80005a4e:	b7c1                	j	80005a0e <sys_open+0xca>
      end_op();
    80005a50:	b29fe0ef          	jal	80004578 <end_op>
      return -1;
    80005a54:	557d                	li	a0,-1
    80005a56:	74aa                	ld	s1,168(sp)
    80005a58:	bf5d                	j	80005a0e <sys_open+0xca>
    iunlockput(ip);
    80005a5a:	8526                	mv	a0,s1
    80005a5c:	a7afe0ef          	jal	80003cd6 <iunlockput>
    end_op();
    80005a60:	b19fe0ef          	jal	80004578 <end_op>
    return -1;
    80005a64:	557d                	li	a0,-1
    80005a66:	74aa                	ld	s1,168(sp)
    80005a68:	b75d                	j	80005a0e <sys_open+0xca>
      fileclose(f);
    80005a6a:	854a                	mv	a0,s2
    80005a6c:	f3bfe0ef          	jal	800049a6 <fileclose>
    80005a70:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005a72:	8526                	mv	a0,s1
    80005a74:	a62fe0ef          	jal	80003cd6 <iunlockput>
    end_op();
    80005a78:	b01fe0ef          	jal	80004578 <end_op>
    return -1;
    80005a7c:	557d                	li	a0,-1
    80005a7e:	74aa                	ld	s1,168(sp)
    80005a80:	790a                	ld	s2,160(sp)
    80005a82:	b771                	j	80005a0e <sys_open+0xca>
    f->type = FD_DEVICE;
    80005a84:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    80005a88:	04649783          	lh	a5,70(s1)
    80005a8c:	02f91223          	sh	a5,36(s2)
    80005a90:	bf35                	j	800059cc <sys_open+0x88>
    itrunc(ip);
    80005a92:	8526                	mv	a0,s1
    80005a94:	924fe0ef          	jal	80003bb8 <itrunc>
    80005a98:	b795                	j	800059fc <sys_open+0xb8>

0000000080005a9a <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005a9a:	7175                	addi	sp,sp,-144
    80005a9c:	e506                	sd	ra,136(sp)
    80005a9e:	e122                	sd	s0,128(sp)
    80005aa0:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005aa2:	a4bfe0ef          	jal	800044ec <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0) {
    80005aa6:	08000613          	li	a2,128
    80005aaa:	f7040593          	addi	a1,s0,-144
    80005aae:	4501                	li	a0,0
    80005ab0:	d60fd0ef          	jal	80003010 <argstr>
    80005ab4:	02054363          	bltz	a0,80005ada <sys_mkdir+0x40>
    80005ab8:	4681                	li	a3,0
    80005aba:	4601                	li	a2,0
    80005abc:	4585                	li	a1,1
    80005abe:	f7040513          	addi	a0,s0,-144
    80005ac2:	95fff0ef          	jal	80005420 <create>
    80005ac6:	c911                	beqz	a0,80005ada <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005ac8:	a0efe0ef          	jal	80003cd6 <iunlockput>
  end_op();
    80005acc:	aadfe0ef          	jal	80004578 <end_op>
  return 0;
    80005ad0:	4501                	li	a0,0
}
    80005ad2:	60aa                	ld	ra,136(sp)
    80005ad4:	640a                	ld	s0,128(sp)
    80005ad6:	6149                	addi	sp,sp,144
    80005ad8:	8082                	ret
    end_op();
    80005ada:	a9ffe0ef          	jal	80004578 <end_op>
    return -1;
    80005ade:	557d                	li	a0,-1
    80005ae0:	bfcd                	j	80005ad2 <sys_mkdir+0x38>

0000000080005ae2 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005ae2:	7135                	addi	sp,sp,-160
    80005ae4:	ed06                	sd	ra,152(sp)
    80005ae6:	e922                	sd	s0,144(sp)
    80005ae8:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005aea:	a03fe0ef          	jal	800044ec <begin_op>
  argint(1, &major);
    80005aee:	f6c40593          	addi	a1,s0,-148
    80005af2:	4505                	li	a0,1
    80005af4:	ce4fd0ef          	jal	80002fd8 <argint>
  argint(2, &minor);
    80005af8:	f6840593          	addi	a1,s0,-152
    80005afc:	4509                	li	a0,2
    80005afe:	cdafd0ef          	jal	80002fd8 <argint>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    80005b02:	08000613          	li	a2,128
    80005b06:	f7040593          	addi	a1,s0,-144
    80005b0a:	4501                	li	a0,0
    80005b0c:	d04fd0ef          	jal	80003010 <argstr>
    80005b10:	02054563          	bltz	a0,80005b3a <sys_mknod+0x58>
      (ip = create(path, T_DEVICE, major, minor)) == 0) {
    80005b14:	f6841683          	lh	a3,-152(s0)
    80005b18:	f6c41603          	lh	a2,-148(s0)
    80005b1c:	458d                	li	a1,3
    80005b1e:	f7040513          	addi	a0,s0,-144
    80005b22:	8ffff0ef          	jal	80005420 <create>
  if ((argstr(0, path, MAXPATH)) < 0 ||
    80005b26:	c911                	beqz	a0,80005b3a <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005b28:	9aefe0ef          	jal	80003cd6 <iunlockput>
  end_op();
    80005b2c:	a4dfe0ef          	jal	80004578 <end_op>
  return 0;
    80005b30:	4501                	li	a0,0
}
    80005b32:	60ea                	ld	ra,152(sp)
    80005b34:	644a                	ld	s0,144(sp)
    80005b36:	610d                	addi	sp,sp,160
    80005b38:	8082                	ret
    end_op();
    80005b3a:	a3ffe0ef          	jal	80004578 <end_op>
    return -1;
    80005b3e:	557d                	li	a0,-1
    80005b40:	bfcd                	j	80005b32 <sys_mknod+0x50>

0000000080005b42 <sys_chdir>:

uint64
sys_chdir(void)
{
    80005b42:	7135                	addi	sp,sp,-160
    80005b44:	ed06                	sd	ra,152(sp)
    80005b46:	e922                	sd	s0,144(sp)
    80005b48:	e14a                	sd	s2,128(sp)
    80005b4a:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80005b4c:	da9fb0ef          	jal	800018f4 <myproc>
    80005b50:	892a                	mv	s2,a0

  begin_op();
    80005b52:	99bfe0ef          	jal	800044ec <begin_op>
  if (argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0) {
    80005b56:	08000613          	li	a2,128
    80005b5a:	f6040593          	addi	a1,s0,-160
    80005b5e:	4501                	li	a0,0
    80005b60:	cb0fd0ef          	jal	80003010 <argstr>
    80005b64:	04054363          	bltz	a0,80005baa <sys_chdir+0x68>
    80005b68:	e526                	sd	s1,136(sp)
    80005b6a:	f6040513          	addi	a0,s0,-160
    80005b6e:	fa0fe0ef          	jal	8000430e <namei>
    80005b72:	84aa                	mv	s1,a0
    80005b74:	c915                	beqz	a0,80005ba8 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005b76:	f55fd0ef          	jal	80003aca <ilock>
  if (ip->type != T_DIR) {
    80005b7a:	04449703          	lh	a4,68(s1)
    80005b7e:	4785                	li	a5,1
    80005b80:	02f71963          	bne	a4,a5,80005bb2 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005b84:	8526                	mv	a0,s1
    80005b86:	ff3fd0ef          	jal	80003b78 <iunlock>
  iput(p->cwd);
    80005b8a:	16893503          	ld	a0,360(s2)
    80005b8e:	8befe0ef          	jal	80003c4c <iput>
  end_op();
    80005b92:	9e7fe0ef          	jal	80004578 <end_op>
  p->cwd = ip;
    80005b96:	16993423          	sd	s1,360(s2)
  return 0;
    80005b9a:	4501                	li	a0,0
    80005b9c:	64aa                	ld	s1,136(sp)
}
    80005b9e:	60ea                	ld	ra,152(sp)
    80005ba0:	644a                	ld	s0,144(sp)
    80005ba2:	690a                	ld	s2,128(sp)
    80005ba4:	610d                	addi	sp,sp,160
    80005ba6:	8082                	ret
    80005ba8:	64aa                	ld	s1,136(sp)
    end_op();
    80005baa:	9cffe0ef          	jal	80004578 <end_op>
    return -1;
    80005bae:	557d                	li	a0,-1
    80005bb0:	b7fd                	j	80005b9e <sys_chdir+0x5c>
    iunlockput(ip);
    80005bb2:	8526                	mv	a0,s1
    80005bb4:	922fe0ef          	jal	80003cd6 <iunlockput>
    end_op();
    80005bb8:	9c1fe0ef          	jal	80004578 <end_op>
    return -1;
    80005bbc:	557d                	li	a0,-1
    80005bbe:	64aa                	ld	s1,136(sp)
    80005bc0:	bff9                	j	80005b9e <sys_chdir+0x5c>

0000000080005bc2 <sys_exec>:

uint64
sys_exec(void)
{
    80005bc2:	7105                	addi	sp,sp,-480
    80005bc4:	ef86                	sd	ra,472(sp)
    80005bc6:	eba2                	sd	s0,464(sp)
    80005bc8:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005bca:	e2840593          	addi	a1,s0,-472
    80005bce:	4505                	li	a0,1
    80005bd0:	c24fd0ef          	jal	80002ff4 <argaddr>
  if (argstr(0, path, MAXPATH) < 0) {
    80005bd4:	08000613          	li	a2,128
    80005bd8:	f3040593          	addi	a1,s0,-208
    80005bdc:	4501                	li	a0,0
    80005bde:	c32fd0ef          	jal	80003010 <argstr>
    80005be2:	87aa                	mv	a5,a0
    return -1;
    80005be4:	557d                	li	a0,-1
  if (argstr(0, path, MAXPATH) < 0) {
    80005be6:	0e07c063          	bltz	a5,80005cc6 <sys_exec+0x104>
    80005bea:	e7a6                	sd	s1,456(sp)
    80005bec:	e3ca                	sd	s2,448(sp)
    80005bee:	ff4e                	sd	s3,440(sp)
    80005bf0:	fb52                	sd	s4,432(sp)
    80005bf2:	f756                	sd	s5,424(sp)
    80005bf4:	f35a                	sd	s6,416(sp)
    80005bf6:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    80005bf8:	e3040a13          	addi	s4,s0,-464
    80005bfc:	10000613          	li	a2,256
    80005c00:	4581                	li	a1,0
    80005c02:	8552                	mv	a0,s4
    80005c04:	8a4fb0ef          	jal	80000ca8 <memset>
  for (i = 0;; i++) {
    if (i >= NELEM(argv)) {
    80005c08:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    80005c0a:	89d2                	mv	s3,s4
    80005c0c:	4901                	li	s2,0
      goto bad;
    }
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    80005c0e:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if (argv[i] == 0)
      goto bad;
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005c12:	6b05                	lui	s6,0x1
    if (i >= NELEM(argv)) {
    80005c14:	02000b93          	li	s7,32
    if (fetchaddr(uargv + sizeof(uint64) * i, (uint64 *)&uarg) < 0) {
    80005c18:	00391513          	slli	a0,s2,0x3
    80005c1c:	85d6                	mv	a1,s5
    80005c1e:	e2843783          	ld	a5,-472(s0)
    80005c22:	953e                	add	a0,a0,a5
    80005c24:	b28fd0ef          	jal	80002f4c <fetchaddr>
    80005c28:	02054663          	bltz	a0,80005c54 <sys_exec+0x92>
    if (uarg == 0) {
    80005c2c:	e2043783          	ld	a5,-480(s0)
    80005c30:	c7a1                	beqz	a5,80005c78 <sys_exec+0xb6>
    argv[i] = kalloc();
    80005c32:	eddfa0ef          	jal	80000b0e <kalloc>
    80005c36:	85aa                	mv	a1,a0
    80005c38:	00a9b023          	sd	a0,0(s3)
    if (argv[i] == 0)
    80005c3c:	cd01                	beqz	a0,80005c54 <sys_exec+0x92>
    if (fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005c3e:	865a                	mv	a2,s6
    80005c40:	e2043503          	ld	a0,-480(s0)
    80005c44:	b52fd0ef          	jal	80002f96 <fetchstr>
    80005c48:	00054663          	bltz	a0,80005c54 <sys_exec+0x92>
    if (i >= NELEM(argv)) {
    80005c4c:	0905                	addi	s2,s2,1
    80005c4e:	09a1                	addi	s3,s3,8
    80005c50:	fd7914e3          	bne	s2,s7,80005c18 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

bad:
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005c54:	100a0a13          	addi	s4,s4,256
    80005c58:	6088                	ld	a0,0(s1)
    80005c5a:	cd31                	beqz	a0,80005cb6 <sys_exec+0xf4>
    kfree(argv[i]);
    80005c5c:	dcbfa0ef          	jal	80000a26 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005c60:	04a1                	addi	s1,s1,8
    80005c62:	ff449be3          	bne	s1,s4,80005c58 <sys_exec+0x96>
  return -1;
    80005c66:	557d                	li	a0,-1
    80005c68:	64be                	ld	s1,456(sp)
    80005c6a:	691e                	ld	s2,448(sp)
    80005c6c:	79fa                	ld	s3,440(sp)
    80005c6e:	7a5a                	ld	s4,432(sp)
    80005c70:	7aba                	ld	s5,424(sp)
    80005c72:	7b1a                	ld	s6,416(sp)
    80005c74:	6bfa                	ld	s7,408(sp)
    80005c76:	a881                	j	80005cc6 <sys_exec+0x104>
      argv[i] = 0;
    80005c78:	0009079b          	sext.w	a5,s2
    80005c7c:	e3040593          	addi	a1,s0,-464
    80005c80:	078e                	slli	a5,a5,0x3
    80005c82:	97ae                	add	a5,a5,a1
    80005c84:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    80005c88:	f3040513          	addi	a0,s0,-208
    80005c8c:	ba0ff0ef          	jal	8000502c <kexec>
    80005c90:	892a                	mv	s2,a0
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005c92:	100a0a13          	addi	s4,s4,256
    80005c96:	6088                	ld	a0,0(s1)
    80005c98:	c511                	beqz	a0,80005ca4 <sys_exec+0xe2>
    kfree(argv[i]);
    80005c9a:	d8dfa0ef          	jal	80000a26 <kfree>
  for (i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005c9e:	04a1                	addi	s1,s1,8
    80005ca0:	ff449be3          	bne	s1,s4,80005c96 <sys_exec+0xd4>
  return ret;
    80005ca4:	854a                	mv	a0,s2
    80005ca6:	64be                	ld	s1,456(sp)
    80005ca8:	691e                	ld	s2,448(sp)
    80005caa:	79fa                	ld	s3,440(sp)
    80005cac:	7a5a                	ld	s4,432(sp)
    80005cae:	7aba                	ld	s5,424(sp)
    80005cb0:	7b1a                	ld	s6,416(sp)
    80005cb2:	6bfa                	ld	s7,408(sp)
    80005cb4:	a809                	j	80005cc6 <sys_exec+0x104>
  return -1;
    80005cb6:	557d                	li	a0,-1
    80005cb8:	64be                	ld	s1,456(sp)
    80005cba:	691e                	ld	s2,448(sp)
    80005cbc:	79fa                	ld	s3,440(sp)
    80005cbe:	7a5a                	ld	s4,432(sp)
    80005cc0:	7aba                	ld	s5,424(sp)
    80005cc2:	7b1a                	ld	s6,416(sp)
    80005cc4:	6bfa                	ld	s7,408(sp)
}
    80005cc6:	60fe                	ld	ra,472(sp)
    80005cc8:	645e                	ld	s0,464(sp)
    80005cca:	613d                	addi	sp,sp,480
    80005ccc:	8082                	ret

0000000080005cce <sys_pipe>:

uint64
sys_pipe(void)
{
    80005cce:	7139                	addi	sp,sp,-64
    80005cd0:	fc06                	sd	ra,56(sp)
    80005cd2:	f822                	sd	s0,48(sp)
    80005cd4:	f426                	sd	s1,40(sp)
    80005cd6:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005cd8:	c1dfb0ef          	jal	800018f4 <myproc>
    80005cdc:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005cde:	fd840593          	addi	a1,s0,-40
    80005ce2:	4501                	li	a0,0
    80005ce4:	b10fd0ef          	jal	80002ff4 <argaddr>
  if (pipealloc(&rf, &wf) < 0)
    80005ce8:	fc840593          	addi	a1,s0,-56
    80005cec:	fd040513          	addi	a0,s0,-48
    80005cf0:	fd7fe0ef          	jal	80004cc6 <pipealloc>
    return -1;
    80005cf4:	57fd                	li	a5,-1
  if (pipealloc(&rf, &wf) < 0)
    80005cf6:	0a054963          	bltz	a0,80005da8 <sys_pipe+0xda>
  fd0 = -1;
    80005cfa:	fcf42223          	sw	a5,-60(s0)
  if ((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0) {
    80005cfe:	fd043503          	ld	a0,-48(s0)
    80005d02:	edeff0ef          	jal	800053e0 <fdalloc>
    80005d06:	fca42223          	sw	a0,-60(s0)
    80005d0a:	08054663          	bltz	a0,80005d96 <sys_pipe+0xc8>
    80005d0e:	fc843503          	ld	a0,-56(s0)
    80005d12:	eceff0ef          	jal	800053e0 <fdalloc>
    80005d16:	fca42023          	sw	a0,-64(s0)
    80005d1a:	06054463          	bltz	a0,80005d82 <sys_pipe+0xb4>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80005d1e:	4711                	li	a4,4
    80005d20:	fc440693          	addi	a3,s0,-60
    80005d24:	fd843603          	ld	a2,-40(s0)
    80005d28:	70ac                	ld	a1,96(s1)
    80005d2a:	74a8                	ld	a0,104(s1)
    80005d2c:	81bfb0ef          	jal	80001546 <copyout>
    80005d30:	00054f63          	bltz	a0,80005d4e <sys_pipe+0x80>
      copyout(p->pagetable, p->sz, fdarray + sizeof(fd0), (char *)&fd1,
    80005d34:	4711                	li	a4,4
    80005d36:	fc040693          	addi	a3,s0,-64
    80005d3a:	fd843603          	ld	a2,-40(s0)
    80005d3e:	963a                	add	a2,a2,a4
    80005d40:	70ac                	ld	a1,96(s1)
    80005d42:	74a8                	ld	a0,104(s1)
    80005d44:	803fb0ef          	jal	80001546 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005d48:	4781                	li	a5,0
  if (copyout(p->pagetable, p->sz, fdarray, (char *)&fd0, sizeof(fd0)) < 0 ||
    80005d4a:	04055f63          	bgez	a0,80005da8 <sys_pipe+0xda>
    p->ofile[fd0] = 0;
    80005d4e:	fc442783          	lw	a5,-60(s0)
    80005d52:	078e                	slli	a5,a5,0x3
    80005d54:	0e078793          	addi	a5,a5,224
    80005d58:	97a6                	add	a5,a5,s1
    80005d5a:	0007b423          	sd	zero,8(a5)
    p->ofile[fd1] = 0;
    80005d5e:	fc042783          	lw	a5,-64(s0)
    80005d62:	078e                	slli	a5,a5,0x3
    80005d64:	0e078793          	addi	a5,a5,224
    80005d68:	94be                	add	s1,s1,a5
    80005d6a:	0004b423          	sd	zero,8(s1)
    fileclose(rf);
    80005d6e:	fd043503          	ld	a0,-48(s0)
    80005d72:	c35fe0ef          	jal	800049a6 <fileclose>
    fileclose(wf);
    80005d76:	fc843503          	ld	a0,-56(s0)
    80005d7a:	c2dfe0ef          	jal	800049a6 <fileclose>
    return -1;
    80005d7e:	57fd                	li	a5,-1
    80005d80:	a025                	j	80005da8 <sys_pipe+0xda>
    if (fd0 >= 0)
    80005d82:	fc442783          	lw	a5,-60(s0)
    80005d86:	0007c863          	bltz	a5,80005d96 <sys_pipe+0xc8>
      p->ofile[fd0] = 0;
    80005d8a:	078e                	slli	a5,a5,0x3
    80005d8c:	0e078793          	addi	a5,a5,224
    80005d90:	97a6                	add	a5,a5,s1
    80005d92:	0007b423          	sd	zero,8(a5)
    fileclose(rf);
    80005d96:	fd043503          	ld	a0,-48(s0)
    80005d9a:	c0dfe0ef          	jal	800049a6 <fileclose>
    fileclose(wf);
    80005d9e:	fc843503          	ld	a0,-56(s0)
    80005da2:	c05fe0ef          	jal	800049a6 <fileclose>
    return -1;
    80005da6:	57fd                	li	a5,-1
}
    80005da8:	853e                	mv	a0,a5
    80005daa:	70e2                	ld	ra,56(sp)
    80005dac:	7442                	ld	s0,48(sp)
    80005dae:	74a2                	ld	s1,40(sp)
    80005db0:	6121                	addi	sp,sp,64
    80005db2:	8082                	ret
	...

0000000080005dc0 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005dc0:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005dc2:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005dc4:	e80e                	sd	gp,16(sp)
        # sd tp, 24(sp)
        sd t0, 32(sp)
    80005dc6:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    80005dc8:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    80005dca:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    80005dcc:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005dce:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005dd0:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005dd2:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005dd4:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005dd6:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    80005dd8:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    80005dda:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    80005ddc:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005dde:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005de0:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005de2:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005de4:	876fd0ef          	jal	80002e5a <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    80005de8:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    80005dea:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    80005dec:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005dee:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005df0:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005df2:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005df4:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005df6:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    80005df8:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    80005dfa:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    80005dfc:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005dfe:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005e00:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005e02:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005e04:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005e06:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    80005e08:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    80005e0a:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    80005e0c:	10200073          	sret
    80005e10:	0001                	nop
    80005e12:	00000013          	nop
    80005e16:	00000013          	nop
    80005e1a:	00000013          	nop

0000000080005e1e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    80005e1e:	1141                	addi	sp,sp,-16
    80005e20:	e406                	sd	ra,8(sp)
    80005e22:	e022                	sd	s0,0(sp)
    80005e24:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32 *)(PLIC + UART0_IRQ * 4) = 1;
    80005e26:	0c000737          	lui	a4,0xc000
    80005e2a:	4785                	li	a5,1
    80005e2c:	d71c                	sw	a5,40(a4)
  *(uint32 *)(PLIC + VIRTIO0_IRQ * 4) = 1;
    80005e2e:	c35c                	sw	a5,4(a4)
}
    80005e30:	60a2                	ld	ra,8(sp)
    80005e32:	6402                	ld	s0,0(sp)
    80005e34:	0141                	addi	sp,sp,16
    80005e36:	8082                	ret

0000000080005e38 <plicinithart>:

void
plicinithart(void)
{
    80005e38:	1141                	addi	sp,sp,-16
    80005e3a:	e406                	sd	ra,8(sp)
    80005e3c:	e022                	sd	s0,0(sp)
    80005e3e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005e40:	a81fb0ef          	jal	800018c0 <cpuid>

  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32 *)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005e44:	0085171b          	slliw	a4,a0,0x8
    80005e48:	0c0027b7          	lui	a5,0xc002
    80005e4c:	97ba                	add	a5,a5,a4
    80005e4e:	40200713          	li	a4,1026
    80005e52:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32 *)PLIC_SPRIORITY(hart) = 0;
    80005e56:	00d5151b          	slliw	a0,a0,0xd
    80005e5a:	0c2017b7          	lui	a5,0xc201
    80005e5e:	97aa                	add	a5,a5,a0
    80005e60:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005e64:	60a2                	ld	ra,8(sp)
    80005e66:	6402                	ld	s0,0(sp)
    80005e68:	0141                	addi	sp,sp,16
    80005e6a:	8082                	ret

0000000080005e6c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    80005e6c:	1141                	addi	sp,sp,-16
    80005e6e:	e406                	sd	ra,8(sp)
    80005e70:	e022                	sd	s0,0(sp)
    80005e72:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005e74:	a4dfb0ef          	jal	800018c0 <cpuid>
  int irq = *(uint32 *)PLIC_SCLAIM(hart);
    80005e78:	00d5151b          	slliw	a0,a0,0xd
    80005e7c:	0c2017b7          	lui	a5,0xc201
    80005e80:	97aa                	add	a5,a5,a0
  return irq;
}
    80005e82:	43c8                	lw	a0,4(a5)
    80005e84:	60a2                	ld	ra,8(sp)
    80005e86:	6402                	ld	s0,0(sp)
    80005e88:	0141                	addi	sp,sp,16
    80005e8a:	8082                	ret

0000000080005e8c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005e8c:	1101                	addi	sp,sp,-32
    80005e8e:	ec06                	sd	ra,24(sp)
    80005e90:	e822                	sd	s0,16(sp)
    80005e92:	e426                	sd	s1,8(sp)
    80005e94:	1000                	addi	s0,sp,32
    80005e96:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005e98:	a29fb0ef          	jal	800018c0 <cpuid>
  *(uint32 *)PLIC_SCLAIM(hart) = irq;
    80005e9c:	00d5179b          	slliw	a5,a0,0xd
    80005ea0:	0c201737          	lui	a4,0xc201
    80005ea4:	97ba                	add	a5,a5,a4
    80005ea6:	c3c4                	sw	s1,4(a5)
}
    80005ea8:	60e2                	ld	ra,24(sp)
    80005eaa:	6442                	ld	s0,16(sp)
    80005eac:	64a2                	ld	s1,8(sp)
    80005eae:	6105                	addi	sp,sp,32
    80005eb0:	8082                	ret

0000000080005eb2 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005eb2:	1141                	addi	sp,sp,-16
    80005eb4:	e406                	sd	ra,8(sp)
    80005eb6:	e022                	sd	s0,0(sp)
    80005eb8:	0800                	addi	s0,sp,16
  if (i >= NUM)
    80005eba:	479d                	li	a5,7
    80005ebc:	04a7ca63          	blt	a5,a0,80005f10 <free_desc+0x5e>
    panic("free_desc 1");
  if (disk.free[i])
    80005ec0:	0001f797          	auipc	a5,0x1f
    80005ec4:	16878793          	addi	a5,a5,360 # 80025028 <disk>
    80005ec8:	97aa                	add	a5,a5,a0
    80005eca:	0187c783          	lbu	a5,24(a5)
    80005ece:	e7b9                	bnez	a5,80005f1c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005ed0:	00451693          	slli	a3,a0,0x4
    80005ed4:	0001f797          	auipc	a5,0x1f
    80005ed8:	15478793          	addi	a5,a5,340 # 80025028 <disk>
    80005edc:	6398                	ld	a4,0(a5)
    80005ede:	9736                	add	a4,a4,a3
    80005ee0:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80005ee4:	6398                	ld	a4,0(a5)
    80005ee6:	9736                	add	a4,a4,a3
    80005ee8:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005eec:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005ef0:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005ef4:	97aa                	add	a5,a5,a0
    80005ef6:	4705                	li	a4,1
    80005ef8:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005efc:	0001f517          	auipc	a0,0x1f
    80005f00:	14450513          	addi	a0,a0,324 # 80025040 <disk+0x18>
    80005f04:	be0fc0ef          	jal	800022e4 <wakeup>
}
    80005f08:	60a2                	ld	ra,8(sp)
    80005f0a:	6402                	ld	s0,0(sp)
    80005f0c:	0141                	addi	sp,sp,16
    80005f0e:	8082                	ret
    panic("free_desc 1");
    80005f10:	00002517          	auipc	a0,0x2
    80005f14:	77050513          	addi	a0,a0,1904 # 80008680 <etext+0x680>
    80005f18:	91dfa0ef          	jal	80000834 <panic>
    panic("free_desc 2");
    80005f1c:	00002517          	auipc	a0,0x2
    80005f20:	77450513          	addi	a0,a0,1908 # 80008690 <etext+0x690>
    80005f24:	911fa0ef          	jal	80000834 <panic>

0000000080005f28 <virtio_disk_init>:
{
    80005f28:	1101                	addi	sp,sp,-32
    80005f2a:	ec06                	sd	ra,24(sp)
    80005f2c:	e822                	sd	s0,16(sp)
    80005f2e:	e426                	sd	s1,8(sp)
    80005f30:	e04a                	sd	s2,0(sp)
    80005f32:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005f34:	00002597          	auipc	a1,0x2
    80005f38:	76c58593          	addi	a1,a1,1900 # 800086a0 <etext+0x6a0>
    80005f3c:	0001f517          	auipc	a0,0x1f
    80005f40:	21450513          	addi	a0,a0,532 # 80025150 <disk+0x128>
    80005f44:	c25fa0ef          	jal	80000b68 <initlock>
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005f48:	100017b7          	lui	a5,0x10001
    80005f4c:	4398                	lw	a4,0(a5)
    80005f4e:	2701                	sext.w	a4,a4
    80005f50:	747277b7          	lui	a5,0x74727
    80005f54:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005f58:	14f71863          	bne	a4,a5,800060a8 <virtio_disk_init+0x180>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005f5c:	100017b7          	lui	a5,0x10001
    80005f60:	43dc                	lw	a5,4(a5)
    80005f62:	2781                	sext.w	a5,a5
  if (*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005f64:	4709                	li	a4,2
    80005f66:	14e79163          	bne	a5,a4,800060a8 <virtio_disk_init+0x180>
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005f6a:	100017b7          	lui	a5,0x10001
    80005f6e:	479c                	lw	a5,8(a5)
    80005f70:	2781                	sext.w	a5,a5
    80005f72:	12e79b63          	bne	a5,a4,800060a8 <virtio_disk_init+0x180>
      *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551) {
    80005f76:	100017b7          	lui	a5,0x10001
    80005f7a:	47d8                	lw	a4,12(a5)
    80005f7c:	2701                	sext.w	a4,a4
      *R(VIRTIO_MMIO_VERSION) != 2 || *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005f7e:	554d47b7          	lui	a5,0x554d4
    80005f82:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005f86:	12f71163          	bne	a4,a5,800060a8 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f8a:	100017b7          	lui	a5,0x10001
    80005f8e:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f92:	4705                	li	a4,1
    80005f94:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f96:	470d                	li	a4,3
    80005f98:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005f9a:	10001737          	lui	a4,0x10001
    80005f9e:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005fa0:	c7ffe6b7          	lui	a3,0xc7ffe
    80005fa4:	55f68693          	addi	a3,a3,1375 # ffffffffc7ffe55f <end+0xffffffff47fd93f7>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005fa8:	8f75                	and	a4,a4,a3
    80005faa:	100016b7          	lui	a3,0x10001
    80005fae:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005fb0:	472d                	li	a4,11
    80005fb2:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005fb4:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005fb8:	439c                	lw	a5,0(a5)
    80005fba:	0007891b          	sext.w	s2,a5
  if (!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005fbe:	8ba1                	andi	a5,a5,8
    80005fc0:	0e078a63          	beqz	a5,800060b4 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005fc4:	100017b7          	lui	a5,0x10001
    80005fc8:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if (*R(VIRTIO_MMIO_QUEUE_READY))
    80005fcc:	43fc                	lw	a5,68(a5)
    80005fce:	2781                	sext.w	a5,a5
    80005fd0:	0e079863          	bnez	a5,800060c0 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005fd4:	100017b7          	lui	a5,0x10001
    80005fd8:	5bdc                	lw	a5,52(a5)
    80005fda:	2781                	sext.w	a5,a5
  if (max == 0)
    80005fdc:	0e078863          	beqz	a5,800060cc <virtio_disk_init+0x1a4>
  if (max < NUM)
    80005fe0:	471d                	li	a4,7
    80005fe2:	0ef77b63          	bgeu	a4,a5,800060d8 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80005fe6:	b29fa0ef          	jal	80000b0e <kalloc>
    80005fea:	0001f497          	auipc	s1,0x1f
    80005fee:	03e48493          	addi	s1,s1,62 # 80025028 <disk>
    80005ff2:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005ff4:	b1bfa0ef          	jal	80000b0e <kalloc>
    80005ff8:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80005ffa:	b15fa0ef          	jal	80000b0e <kalloc>
    80005ffe:	87aa                	mv	a5,a0
    80006000:	e888                	sd	a0,16(s1)
  if (!disk.desc || !disk.avail || !disk.used)
    80006002:	6088                	ld	a0,0(s1)
    80006004:	0e050063          	beqz	a0,800060e4 <virtio_disk_init+0x1bc>
    80006008:	0001f717          	auipc	a4,0x1f
    8000600c:	02873703          	ld	a4,40(a4) # 80025030 <disk+0x8>
    80006010:	cb71                	beqz	a4,800060e4 <virtio_disk_init+0x1bc>
    80006012:	cbe9                	beqz	a5,800060e4 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80006014:	6605                	lui	a2,0x1
    80006016:	4581                	li	a1,0
    80006018:	c91fa0ef          	jal	80000ca8 <memset>
  memset(disk.avail, 0, PGSIZE);
    8000601c:	0001f497          	auipc	s1,0x1f
    80006020:	00c48493          	addi	s1,s1,12 # 80025028 <disk>
    80006024:	6605                	lui	a2,0x1
    80006026:	4581                	li	a1,0
    80006028:	6488                	ld	a0,8(s1)
    8000602a:	c7ffa0ef          	jal	80000ca8 <memset>
  memset(disk.used, 0, PGSIZE);
    8000602e:	6605                	lui	a2,0x1
    80006030:	4581                	li	a1,0
    80006032:	6888                	ld	a0,16(s1)
    80006034:	c75fa0ef          	jal	80000ca8 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80006038:	100017b7          	lui	a5,0x10001
    8000603c:	4721                	li	a4,8
    8000603e:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    80006040:	4098                	lw	a4,0(s1)
    80006042:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80006046:	40d8                	lw	a4,4(s1)
    80006048:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    8000604c:	649c                	ld	a5,8(s1)
    8000604e:	0007869b          	sext.w	a3,a5
    80006052:	10001737          	lui	a4,0x10001
    80006056:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    8000605a:	9781                	srai	a5,a5,0x20
    8000605c:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80006060:	689c                	ld	a5,16(s1)
    80006062:	0007869b          	sext.w	a3,a5
    80006066:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000606a:	9781                	srai	a5,a5,0x20
    8000606c:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80006070:	4785                	li	a5,1
    80006072:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80006074:	00f48c23          	sb	a5,24(s1)
    80006078:	00f48ca3          	sb	a5,25(s1)
    8000607c:	00f48d23          	sb	a5,26(s1)
    80006080:	00f48da3          	sb	a5,27(s1)
    80006084:	00f48e23          	sb	a5,28(s1)
    80006088:	00f48ea3          	sb	a5,29(s1)
    8000608c:	00f48f23          	sb	a5,30(s1)
    80006090:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80006094:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80006098:	07272823          	sw	s2,112(a4)
}
    8000609c:	60e2                	ld	ra,24(sp)
    8000609e:	6442                	ld	s0,16(sp)
    800060a0:	64a2                	ld	s1,8(sp)
    800060a2:	6902                	ld	s2,0(sp)
    800060a4:	6105                	addi	sp,sp,32
    800060a6:	8082                	ret
    panic("could not find virtio disk");
    800060a8:	00002517          	auipc	a0,0x2
    800060ac:	60850513          	addi	a0,a0,1544 # 800086b0 <etext+0x6b0>
    800060b0:	f84fa0ef          	jal	80000834 <panic>
    panic("virtio disk FEATURES_OK unset");
    800060b4:	00002517          	auipc	a0,0x2
    800060b8:	61c50513          	addi	a0,a0,1564 # 800086d0 <etext+0x6d0>
    800060bc:	f78fa0ef          	jal	80000834 <panic>
    panic("virtio disk should not be ready");
    800060c0:	00002517          	auipc	a0,0x2
    800060c4:	63050513          	addi	a0,a0,1584 # 800086f0 <etext+0x6f0>
    800060c8:	f6cfa0ef          	jal	80000834 <panic>
    panic("virtio disk has no queue 0");
    800060cc:	00002517          	auipc	a0,0x2
    800060d0:	64450513          	addi	a0,a0,1604 # 80008710 <etext+0x710>
    800060d4:	f60fa0ef          	jal	80000834 <panic>
    panic("virtio disk max queue too short");
    800060d8:	00002517          	auipc	a0,0x2
    800060dc:	65850513          	addi	a0,a0,1624 # 80008730 <etext+0x730>
    800060e0:	f54fa0ef          	jal	80000834 <panic>
    panic("virtio disk kalloc");
    800060e4:	00002517          	auipc	a0,0x2
    800060e8:	66c50513          	addi	a0,a0,1644 # 80008750 <etext+0x750>
    800060ec:	f48fa0ef          	jal	80000834 <panic>

00000000800060f0 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800060f0:	711d                	addi	sp,sp,-96
    800060f2:	ec86                	sd	ra,88(sp)
    800060f4:	e8a2                	sd	s0,80(sp)
    800060f6:	e4a6                	sd	s1,72(sp)
    800060f8:	e0ca                	sd	s2,64(sp)
    800060fa:	fc4e                	sd	s3,56(sp)
    800060fc:	f852                	sd	s4,48(sp)
    800060fe:	f456                	sd	s5,40(sp)
    80006100:	f05a                	sd	s6,32(sp)
    80006102:	ec5e                	sd	s7,24(sp)
    80006104:	e862                	sd	s8,16(sp)
    80006106:	1080                	addi	s0,sp,96
    80006108:	89aa                	mv	s3,a0
    8000610a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    8000610c:	00c52b83          	lw	s7,12(a0)
    80006110:	001b9b9b          	slliw	s7,s7,0x1
    80006114:	1b82                	slli	s7,s7,0x20
    80006116:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    8000611a:	0001f517          	auipc	a0,0x1f
    8000611e:	03650513          	addi	a0,a0,54 # 80025150 <disk+0x128>
    80006122:	ac7fa0ef          	jal	80000be8 <acquire>
  for (int i = 0; i < NUM; i++) {
    80006126:	44a1                	li	s1,8
      disk.free[i] = 0;
    80006128:	0001fa97          	auipc	s5,0x1f
    8000612c:	f00a8a93          	addi	s5,s5,-256 # 80025028 <disk>
  for (int i = 0; i < 3; i++) {
    80006130:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80006132:	5c7d                	li	s8,-1
    80006134:	a8a5                	j	800061ac <virtio_disk_rw+0xbc>
      disk.free[i] = 0;
    80006136:	00fa8733          	add	a4,s5,a5
    8000613a:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    8000613e:	c19c                	sw	a5,0(a1)
    if (idx[i] < 0) {
    80006140:	0207c563          	bltz	a5,8000616a <virtio_disk_rw+0x7a>
  for (int i = 0; i < 3; i++) {
    80006144:	2905                	addiw	s2,s2,1
    80006146:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80006148:	07490663          	beq	s2,s4,800061b4 <virtio_disk_rw+0xc4>
    idx[i] = alloc_desc();
    8000614c:	85b2                	mv	a1,a2
  for (int i = 0; i < NUM; i++) {
    8000614e:	0001f717          	auipc	a4,0x1f
    80006152:	eda70713          	addi	a4,a4,-294 # 80025028 <disk>
    80006156:	4781                	li	a5,0
    if (disk.free[i]) {
    80006158:	01874683          	lbu	a3,24(a4)
    8000615c:	fee9                	bnez	a3,80006136 <virtio_disk_rw+0x46>
  for (int i = 0; i < NUM; i++) {
    8000615e:	2785                	addiw	a5,a5,1
    80006160:	0705                	addi	a4,a4,1
    80006162:	fe979be3          	bne	a5,s1,80006158 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80006166:	0185a023          	sw	s8,0(a1)
      for (int j = 0; j < i; j++)
    8000616a:	01205d63          	blez	s2,80006184 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    8000616e:	fa042503          	lw	a0,-96(s0)
    80006172:	d41ff0ef          	jal	80005eb2 <free_desc>
      for (int j = 0; j < i; j++)
    80006176:	4785                	li	a5,1
    80006178:	0127d663          	bge	a5,s2,80006184 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    8000617c:	fa442503          	lw	a0,-92(s0)
    80006180:	d33ff0ef          	jal	80005eb2 <free_desc>
  int idx[3];
  while (1) {
    if (alloc3_desc(idx) == 0) {
      break;
    }
    sleep_prepare(&disk.free[0]);
    80006184:	0001f517          	auipc	a0,0x1f
    80006188:	ebc50513          	addi	a0,a0,-324 # 80025040 <disk+0x18>
    8000618c:	8ecfc0ef          	jal	80002278 <sleep_prepare>
    release(&disk.vdisk_lock);
    80006190:	0001f517          	auipc	a0,0x1f
    80006194:	fc050513          	addi	a0,a0,-64 # 80025150 <disk+0x128>
    80006198:	ad9fa0ef          	jal	80000c70 <release>
    sleep();
    8000619c:	918fc0ef          	jal	800022b4 <sleep>
    acquire(&disk.vdisk_lock);
    800061a0:	0001f517          	auipc	a0,0x1f
    800061a4:	fb050513          	addi	a0,a0,-80 # 80025150 <disk+0x128>
    800061a8:	a41fa0ef          	jal	80000be8 <acquire>
  for (int i = 0; i < 3; i++) {
    800061ac:	fa040613          	addi	a2,s0,-96
    800061b0:	4901                	li	s2,0
    800061b2:	bf69                	j	8000614c <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800061b4:	fa042503          	lw	a0,-96(s0)
    800061b8:	00451693          	slli	a3,a0,0x4

  if (write)
    800061bc:	0001f797          	auipc	a5,0x1f
    800061c0:	e6c78793          	addi	a5,a5,-404 # 80025028 <disk>
    800061c4:	00451713          	slli	a4,a0,0x4
    800061c8:	0a070713          	addi	a4,a4,160
    800061cc:	973e                	add	a4,a4,a5
    800061ce:	01603633          	snez	a2,s6
    800061d2:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    800061d4:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    800061d8:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64)buf0;
    800061dc:	6398                	ld	a4,0(a5)
    800061de:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800061e0:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    800061e4:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64)buf0;
    800061e6:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    800061e8:	6390                	ld	a2,0(a5)
    800061ea:	00d60833          	add	a6,a2,a3
    800061ee:	4741                	li	a4,16
    800061f0:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800061f4:	4585                	li	a1,1
    800061f6:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    800061fa:	fa442703          	lw	a4,-92(s0)
    800061fe:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64)b->data;
    80006202:	0712                	slli	a4,a4,0x4
    80006204:	963a                	add	a2,a2,a4
    80006206:	05898813          	addi	a6,s3,88
    8000620a:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    8000620e:	0007b883          	ld	a7,0(a5)
    80006212:	9746                	add	a4,a4,a7
    80006214:	40000613          	li	a2,1024
    80006218:	c710                	sw	a2,8(a4)
  if (write)
    8000621a:	001b3613          	seqz	a2,s6
    8000621e:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    80006222:	8e4d                	or	a2,a2,a1
    80006224:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80006228:	fa842603          	lw	a2,-88(s0)
    8000622c:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    80006230:	00451813          	slli	a6,a0,0x4
    80006234:	02080813          	addi	a6,a6,32
    80006238:	983e                	add	a6,a6,a5
    8000623a:	577d                	li	a4,-1
    8000623c:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64)&disk.info[idx[0]].status;
    80006240:	0612                	slli	a2,a2,0x4
    80006242:	98b2                	add	a7,a7,a2
    80006244:	03068713          	addi	a4,a3,48
    80006248:	973e                	add	a4,a4,a5
    8000624a:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    8000624e:	6398                	ld	a4,0(a5)
    80006250:	9732                	add	a4,a4,a2
    80006252:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80006254:	4689                	li	a3,2
    80006256:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    8000625a:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000625e:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    80006262:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80006266:	6794                	ld	a3,8(a5)
    80006268:	0026d703          	lhu	a4,2(a3)
    8000626c:	8b1d                	andi	a4,a4,7
    8000626e:	0706                	slli	a4,a4,0x1
    80006270:	96ba                	add	a3,a3,a4
    80006272:	00a69223          	sh	a0,4(a3)

// fence for memory-mapped IO
static inline void
io_fence()
{
  asm volatile("fence iorw, iorw" ::: "memory");
    80006276:	0ff0000f          	fence

  io_fence();

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    8000627a:	6798                	ld	a4,8(a5)
    8000627c:	00275783          	lhu	a5,2(a4)
    80006280:	2785                	addiw	a5,a5,1
    80006282:	00f71123          	sh	a5,2(a4)
    80006286:	0ff0000f          	fence

  io_fence();

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    8000628a:	100017b7          	lui	a5,0x10001
    8000628e:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while (b->disk == 1) {
    80006292:	0049a783          	lw	a5,4(s3)
    sleep_prepare(b);
    release(&disk.vdisk_lock);
    80006296:	0001f497          	auipc	s1,0x1f
    8000629a:	eba48493          	addi	s1,s1,-326 # 80025150 <disk+0x128>
  while (b->disk == 1) {
    8000629e:	892e                	mv	s2,a1
    800062a0:	02b79163          	bne	a5,a1,800062c2 <virtio_disk_rw+0x1d2>
    sleep_prepare(b);
    800062a4:	854e                	mv	a0,s3
    800062a6:	fd3fb0ef          	jal	80002278 <sleep_prepare>
    release(&disk.vdisk_lock);
    800062aa:	8526                	mv	a0,s1
    800062ac:	9c5fa0ef          	jal	80000c70 <release>
    sleep();
    800062b0:	804fc0ef          	jal	800022b4 <sleep>
    acquire(&disk.vdisk_lock);
    800062b4:	8526                	mv	a0,s1
    800062b6:	933fa0ef          	jal	80000be8 <acquire>
  while (b->disk == 1) {
    800062ba:	0049a783          	lw	a5,4(s3)
    800062be:	ff2783e3          	beq	a5,s2,800062a4 <virtio_disk_rw+0x1b4>
  }

  disk.info[idx[0]].b = 0;
    800062c2:	fa042903          	lw	s2,-96(s0)
    800062c6:	00491713          	slli	a4,s2,0x4
    800062ca:	02070713          	addi	a4,a4,32
    800062ce:	0001f797          	auipc	a5,0x1f
    800062d2:	d5a78793          	addi	a5,a5,-678 # 80025028 <disk>
    800062d6:	97ba                	add	a5,a5,a4
    800062d8:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800062dc:	0001f997          	auipc	s3,0x1f
    800062e0:	d4c98993          	addi	s3,s3,-692 # 80025028 <disk>
    800062e4:	00491713          	slli	a4,s2,0x4
    800062e8:	0009b783          	ld	a5,0(s3)
    800062ec:	97ba                	add	a5,a5,a4
    800062ee:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    800062f2:	854a                	mv	a0,s2
    800062f4:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    800062f8:	bbbff0ef          	jal	80005eb2 <free_desc>
    if (flag & VRING_DESC_F_NEXT)
    800062fc:	8885                	andi	s1,s1,1
    800062fe:	f0fd                	bnez	s1,800062e4 <virtio_disk_rw+0x1f4>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    80006300:	0001f517          	auipc	a0,0x1f
    80006304:	e5050513          	addi	a0,a0,-432 # 80025150 <disk+0x128>
    80006308:	969fa0ef          	jal	80000c70 <release>
}
    8000630c:	60e6                	ld	ra,88(sp)
    8000630e:	6446                	ld	s0,80(sp)
    80006310:	64a6                	ld	s1,72(sp)
    80006312:	6906                	ld	s2,64(sp)
    80006314:	79e2                	ld	s3,56(sp)
    80006316:	7a42                	ld	s4,48(sp)
    80006318:	7aa2                	ld	s5,40(sp)
    8000631a:	7b02                	ld	s6,32(sp)
    8000631c:	6be2                	ld	s7,24(sp)
    8000631e:	6c42                	ld	s8,16(sp)
    80006320:	6125                	addi	sp,sp,96
    80006322:	8082                	ret

0000000080006324 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80006324:	1101                	addi	sp,sp,-32
    80006326:	ec06                	sd	ra,24(sp)
    80006328:	e822                	sd	s0,16(sp)
    8000632a:	e426                	sd	s1,8(sp)
    8000632c:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    8000632e:	0001f497          	auipc	s1,0x1f
    80006332:	cfa48493          	addi	s1,s1,-774 # 80025028 <disk>
    80006336:	0001f517          	auipc	a0,0x1f
    8000633a:	e1a50513          	addi	a0,a0,-486 # 80025150 <disk+0x128>
    8000633e:	8abfa0ef          	jal	80000be8 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    80006342:	100017b7          	lui	a5,0x10001
    80006346:	53bc                	lw	a5,96(a5)
    80006348:	8b8d                	andi	a5,a5,3
    8000634a:	10001737          	lui	a4,0x10001
    8000634e:	d37c                	sw	a5,100(a4)
    80006350:	0ff0000f          	fence
  io_fence();

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while (disk.used_idx != disk.used->idx) {
    80006354:	689c                	ld	a5,16(s1)
    80006356:	0204d703          	lhu	a4,32(s1)
    8000635a:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    8000635e:	04f70863          	beq	a4,a5,800063ae <virtio_disk_intr+0x8a>
    80006362:	0ff0000f          	fence
    io_fence();
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80006366:	6898                	ld	a4,16(s1)
    80006368:	0204d783          	lhu	a5,32(s1)
    8000636c:	8b9d                	andi	a5,a5,7
    8000636e:	078e                	slli	a5,a5,0x3
    80006370:	97ba                	add	a5,a5,a4
    80006372:	43dc                	lw	a5,4(a5)

    if (disk.info[id].status != 0)
    80006374:	00479713          	slli	a4,a5,0x4
    80006378:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    8000637c:	9726                	add	a4,a4,s1
    8000637e:	01074703          	lbu	a4,16(a4)
    80006382:	e329                	bnez	a4,800063c4 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80006384:	0792                	slli	a5,a5,0x4
    80006386:	02078793          	addi	a5,a5,32
    8000638a:	97a6                	add	a5,a5,s1
    8000638c:	6788                	ld	a0,8(a5)
    b->disk = 0; // disk is done with buf
    8000638e:	00052223          	sw	zero,4(a0)
    wakeup(b);
    80006392:	f53fb0ef          	jal	800022e4 <wakeup>

    disk.used_idx += 1;
    80006396:	0204d783          	lhu	a5,32(s1)
    8000639a:	2785                	addiw	a5,a5,1
    8000639c:	17c2                	slli	a5,a5,0x30
    8000639e:	93c1                	srli	a5,a5,0x30
    800063a0:	02f49023          	sh	a5,32(s1)
  while (disk.used_idx != disk.used->idx) {
    800063a4:	6898                	ld	a4,16(s1)
    800063a6:	00275703          	lhu	a4,2(a4)
    800063aa:	faf71ce3          	bne	a4,a5,80006362 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    800063ae:	0001f517          	auipc	a0,0x1f
    800063b2:	da250513          	addi	a0,a0,-606 # 80025150 <disk+0x128>
    800063b6:	8bbfa0ef          	jal	80000c70 <release>
}
    800063ba:	60e2                	ld	ra,24(sp)
    800063bc:	6442                	ld	s0,16(sp)
    800063be:	64a2                	ld	s1,8(sp)
    800063c0:	6105                	addi	sp,sp,32
    800063c2:	8082                	ret
      panic("virtio_disk_intr status");
    800063c4:	00002517          	auipc	a0,0x2
    800063c8:	3a450513          	addi	a0,a0,932 # 80008768 <etext+0x768>
    800063cc:	c68fa0ef          	jal	80000834 <panic>
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0)
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	9282                	jalr	t0

000000008000709c <userret>:
    8000709c:	0000100f          	fence.i
    800070a0:	12000073          	sfence.vma
    800070a4:	18051073          	csrw	satp,a0
    800070a8:	12000073          	sfence.vma
    800070ac:	02000537          	lui	a0,0x2000
    800070b0:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800070b2:	0536                	slli	a0,a0,0xd
    800070b4:	02853083          	ld	ra,40(a0)
    800070b8:	03053103          	ld	sp,48(a0)
    800070bc:	03853183          	ld	gp,56(a0)
    800070c0:	04053203          	ld	tp,64(a0)
    800070c4:	04853283          	ld	t0,72(a0)
    800070c8:	05053303          	ld	t1,80(a0)
    800070cc:	05853383          	ld	t2,88(a0)
    800070d0:	7120                	ld	s0,96(a0)
    800070d2:	7524                	ld	s1,104(a0)
    800070d4:	7d2c                	ld	a1,120(a0)
    800070d6:	6150                	ld	a2,128(a0)
    800070d8:	6554                	ld	a3,136(a0)
    800070da:	6958                	ld	a4,144(a0)
    800070dc:	6d5c                	ld	a5,152(a0)
    800070de:	0a053803          	ld	a6,160(a0)
    800070e2:	0a853883          	ld	a7,168(a0)
    800070e6:	0b053903          	ld	s2,176(a0)
    800070ea:	0b853983          	ld	s3,184(a0)
    800070ee:	0c053a03          	ld	s4,192(a0)
    800070f2:	0c853a83          	ld	s5,200(a0)
    800070f6:	0d053b03          	ld	s6,208(a0)
    800070fa:	0d853b83          	ld	s7,216(a0)
    800070fe:	0e053c03          	ld	s8,224(a0)
    80007102:	0e853c83          	ld	s9,232(a0)
    80007106:	0f053d03          	ld	s10,240(a0)
    8000710a:	0f853d83          	ld	s11,248(a0)
    8000710e:	10053e03          	ld	t3,256(a0)
    80007112:	10853e83          	ld	t4,264(a0)
    80007116:	11053f03          	ld	t5,272(a0)
    8000711a:	11853f83          	ld	t6,280(a0)
    8000711e:	7928                	ld	a0,112(a0)
    80007120:	10200073          	sret
	...
