#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
  printf("semtest: starting\n");

  if (sem_init(0, 1) < 0) {
    printf("semtest: init failed\n");
    exit(1);
  }

  if (sem_wait(0) < 0) {
    printf("semtest: wait failed\n");
    exit(1);
  }

  printf("semtest: wait passed\n");

  if (sem_signal(0) < 0) {
    printf("semtest: signal failed\n");
    exit(1);
  }

  printf("semtest: PASS\n");
  exit(0);
}
