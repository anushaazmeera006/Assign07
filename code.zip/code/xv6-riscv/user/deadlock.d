user/deadlock.o: user/deadlock.c kernel/types.h kernel/stat.h user/user.h
