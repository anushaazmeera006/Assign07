
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define N 5
#define M 3

int allocation[N][M] = {
  {0, 1, 0},
  {2, 0, 0},
  {3, 0, 2},
  {2, 1, 1},
  {0, 0, 2}
};

int maximum[N][M] = {
  {7, 5, 3},
  {3, 2, 2},
  {9, 0, 2},
  {2, 2, 2},
  {4, 3, 3}
};

int available[M] = {3, 3, 2};

int need[N][M];
int finish[N];

void print_vector(char *name, int v[M])
{
  int j;
  printf("%s: ", name);
  for(j = 0; j < M; j++)
    printf("%d ", v[j]);
  printf("\n");
}

void calculate_need(void)
{
  int i, j;
  for(i = 0; i < N; i++)
    for(j = 0; j < M; j++)
      need[i][j] = maximum[i][j] - allocation[i][j];
}

int less_equal(int a[M], int b[M])
{
  int j;
  for(j = 0; j < M; j++)
    if(a[j] > b[j])
      return 0;
  return 1;
}

void print_matrices(void)
{
  int i;
  printf("Process  Allocation    Need\n");
  for(i = 0; i < N; i++)
    printf("P%d       %d %d %d       %d %d %d\n",
           i,
           allocation[i][0], allocation[i][1], allocation[i][2],
           need[i][0], need[i][1], need[i][2]);
  print_vector("Available", available);
}

int safe_state(void)
{
  int work[M];
  int done[N];
  int i, j, found, count = 0;

  for(j = 0; j < M; j++)
    work[j] = available[j];
  for(i = 0; i < N; i++)
    done[i] = 0;

  while(count < N) {
    found = 0;
    for(i = 0; i < N; i++) {
      if(!done[i] && less_equal(need[i], work)) {
        for(j = 0; j < M; j++)
          work[j] += allocation[i][j];
        done[i] = 1;
        count++;
        found = 1;
        printf("P%d can finish; Work = %d %d %d\n",
               i, work[0], work[1], work[2]);
      }
    }
    if(!found)
      break;
  }

  if(count == N) {
    printf("SAFE state. Safe sequence exists.\n");
    return 1;
  }

  printf("UNSAFE state. No safe sequence found.\n");
  return 0;
}

int detect_deadlock(int alloc[N][M],
                    int request[N][M],
                    int avail[M])
{
  int work[M];
  int done[N];
  int i, j, found, deadlocked = 0;

  for(j = 0; j < M; j++)
    work[j] = avail[j];

  for(i = 0; i < N; i++) {
    done[i] = 1;
    for(j = 0; j < M; j++)
      if(alloc[i][j] != 0)
        done[i] = 0;
  }

  while(1) {
    found = 0;
    for(i = 0; i < N; i++) {
      if(!done[i] && less_equal(request[i], work)) {
        for(j = 0; j < M; j++)
          work[j] += alloc[i][j];
        done[i] = 1;
        found = 1;
        printf("Detection: P%d can finish\n", i);
      }
    }
    if(!found)
      break;
  }

  printf("Processes still unfinished: ");
  for(i = 0; i < N; i++) {
    if(!done[i]) {
      printf("P%d ", i);
      deadlocked = 1;
    }
  }
  printf("\n");

  if(deadlocked)
    printf("DEADLOCK detected.\n");
  else
    printf("No deadlock detected.\n");

  return deadlocked;
}
void unsafe_request_test(void)
{
  int alloc[3][3] = {
    {1, 0, 0},
    {0, 1, 0},
    {0, 0, 1}
  };
  int max[3][3] = {
    {2, 1, 0},
    {0, 2, 1},
    {1, 0, 2}
  };
  int avail[3] = {0, 0, 0};
  int req[3] = {1, 0, 0};
  int need3[3][3];
  int work[3], finish[3] = {0, 0, 0};
  int i, j, found, count = 0;

  printf("Testing request by P0: 1 0 0\n");

  for(i = 0; i < 3; i++) {
    work[i] = avail[i];
    for(j = 0; j < 3; j++)
      need3[i][j] = max[i][j] - alloc[i][j];
  }

  for(j = 0; j < 3; j++) {
    avail[j] -= req[j];
    alloc[0][j] += req[j];
    need3[0][j] -= req[j];
  }

  for(j = 0; j < 3; j++)
    work[j] = avail[j];

  while(1) {
    found = 0;
    for(i = 0; i < 3; i++) {
      if(!finish[i] &&
         need3[i][0] <= work[0] &&
         need3[i][1] <= work[1] &&
         need3[i][2] <= work[2]) {
        for(j = 0; j < 3; j++)
          work[j] += alloc[i][j];
        finish[i] = 1;
        count++;
        found = 1;
      }
    }
    if(!found)
      break;
  }

  if(count == 3)
    printf("Request keeps state SAFE.\n");
  else
    printf("Request makes state UNSAFE; deny request.\n");
}


void pipe_deadlock_demo(void)
{
  int p1[2], p2[2];
  int pidA, pidB;
  char c = 'X';

  printf("\n=== Actual Process Deadlock Demo ===\n");

  if(pipe(p1) < 0 || pipe(p2) < 0) {
    printf("Pipe creation failed\n");
    return;
  }

  pidA = fork();
  if(pidA < 0) {
    printf("Fork A failed\n");
    close(p1[0]); close(p1[1]);
    close(p2[0]); close(p2[1]);
    return;
  }

  if(pidA == 0) {
    close(p1[0]);
    close(p2[1]);
    printf("Child A: waiting to read from Pipe2\n");
    read(p2[0], &c, 1);
    close(p2[0]);
    close(p1[1]);
    exit(0);
  }

  pidB = fork();
  if(pidB < 0) {
    printf("Fork B failed\n");
    kill(pidA);
    close(p1[0]); close(p1[1]);
    close(p2[0]); close(p2[1]);
    wait(0);
    return;
  }

  if(pidB == 0) {
    close(p1[1]);
    close(p2[0]);
    printf("Child B: waiting to read from Pipe1\n");
    read(p1[0], &c, 1);
    close(p1[0]);
    close(p2[1]);
    exit(0);
  }

  close(p1[0]);
  close(p1[1]);
  close(p2[0]);
  close(p2[1]);

  for(volatile int i = 0; i < 10000000; i++)
  ;
  printf("Parent: circular wait detected; stopping children\n");

  kill(pidA);
  kill(pidB);
  wait(0);
  wait(0);

  printf("Actual-process deadlock demo completed.\n");
}

int main(void)
{
  
  int deadlock_request[N][M] = {
    {1, 0, 0},
    {0, 1, 0},
    {0, 0, 1},
    {0, 0, 0},
    {0, 0, 0}
  };
  int deadlock_alloc[N][M] = {
    {1, 0, 0},
    {0, 1, 0},
    {0, 0, 1},
    {0, 0, 0},
    {0, 0, 0}
  };
  int deadlock_avail[M] = {0, 0, 0};

  printf("\n=== Q3: Deadlock Detection and Avoidance ===\n");

  calculate_need();
  print_matrices();

  printf("\n=== Test 1: Banker's Safe-State Test ===\n");
  safe_state();

  printf("\n=== Test 2: Deadlock Detection ===\n");
  detect_deadlock(deadlock_alloc, deadlock_request, deadlock_avail);

  printf("\n=== Test 3: Unsafe Request ===\n");
  unsafe_request_test();
  pipe_deadlock_demo();
  printf("\nQ3 matrix tests completed.\n");
  exit(0);
}

